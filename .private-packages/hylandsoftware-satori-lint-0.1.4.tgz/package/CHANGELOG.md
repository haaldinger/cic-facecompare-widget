## 0.1.4 (2026-02-03)

### 🚀 Features

- **satori-lint:** DS-1302 eslint autofix material icons ([#1344](https://github.com/HylandSoftware/satori/pull/1344))
- DS-1350 use variable font and semibold as prominent ([#1333](https://github.com/HylandSoftware/satori/pull/1333))

### ❤️ Thank You

- Yvain Liechti @ryuran

## 0.1.3 (2025-12-15)

This was a version bump only for satori-lint to align it with other projects, there were no code changes.

## 0.1.2 (2025-11-19)

This was a version bump only for satori-lint to align it with other projects, there were no code changes.

## 0.1.1 (2025-11-17)

### 🚀 Features

- DS-1015 Styling Hygiene checking ([#1025](https://github.com/HylandSoftware/satori/pull/1025))
- DS-1015 Componentry checking ([#1007](https://github.com/HylandSoftware/satori/pull/1007))
- DS-1014 Design language checking ([#1005](https://github.com/HylandSoftware/satori/pull/1005))
- DS-1056 Fixing wrongly exposed artefacts in the linter bundle ([#984](https://github.com/HylandSoftware/satori/pull/984))
- DS-1056 Documenting StyleLint rules ([#982](https://github.com/HylandSoftware/satori/pull/982))
- DS-1056 Documenting ESLint rules ([#981](https://github.com/HylandSoftware/satori/pull/981))
- DS-1057 Exposing recommended config for adoption linters ([#977](https://github.com/HylandSoftware/satori/pull/977))
- DS-1010 No MDS2 theming eslint rule ([#965](https://github.com/HylandSoftware/satori/pull/965))
- DS-1009 No MDS2 theme structure eslint rule ([#964](https://github.com/HylandSoftware/satori/pull/964))
- DS-1008 No MDS2 mixins eslint rule ([#962](https://github.com/HylandSoftware/satori/pull/962))
- DS-1007 No MDS2 imports eslint rule ([#961](https://github.com/HylandSoftware/satori/pull/961))
- DS-1006 No MDS2 compatibility mixins eslint rule ([#960](https://github.com/HylandSoftware/satori/pull/960))
- DS-1005 No MDS2 color extraction eslint rule ([#955](https://github.com/HylandSoftware/satori/pull/955))
- DS-1011 Scaffolding sdsp (Satori Design System Police) cli package ([#951](https://github.com/HylandSoftware/satori/pull/951))
- DS-1004 No DS internal overrides stylelint rule ([#950](https://github.com/HylandSoftware/satori/pull/950))
- DS-1003 Satori SVG icon detector eslint rule ([#949](https://github.com/HylandSoftware/satori/pull/949))
- DS-1002 Material font icon detector eslint rule ([#947](https://github.com/HylandSoftware/satori/pull/947))
- DS-1001 forbidden elements eslint rule ([#942](https://github.com/HylandSoftware/satori/pull/942))
- DS-1000 custom element counter eslint rule ([#939](https://github.com/HylandSoftware/satori/pull/939))
- DS-946 satori-linter and no _24px suffix icon rule ([#921](https://github.com/HylandSoftware/satori/pull/921))

### 🩹 Fixes

- DS-1218 fix satori-lint polynomial regular expression security issue ([#1103](https://github.com/HylandSoftware/satori/pull/1103))

### ❤️ Thank You

- Kasia Biernat-Kluba @kathrine0
- Popovics András @popovicsandras
- Yvain Liechti @ryuran