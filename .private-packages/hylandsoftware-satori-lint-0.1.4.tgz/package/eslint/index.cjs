"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// packages/tools/satori-lint/src/eslint/index.ts
var eslint_exports = {};
__export(eslint_exports, {
  adoptionPlugin: () => adoption_plugin_default,
  configs: () => configs2,
  default: () => eslint_default,
  rulePrefix: () => rule_prefix_default,
  rules: () => rules2
});
module.exports = __toCommonJS(eslint_exports);

// packages/tools/satori-lint/src/eslint/no-24px-icon-suffix/no-24px-icon-suffix.ts
var ICON_SUFFIX_PATTERN = "_24px";
var SVG_ICON_REGEX = new RegExp(
  /(?:svgIcon\s*=\s*(['"`])([^'"]*_24px)\1|\[svgIcon\]\s*=\s*"'([^'"]*_24px)'")/g
);
var rule = {
  meta: {
    type: "problem",
    docs: {
      description: "Disallow mat-icon svgIcon with _24px suffix",
      recommended: true
    },
    fixable: "code",
    schema: [],
    messages: {
      no24pxIconSuffix: "The mat-icon svgIcon with _24px suffix is deprecated. Use the icon without the suffix instead.",
      no24pxIconSuffixSummary: "Found {{count}} deprecated mat-icon with 24px suffix occurrence(s) in total."
    }
  },
  create: (context) => {
    const sourceCode = context.sourceCode;
    function getAttributeValue(attr) {
      if (!attr.value) return "";
      let value = "";
      if (typeof attr.value === "string") {
        value = attr.value;
      } else if (attr.value.value !== void 0) {
        value = String(attr.value.value);
      } else if (attr.value.raw) {
        value = attr.value.raw;
      } else if (attr.value.source) {
        value = attr.value.source;
      }
      while (value.length >= 2 && (value[0] === '"' || value[0] === "'" || value[0] === "`") && value[0] === value[value.length - 1]) {
        value = value.slice(1, -1);
      }
      return value;
    }
    function isSvgIconAttribute(attrName) {
      if (!attrName) return false;
      return attrName === "svgIcon" || attrName === "[svgIcon]";
    }
    function findViolatingAttribute(node) {
      if (node.name !== "mat-icon") return null;
      const attrsToCheck = [...node.attributes || [], ...node.inputs || []];
      return attrsToCheck.find((attr) => {
        if (!isSvgIconAttribute(attr.name)) return false;
        const value = getAttributeValue(attr);
        return new RegExp(`${ICON_SUFFIX_PATTERN}['"\`]*$`).test(value);
      }) || null;
    }
    function createAttributeFix(fixer, attr) {
      const valueNode = attr.value;
      if (!valueNode) return null;
      if (valueNode.range) {
        const currentText = sourceCode.getText(valueNode);
        const fixedText = currentText.replace(new RegExp(ICON_SUFFIX_PATTERN, "g"), "");
        return fixer.replaceText(valueNode, fixedText);
      }
      if (attr.range) {
        const attrText = sourceCode.getText(attr);
        const match = attrText.match(/=\s*["']([^"']*)["']/);
        if (match) {
          const valueStart = attr.range[0] + attrText.indexOf(match[1]);
          const valueEnd = valueStart + match[1].length;
          const fixedText = match[1].replace(new RegExp(ICON_SUFFIX_PATTERN, "g"), "");
          return fixer.replaceTextRange([valueStart, valueEnd], fixedText);
        }
      }
      return null;
    }
    function reportViolation(node, violatingAttr) {
      context.report({
        node,
        messageId: "no24pxIconSuffix",
        fix: (fixer) => createAttributeFix(fixer, violatingAttr)
      });
    }
    function checkMatIconElement(node, reportNode) {
      const violatingAttr = findViolatingAttribute(node);
      if (violatingAttr) {
        reportViolation(reportNode, violatingAttr);
      }
    }
    function processHtmlFile(node) {
      const text = sourceCode.getText();
      const regex = new RegExp(SVG_ICON_REGEX.source, "g");
      let match;
      while ((match = regex.exec(text)) !== null) {
        const attrValue = match[2] || match[3];
        const matchStart = match.index;
        const valueStart = text.indexOf(attrValue, matchStart);
        const valueEnd = valueStart + attrValue.length;
        context.report({
          node,
          messageId: "no24pxIconSuffix",
          loc: {
            start: sourceCode.getLocFromIndex(valueStart),
            end: sourceCode.getLocFromIndex(valueEnd)
          },
          fix: (fixer) => {
            const fixedValue = attrValue.replace(new RegExp(ICON_SUFFIX_PATTERN, "g"), "");
            return fixer.replaceTextRange([valueStart, valueEnd], fixedValue);
          }
        });
      }
    }
    function processInlineTemplate(templateString, templateNode) {
      try {
        const angularTemplateParser = require("@angular-eslint/template-parser");
        const parseResult = angularTemplateParser.parseForESLint(templateString, {
          range: true,
          loc: true,
          comment: true
        });
        const templateAst = parseResult.ast || parseResult;
        traverseTemplateAst(templateAst, templateNode);
      } catch {
        processInlineTemplateWithRegex(templateNode);
      }
    }
    function traverseTemplateAst(node, templateNode) {
      if (!node || typeof node !== "object") return;
      if (node.type === "Element") {
        const violatingAttr = findViolatingAttribute(node);
        if (violatingAttr) {
          context.report({
            node: templateNode,
            messageId: "no24pxIconSuffix",
            fix: (fixer) => {
              const templateText = sourceCode.getText(templateNode.value);
              const fixedTemplate = templateText.replace(new RegExp(ICON_SUFFIX_PATTERN, "g"), "");
              return fixer.replaceText(templateNode.value, fixedTemplate);
            }
          });
        }
      }
      for (const key in node) {
        const value = node[key];
        if (Array.isArray(value)) {
          value.forEach((child) => traverseTemplateAst(child, templateNode));
        } else if (value && typeof value === "object") {
          traverseTemplateAst(value, templateNode);
        }
      }
    }
    function processInlineTemplateWithRegex(templateNode) {
      const templateText = sourceCode.getText(templateNode.value);
      const regex = new RegExp(SVG_ICON_REGEX.source, "g");
      let match;
      while ((match = regex.exec(templateText)) !== null) {
        const attrValue = match[2] || match[3];
        const matchStart = match.index;
        const valueStartLocal = templateText.indexOf(attrValue, matchStart);
        if (valueStartLocal === -1) continue;
        const valueEndLocal = valueStartLocal + attrValue.length;
        const baseIndex = templateNode.value.range?.[0] ?? 0;
        const valueStart = baseIndex + valueStartLocal;
        const valueEnd = baseIndex + valueEndLocal;
        context.report({
          node: templateNode,
          messageId: "no24pxIconSuffix",
          loc: {
            start: sourceCode.getLocFromIndex(valueStart),
            end: sourceCode.getLocFromIndex(valueEnd)
          },
          fix: (fixer) => {
            const fixedValue = attrValue.replace(new RegExp(ICON_SUFFIX_PATTERN, "g"), "");
            return fixer.replaceTextRange([valueStart, valueEnd], fixedValue);
          }
        });
      }
    }
    function getTemplateString(node) {
      if (node.value.type === "Literal") {
        return node.value.value || "";
      }
      if (node.value.type === "TemplateLiteral") {
        return node.value.quasis.map((quasi) => quasi.value.raw).join("");
      }
      return "";
    }
    return {
      // Handle HTML files
      Program(node) {
        const filename = context.filename || context.getFilename();
        if (filename?.endsWith(".html")) {
          processHtmlFile(node);
        }
      },
      // Handle template elements
      Element(node) {
        checkMatIconElement(node, node);
      },
      // Handle inline templates in TypeScript files
      Property(node) {
        if (node.key?.name === "template" && node.value && (node.value.type === "Literal" || node.value.type === "TemplateLiteral")) {
          const templateString = getTemplateString(node);
          if (templateString) {
            processInlineTemplate(templateString, node);
          }
        }
      }
    };
  }
};
var no_24px_icon_suffix_default = rule;

// packages/tools/satori-lint/src/eslint/utils/standard-html-elements.ts
var standardHtmlElements = /* @__PURE__ */ new Set([
  // Document metadata
  "html",
  "head",
  "title",
  "base",
  "link",
  "meta",
  "style",
  // Sectioning root
  "body",
  // Content sectioning
  "address",
  "article",
  "aside",
  "footer",
  "header",
  "h1",
  "h2",
  "h3",
  "h4",
  "h5",
  "h6",
  "main",
  "nav",
  "section",
  // Text content
  "blockquote",
  "dd",
  "div",
  "dl",
  "dt",
  "figcaption",
  "figure",
  "hr",
  "li",
  "ol",
  "p",
  "pre",
  "ul",
  // Inline text semantics
  "a",
  "abbr",
  "b",
  "bdi",
  "bdo",
  "br",
  "cite",
  "code",
  "data",
  "dfn",
  "em",
  "i",
  "kbd",
  "mark",
  "q",
  "rp",
  "rt",
  "ruby",
  "s",
  "samp",
  "small",
  "span",
  "strong",
  "sub",
  "sup",
  "time",
  "u",
  "var",
  "wbr",
  // Image and multimedia
  "area",
  "audio",
  "img",
  "map",
  "track",
  "video",
  // Embedded content
  "embed",
  "iframe",
  "object",
  "picture",
  "portal",
  "source",
  // SVG and MathML
  "svg",
  "math",
  // SVG elements
  "circle",
  "ellipse",
  "line",
  "polygon",
  "polyline",
  "rect",
  "path",
  "text",
  "tspan",
  "tref",
  "textpath",
  "marker",
  "pattern",
  "clippath",
  "mask",
  "image",
  "switch",
  "foreignobject",
  "g",
  "defs",
  "desc",
  "title",
  "metadata",
  "symbol",
  "use",
  "view",
  "animate",
  "animatecolor",
  "animatemotion",
  "animatetransform",
  "set",
  "altglyph",
  "altglyphdef",
  "altglyphitem",
  "glyph",
  "glyphref",
  "textpath",
  "tref",
  "tspan",
  "font",
  "font-face",
  "font-face-format",
  "font-face-name",
  "font-face-src",
  "font-face-uri",
  "hkern",
  "vkern",
  "missing-glyph",
  "fefuncr",
  "fefuncg",
  "fefuncb",
  "fefunca",
  "feblend",
  "fecolormatrix",
  "fecomponenttransfer",
  "fecomposite",
  "feconvolvematrix",
  "fediffuselighting",
  "fedisplacementmap",
  "fedistantlight",
  "fedropshadow",
  "feflood",
  "fegaussianblur",
  "feimage",
  "femerge",
  "femergenode",
  "femorphology",
  "feoffset",
  "fepointlight",
  "fespecularlighting",
  "fespotlight",
  "fetile",
  "feturbulence",
  "filter",
  "lineargradient",
  "radialgradient",
  "stop",
  // Scripting
  "canvas",
  "noscript",
  "script",
  // Demarcating edits
  "del",
  "ins",
  // Table content
  "caption",
  "col",
  "colgroup",
  "table",
  "tbody",
  "td",
  "tfoot",
  "th",
  "thead",
  "tr",
  // Forms
  "button",
  "datalist",
  "fieldset",
  "form",
  "input",
  "label",
  "legend",
  "meter",
  "optgroup",
  "option",
  "output",
  "progress",
  "select",
  "textarea",
  // Interactive elements
  "details",
  "dialog",
  "summary",
  // Web Components
  "slot",
  "template",
  // Obsolete and deprecated elements that might still be encountered
  "acronym",
  "applet",
  "basefont",
  "bgsound",
  "big",
  "blink",
  "center",
  "command",
  "content",
  "dir",
  "element",
  "font",
  "frame",
  "frameset",
  "hgroup",
  "image",
  "isindex",
  "keygen",
  "listing",
  "marquee",
  "menu",
  "menuitem",
  "multicol",
  "nextid",
  "nobr",
  "noembed",
  "noframes",
  "plaintext",
  "shadow",
  "spacer",
  "strike",
  "tt",
  "xmp"
]);
var angularBuiltinElements = /* @__PURE__ */ new Set(["ng-container", "ng-content", "ng-template"]);

// packages/tools/satori-lint/src/eslint/no-custom-elements/no-custom-elements.ts
var rule2 = {
  meta: {
    type: "problem",
    docs: {
      description: "Disallow custom components (non-standard HTML elements) in Angular templates",
      category: "Best Practices",
      recommended: false
    },
    fixable: void 0,
    schema: [],
    messages: {
      noCustomElements: 'Custom element "{{elementName}}" is not allowed. Use only standard HTML elements.',
      customElementsSummary: "Found {{count}} custom element occurrence(s) in total."
    }
  },
  create(context) {
    let violationCount = 0;
    let programNode = null;
    function isCustomComponent(elementName) {
      const cleanName = elementName.replace(/^:[^:]+:/, "").toLowerCase();
      if (standardHtmlElements.has(cleanName)) {
        return false;
      }
      if (angularBuiltinElements.has(cleanName)) {
        return false;
      }
      return true;
    }
    function checkCustomComponentViolation(node, reportNode) {
      if (node.name && isCustomComponent(node.name)) {
        violationCount++;
        context.report({
          node: reportNode,
          messageId: "noCustomElements",
          data: { elementName: node.name }
        });
      }
    }
    function parseInlineTemplate(templateString, templateNode) {
      try {
        let traverseTemplateAst2 = function(node) {
          if (node && typeof node === "object") {
            if (node.type === "Element") {
              checkCustomComponentViolation(node, templateNode);
            }
            for (const key in node) {
              const value = node[key];
              if (Array.isArray(value)) {
                for (const child of value) {
                  traverseTemplateAst2(child);
                }
              } else if (value && typeof value === "object") {
                traverseTemplateAst2(value);
              }
            }
          }
        };
        var traverseTemplateAst = traverseTemplateAst2;
        const angularTemplateParser = require("@angular-eslint/template-parser");
        const parseResult = angularTemplateParser.parseForESLint(templateString, {
          range: true,
          loc: true,
          comment: true
        });
        const templateAst = parseResult.ast || parseResult;
        traverseTemplateAst2(templateAst);
      } catch (error) {
        const tagStart = "<";
        const tagEnd = ">";
        let i = 0;
        while (i < templateString.length) {
          const startIdx = templateString.indexOf(tagStart, i);
          if (startIdx === -1) break;
          const endIdx = templateString.indexOf(tagEnd, startIdx + 1);
          if (endIdx === -1) break;
          const tagContent = templateString.slice(startIdx + 1, endIdx).trim();
          const tagNameMatch = /^[a-zA-Z][a-zA-Z0-9-]*/.exec(tagContent);
          if (tagNameMatch) {
            const elementName = tagNameMatch[0];
            if (isCustomComponent(elementName)) {
              violationCount++;
              context.report({
                node: templateNode,
                messageId: "noCustomElements",
                data: { elementName }
              });
            }
          }
          i = endIdx + 1;
        }
      }
    }
    return {
      // Capture the Program node for summary reporting
      Program(node) {
        programNode = node;
      },
      // Handle Angular template elements (for .html files)
      Element(node) {
        checkCustomComponentViolation(node, node);
      },
      // Handle TypeScript files with inline templates
      Property(node) {
        if (node.key && node.key.name === "template" && node.value && (node.value.type === "Literal" || node.value.type === "TemplateLiteral")) {
          let templateString = "";
          if (node.value.type === "Literal") {
            templateString = node.value.value;
          } else if (node.value.type === "TemplateLiteral") {
            templateString = node.value.quasis.map((quasi) => quasi.value.raw).join("${...}");
          }
          if (templateString && typeof templateString === "string") {
            parseInlineTemplate(templateString, node);
          }
        }
      }
    };
  }
};
var no_custom_elements_default = rule2;

// packages/tools/satori-lint/src/eslint/no-custom-elements/index.ts
var no_custom_elements_default2 = no_custom_elements_default;

// packages/tools/satori-lint/src/eslint/no-forbidden-elements/no-forbidden-elements.ts
var rule3 = {
  meta: {
    type: "problem",
    docs: {
      description: "Disallow specific custom elements based on configurable patterns",
      category: "Best Practices",
      recommended: false
    },
    fixable: void 0,
    schema: [
      {
        type: "object",
        properties: {
          patterns: {
            type: "array",
            items: {
              type: "object",
              properties: {
                pattern: {
                  type: "string"
                },
                type: {
                  type: "string",
                  enum: ["exact", "regex"]
                },
                message: {
                  type: "string"
                }
              },
              required: ["pattern", "type"],
              additionalProperties: false
            }
          }
        },
        additionalProperties: false
      }
    ],
    messages: {
      forbiddenElement: 'Element "{{elementName}}" is forbidden: {{reason}}',
      forbiddenElementsSummary: "Found {{count}} forbidden element occurrence(s) in total."
    }
  },
  create(context) {
    let violationCount = 0;
    let programNode = null;
    const options = context.options[0] || { patterns: [] };
    const compiledPatterns = options.patterns.map((config) => ({
      ...config,
      compiledRegex: config.type === "regex" ? new RegExp(`^${config.pattern}$`, "i") : null
    }));
    function checkForbiddenElement(elementName) {
      const cleanName = elementName.replace(/^:[^:]+:/, "").toLowerCase();
      if (standardHtmlElements.has(cleanName)) {
        return { isForbidden: false };
      }
      if (angularBuiltinElements.has(cleanName)) {
        return { isForbidden: false };
      }
      for (const config of compiledPatterns) {
        let matches = false;
        if (config.type === "exact") {
          matches = cleanName === config.pattern.toLowerCase();
        } else if (config.type === "regex" && config.compiledRegex) {
          matches = config.compiledRegex.test(cleanName);
        }
        if (matches) {
          return {
            isForbidden: true,
            reason: config.message || `matches pattern "${config.pattern}"`
          };
        }
      }
      return { isForbidden: false };
    }
    function checkForbiddenElementViolation(node, reportNode) {
      if (node.name) {
        const result = checkForbiddenElement(node.name);
        if (result.isForbidden) {
          violationCount++;
          context.report({
            node: reportNode,
            messageId: "forbiddenElement",
            data: {
              elementName: node.name,
              reason: result.reason || "forbidden element"
            }
          });
        }
      }
    }
    function parseInlineTemplate(templateString, templateNode) {
      try {
        let traverseTemplateAst2 = function(node) {
          if (node && typeof node === "object") {
            if (node.type === "Element") {
              checkForbiddenElementViolation(node, templateNode);
            }
            for (const key in node) {
              const value = node[key];
              if (Array.isArray(value)) {
                for (const child of value) {
                  traverseTemplateAst2(child);
                }
              } else if (value && typeof value === "object") {
                traverseTemplateAst2(value);
              }
            }
          }
        };
        var traverseTemplateAst = traverseTemplateAst2;
        const angularTemplateParser = require("@angular-eslint/template-parser");
        const parseResult = angularTemplateParser.parseForESLint(templateString, {
          range: true,
          loc: true,
          comment: true
        });
        const templateAst = parseResult.ast || parseResult;
        traverseTemplateAst2(templateAst);
      } catch (error) {
        const tagStart = "<";
        const tagEnd = ">";
        let i = 0;
        while (i < templateString.length) {
          const startIdx = templateString.indexOf(tagStart, i);
          if (startIdx === -1) break;
          const endIdx = templateString.indexOf(tagEnd, startIdx + 1);
          if (endIdx === -1) break;
          const tagContent = templateString.slice(startIdx + 1, endIdx).trim();
          const tagNameMatch = /^[a-zA-Z][a-zA-Z0-9-]*/.exec(tagContent);
          if (tagNameMatch) {
            const elementName = tagNameMatch[0];
            const result = checkForbiddenElement(elementName);
            if (result.isForbidden) {
              violationCount++;
              context.report({
                node: templateNode,
                messageId: "forbiddenElement",
                data: {
                  elementName,
                  reason: result.reason || "forbidden element"
                }
              });
            }
          }
          i = endIdx + 1;
        }
      }
    }
    return {
      // Capture the Program node for summary reporting
      Program(node) {
        programNode = node;
      },
      // Handle Angular template elements (for .html files)
      Element(node) {
        checkForbiddenElementViolation(node, node);
      },
      // Handle TypeScript files with inline templates
      Property(node) {
        if (node.key && node.key.name === "template" && node.value && (node.value.type === "Literal" || node.value.type === "TemplateLiteral")) {
          let templateString = "";
          if (node.value.type === "Literal") {
            templateString = node.value.value;
          } else if (node.value.type === "TemplateLiteral") {
            templateString = node.value.quasis.map((quasi) => quasi.value.raw).join("${...}");
            templateString = node.value.quasis[0]?.value?.raw || "";
          }
          if (templateString && typeof templateString === "string") {
            parseInlineTemplate(templateString, node);
          }
        }
      }
    };
  }
};
var no_forbidden_elements_default = rule3;

// packages/tools/satori-lint/src/eslint/no-forbidden-elements/index.ts
var noForbiddenElements = no_forbidden_elements_default;

// packages/tools/satori-lint/src/eslint/utils/icon-map.ts
var AM_FONT_ICON_MAP_TO_SATORI = {
  // Common Material Icons
  account_balance: "governance",
  add: "plus_large",
  add_box: "circle_add",
  add_circle: "circle_add",
  add_circle_outline: "circle_add",
  alarm: "alarm",
  arrow_back: "arrow_left",
  arrow_backward: "arrow_left",
  arrow_downward: "arrow_down",
  arrow_drop_down: "arrow_submenu_down",
  arrow_forward: "arrow_right",
  arrow_forward_ios: "chevron_right",
  arrow_right: "arrow_submenu_right",
  arrow_upward: "arrow_up",
  article: "form",
  assessment: "bar_chart",
  assignment: "notepad",
  auto_awesome: "UI",
  // or 'collapse_builder_toolbox'
  backspace: "backspace",
  block: "block",
  book: "bookmark",
  book_4_spark: "book",
  box: "box",
  calendar_today: "calendar",
  cancel: "circle_x",
  center_focus_strong: "fit_viewport",
  check: "check",
  check_circle: "circle_check",
  check_circle_outline: "circle_check",
  check_small: "check_small",
  chevron_left: "chevron_left",
  chevron_right: "chevron_right",
  circle: "oval",
  circle_add: "circle_add",
  clear: "x_large",
  close: "x_large",
  cloud: "cloud",
  cloud_done: "cloud_check",
  cloud_download: "cloud_download",
  cloud_off: "cloud_off",
  code: "code",
  code_off: "code_off",
  comment: "comment_text",
  compare_arrows: "compare",
  content_copy: "copy",
  copy: "copy",
  create: "pencil",
  create_new_folder: "add_folder",
  critical: "critical",
  crop: "crop",
  dashboard: "dashboard",
  delete: "trash",
  delete_forever: "trash_x",
  delete_outline: "trash",
  delete_sweep: "trash_sweep",
  description: "document",
  device_hub: "processes",
  devices_other: "devices",
  dialpad: "dialpad",
  done: "check",
  done_all: "check_double",
  double_arrow: "chevron_double_right",
  download: "download",
  drag_handle: "drag_handle_horiz",
  drag_indicator: "drag_and_drop_handle",
  edit: "pencil",
  email: "mail",
  emails: "emails",
  emergency: "asterisk",
  error: "critical",
  error_outline: "critical",
  exit_to_app: "exit_to_app",
  expand_less: "chevron_up",
  expand_more: "chevron_down",
  file_download: "attach_file",
  file_upload: "attach_file",
  filter_list: "sort",
  find_in_page: "full_text_search",
  flag: "flag",
  folder: "folder",
  folder_outline: "folder",
  folder_zip: "folder_zip",
  fullscreen: "fullscreen",
  gavel: "gavel",
  group: "users",
  // or 'user_group'
  height: "height",
  help: "help",
  help_outline: "help",
  help_outlined: "help",
  highlight_off: "circle_x",
  history: "clock",
  home: "home",
  info: "info",
  info_outline: "info",
  info_outlined: "info",
  insert_drive_file: "add_to_drive",
  integration_instructions: "notepad_code",
  keyboard_alt: "keyboard",
  keyboard_arrow_down: "chevron_down",
  keyboard_arrow_left: "chevron_left",
  keyboard_arrow_right: "chevron_right",
  keyboard_arrow_up: "chevron_up",
  keyboard_double_arrow_left: "chevron_double_left",
  keyboard_double_arrow_right: "chevron_double_right",
  language: "globe",
  launch: "launch",
  layers: "edit_form_properties",
  library_add: "add_multiple",
  link: "url",
  link_off: "url_off",
  list_alt: "bullet_list",
  // or 'list_bullet'
  lock: "lock",
  logout: "logout",
  low_priority: "low_priority",
  memory: "memory",
  menu: "menu",
  mode_edit: "pencil",
  money_off: "currency_off",
  more_horiz: "more_horiz",
  more_vert: "more_vert",
  more_vert_24px: "more_vert",
  move_down: "move_down",
  move_up: "move_up",
  navigate_before: "chevron_up",
  navigate_next: "chevron_down",
  north: "arrow_up",
  notifications: "bell",
  notifications_off: "bell_off",
  open_in_new: "launch",
  open_with: "move",
  people_alt_outline: "group",
  people_outline: "user",
  person: "user",
  person_add: "add_user",
  person_add_outline: "add_user",
  picture_in_picture_alt: "picture_in_picture",
  playlist_add: "add_list",
  plus_small: "plus_small",
  post_add: "add_post",
  print: "printer",
  print_outline: "printer",
  priority_high: "exclamation",
  public: "earth",
  query_builder: "clock",
  queue: "add_multiple",
  redo: "redo",
  refresh: "refresh",
  remove: "minus_large",
  remove_circle: "circle_minus",
  remove_circle_outline: "circle_minus",
  report_problem: "report_problem",
  restore: "restore",
  restore_24px: "restore",
  right_panel_close: "panel_close",
  right_panel_open: "panel_open",
  rotate_left: "rotate_left",
  rule: "edit_form_rules",
  save: "save",
  save_alt: "download",
  save_as: "save_as",
  schedule: "clock",
  search: "search",
  search_16px: "search",
  send: "send",
  settings: "settings",
  settings_backup_restore: "restore_backup",
  share: "share",
  sort: "sort",
  south: "arrow_down",
  space_bar: "spacebar",
  star_border: "star",
  subdirectory_arrow_right: "down_right_arrow",
  subject: "multi_line_text_field",
  supervised_user_circle: "users_circle",
  swap_vert: "import_export",
  switch_camera: "switch_camera",
  sync: "regenerate_AI",
  sync_problem: "sync_problem",
  text_format: "text",
  timer: "timer",
  translate: "translate",
  trash: "trash",
  tune: "settings",
  undo: "undo",
  unfold_less: "enlarge_horizontal",
  unfold_more: "enlarge_vertical",
  update: "update",
  user: "user",
  user_group: "user_group",
  view_week_outline: "column_view",
  visibility: "view",
  voicemail: "voicemail",
  warning: "error",
  warning_amber: "error",
  web_asset: "content_models",
  x_large: "x_large",
  zoom_in: "zoom_in",
  zoom_out: "zoom_out",
  zoom_out_map: "minimize"
  // Add more mappings as needed
};

// packages/tools/satori-lint/src/eslint/no-material-font-icons/no-material-font-icons.ts
function getFontIconValue(node) {
  if (!node.attributes) return null;
  const fontIconAttr = node.attributes.find((attr) => attr.name === "fontIcon");
  if (!fontIconAttr) return null;
  if (fontIconAttr.value && typeof fontIconAttr.value === "string") {
    return fontIconAttr.value;
  }
  if (fontIconAttr.value?.type === "BoundAttribute") {
    const boundValue = fontIconAttr.value.value;
    if (typeof boundValue === "string") {
      return boundValue;
    }
  }
  return null;
}
var rule4 = {
  meta: {
    type: "problem",
    docs: {
      description: "Disallow font-based Angular Material icons (mat-icon with text content or fontSet/fontIcon attributes)",
      category: "Best Practices",
      recommended: false
    },
    fixable: "code",
    schema: [],
    messages: {
      noFontIcons: "Font-based Angular Material icons are not allowed. Use SVG icons instead.",
      fontIconsSummary: "Found {{count}} font icon occurrence(s) in total."
    }
  },
  create(context) {
    let violationCount = 0;
    let programNode = null;
    function checkMatIconViolation(node, reportNode, templateLiteralNode) {
      if (node.name === "mat-icon") {
        let hasViolation = false;
        let fontIconValue = null;
        let textContent = null;
        if (node.children && node.children.length > 0) {
          for (const child of node.children) {
            if (child.type === "Text" && child.value?.trim()) {
              hasViolation = true;
              textContent = child.value.trim();
              break;
            }
            if (child.type === "BoundText") {
              hasViolation = true;
              break;
            }
          }
        }
        if (node.attributes && node.attributes.length > 0) {
          fontIconValue = getFontIconValue(node);
          for (const attr of node.attributes) {
            if (attr.name === "fontIcon" || attr.name === "fontSet") {
              hasViolation = true;
              break;
            }
          }
        }
        if (hasViolation) {
          fontIconValue = getFontIconValue(node);
          violationCount++;
          const iconName = fontIconValue ?? textContent;
          let fix = void 0;
          const literalNode = templateLiteralNode || reportNode;
          if (literalNode && literalNode.type === "Literal" && typeof literalNode.value === "string") {
            fix = (fixer) => {
              const templateText = literalNode.value;
              let fixedTemplate = templateText;
              if (iconName) {
                const svgIconName = AM_FONT_ICON_MAP_TO_SATORI[iconName] ?? null;
                if (svgIconName) {
                  if (fontIconValue) {
                    fixedTemplate = fixedTemplate.replace(
                      /fontIcon\s*=\s*["']([^"']+)["']/g,
                      `svgIcon="${svgIconName}"`
                    );
                    fixedTemplate = fixedTemplate.replace(
                      /\[fontIcon\]\s*=\s*["']([^"']+)["']/g,
                      `svgIcon="${svgIconName}"`
                    );
                  }
                  if (textContent) {
                    const escapedText = textContent.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                    fixedTemplate = fixedTemplate.replace(
                      new RegExp(`<mat-icon([^>]*)>\\s*${escapedText}\\s*</mat-icon>`, "g"),
                      `<mat-icon$1 svgIcon="${svgIconName}"></mat-icon>`
                    );
                  }
                  fixedTemplate = fixedTemplate.replace(/\s*fontSet\s*=\s*["'][^"']*["']/g, "");
                  fixedTemplate = fixedTemplate.replace(/\s*\[fontSet\]\s*=\s*["'][^"']*["']/g, "");
                }
              }
              return fixer.replaceText(literalNode, `'${fixedTemplate}'`);
            };
          }
          context.report({
            node: reportNode,
            messageId: "noFontIcons",
            fix
          });
        }
      }
    }
    function parseInlineTemplate(templateString, templateNode, literalNode) {
      try {
        let traverseTemplateAst2 = function(node) {
          if (node && typeof node === "object") {
            if (node.type === "Element") {
              checkMatIconViolation(node, templateNode, literalNode);
            }
            for (const key in node) {
              const value = node[key];
              if (Array.isArray(value)) {
                for (const child of value) {
                  traverseTemplateAst2(child);
                }
              } else if (value && typeof value === "object") {
                traverseTemplateAst2(value);
              }
            }
          }
        };
        var traverseTemplateAst = traverseTemplateAst2;
        const angularTemplateParser = require("@angular-eslint/template-parser");
        const parseResult = angularTemplateParser.parseForESLint(templateString, {
          range: true,
          loc: true,
          comment: true
        });
        const templateAst = parseResult.ast || parseResult;
        traverseTemplateAst2(templateAst);
      } catch (error) {
        const blocks = [];
        let start = 0;
        while ((start = templateString.indexOf("<mat-icon", start)) !== -1) {
          const end = templateString.indexOf("</mat-icon>", start);
          if (end === -1) break;
          blocks.push(templateString.slice(start, end + "</mat-icon>".length));
          start = end + "</mat-icon>".length;
        }
        for (const block of blocks) {
          if (block.includes("fontIcon") || block.includes("fontSet") || block.includes("{{") || // Check for non-empty content between tags
          block.split(">")[1]?.split("</mat-icon>")[0]?.trim().length > 0) {
            violationCount++;
            let fix = void 0;
            if (literalNode && literalNode.type === "Literal" && typeof literalNode.value === "string") {
              const fontIconRegex = /fontIcon\s*=\s*["']([^"']+)["']/;
              const textRegex = /<mat-icon[^>]*>([^<]+)</;
              const fontIconMatch = fontIconRegex.exec(block);
              const textMatch = textRegex.exec(block);
              const fontIconValue = fontIconMatch?.[1];
              const textContent = textMatch?.[1]?.trim();
              const iconName = fontIconValue ?? textContent;
              fix = (fixer) => {
                let fixedTemplate = literalNode.value;
                if (iconName) {
                  const svgIconName = AM_FONT_ICON_MAP_TO_SATORI[iconName] ?? null;
                  if (svgIconName) {
                    if (fontIconValue) {
                      fixedTemplate = fixedTemplate.replace(
                        /fontIcon\s*=\s*["']([^"']+)["']/g,
                        `svgIcon="${svgIconName}"`
                      );
                      fixedTemplate = fixedTemplate.replace(
                        /\[fontIcon\]\s*=\s*["']([^"']+)["']/g,
                        `svgIcon="${svgIconName}"`
                      );
                    }
                    if (textContent) {
                      const escapedText = textContent.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
                      fixedTemplate = fixedTemplate.replace(
                        new RegExp(`<mat-icon([^>]*)>\\s*${escapedText}\\s*</mat-icon>`, "g"),
                        `<mat-icon$1 svgIcon="${svgIconName}"></mat-icon>`
                      );
                    }
                    fixedTemplate = fixedTemplate.replace(/\s*fontSet\s*=\s*["'][^"']*["']/g, "");
                    fixedTemplate = fixedTemplate.replace(
                      /\s*\[fontSet\]\s*=\s*["'][^"']*["']/g,
                      ""
                    );
                  }
                }
                return fixer.replaceText(literalNode, `'${fixedTemplate}'`);
              };
            }
            context.report({
              node: templateNode,
              messageId: "noFontIcons",
              fix
            });
          }
        }
      }
    }
    return {
      // Capture the Program node for summary reporting
      Program(node) {
        programNode = node;
      },
      // Handle Angular template elements (for .html files)
      Element(node) {
        checkMatIconViolation(node, node);
      },
      // Handle TypeScript files with inline templates
      Property(node) {
        if (node.key?.name === "template" && node.value && (node.value.type === "Literal" || node.value.type === "TemplateLiteral")) {
          let templateString = "";
          if (node.value.type === "Literal") {
            templateString = node.value.value;
          } else if (node.value.type === "TemplateLiteral") {
            templateString = node.value.quasis.map((quasi) => quasi.value.raw).join("${...}");
          }
          if (templateString && typeof templateString === "string") {
            parseInlineTemplate(templateString, node, node.value);
          }
        }
      }
    };
  }
};
var no_material_font_icons_default = rule4;

// packages/tools/satori-lint/src/eslint/no-satori-svg-icons/no-satori-svg-icons.ts
var rule5 = {
  meta: {
    type: "problem",
    docs: {
      description: "Disallow SVG-based Angular Material icons (mat-icon with svgIcon attribute)",
      category: "Best Practices",
      recommended: false
    },
    fixable: void 0,
    schema: [],
    messages: {
      noSvgIcons: "SVG-based Angular Material (Satori) icons found.",
      svgIconsSummary: "Found {{count}} SVG icon occurrence(s) in total."
    }
  },
  create(context) {
    let violationCount = 0;
    let programNode = null;
    function checkMatIconViolation(node, reportNode) {
      if (node.name === "mat-icon") {
        let hasViolation = false;
        if (node.attributes && node.attributes.length > 0) {
          for (const attr of node.attributes) {
            if (attr.name === "svgIcon") {
              hasViolation = true;
              break;
            }
          }
        }
        if (node.inputs && node.inputs.length > 0) {
          for (const input of node.inputs) {
            if (input.name === "svgIcon" && input.type === "BoundAttribute") {
              hasViolation = true;
              break;
            }
          }
        }
        if (hasViolation) {
          violationCount++;
          context.report({
            node: reportNode,
            messageId: "noSvgIcons"
          });
        }
      }
    }
    function parseInlineTemplate(templateString, templateNode) {
      try {
        let traverseTemplateAst2 = function(node) {
          if (node && typeof node === "object") {
            if (node.type === "Element") {
              checkMatIconViolation(node, templateNode);
            }
            for (const key in node) {
              const value = node[key];
              if (Array.isArray(value)) {
                for (const child of value) {
                  traverseTemplateAst2(child);
                }
              } else if (value && typeof value === "object") {
                traverseTemplateAst2(value);
              }
            }
          }
        };
        var traverseTemplateAst = traverseTemplateAst2;
        const angularTemplateParser = require("@angular-eslint/template-parser");
        const parseResult = angularTemplateParser.parseForESLint(templateString, {
          range: true,
          loc: true,
          comment: true
        });
        const templateAst = parseResult.ast || parseResult;
        traverseTemplateAst2(templateAst);
      } catch (error) {
        let idx = 0;
        while ((idx = templateString.indexOf("<mat-icon", idx)) !== -1) {
          const endIdx = templateString.indexOf(">", idx);
          if (endIdx === -1) break;
          const tagContent = templateString.slice(idx, endIdx + 1).toLowerCase();
          if (tagContent.includes("svgicon") || tagContent.includes("[svgicon]") || tagContent.includes("svgicon=")) {
            violationCount++;
            context.report({
              node: templateNode,
              messageId: "noSvgIcons"
            });
          }
          idx = endIdx + 1;
        }
      }
    }
    return {
      // Capture the Program node for summary reporting
      Program(node) {
        programNode = node;
      },
      // Handle Angular template elements (for .html files)
      Element(node) {
        checkMatIconViolation(node, node);
      },
      // Handle TypeScript files with inline templates
      Property(node) {
        if (node.key && node.key.name === "template" && node.value && (node.value.type === "Literal" || node.value.type === "TemplateLiteral")) {
          let templateString = "";
          if (node.value.type === "Literal") {
            templateString = node.value.value;
          } else if (node.value.type === "TemplateLiteral") {
            templateString = node.value.quasis.map((quasi) => quasi.value.raw).join("${...}");
          }
          if (templateString && typeof templateString === "string") {
            parseInlineTemplate(templateString, node);
          }
        }
      }
    };
  }
};
var no_satori_svg_icons_default = rule5;

// packages/tools/satori-lint/src/eslint/rule-prefix.ts
var rule_prefix_default = "@hylandsoftware/satori-lint/eslint";

// packages/tools/satori-lint/src/eslint/eslint-plugin.ts
var rules = {
  // These ones are only used for satori adoption score calculation, hence not in the recommended config
  "no-custom-elements": no_custom_elements_default2,
  "no-satori-svg-icons": no_satori_svg_icons_default,
  // These ones are part of the recommended config
  "no-forbidden-elements": noForbiddenElements,
  "no-24px-icon-suffix": no_24px_icon_suffix_default,
  "no-material-font-icons": no_material_font_icons_default
};
var plugin = {
  rules
};
var recommendedRules = {
  [`${rule_prefix_default}/no-24px-icon-suffix`]: "error",
  [`${rule_prefix_default}/no-material-font-icons`]: "error",
  [`${rule_prefix_default}/no-forbidden-elements`]: [
    "warn",
    {
      patterns: [
        { pattern: "adf-.*", type: "regex", message: "ADF elements are not allowed" },
        { pattern: "hy-.*", type: "regex", message: "HY elements are not allowed" }
      ]
    }
  ]
};
plugin.configs = {
  recommended: {
    rules: recommendedRules
  },
  "flat/recommended": [
    {
      files: ["**/*.{ts,html}"],
      plugins: {
        [rule_prefix_default]: plugin
      },
      rules: recommendedRules
    }
  ]
};
var eslint_plugin_default = plugin;

// packages/tools/satori-lint/src/eslint/adoption-plugin.ts
var configs = {
  recommended: {
    plugins: [rule_prefix_default],
    rules: {
      [`${rule_prefix_default}/no-material-font-icons`]: "error",
      [`${rule_prefix_default}/no-satori-svg-icons`]: "error",
      [`${rule_prefix_default}/no-custom-elements`]: "error",
      [`${rule_prefix_default}/no-forbidden-elements`]: "error"
    }
  }
};
var adoption_plugin_default = {
  rules,
  configs
};

// packages/tools/satori-lint/src/eslint/index.ts
var rules2 = eslint_plugin_default.rules;
var configs2 = eslint_plugin_default.configs;
var eslint_default = eslint_plugin_default;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  adoptionPlugin,
  configs,
  rulePrefix,
  rules
});
