// packages/tools/satori-lint/src/stylelint/no-ds-internals-overrides/no-ds-internals-overrides.ts
import stylelint from "stylelint";

// packages/tools/satori-lint/src/stylelint/constants.ts
var RULE_PREFIX = "@hylandsoftware/satori-lint/stylelint";
var RULE_SUFFIX_DS_INTERNAL_OVERRIDES = "no-ds-internals-overrides";
var RULE_SUFFIX_NO_MDS2_COLOR_EXTRACTION = "no-mds2-color-extraction";
var RULE_SUFFIX_NO_MDS2_COMPATIBILITY_MIXINS = "no-mds2-compatibility-mixins";
var RULE_SUFFIX_NO_MDS2_IMPORTS = "no-mds2-imports";
var RULE_SUFFIX_NO_MDS2_MIXINS = "no-mds2-mixins";
var RULE_SUFFIX_NO_MDS2_THEME_STRUCTURE = "no-mds2-theme-structure";
var RULE_SUFFIX_NO_MDS2_THEMING = "no-mds2-theming";
function getFullRuleName(ruleSuffix) {
  return `${RULE_PREFIX}/${ruleSuffix}`;
}

// packages/tools/satori-lint/src/stylelint/no-ds-internals-overrides/no-ds-internals-overrides.ts
var {
  createPlugin,
  utils: { report, ruleMessages, validateOptions }
} = stylelint;
var ruleName = getFullRuleName(RULE_SUFFIX_DS_INTERNAL_OVERRIDES);
var messages = ruleMessages(ruleName, {
  internalSelectorsRejection: "Internal selector overrides are forbidden.",
  customPropertiesRejection: "Internal custom property overrides are forbidden."
});
var meta = {
  url: "https://github.com/HylandSoftware/satori",
  fixable: false
};
var DEFAULT_PREFIXES = ["mat", "mat-mdc", "mdc", "sat", "cdk"];
function hasDesignSystemClassSelector(selector, prefixes = DEFAULT_PREFIXES) {
  const escapedPrefixes = prefixes.map((prefix) => prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const classPattern = new RegExp(`\\.(?:${escapedPrefixes.join("|")})-`, "i");
  return classPattern.test(selector);
}
function hasDesignSystemElementSelector(selector, prefixes = DEFAULT_PREFIXES) {
  const escapedPrefixes = prefixes.map((prefix) => prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const elementPattern = new RegExp(`\\b(?:${escapedPrefixes.join("|")})-\\w+`, "i");
  return elementPattern.test(selector);
}
function isDesignSystemOverride(selector, prefixes = DEFAULT_PREFIXES) {
  return hasDesignSystemClassSelector(selector, prefixes) || hasDesignSystemElementSelector(selector, prefixes);
}
function hasDesignSystemCustomProperties(declarations, prefixes = DEFAULT_PREFIXES) {
  return declarations.some((decl) => {
    if (decl.type !== "decl") return false;
    const escapedPrefixes = prefixes.map((prefix) => prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    const customPropertyPattern = new RegExp(`^--(?:${escapedPrefixes.join("|")})-`, "i");
    return customPropertyPattern.test(decl.prop);
  });
}
var ruleFunction = (primary, secondaryOptions, context) => {
  return (root, result) => {
    const validOptions = validateOptions(result, ruleName, {
      actual: primary,
      possible: [true, false]
    });
    if (!validOptions) return;
    if (!primary) {
      return;
    }
    const prefixes = secondaryOptions?.prefixes || DEFAULT_PREFIXES;
    root.walkRules((rule) => {
      let hasViolation = false;
      let rejectionMessage = "unknown";
      const hasDesignSystemSelector = rule.selectors.some(
        (selector) => isDesignSystemOverride(selector, prefixes)
      );
      if (hasDesignSystemSelector) {
        hasViolation = true;
        rejectionMessage = messages.internalSelectorsRejection;
      }
      if (!hasViolation) {
        const declarations = [];
        rule.walkDecls((decl) => {
          declarations.push(decl);
        });
        if (hasDesignSystemCustomProperties(declarations, prefixes)) {
          hasViolation = true;
          rejectionMessage = messages.customPropertiesRejection;
        }
      }
      if (hasViolation) {
        report({
          result,
          ruleName,
          message: rejectionMessage,
          node: rule
        });
      }
    });
  };
};
ruleFunction.ruleName = ruleName;
ruleFunction.messages = messages;
ruleFunction.meta = meta;
var no_ds_internals_overrides_default = createPlugin(ruleName, ruleFunction);

// packages/tools/satori-lint/src/stylelint/no-mds2-color-extraction/no-mds2-color-extraction.ts
import stylelint2 from "stylelint";
var {
  createPlugin: createPlugin2,
  utils: { report: report2, ruleMessages: ruleMessages2, validateOptions: validateOptions2 }
} = stylelint2;
var ruleName2 = getFullRuleName(RULE_SUFFIX_NO_MDS2_COLOR_EXTRACTION);
var messages2 = ruleMessages2(ruleName2, {
  rejected: "Angular Material Design System 2 color extraction functions are not allowed"
});
var meta2 = {
  url: "https://github.com/HylandSoftware/satori",
  fixable: false
};
function doesContainMds2ColorExtraction(source) {
  const mds2ColorFunctions = ["mat-color"];
  return mds2ColorFunctions.some((func) => {
    const escapedFunc = func.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(`${escapedFunc}\\s*\\(`, "g");
    return regex.test(source);
  });
}
var ruleFunction2 = (primary, secondaryOptions, context) => {
  return (root, result) => {
    const validOptions = validateOptions2(result, ruleName2, {
      actual: primary,
      possible: [true, false]
    });
    if (!validOptions) return;
    if (!primary) {
      return;
    }
    root.walkDecls((decl) => {
      if (doesContainMds2ColorExtraction(decl.value)) {
        report2({
          result,
          ruleName: ruleName2,
          message: messages2.rejected,
          node: decl
        });
      }
    });
  };
};
ruleFunction2.ruleName = ruleName2;
ruleFunction2.messages = messages2;
ruleFunction2.meta = meta2;
var no_mds2_color_extraction_default = createPlugin2(ruleName2, ruleFunction2);

// packages/tools/satori-lint/src/stylelint/no-mds2-compatibility-mixins/no-mds2-compatibility-mixins.ts
import stylelint3 from "stylelint";
var {
  createPlugin: createPlugin3,
  utils: { report: report3, ruleMessages: ruleMessages3, validateOptions: validateOptions3 }
} = stylelint3;
var ruleName3 = getFullRuleName(RULE_SUFFIX_NO_MDS2_COMPATIBILITY_MIXINS);
var messages3 = ruleMessages3(ruleName3, {
  rejected: "Angular Material Design System 2 compatibility mixins are not allowed"
});
var meta3 = {
  url: "https://github.com/HylandSoftware/satori",
  fixable: false
};
function doesContainMds2CompatibilityMixins(source) {
  const mds2CompatibilityMixinRegex = /@include\s+mat\.m2-[\w-]+\s*\(/g;
  return mds2CompatibilityMixinRegex.test(source);
}
var ruleFunction3 = (primary, secondaryOptions, context) => {
  return (root, result) => {
    const validOptions = validateOptions3(result, ruleName3, {
      actual: primary,
      possible: [true, false]
    });
    if (!validOptions) return;
    if (!primary) {
      return;
    }
    root.walkAtRules("include", (atRule) => {
      const fullAtRule = `@include ${atRule.params}`;
      if (doesContainMds2CompatibilityMixins(fullAtRule)) {
        report3({
          result,
          ruleName: ruleName3,
          message: messages3.rejected,
          node: atRule
        });
      }
    });
  };
};
ruleFunction3.ruleName = ruleName3;
ruleFunction3.messages = messages3;
ruleFunction3.meta = meta3;
var no_mds2_compatibility_mixins_default = createPlugin3(ruleName3, ruleFunction3);

// packages/tools/satori-lint/src/stylelint/no-mds2-imports/no-mds2-imports.ts
import stylelint4 from "stylelint";
var {
  createPlugin: createPlugin4,
  utils: { report: report4, ruleMessages: ruleMessages4, validateOptions: validateOptions4 }
} = stylelint4;
var ruleName4 = getFullRuleName(RULE_SUFFIX_NO_MDS2_IMPORTS);
var messages4 = ruleMessages4(ruleName4, {
  rejected: "Angular Material Design System 2 imports are not allowed"
});
var meta4 = {
  url: "https://github.com/HylandSoftware/satori",
  fixable: false
};
function doesContainMds2Imports(source) {
  const mds2ThemingImportPattern = "@angular/material/theming";
  const tildeImportPattern = `@import '~${mds2ThemingImportPattern}'`;
  const directImportPattern = `@import '${mds2ThemingImportPattern}'`;
  return source.includes(tildeImportPattern) || source.includes(directImportPattern);
}
var ruleFunction4 = (primary, secondaryOptions, context) => {
  return (root, result) => {
    const validOptions = validateOptions4(result, ruleName4, {
      actual: primary,
      possible: [true, false]
    });
    if (!validOptions) return;
    if (!primary) {
      return;
    }
    root.walkAtRules("import", (atRule) => {
      const importValue = atRule.params;
      if (doesContainMds2Imports(`@import ${importValue}`)) {
        report4({
          result,
          ruleName: ruleName4,
          message: messages4.rejected,
          node: atRule
        });
      }
    });
  };
};
ruleFunction4.ruleName = ruleName4;
ruleFunction4.messages = messages4;
ruleFunction4.meta = meta4;
var no_mds2_imports_default = createPlugin4(ruleName4, ruleFunction4);

// packages/tools/satori-lint/src/stylelint/no-mds2-mixins/no-mds2-mixins.ts
import stylelint5 from "stylelint";
var {
  createPlugin: createPlugin5,
  utils: { report: report5, ruleMessages: ruleMessages5, validateOptions: validateOptions5 }
} = stylelint5;
var ruleName5 = getFullRuleName(RULE_SUFFIX_NO_MDS2_MIXINS);
var messages5 = ruleMessages5(ruleName5, {
  rejected: "Angular Material Design System 2 mixins are not allowed"
});
var meta5 = {
  url: "https://github.com/HylandSoftware/satori",
  fixable: false
};
function doesContainMds2Mixins(source) {
  const mds2Mixins = ["mat-core", "angular-material-theme"];
  return mds2Mixins.some((mixin) => {
    const escapedMixin = mixin.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(`@include\\s+${escapedMixin}\\s*\\(`, "g");
    return regex.test(source);
  });
}
var ruleFunction5 = (primary, secondaryOptions, context) => {
  return (root, result) => {
    const validOptions = validateOptions5(result, ruleName5, {
      actual: primary,
      possible: [true, false]
    });
    if (!validOptions) return;
    if (!primary) {
      return;
    }
    root.walkAtRules("include", (atRule) => {
      const fullAtRule = `@include ${atRule.params}`;
      if (doesContainMds2Mixins(fullAtRule)) {
        report5({
          result,
          ruleName: ruleName5,
          message: messages5.rejected,
          node: atRule
        });
      }
    });
  };
};
ruleFunction5.ruleName = ruleName5;
ruleFunction5.messages = messages5;
ruleFunction5.meta = meta5;
var no_mds2_mixins_default = createPlugin5(ruleName5, ruleFunction5);

// packages/tools/satori-lint/src/stylelint/no-mds2-theme-structure/no-mds2-theme-structure.ts
import stylelint6 from "stylelint";
var {
  createPlugin: createPlugin6,
  utils: { report: report6, ruleMessages: ruleMessages6, validateOptions: validateOptions6 }
} = stylelint6;
var ruleName6 = getFullRuleName(RULE_SUFFIX_NO_MDS2_THEME_STRUCTURE);
var messages6 = ruleMessages6(ruleName6, {
  rejected: "Angular Material Design System 2 theme structure is not allowed"
});
var meta6 = {
  url: "https://github.com/HylandSoftware/satori",
  fixable: false
};
function doesContainMds2ThemeStructure(source) {
  const mds2ThemePattern = /color:\s*\(\s*[^)]*accent[^)]*warn[^)]*\)/i;
  const alternativePattern = /color:\s*\(\s*[^)]*warn[^)]*accent[^)]*\)/i;
  return mds2ThemePattern.test(source) || alternativePattern.test(source);
}
var ruleFunction6 = (primary, secondaryOptions, context) => {
  return (root, result) => {
    const validOptions = validateOptions6(result, ruleName6, {
      actual: primary,
      possible: [true, false]
    });
    if (!validOptions) return;
    if (!primary) {
      return;
    }
    root.walkDecls((decl) => {
      if (doesContainMds2ThemeStructure(decl.value)) {
        report6({
          result,
          ruleName: ruleName6,
          message: messages6.rejected,
          node: decl
        });
      }
    });
  };
};
ruleFunction6.ruleName = ruleName6;
ruleFunction6.messages = messages6;
ruleFunction6.meta = meta6;
var no_mds2_theme_structure_default = createPlugin6(ruleName6, ruleFunction6);

// packages/tools/satori-lint/src/stylelint/no-mds2-theming/no-mds2-theming.ts
import stylelint7 from "stylelint";
var {
  createPlugin: createPlugin7,
  utils: { report: report7, ruleMessages: ruleMessages7, validateOptions: validateOptions7 }
} = stylelint7;
var ruleName7 = getFullRuleName(RULE_SUFFIX_NO_MDS2_THEMING);
var messages7 = ruleMessages7(ruleName7, {
  rejected: "Angular Material Design System 2 theming functions are not allowed"
});
var meta7 = {
  url: "https://github.com/HylandSoftware/satori",
  fixable: false
};
function doesContainMds2ThemingFunctions(source) {
  const mds2ThemingFunctions = [
    "mat.define-palette",
    "mat.define-light-theme",
    "mat.define-dark-theme"
  ];
  return mds2ThemingFunctions.some((func) => {
    const escapedFunc = func.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(`${escapedFunc}\\s*\\(`, "g");
    return regex.test(source);
  });
}
var ruleFunction7 = (primary, secondaryOptions, context) => {
  return (root, result) => {
    const validOptions = validateOptions7(result, ruleName7, {
      actual: primary,
      possible: [true, false]
    });
    if (!validOptions) return;
    if (!primary) {
      return;
    }
    root.walkDecls((decl) => {
      if (doesContainMds2ThemingFunctions(decl.value)) {
        report7({
          result,
          ruleName: ruleName7,
          message: messages7.rejected,
          node: decl
        });
      }
    });
  };
};
ruleFunction7.ruleName = ruleName7;
ruleFunction7.messages = messages7;
ruleFunction7.meta = meta7;
var no_mds2_theming_default = createPlugin7(ruleName7, ruleFunction7);

// packages/tools/satori-lint/src/stylelint/satori-adoption.rules.ts
var rules = [
  no_ds_internals_overrides_default,
  no_mds2_color_extraction_default,
  no_mds2_compatibility_mixins_default,
  no_mds2_imports_default,
  no_mds2_mixins_default,
  no_mds2_theme_structure_default,
  no_mds2_theming_default
];
var satori_adoption_rules_default = rules;
export {
  satori_adoption_rules_default as default
};
