var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// packages/tools/satori-lint/src/stylelint/constants.ts
function getFullRuleName(ruleSuffix) {
  return `${RULE_PREFIX}/${ruleSuffix}`;
}
var RULE_PREFIX, RULE_SUFFIX_DS_INTERNAL_OVERRIDES, RULE_SUFFIX_NO_MDS2_COLOR_EXTRACTION, RULE_SUFFIX_NO_MDS2_COMPATIBILITY_MIXINS, RULE_SUFFIX_NO_MDS2_IMPORTS, RULE_SUFFIX_NO_MDS2_MIXINS, RULE_SUFFIX_NO_MDS2_THEME_STRUCTURE, RULE_SUFFIX_NO_MDS2_THEMING;
var init_constants = __esm({
  "packages/tools/satori-lint/src/stylelint/constants.ts"() {
    "use strict";
    RULE_PREFIX = "@hylandsoftware/satori-lint/stylelint";
    RULE_SUFFIX_DS_INTERNAL_OVERRIDES = "no-ds-internals-overrides";
    RULE_SUFFIX_NO_MDS2_COLOR_EXTRACTION = "no-mds2-color-extraction";
    RULE_SUFFIX_NO_MDS2_COMPATIBILITY_MIXINS = "no-mds2-compatibility-mixins";
    RULE_SUFFIX_NO_MDS2_IMPORTS = "no-mds2-imports";
    RULE_SUFFIX_NO_MDS2_MIXINS = "no-mds2-mixins";
    RULE_SUFFIX_NO_MDS2_THEME_STRUCTURE = "no-mds2-theme-structure";
    RULE_SUFFIX_NO_MDS2_THEMING = "no-mds2-theming";
  }
});

// packages/tools/satori-lint/src/stylelint/no-ds-internals-overrides/no-ds-internals-overrides.ts
import stylelint from "stylelint";
function hasDesignSystemClassSelector(selector, prefixes = DEFAULT_PREFIXES) {
  const escapedPrefixes = prefixes.map((prefix) => prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const classPattern = new RegExp(`\\.(?:${escapedPrefixes.join("|")})-`, "i");
  return classPattern.test(selector);
}
function hasDesignSystemElementSelector(selector, prefixes = DEFAULT_PREFIXES) {
  const escapedPrefixes = prefixes.map((prefix) => prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const elementPattern = new RegExp(`\\b(?:${escapedPrefixes.join("|")})-\\w+`, "i");
  return elementPattern.test(selector);
}
function isDesignSystemOverride(selector, prefixes = DEFAULT_PREFIXES) {
  return hasDesignSystemClassSelector(selector, prefixes) || hasDesignSystemElementSelector(selector, prefixes);
}
function hasDesignSystemCustomProperties(declarations, prefixes = DEFAULT_PREFIXES) {
  return declarations.some((decl) => {
    if (decl.type !== "decl") return false;
    const escapedPrefixes = prefixes.map((prefix) => prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    const customPropertyPattern = new RegExp(`^--(?:${escapedPrefixes.join("|")})-`, "i");
    return customPropertyPattern.test(decl.prop);
  });
}
var createPlugin, report, ruleMessages, validateOptions, ruleName, messages, meta, DEFAULT_PREFIXES, ruleFunction, no_ds_internals_overrides_default;
var init_no_ds_internals_overrides = __esm({
  "packages/tools/satori-lint/src/stylelint/no-ds-internals-overrides/no-ds-internals-overrides.ts"() {
    "use strict";
    init_constants();
    ({
      createPlugin,
      utils: { report, ruleMessages, validateOptions }
    } = stylelint);
    ruleName = getFullRuleName(RULE_SUFFIX_DS_INTERNAL_OVERRIDES);
    messages = ruleMessages(ruleName, {
      internalSelectorsRejection: "Internal selector overrides are forbidden.",
      customPropertiesRejection: "Internal custom property overrides are forbidden."
    });
    meta = {
      url: "https://github.com/HylandSoftware/satori",
      fixable: false
    };
    DEFAULT_PREFIXES = ["mat", "mat-mdc", "mdc", "sat", "cdk"];
    ruleFunction = (primary, secondaryOptions, context) => {
      return (root, result) => {
        const validOptions = validateOptions(result, ruleName, {
          actual: primary,
          possible: [true, false]
        });
        if (!validOptions) return;
        if (!primary) {
          return;
        }
        const prefixes = secondaryOptions?.prefixes || DEFAULT_PREFIXES;
        root.walkRules((rule) => {
          let hasViolation = false;
          let rejectionMessage = "unknown";
          const hasDesignSystemSelector = rule.selectors.some(
            (selector) => isDesignSystemOverride(selector, prefixes)
          );
          if (hasDesignSystemSelector) {
            hasViolation = true;
            rejectionMessage = messages.internalSelectorsRejection;
          }
          if (!hasViolation) {
            const declarations = [];
            rule.walkDecls((decl) => {
              declarations.push(decl);
            });
            if (hasDesignSystemCustomProperties(declarations, prefixes)) {
              hasViolation = true;
              rejectionMessage = messages.customPropertiesRejection;
            }
          }
          if (hasViolation) {
            report({
              result,
              ruleName,
              message: rejectionMessage,
              node: rule
            });
          }
        });
      };
    };
    ruleFunction.ruleName = ruleName;
    ruleFunction.messages = messages;
    ruleFunction.meta = meta;
    no_ds_internals_overrides_default = createPlugin(ruleName, ruleFunction);
  }
});

// packages/tools/satori-lint/src/stylelint/no-ds-internals-overrides/index.ts
var init_no_ds_internals_overrides2 = __esm({
  "packages/tools/satori-lint/src/stylelint/no-ds-internals-overrides/index.ts"() {
    "use strict";
    init_no_ds_internals_overrides();
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-color-extraction/no-mds2-color-extraction.ts
import stylelint2 from "stylelint";
function doesContainMds2ColorExtraction(source) {
  const mds2ColorFunctions = ["mat-color"];
  return mds2ColorFunctions.some((func) => {
    const escapedFunc = func.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(`${escapedFunc}\\s*\\(`, "g");
    return regex.test(source);
  });
}
var createPlugin2, report2, ruleMessages2, validateOptions2, ruleName2, messages2, meta2, ruleFunction2, no_mds2_color_extraction_default;
var init_no_mds2_color_extraction = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-color-extraction/no-mds2-color-extraction.ts"() {
    "use strict";
    init_constants();
    ({
      createPlugin: createPlugin2,
      utils: { report: report2, ruleMessages: ruleMessages2, validateOptions: validateOptions2 }
    } = stylelint2);
    ruleName2 = getFullRuleName(RULE_SUFFIX_NO_MDS2_COLOR_EXTRACTION);
    messages2 = ruleMessages2(ruleName2, {
      rejected: "Angular Material Design System 2 color extraction functions are not allowed"
    });
    meta2 = {
      url: "https://github.com/HylandSoftware/satori",
      fixable: false
    };
    ruleFunction2 = (primary, secondaryOptions, context) => {
      return (root, result) => {
        const validOptions = validateOptions2(result, ruleName2, {
          actual: primary,
          possible: [true, false]
        });
        if (!validOptions) return;
        if (!primary) {
          return;
        }
        root.walkDecls((decl) => {
          if (doesContainMds2ColorExtraction(decl.value)) {
            report2({
              result,
              ruleName: ruleName2,
              message: messages2.rejected,
              node: decl
            });
          }
        });
      };
    };
    ruleFunction2.ruleName = ruleName2;
    ruleFunction2.messages = messages2;
    ruleFunction2.meta = meta2;
    no_mds2_color_extraction_default = createPlugin2(ruleName2, ruleFunction2);
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-color-extraction/index.ts
var init_no_mds2_color_extraction2 = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-color-extraction/index.ts"() {
    "use strict";
    init_no_mds2_color_extraction();
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-compatibility-mixins/no-mds2-compatibility-mixins.ts
import stylelint3 from "stylelint";
function doesContainMds2CompatibilityMixins(source) {
  const mds2CompatibilityMixinRegex = /@include\s+mat\.m2-[\w-]+\s*\(/g;
  return mds2CompatibilityMixinRegex.test(source);
}
var createPlugin3, report3, ruleMessages3, validateOptions3, ruleName3, messages3, meta3, ruleFunction3, no_mds2_compatibility_mixins_default;
var init_no_mds2_compatibility_mixins = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-compatibility-mixins/no-mds2-compatibility-mixins.ts"() {
    "use strict";
    init_constants();
    ({
      createPlugin: createPlugin3,
      utils: { report: report3, ruleMessages: ruleMessages3, validateOptions: validateOptions3 }
    } = stylelint3);
    ruleName3 = getFullRuleName(RULE_SUFFIX_NO_MDS2_COMPATIBILITY_MIXINS);
    messages3 = ruleMessages3(ruleName3, {
      rejected: "Angular Material Design System 2 compatibility mixins are not allowed"
    });
    meta3 = {
      url: "https://github.com/HylandSoftware/satori",
      fixable: false
    };
    ruleFunction3 = (primary, secondaryOptions, context) => {
      return (root, result) => {
        const validOptions = validateOptions3(result, ruleName3, {
          actual: primary,
          possible: [true, false]
        });
        if (!validOptions) return;
        if (!primary) {
          return;
        }
        root.walkAtRules("include", (atRule) => {
          const fullAtRule = `@include ${atRule.params}`;
          if (doesContainMds2CompatibilityMixins(fullAtRule)) {
            report3({
              result,
              ruleName: ruleName3,
              message: messages3.rejected,
              node: atRule
            });
          }
        });
      };
    };
    ruleFunction3.ruleName = ruleName3;
    ruleFunction3.messages = messages3;
    ruleFunction3.meta = meta3;
    no_mds2_compatibility_mixins_default = createPlugin3(ruleName3, ruleFunction3);
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-compatibility-mixins/index.ts
var init_no_mds2_compatibility_mixins2 = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-compatibility-mixins/index.ts"() {
    "use strict";
    init_no_mds2_compatibility_mixins();
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-imports/no-mds2-imports.ts
import stylelint4 from "stylelint";
function doesContainMds2Imports(source) {
  const mds2ThemingImportPattern = "@angular/material/theming";
  const tildeImportPattern = `@import '~${mds2ThemingImportPattern}'`;
  const directImportPattern = `@import '${mds2ThemingImportPattern}'`;
  return source.includes(tildeImportPattern) || source.includes(directImportPattern);
}
var createPlugin4, report4, ruleMessages4, validateOptions4, ruleName4, messages4, meta4, ruleFunction4, no_mds2_imports_default;
var init_no_mds2_imports = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-imports/no-mds2-imports.ts"() {
    "use strict";
    init_constants();
    ({
      createPlugin: createPlugin4,
      utils: { report: report4, ruleMessages: ruleMessages4, validateOptions: validateOptions4 }
    } = stylelint4);
    ruleName4 = getFullRuleName(RULE_SUFFIX_NO_MDS2_IMPORTS);
    messages4 = ruleMessages4(ruleName4, {
      rejected: "Angular Material Design System 2 imports are not allowed"
    });
    meta4 = {
      url: "https://github.com/HylandSoftware/satori",
      fixable: false
    };
    ruleFunction4 = (primary, secondaryOptions, context) => {
      return (root, result) => {
        const validOptions = validateOptions4(result, ruleName4, {
          actual: primary,
          possible: [true, false]
        });
        if (!validOptions) return;
        if (!primary) {
          return;
        }
        root.walkAtRules("import", (atRule) => {
          const importValue = atRule.params;
          if (doesContainMds2Imports(`@import ${importValue}`)) {
            report4({
              result,
              ruleName: ruleName4,
              message: messages4.rejected,
              node: atRule
            });
          }
        });
      };
    };
    ruleFunction4.ruleName = ruleName4;
    ruleFunction4.messages = messages4;
    ruleFunction4.meta = meta4;
    no_mds2_imports_default = createPlugin4(ruleName4, ruleFunction4);
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-imports/index.ts
var init_no_mds2_imports2 = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-imports/index.ts"() {
    "use strict";
    init_no_mds2_imports();
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-mixins/no-mds2-mixins.ts
import stylelint5 from "stylelint";
function doesContainMds2Mixins(source) {
  const mds2Mixins = ["mat-core", "angular-material-theme"];
  return mds2Mixins.some((mixin) => {
    const escapedMixin = mixin.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(`@include\\s+${escapedMixin}\\s*\\(`, "g");
    return regex.test(source);
  });
}
var createPlugin5, report5, ruleMessages5, validateOptions5, ruleName5, messages5, meta5, ruleFunction5, no_mds2_mixins_default;
var init_no_mds2_mixins = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-mixins/no-mds2-mixins.ts"() {
    "use strict";
    init_constants();
    ({
      createPlugin: createPlugin5,
      utils: { report: report5, ruleMessages: ruleMessages5, validateOptions: validateOptions5 }
    } = stylelint5);
    ruleName5 = getFullRuleName(RULE_SUFFIX_NO_MDS2_MIXINS);
    messages5 = ruleMessages5(ruleName5, {
      rejected: "Angular Material Design System 2 mixins are not allowed"
    });
    meta5 = {
      url: "https://github.com/HylandSoftware/satori",
      fixable: false
    };
    ruleFunction5 = (primary, secondaryOptions, context) => {
      return (root, result) => {
        const validOptions = validateOptions5(result, ruleName5, {
          actual: primary,
          possible: [true, false]
        });
        if (!validOptions) return;
        if (!primary) {
          return;
        }
        root.walkAtRules("include", (atRule) => {
          const fullAtRule = `@include ${atRule.params}`;
          if (doesContainMds2Mixins(fullAtRule)) {
            report5({
              result,
              ruleName: ruleName5,
              message: messages5.rejected,
              node: atRule
            });
          }
        });
      };
    };
    ruleFunction5.ruleName = ruleName5;
    ruleFunction5.messages = messages5;
    ruleFunction5.meta = meta5;
    no_mds2_mixins_default = createPlugin5(ruleName5, ruleFunction5);
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-mixins/index.ts
var init_no_mds2_mixins2 = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-mixins/index.ts"() {
    "use strict";
    init_no_mds2_mixins();
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-theme-structure/no-mds2-theme-structure.ts
import stylelint6 from "stylelint";
function doesContainMds2ThemeStructure(source) {
  const mds2ThemePattern = /color:\s*\(\s*[^)]*accent[^)]*warn[^)]*\)/i;
  const alternativePattern = /color:\s*\(\s*[^)]*warn[^)]*accent[^)]*\)/i;
  return mds2ThemePattern.test(source) || alternativePattern.test(source);
}
var createPlugin6, report6, ruleMessages6, validateOptions6, ruleName6, messages6, meta6, ruleFunction6, no_mds2_theme_structure_default;
var init_no_mds2_theme_structure = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-theme-structure/no-mds2-theme-structure.ts"() {
    "use strict";
    init_constants();
    ({
      createPlugin: createPlugin6,
      utils: { report: report6, ruleMessages: ruleMessages6, validateOptions: validateOptions6 }
    } = stylelint6);
    ruleName6 = getFullRuleName(RULE_SUFFIX_NO_MDS2_THEME_STRUCTURE);
    messages6 = ruleMessages6(ruleName6, {
      rejected: "Angular Material Design System 2 theme structure is not allowed"
    });
    meta6 = {
      url: "https://github.com/HylandSoftware/satori",
      fixable: false
    };
    ruleFunction6 = (primary, secondaryOptions, context) => {
      return (root, result) => {
        const validOptions = validateOptions6(result, ruleName6, {
          actual: primary,
          possible: [true, false]
        });
        if (!validOptions) return;
        if (!primary) {
          return;
        }
        root.walkDecls((decl) => {
          if (doesContainMds2ThemeStructure(decl.value)) {
            report6({
              result,
              ruleName: ruleName6,
              message: messages6.rejected,
              node: decl
            });
          }
        });
      };
    };
    ruleFunction6.ruleName = ruleName6;
    ruleFunction6.messages = messages6;
    ruleFunction6.meta = meta6;
    no_mds2_theme_structure_default = createPlugin6(ruleName6, ruleFunction6);
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-theme-structure/index.ts
var init_no_mds2_theme_structure2 = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-theme-structure/index.ts"() {
    "use strict";
    init_no_mds2_theme_structure();
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-theming/no-mds2-theming.ts
import stylelint7 from "stylelint";
function doesContainMds2ThemingFunctions(source) {
  const mds2ThemingFunctions = [
    "mat.define-palette",
    "mat.define-light-theme",
    "mat.define-dark-theme"
  ];
  return mds2ThemingFunctions.some((func) => {
    const escapedFunc = func.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(`${escapedFunc}\\s*\\(`, "g");
    return regex.test(source);
  });
}
var createPlugin7, report7, ruleMessages7, validateOptions7, ruleName7, messages7, meta7, ruleFunction7, no_mds2_theming_default;
var init_no_mds2_theming = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-theming/no-mds2-theming.ts"() {
    "use strict";
    init_constants();
    ({
      createPlugin: createPlugin7,
      utils: { report: report7, ruleMessages: ruleMessages7, validateOptions: validateOptions7 }
    } = stylelint7);
    ruleName7 = getFullRuleName(RULE_SUFFIX_NO_MDS2_THEMING);
    messages7 = ruleMessages7(ruleName7, {
      rejected: "Angular Material Design System 2 theming functions are not allowed"
    });
    meta7 = {
      url: "https://github.com/HylandSoftware/satori",
      fixable: false
    };
    ruleFunction7 = (primary, secondaryOptions, context) => {
      return (root, result) => {
        const validOptions = validateOptions7(result, ruleName7, {
          actual: primary,
          possible: [true, false]
        });
        if (!validOptions) return;
        if (!primary) {
          return;
        }
        root.walkDecls((decl) => {
          if (doesContainMds2ThemingFunctions(decl.value)) {
            report7({
              result,
              ruleName: ruleName7,
              message: messages7.rejected,
              node: decl
            });
          }
        });
      };
    };
    ruleFunction7.ruleName = ruleName7;
    ruleFunction7.messages = messages7;
    ruleFunction7.meta = meta7;
    no_mds2_theming_default = createPlugin7(ruleName7, ruleFunction7);
  }
});

// packages/tools/satori-lint/src/stylelint/no-mds2-theming/index.ts
var init_no_mds2_theming2 = __esm({
  "packages/tools/satori-lint/src/stylelint/no-mds2-theming/index.ts"() {
    "use strict";
    init_no_mds2_theming();
  }
});

// packages/tools/satori-lint/src/stylelint/satori-adoption.rule-configs.ts
var ruleConfigurations;
var init_satori_adoption_rule_configs = __esm({
  "packages/tools/satori-lint/src/stylelint/satori-adoption.rule-configs.ts"() {
    "use strict";
    init_constants();
    init_no_ds_internals_overrides2();
    init_no_mds2_color_extraction2();
    init_no_mds2_compatibility_mixins2();
    init_no_mds2_imports2();
    init_no_mds2_mixins2();
    init_no_mds2_theme_structure2();
    init_no_mds2_theming2();
    ruleConfigurations = [
      { ruleName: ruleName7, ruleSuffix: RULE_SUFFIX_NO_MDS2_THEMING },
      { ruleName: ruleName4, ruleSuffix: RULE_SUFFIX_NO_MDS2_IMPORTS },
      { ruleName: ruleName5, ruleSuffix: RULE_SUFFIX_NO_MDS2_MIXINS },
      { ruleName: ruleName6, ruleSuffix: RULE_SUFFIX_NO_MDS2_THEME_STRUCTURE },
      { ruleName: ruleName2, ruleSuffix: RULE_SUFFIX_NO_MDS2_COLOR_EXTRACTION },
      {
        ruleName: ruleName3,
        ruleSuffix: RULE_SUFFIX_NO_MDS2_COMPATIBILITY_MIXINS
      },
      { ruleName, ruleSuffix: RULE_SUFFIX_DS_INTERNAL_OVERRIDES }
    ];
  }
});

// packages/tools/satori-lint/src/stylelint/satori-adoption.stylelintrc.ts
import * as postcssScss from "postcss-scss";
var require_satori_adoption_stylelintrc = __commonJS({
  "packages/tools/satori-lint/src/stylelint/satori-adoption.stylelintrc.ts"(exports, module) {
    init_satori_adoption_rule_configs();
    function getRuleState(enabledRules, ruleName8) {
      if (enabledRules === null) {
        return true;
      }
      return enabledRules.includes(ruleName8) ? true : null;
    }
    function parseEnabledRules() {
      const envVar = process.env["SATORI_ADOPTION_RULES"];
      if (envVar === void 0) {
        return null;
      }
      if (envVar.trim() === "") {
        return [];
      }
      return envVar.split(",").map((rule) => rule.trim());
    }
    module.exports = {
      plugins: ["stylelint-scss", "@hylandsoftware/satori-lint/stylelint/satori-adoption.rules"],
      customSyntax: postcssScss,
      rules: (() => {
        const enabledRules = parseEnabledRules();
        const rules = {};
        for (const { ruleName: ruleName8, ruleSuffix } of ruleConfigurations) {
          rules[ruleName8] = getRuleState(enabledRules, ruleSuffix);
        }
        return rules;
      })()
    };
  }
});
export default require_satori_adoption_stylelintrc();
