export declare const ruleConfigurations: {
    ruleName: string;
    ruleSuffix: string;
}[];
