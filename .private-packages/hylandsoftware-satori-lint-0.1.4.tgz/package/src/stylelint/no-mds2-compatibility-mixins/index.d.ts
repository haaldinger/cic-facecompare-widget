export { default, ruleName } from './no-mds2-compatibility-mixins';
