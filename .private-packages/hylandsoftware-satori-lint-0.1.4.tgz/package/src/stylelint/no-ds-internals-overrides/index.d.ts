export { default, ruleName } from './no-ds-internals-overrides';
