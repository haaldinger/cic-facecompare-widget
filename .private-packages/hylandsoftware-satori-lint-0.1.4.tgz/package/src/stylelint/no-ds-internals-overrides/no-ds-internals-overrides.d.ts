import stylelint from 'stylelint';
export declare const ruleName: string;
declare const _default: stylelint.Plugin;
export default _default;
