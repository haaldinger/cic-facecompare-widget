import { Plugin } from 'stylelint';
declare const rules: Plugin[];
export default rules;
