/**
 * Stylelint configuration for the satori-adoption stylelint rules.
 *
 * Rules are dynamically enabled based on the optional SATORI_ADOPTION_RULES environment variable.
 *
 * Behavior:
 * - If SATORI_ADOPTION_RULES is not set: All rules are enabled by default
 * - If SATORI_ADOPTION_RULES is set: Only specified rules are enabled
 * - If SATORI_ADOPTION_RULES is empty string: All rules are disabled
 *
 * Usage:
 * Set SATORI_ADOPTION_RULES to a comma-separated list of rule names.
 * Note: Only use the rule name suffix (e.g., "no-mds2-theming"),
 * not the full prefix "<plugin-name>/no-mds2-theming".
 *
 * Examples:
 *   # Enable all rules (default when env var not set)
 *   npx stylelint . --config  <this file> # no env var set
 *
 *   # Enable only specific rules
 *   SATORI_ADOPTION_RULES="no-mds2-theming,other-rule" npx stylelint . --config  <this file>
 *
 *   # Disable all rules
 *   SATORI_ADOPTION_RULES="" npx stylelint . --config  <this file>
 *
 */
import * as postcssScss from 'postcss-scss';
declare const _default: {
    plugins: string[];
    customSyntax: typeof postcssScss;
    rules: Record<string, true | null>;
};
export = _default;
