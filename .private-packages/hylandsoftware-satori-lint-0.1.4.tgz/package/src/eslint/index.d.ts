import plugin from './eslint-plugin';
export declare const rules: Record<string, import("@typescript-eslint/utils/ts-eslint").LooseRuleDefinition> | undefined;
export declare const configs: import("@typescript-eslint/utils/ts-eslint").FlatConfig.SharedConfigs | undefined;
export default plugin;
export { default as adoptionPlugin } from './adoption-plugin';
export { default as rulePrefix } from './rule-prefix';
