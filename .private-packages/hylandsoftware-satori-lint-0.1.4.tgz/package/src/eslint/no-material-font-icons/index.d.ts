export { default as noMaterialFontIcons } from './no-material-font-icons';
