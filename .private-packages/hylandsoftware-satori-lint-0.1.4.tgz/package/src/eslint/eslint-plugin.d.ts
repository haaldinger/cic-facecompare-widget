import type { TSESLint } from '@typescript-eslint/utils';
export declare const rules: {
    'no-custom-elements': import("eslint").Rule.RuleModule;
    'no-satori-svg-icons': import("eslint").Rule.RuleModule;
    'no-forbidden-elements': import("eslint").Rule.RuleModule;
    'no-24px-icon-suffix': import("eslint").Rule.RuleModule;
    'no-material-font-icons': import("eslint").Rule.RuleModule;
};
declare const plugin: TSESLint.FlatConfig.Plugin;
export default plugin;
