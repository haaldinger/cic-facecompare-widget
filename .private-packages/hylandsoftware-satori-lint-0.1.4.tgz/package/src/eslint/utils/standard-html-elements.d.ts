/**
 * Comprehensive set of standard HTML elements including HTML5, SVG, MathML,
 * and some obsolete/deprecated elements that might still be encountered.
 */
export declare const standardHtmlElements: Set<string>;
/**
 * Angular built-in elements that should be allowed in templates
 */
export declare const angularBuiltinElements: Set<string>;
