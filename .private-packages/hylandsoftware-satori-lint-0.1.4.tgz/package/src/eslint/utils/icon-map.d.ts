export declare const AM_FONT_ICON_MAP_TO_SATORI: Record<string, string>;
