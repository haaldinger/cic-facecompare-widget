declare const _default: "@hylandsoftware/satori-lint/eslint";
export default _default;
