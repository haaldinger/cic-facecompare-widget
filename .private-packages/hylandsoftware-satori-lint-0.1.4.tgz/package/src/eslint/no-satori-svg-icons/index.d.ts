export { default as noSatoriSvgIcons } from './no-satori-svg-icons';
