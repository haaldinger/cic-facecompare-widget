import rule from './no-custom-elements';
export declare const noCustomElements: import("eslint").Rule.RuleModule;
export default rule;
