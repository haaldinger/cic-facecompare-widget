export { default as no24pxIconSuffix } from './no-24px-icon-suffix';
