declare const _default: {
    rules: {
        'no-custom-elements': import("eslint").Rule.RuleModule;
        'no-satori-svg-icons': import("eslint").Rule.RuleModule;
        'no-forbidden-elements': import("eslint").Rule.RuleModule;
        'no-24px-icon-suffix': import("eslint").Rule.RuleModule;
        'no-material-font-icons': import("eslint").Rule.RuleModule;
    };
    configs: {
        recommended: {
            plugins: string[];
            rules: {
                [x: string]: string;
            };
        };
    };
};
export default _default;
