import rule from './no-forbidden-elements';
export declare const noForbiddenElements: import("eslint").Rule.RuleModule;
export default rule;
