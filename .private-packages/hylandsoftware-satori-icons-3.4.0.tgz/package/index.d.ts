export const SATORI_ICONS: string;
