# Satori Icons

Sourced from https://www.figma.com/design/iojZRiN8Moza48zAH7LoTs/Satori-Design-Library?node-id=63480-8228

## Usage

First, install:

```sh
npm install @hylandsoftware/satori-icons
```

Then:

```ts
import { inject } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

import { SATORI_ICONS } from '@hylandsoftware/satori-icons';

inject(MatIconRegistry).addSvgIconSetLiteral(
  inject(DomSanitizer).bypassSecurityTrustHtml(SATORI_ICONS)
);
```

Then:

```html
<mat-icon svgIcon="add_folder"></mat-icon>
```

## Maintainers

### Update icons from Figma

To update from [Figma source](https://www.figma.com/design/iojZRiN8Moza48zAH7LoTs/Satori-Design-Library?node-id=63480-8228), run https://github.com/HylandSoftware/satori-icons/actions/workflows/update.yml

### Release

Run [github bump workflow](https://github.com/HylandSoftware/satori-icons/actions/workflows/bump.yml).
It will create a PR with the version change.
Review and merge this PR.
When merged, the version will be automatically tagged, published and a Github release will be created.

#### Versioning Recommendation

- Increment the patch version for bug fixes.
- Increment the minor version for new icons (when updating from Figma).
- Increment the major version for breaking changes.

### Visual Regression Testing

In order to run VR tests, first you need to regenerate backstop config to retrieve the icons list:

`npm run vr:config`

Before running backstop, start an application:

`npx serve .`

Run tests:

`npm run vr:test`

If there's a mismatch, verify it and approve with

`npm run vr:approve`

Commit new bitmaps into the repository.

### Detect Deleted Icons

Run following test to detect if any icons have been removed:

`npm run test:removed-icons`

If the removal is intentional, regenerate the snapshot with

`npm run snapshot:regenerate`
