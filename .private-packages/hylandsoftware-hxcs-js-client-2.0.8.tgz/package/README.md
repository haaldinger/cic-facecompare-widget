# HxP Repository JavaScript SDK

## Overview
The SDK provides methods for REST queries to HxP Repository.
Moreover, the SDK provides also the types and interfaces to be used in user's code.

[![status](https://github.com/HylandSoftware/hxpr-sdk-js/actions/workflows/build-javascript-client.yml/badge.svg?branch=main)](https://github.com/HylandSoftware/hxpr-sdk-js/actions/workflows/build-javascript-client.yml?query=branch%3Amain)

## Usage

### Add the dependency to your project:
* Go to your project directory
* Run `npm install @hylandsoftware/hxcs-js-client@latest`
> **_NOTE:_** This package is currently private, so to use it, it is necessary to run `npm login` command to be able to download it.
> Please refer to https://docs.github.com/en/packages/working-with-a-github-packages-registry/working-with-the-npm-registry for more details.

### Authorization
Before doing any operations with the SDK methods, the authorization has to be performed.
Bearer token can be fetched from HxP Repository Id Provider: http://localhost:5002/idp/connect/token.
The method below can be used for that purpose:

```typescript
async function getOAuthToken(): Promise<string> {
    const tokenResponse = await fetch('http://localhost:5002/idp/connect/token', {
        method: 'POST',
        body:
            'grant_type=password&' +
            'username=testuser&' +
            'password=password&' +
            'scope=openid profile email hxpr&' +
            'client_id=nuxeo-client&' +
            'client_secret=secret',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    });

    const json = await tokenResponse.json();

    return json.access_token;
}
```

Thanks to that method, the new Configuration object, which contains obtained token, can be created:

```typescript
const configuration = new Configuration({
    basePath: 'http://localhost:8080',
    accessToken: getOAuthToken(),
});
```
After that the Configuration object can be passed to an API object constructor.

### Code example

Here is a code snippet showing the usage of basic functions of the SDK.

```typescript
import { DocumentApi, Document } from '@hylandsoftware/hxcs-js-client';

const documentApi = new DocumentApi(configuration);

const rootId = "00000000-0000-0000-0000-000000000000";
const HXCS_REPO = "default";
const folderReq: Document = {
    sys_name: "My folder",
    sys_primaryType: "SysFolder",
    sys_title: "My folder title",
    properties: {
        sys_description: "My folder description",
        sys_title: "My folder title",
    },
};
const fileReq: Document = {
    sys_name: "My file",
    sys_primaryType: "SysFile",
    sys_title: "My file title",
    properties: {
        sys_description: "My file description",
        sys_title: "My file title"
    },
};

const updatedFileReq: Document = {
    sys_primaryType: "SysFile",
    properties: {
        sys_title: "My file title updated",
    },
};

async function createFolder() {
    const folder = await documentApi.createDocumentUnderParentById(
        rootId,
        HXCS_REPO,
        folderReq
    );
    console.log(folder.data.sysPrimaryType);
    console.log(folder.data.sysParentId);
    return folder;
}

async function createFile(folder: any) {
    const file = await documentApi.createDocumentUnderParentById(
        folder.data.sys_id!,
        HXCS_REPO,
        fileReq
    );
    console.log(file.data.sysPrimaryType);
    console.log(file.data.sysParentId);
    return file;
}

async function updateFile(file: any) {
    const updatedFile = await documentApi.updateDocumentById(
        file.data.sys_id!,
        HXCS_REPO,
        updatedFileReq
    );
    console.log(updatedFile.data.sys_id);
    console.log(updatedFile.data.sys_primaryType);
    return updatedFile;
}

async function deleteFile(file: any) {
    await documentApi.deleteDocumentById(file.data.sys_id!, HXCS_REPO).then(() => {
        documentApi.getDocumentById(file.data.sys_id!, HXCS_REPO).catch(err => {
            console.log(err); // should be 404
        });
    });
}

async function deleteFolder(folder: any) {
    await documentApi.deleteDocumentById(folder.data.sys_id!, HXCS_REPO).then(() => {
        documentApi.getDocumentById(folder.data.sys_id!, HXCS_REPO).catch(err => {
            console.log(err); // should be 404
        });
    });
}

(async () => {
    const folder = await createFolder();
    console.log("folder", folder);

    const file = await createFile(folder);
    console.log("file", file);

    const updatedFile = await updateFile(file);
    console.log("updatedFile", updatedFile);

    deleteFile(file);
    deleteFolder(folder);
})();

```

## Development (Internal usage only)

### Generating the TypeScript SDK
* Install [Node.js v18](https://nodejs.org/download/release/latest-v18.x/)
> **_NOTE:_** It can be done using nvm package manager. More details under: https://github.com/nvm-sh/nvm
* Clone the repo `git clone https://github.com/HylandSoftware/hxpr-sdk-js.git`
* Start a local HxP Repository instance - please refer to https://github.com/HylandSoftware/hxpr#readme for more details
* Go to downloaded JS SDK repository directory and install dependencies: `npm i`
* Run the open api generator CLI: `npm run generate`
* Run the build script to bundle the SDK: `npm run build`

### Testing the TypeScript SDK

1. Generate the TypeScript SDK
2. Start docker services in the root:
```
docker compose up
```
3. Run tests by following command:
```
npm run test
```
or if needed with watch
```
npm run test -- --watchAll
```

If a significant change of the SDK was made (for example: switch of generator), 
the SDK can be tested automatically with end-to-end integration tests ran from [Nuxeo-playground project](https://github.com/HylandSoftware/nuxeo-cncr-nx-playground)
```shell
npm run e2e
```

### Releasing the JavaScript SDK

Releases of the JavaScript SDK are currently handled manually. In order to release a new version:
1. Ensure that the current state of the branch to release is stable and it builds successfully.
2. [Run the "Release" workflow](https://github.com/HylandSoftware/hxpr-sdk-js/actions/workflows/release.yml) with the following parameters:
   1. Branch: base branch for the release. Default: `main`.
   1. Release version: the version of the JavaScript SDK to be released.
   1. Dry run: whether to execute a test run (doesn't create tags/releases or publishes packages). Default: `true`.
   1. HxP Repository Docker image version: Version of the HxP Repository Docker image. Default: `latest`. Note: `latest` is not a valid version because it's not currently being pushed to the registry, so an appropriate existing version (ex: `1.0.110`) should be provided instead.

If the release is successful, [a tag should be pushed](https://github.com/HylandSoftware/hxpr-sdk-js/tags), [a GitHub release should be created](https://github.com/HylandSoftware/hxpr-sdk-js/releases) and [a npm package should be made available in the registry](https://github.com/orgs/HylandSoftware/packages?repo_name=hxpr-sdk-js).
