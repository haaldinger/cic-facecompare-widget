# Rich Text Editor

Editor.js configuration, customized plugins and utilities for a rich text editor support.

## Features

- **Editor.js Configuration**: Editor.js configuration for customized and third-party plugins.
- **Custom Plugins**: Customized open-source Editor.js plugins, ESM compatible.
- **Parser**: Utilities for parsing and transforming editor content to readable html.
- **Material Design**: Styles are loosely based on Material Design and rely on Angular Material system variables (`--mat-sys-*`).
- **Development Sandbox**: A sandbox environment for quick testing and development.

## Getting Started

### Installation

```bash
bun install
```

### Development

```bash
bun dev
```

### Build

```bash
bun bundle
```

## Usage

### Development sandbox

To quickly get to the editor without installing it in your project, you can run the development sandbox:

```bash
bun run sandbox
```

### In your project

Import and initialize the editor in your application:

```typescript
import { getEditorJsConfig } from '@hylandsoftware/rich-text-editor';

const editorInstance = new EditorJS({
  ...getEditorJsConfig(),
  // your configuration options
});
```

## References

- [Editor.js](https://editorjs.io/)
- Plugin documentation in each plugin's `README.md` and `PLUGIN-META.md`.
