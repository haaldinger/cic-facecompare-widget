import { EnvironmentProviders, InjectionToken } from '@angular/core';
/**
 * Configuration options for Satori illustrations SVG path.
 */
export interface SatIllustrationConfig {
    /** Path to the SVG illustrations directory. Defaults to 'satori-svg'. */
    svgPath?: string;
    /** Namespace for the SVG illustrations. Defaults to 'sat-illustrations'. */
    namespace?: string;
}
export declare const SAT_ILLUSTRATION_DEFAULT_CONFIG: SatIllustrationConfig;
/**
 * Injection token for Satori illustration configuration.
 */
export declare const SAT_ILLUSTRATION_CONFIG: InjectionToken<SatIllustrationConfig>;
export declare function provideSatoriIllustrations(config?: SatIllustrationConfig): EnvironmentProviders;
