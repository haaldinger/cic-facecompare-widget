import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SatIllustrationComponent {
    readonly _elementRef: ElementRef<HTMLElement>;
    private readonly _iconRegistry;
    private readonly illustrationConfig;
    private readonly _errorHandler;
    /**
     * The size of the illustration.
     */
    readonly size: import("@angular/core").InputSignal<"large" | "medium" | "small">;
    /**
     * The name of the illustration to display.
     */
    readonly illustration: import("@angular/core").InputSignal<string | null>;
    constructor();
    readonly svgResource: import("@angular/core").ResourceRef<SVGElement | null | undefined>;
    private _loadSvg;
    /** Clears out the current SVG element from the host element. */
    private _clearSvgElement;
    /** Sets the current SVG element on the host element. */
    private _setSvgElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatIllustrationComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatIllustrationComponent, "sat-illustration", never, { "size": { "alias": "size"; "required": false; "isSignal": true; }; "illustration": { "alias": "illustration"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
