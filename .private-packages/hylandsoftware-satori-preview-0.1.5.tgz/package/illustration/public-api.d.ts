export { SatIllustrationComponent } from './illustration.component';
export { SatIllustrationModule } from './module';
export { provideSatoriIllustrations, SAT_ILLUSTRATION_DEFAULT_CONFIG, SAT_ILLUSTRATION_CONFIG, SatIllustrationConfig, } from './providers/provide-satori-illustrations';
