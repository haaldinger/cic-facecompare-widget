import * as i0 from "@angular/core";
import * as i1 from "./illustration.component";
export declare class SatIllustrationModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatIllustrationModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatIllustrationModule, never, [typeof i1.SatIllustrationComponent], [typeof i1.SatIllustrationComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatIllustrationModule>;
}
