/**
 * Root entrypoint for the Satori Preview library.
 *
 * @remarks
 * This placeholder export exists only to satisfy ng-packagr requirements.
 * Consumers should import components from their specific entrypoints
 * (e.g., `import { PackageName } from '@hylandsoftware/satori-preview/<package-name>'`) instead of the root.
 *
 * @internal
 */
export declare const HYLAND_SOFTWARE_SATORI_PREVIEW = "@hylandsoftware/satori-preview";
