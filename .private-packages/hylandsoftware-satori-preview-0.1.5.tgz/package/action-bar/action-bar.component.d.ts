import * as i0 from "@angular/core";
/**
 * Container component for action bars.
 * Provides a dedicated horizontal surface for bulk and contextual actions,
 * typically placed above or below data-heavy content like tables or lists.
 */
export declare class SatActionBarComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatActionBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatActionBarComponent, "sat-action-bar", never, {}, {}, never, ["*"], true, never>;
}
