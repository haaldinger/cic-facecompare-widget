import { TranslateService } from '@ngx-translate/core';
import { SatActionGroupItem } from '../action-group/action-group.component';
import * as i0 from "@angular/core";
/**
 * Displays the current selection count and provides actions for managing selected items.
 * Shows a clear button when items are selected and renders trailing actions via sat-action-group.
 *
 * @example
 * ```html
 * <sat-selection-bar
 *   [count]="selectedItems.length"
 *   [actions]="selectionActions"
 *   (cleared)="clearSelection()"
 * />
 * ```
 */
export declare class SatSelectionBarComponent {
    /** Number of items currently selected. */
    readonly count: import("@angular/core").InputSignal<number>;
    /** Actions rendered inside the trailing action group. */
    readonly actions: import("@angular/core").InputSignal<SatActionGroupItem[]>;
    /**
     * Emitted when the clear button is activated.
     */
    readonly cleared: import("@angular/core").OutputEmitterRef<void>;
    protected readonly hasSelection: import("@angular/core").Signal<boolean>;
    readonly translateService: TranslateService;
    protected emitCleared(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatSelectionBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatSelectionBarComponent, "sat-selection-bar", never, { "count": { "alias": "count"; "required": false; "isSignal": true; }; "actions": { "alias": "actions"; "required": false; "isSignal": true; }; }, { "cleared": "cleared"; }, never, never, true, never>;
}
