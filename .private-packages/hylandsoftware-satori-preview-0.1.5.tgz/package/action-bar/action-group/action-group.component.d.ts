import { OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Type definition for action group items.
 * Each item must have an icon and action, with optional disabled state and divider.
 * Must provide either a label (shown with icon) or ariaLabel (icon-only with tooltip).
 */
export type SatActionGroupItem = {
    icon: string;
    action: () => unknown;
    disabled?: boolean;
    hasTrailingDivider?: boolean;
} & ({
    label: string;
} | {
    ariaLabel: string;
});
/**
 * Renders a row of action buttons with automatic overflow handling.
 * Collapses overflowing items into a "More" menu and provides keyboard navigation.
 *
 * Features:
 * - Responsive truncation based on available width
 * - Keyboard navigation with arrow keys
 * - Skips disabled items during navigation
 * - Menu trigger included in keyboard navigation sequence
 * - Tooltips for icon-only buttons
 *
 * @example
 * ```html
 * <sat-action-group [items]="actions" />
 * ```
 */
export declare class SatActionGroupComponent implements OnDestroy {
    readonly lastFocusedIndex: import("@angular/core").WritableSignal<number>;
    readonly items: import("@angular/core").InputSignal<SatActionGroupItem[]>;
    /**
     * Signal for the items currently displayed in the group.
     * @internal
     */
    readonly visibleItems: import("@angular/core").WritableSignal<SatActionGroupItem[]>;
    /**
     * Computed signal for the hidden items (collapsed into the menu).
     * @internal
     */
    readonly hiddenItems: import("@angular/core").Signal<SatActionGroupItem[]>;
    /**
     * Computed signal for the initial focus index (first non-disabled item).
     * @internal
     */
    readonly initialFocusIndex: import("@angular/core").Signal<number>;
    /**
     * Computed signal for the total number of focusable buttons (visible items + menu trigger if present).
     * @internal
     */
    readonly totalFocusableButtons: import("@angular/core").Signal<number>;
    private readonly _element;
    /**
     * Last registered width of the component
     */
    private width;
    private truncationTimeout?;
    private resizeTimeout?;
    private resizeObserver;
    constructor();
    ngOnDestroy(): void;
    /** @internal */
    focusNext(event: Event, index: number): void;
    /** @internal */
    focusPrevious(event: Event, index: number): void;
    /** @internal to resolve TypeScript lint errors in the template. */
    getMenuDisplayText(item: SatActionGroupItem): string;
    /** @internal to resolve TypeScript lint errors in the template. */
    getTooltip(item: SatActionGroupItem): string | null;
    /** @internal to resolve TypeScript lint errors in the template. */
    hasLabel(item: SatActionGroupItem): item is SatActionGroupItem & {
        label: string;
    };
    /**
     * The resize event can fire frequently during user interactions, so we debounce it to trigger
     * only after resizing or layout changes have stopped. This prevents flickering effects during resizing.
     */
    private debounceResize;
    /**
     * Recursively manages Action Group item overflow.
     * Uses a 0ms timeout to run immediately after the next render cycle,
     * ensuring the component measures its size accurately for each recursion step.
     */
    private debounceTruncation;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatActionGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatActionGroupComponent, "sat-action-group", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
