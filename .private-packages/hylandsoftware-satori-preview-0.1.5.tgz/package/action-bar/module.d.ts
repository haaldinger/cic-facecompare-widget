import * as i0 from "@angular/core";
import * as i1 from "./action-bar-button/action-bar-button.component";
import * as i2 from "./action-group/action-group.component";
import * as i3 from "./action-bar.component";
import * as i4 from "./selection-bar/selection-bar.component";
export declare class SatActionBarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatActionBarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatActionBarModule, never, [typeof i1.SatActionBarButtonComponent, typeof i2.SatActionGroupComponent, typeof i3.SatActionBarComponent, typeof i4.SatSelectionBarComponent], [typeof i1.SatActionBarButtonComponent, typeof i2.SatActionGroupComponent, typeof i3.SatActionBarComponent, typeof i4.SatSelectionBarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatActionBarModule>;
}
