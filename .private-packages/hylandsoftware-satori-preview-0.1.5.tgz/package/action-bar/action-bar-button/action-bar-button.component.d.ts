import * as i0 from "@angular/core";
/**
 * Attribute selector component that styles buttons for the Action Bar.
 * Provides consistent visual language and behavior including ripple effects,
 * spacing, and disabled state handling.
 *
 * @example
 * ```html
 * <button satActionBarButton type="button" (click)="add()">
 *   <mat-icon svgIcon="circle_add"></mat-icon>
 *   Add
 * </button>
 * <button satActionBarButton type="button" (click)="add()" aria-label="Add">
 *   <mat-icon svgIcon="circle_add"></mat-icon>
 * </button>
 * ```
 */
export declare class SatActionBarButtonComponent {
    /** Whether the button is disabled. */
    readonly disabled: import("@angular/core").InputSignal<boolean>;
    private readonly ripple;
    launchRipple(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatActionBarButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatActionBarButtonComponent, "[sat-action-bar-button], [satActionBarButton]", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["mat-icon", "*"], true, never>;
}
