import { AfterContentInit } from '@angular/core';
import * as i0 from "@angular/core";
/** Navigation tabs provide a tabbed interface for navigating between different views or sections. */
export declare class SatNavigationTabsComponent implements AfterContentInit {
    private readonly tabs;
    ngAfterContentInit(): void;
    onKeydown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatNavigationTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatNavigationTabsComponent, "sat-navigation-tabs", never, {}, {}, ["tabs"], ["a[satNavigationTab]"], true, never>;
}
