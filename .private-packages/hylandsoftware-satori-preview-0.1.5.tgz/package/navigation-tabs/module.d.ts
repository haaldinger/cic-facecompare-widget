import * as i0 from "@angular/core";
import * as i1 from "./navigation-tabs.component";
import * as i2 from "./navigation-tab.directive";
export declare class SatNavigationTabsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatNavigationTabsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatNavigationTabsModule, never, [typeof i1.SatNavigationTabsComponent, typeof i2.SatNavigationTabDirective], [typeof i1.SatNavigationTabsComponent, typeof i2.SatNavigationTabDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatNavigationTabsModule>;
}
