import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
/** A directive applied to anchor elements to create navigation tabs. */
export declare class SatNavigationTabDirective {
    /** Whether the tab is active. */
    readonly active: import("@angular/core").InputSignal<boolean>;
    /** @internal */
    readonly elementRef: ElementRef<HTMLAnchorElement>;
    /** @internal */
    readonly tabindex: import("@angular/core").WritableSignal<number>;
    private readonly ripple;
    launchRipple(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatNavigationTabDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatNavigationTabDirective, "a[satNavigationTab]", never, { "active": { "alias": "active"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
