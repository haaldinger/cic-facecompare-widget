export { SatNavigationTabsComponent } from './navigation-tabs.component';
export { SatNavigationTabDirective } from './navigation-tab.directive';
export { SatNavigationTabsModule } from './module';
