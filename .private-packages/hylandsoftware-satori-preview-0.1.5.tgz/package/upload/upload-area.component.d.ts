import * as i0 from "@angular/core";
import * as i1 from "./upload.directive";
/**
 * A drag-and-drop upload area component.
 *
 * This component visually indicates when files are being dragged over the window,
 * and emits `filesLoaded` output via the `SatUploadDirective`. It uses Angular signals
 * to track drag state and updates its CSS classes accordingly.
 *
 * Host listeners are registered for drag events on the window to manage the drag state:
 * - `dragenter`: Activates the dragging state.
 * - `dragleave`: Deactivates dragging only when leaving the window/document.
 * - `dragend` and `drop`: Always deactivates dragging.
 */
export declare class SatUploadAreaComponent {
    readonly isDragging: import("@angular/core").WritableSignal<boolean>;
    /** @internal */
    onWindowDragEnter(): void;
    /** @internal */
    onWindowDragLeave(event: DragEvent): void;
    /** @internal */
    onWindowDragEnd(): void;
    /** @internal */
    onWindowDrop(event: DragEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatUploadAreaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatUploadAreaComponent, "sat-upload-area", never, {}, {}, never, ["*"], true, [{ directive: typeof i1.SatUploadDirective; inputs: {}; outputs: { "filesLoaded": "filesLoaded"; }; }]>;
}
