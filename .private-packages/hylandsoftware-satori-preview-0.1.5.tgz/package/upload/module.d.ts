import * as i0 from "@angular/core";
import * as i1 from "./upload-area.component";
import * as i2 from "./upload.directive";
export declare class SatUploadModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatUploadModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatUploadModule, never, [typeof i1.SatUploadAreaComponent, typeof i2.SatUploadDirective], [typeof i1.SatUploadAreaComponent, typeof i2.SatUploadDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatUploadModule>;
}
