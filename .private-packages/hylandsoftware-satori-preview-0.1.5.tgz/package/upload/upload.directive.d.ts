import { OnDestroy, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Directive to enable file upload functionality via drag-and-drop or file input dialog.
 *
 * Usage:
 * - Attach to a button element to open file selector dialog.
 * - Supports drag-and-drop for file uploads.
 * - Emits selected or dropped files via the `filesLoaded` output.
 *
 * Features:
 * - Handles file selection via input element.
 * - Handles drag-and-drop events for file uploads.
 * - Adds/removes CSS class during drag events for visual feedback.
 * - Emits a custom event with selected files.
 */
export declare class SatUploadDirective implements OnInit, OnDestroy {
    private readonly element;
    private readonly renderer;
    /**
     * Reference to a file input element.
     * Needed to open the file system dialog when the element is clicked.
     * This input element could be hidden.
     */
    readonly input: import("@angular/core").InputSignal<HTMLInputElement | undefined>;
    /**
     * Indicates if the host element should open the file system dialog on click.
     */
    private isButton;
    /**
     * Emits an event containing the selected or dropped files.
     */
    readonly filesLoaded: import("@angular/core").OutputEmitterRef<File[]>;
    /**
     * CSS class name applied during drag events for visual feedback.
     */
    private readonly dragging;
    /**
     * Handler for the file input change event.
     */
    private clearChangeEventHandler?;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    /** @internal */
    onClick(event: Event): void;
    /** @internal */
    onDragEnter(event: DragEvent): void;
    /** @internal */
    onDragOver(event: DragEvent): void;
    /** @internal */
    onDragLeave(): void;
    /** @internal */
    onDrop(event: DragEvent): void;
    /** @internal */
    onFilesLoaded(files: File[]): void;
    /**
     * Extract files from the DataTransfer object used to hold the data that is being dragged during a drag and drop operation.
     *
     * @internal
     * @param dataTransfer DataTransfer object
     * @returns a list of file info objects
     */
    getFilesDropped(dataTransfer: DataTransfer): File[];
    /**
     * Invoked when user selects files or folders by means of File Dialog
     * @internal
     */
    onSelectFiles(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatUploadDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatUploadDirective, "[satUpload]", ["satUpload"], { "input": { "alias": "input"; "required": false; "isSignal": true; }; }, { "filesLoaded": "filesLoaded"; }, never, never, true, never>;
}
