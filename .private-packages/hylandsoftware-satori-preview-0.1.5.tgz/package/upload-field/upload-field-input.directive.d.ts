import * as i0 from "@angular/core";
/**
 * Directive to be used on the file input inside a `sat-upload-field` component.
 */
export declare class SatUploadFieldInputDirective {
    /** Unique ID for the input. Used for the label for attribute. */
    readonly id: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatUploadFieldInputDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatUploadFieldInputDirective, "input[type=file][satUploadFieldInput]", ["satUploadFieldInput"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
