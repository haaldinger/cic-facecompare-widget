import * as i0 from "@angular/core";
import * as i1 from "./upload-field.component";
import * as i2 from "./upload-field-input.directive";
export declare class SatUploadFieldModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatUploadFieldModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatUploadFieldModule, never, [typeof i1.SatUploadFieldComponent, typeof i2.SatUploadFieldInputDirective], [typeof i1.SatUploadFieldComponent, typeof i2.SatUploadFieldInputDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatUploadFieldModule>;
}
