import { AfterContentInit, ElementRef, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
export declare class SatUploadFieldComponent implements AfterContentInit, OnDestroy {
    /**
     * The files that have been uploaded. This input is necessary for a11y compliance.
     */
    readonly uploadedFiles: import("@angular/core").InputSignalWithTransform<File[] | null, File | File[] | null | undefined>;
    /**
     * Whether a label has been provided in the content.
     */
    readonly hasLabel: import("@angular/core").Signal<boolean>;
    /**
     * Emits an event containing the selected or dropped files.
     */
    readonly filesLoaded: import("@angular/core").OutputEmitterRef<File[]>;
    /**
     * Denotes whether the upload field is disabled.
     */
    readonly disabled: import("@angular/core").WritableSignal<any>;
    /**
     * Denotes whether the upload field is required.
     */
    readonly required: import("@angular/core").WritableSignal<any>;
    private observer;
    readonly isDragging: import("@angular/core").WritableSignal<boolean>;
    readonly fileInput: import("@angular/core").Signal<ElementRef<any> | undefined>;
    readonly hints: import("@angular/core").Signal<readonly ElementRef<any>[]>;
    readonly errors: import("@angular/core").Signal<readonly ElementRef<any>[]>;
    readonly fileStatus: import("@angular/core").Signal<ElementRef<HTMLDivElement>>;
    private readonly _labelChild;
    readonly fileStatusId: string;
    readonly fileStatusContents: import("@angular/core").Signal<string>;
    readonly buttonDescribedBy: import("@angular/core").Signal<string>;
    readonly isInvalid: import("@angular/core").Signal<boolean>;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    /** @internal */
    onWindowDragEnter(): void;
    /** @internal */
    onWindowDragLeave(event: DragEvent): void;
    /** @internal */
    onWindowDragEnd(): void;
    /** @internal */
    onWindowDrop(event: DragEvent): void;
    private inputFilesChanged;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatUploadFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatUploadFieldComponent, "sat-upload-field", never, { "uploadedFiles": { "alias": "uploadedFiles"; "required": false; "isSignal": true; }; }, { "filesLoaded": "filesLoaded"; }, ["fileInput", "hints", "errors", "_labelChild"], ["mat-label", "img", "mat-icon, svg", "*", "mat-hint", "input[type=file]", "mat-error, [matError]"], true, never>;
}
