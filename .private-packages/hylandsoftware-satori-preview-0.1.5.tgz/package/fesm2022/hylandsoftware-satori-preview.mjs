/**
 * Root entrypoint for the Satori Preview library.
 *
 * @remarks
 * This placeholder export exists only to satisfy ng-packagr requirements.
 * Consumers should import components from their specific entrypoints
 * (e.g., `import { PackageName } from '@hylandsoftware/satori-preview/<package-name>'`) instead of the root.
 *
 * @internal
 */
const HYLAND_SOFTWARE_SATORI_PREVIEW = '@hylandsoftware/satori-preview';

/**
 * Generated bundle index. Do not edit.
 */

export { HYLAND_SOFTWARE_SATORI_PREVIEW };
//# sourceMappingURL=hylandsoftware-satori-preview.mjs.map
