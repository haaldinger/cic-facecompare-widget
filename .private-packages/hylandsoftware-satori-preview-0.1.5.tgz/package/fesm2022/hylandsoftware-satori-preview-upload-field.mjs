import { _IdGenerator } from '@angular/cdk/a11y';
import * as i0 from '@angular/core';
import { input, inject, Directive, computed, output, linkedSignal, signal, contentChild, ElementRef, contentChildren, viewChild, HostListener, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i1 from '@angular/material/core';
import { MatRippleModule } from '@angular/material/core';
import { MatHint, MatError, MatLabel, MatFormFieldModule } from '@angular/material/form-field';
import { TranslatePipe } from '@ngx-translate/core';
import { SatUploadDirective } from '@hylandsoftware/satori-preview/upload';

/**
 * Directive to be used on the file input inside a `sat-upload-field` component.
 */
class SatUploadFieldInputDirective {
    /** Unique ID for the input. Used for the label for attribute. */
    id = input(inject(_IdGenerator).getId('sat-upload-field-input-'));
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadFieldInputDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.19", type: SatUploadFieldInputDirective, isStandalone: true, selector: "input[type=file][satUploadFieldInput]", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "hidden": "true", "id": "id()" } }, exportAs: ["satUploadFieldInput"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadFieldInputDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'input[type=file][satUploadFieldInput]',
                    exportAs: 'satUploadFieldInput',
                    host: {
                        '[hidden]': 'true',
                        '[id]': 'id()',
                    },
                }]
        }] });

class SatUploadFieldComponent {
    /**
     * The files that have been uploaded. This input is necessary for a11y compliance.
     */
    uploadedFiles = input(null, {
        transform: value => (Array.isArray(value) ? value : value ? [value] : null),
    });
    /**
     * Whether a label has been provided in the content.
     */
    hasLabel = computed(() => !!this._labelChild());
    /**
     * Emits an event containing the selected or dropped files.
     */
    filesLoaded = output();
    /**
     * Denotes whether the upload field is disabled.
     */
    disabled = linkedSignal(() => this.fileInput()?.nativeElement.disabled ?? false);
    /**
     * Denotes whether the upload field is required.
     */
    required = linkedSignal(() => this.fileInput()?.nativeElement.required ?? false);
    observer = new MutationObserver(() => this.inputFilesChanged());
    isDragging = signal(false);
    fileInput = contentChild(SatUploadFieldInputDirective, { read: ElementRef });
    hints = contentChildren(MatHint, { read: ElementRef });
    errors = contentChildren(MatError, { read: ElementRef });
    fileStatus = viewChild.required('fileStatus');
    _labelChild = contentChild(MatLabel);
    fileStatusId = inject(_IdGenerator).getId('sat-upload-field-status-');
    fileStatusContents = computed(() => this.uploadedFiles()
        ?.map(file => file.name)
        ?.join(', ') ?? '');
    // errors are referenced in aria-describedby instead of aria-errormessage because of a lack of support for the latter in VoiceOver
    // order is important here: hints first, then file status, then errors
    buttonDescribedBy = computed(() => [
        ...this.hints().map(({ nativeElement }) => nativeElement?.id),
        this.fileStatusId,
        ...this.errors().map(({ nativeElement }) => nativeElement?.id),
    ]
        .filter(id => !!id)
        .join(' '));
    isInvalid = computed(() => this.errors().length > 0);
    ngAfterContentInit() {
        const fileInput = this.fileInput();
        if (fileInput) {
            this.observer.observe(fileInput.nativeElement, { attributes: true });
        }
        this.hints().forEach(({ nativeElement }) => nativeElement.setAttribute('aria-hidden', 'true'));
    }
    ngOnDestroy() {
        this.observer.disconnect();
    }
    /** @internal */
    onWindowDragEnter() {
        if (!this.isDragging()) {
            this.isDragging.set(true);
        }
    }
    /** @internal */
    onWindowDragLeave(event) {
        // Only set false if leaving the document/window
        if (event.relatedTarget === null) {
            this.isDragging.set(false);
        }
    }
    /** @internal */
    onWindowDragEnd() {
        this.isDragging.set(false);
    }
    /** @internal */
    onWindowDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragging.set(false);
    }
    inputFilesChanged() {
        this.disabled.set(this.fileInput()?.nativeElement.disabled ?? false);
        this.required.set(this.fileInput()?.nativeElement.required ?? false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatUploadFieldComponent, isStandalone: true, selector: "sat-upload-field", inputs: { uploadedFiles: { classPropertyName: "uploadedFiles", publicName: "uploadedFiles", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { filesLoaded: "filesLoaded" }, host: { listeners: { "window:dragenter": "onWindowDragEnter($event)", "window:dragleave": "onWindowDragLeave($event)", "window:dragend": "onWindowDragEnd($event)", "window:drop": "onWindowDrop($event)" }, properties: { "class.sat-upload-field-dragging": "isDragging()" }, classAttribute: "sat-upload-field" }, queries: [{ propertyName: "fileInput", first: true, predicate: SatUploadFieldInputDirective, descendants: true, read: ElementRef, isSignal: true }, { propertyName: "hints", predicate: MatHint, read: ElementRef, isSignal: true }, { propertyName: "errors", predicate: MatError, read: ElementRef, isSignal: true }, { propertyName: "_labelChild", first: true, predicate: MatLabel, descendants: true, isSignal: true }], viewQueries: [{ propertyName: "fileStatus", first: true, predicate: ["fileStatus"], descendants: true, isSignal: true }], ngImport: i0, template: "@if (hasLabel()) {\n  <label [attr.for]=\"fileInput()?.nativeElement.id\" class=\"sat-upload-field-label\">\n    <ng-content select=\"mat-label\"></ng-content>\n    <!--\n      We set the required marker as a separate element, in order to make it easier to target if\n      apps want to override it and to be able to set `aria-hidden` so that screen readers don't\n      pick it up.\n    -->\n    @if (required()) {\n      <span aria-hidden=\"true\" class=\"sat-upload-field-required-marker\"></span>\n    }\n  </label>\n}\n<button\n  type=\"button\"\n  satUpload\n  matRipple\n  matRippleColor=\"color-mix(in srgb, var(--mat-sys-primary) 8%, transparent)\"\n  [input]=\"fileInput()?.nativeElement\"\n  (filesLoaded)=\"filesLoaded.emit($event)\"\n  [disabled]=\"disabled()\"\n  class=\"sat-upload-field-interactive\"\n  [attr.aria-describedby]=\"buttonDescribedBy()\"\n  [attr.aria-invalid]=\"isInvalid() || null\"\n>\n  <ng-content select=\"img\"></ng-content>\n  <ng-content select=\"mat-icon, svg\"></ng-content>\n  <ng-content>\n    <span>{{ 'sat-preview.upload-field.browse-or-drop' | translate }}</span>\n  </ng-content>\n  <ng-content select=\"mat-hint\"></ng-content>\n</button>\n<div #fileStatus [id]=\"fileStatusId\" aria-live=\"polite\" class=\"cdk-visually-hidden\">\n  @if (fileStatusContents(); as fileStatusContents) {\n    {{ 'sat-preview.upload-field.files-loaded' | translate : { files: fileStatusContents } }}\n  }\n</div>\n<ng-content select=\"input[type=file]\"></ng-content>\n<div class=\"sat-upload-field-error-wrapper\" aria-atomic=\"true\" aria-live=\"polite\">\n  <ng-content select=\"mat-error, [matError]\"></ng-content>\n</div>\n", styles: [".sat-upload-field{display:flex;gap:4px;flex-direction:column}.sat-upload-field-label{display:block;color:var(--mat-sys-on-surface-variant);font:var(--mat-sys-body-large)}.sat-upload-field-label:has(+.sat-upload-field-interactive:disabled){opacity:.38}.sat-upload-field-label:has(+.sat-upload-field-interactive.sat-upload-dragging),.sat-upload-field-label:has(+.sat-upload-field-interactive:focus-visible){color:var(--mat-sys-primary)}.sat-upload-field-required-marker:after{content:\"*\";margin-inline-start:1px;margin-inline-end:0}.sat-upload-field-interactive{appearance:none;display:flex;flex-direction:column;justify-content:center;width:var(--sat-upload-field-button-width, auto);height:var(--sat-upload-field-button-height, fit-content);min-height:var(--sat-upload-field-button-min-height, 0);align-items:center;padding:24px 16px;gap:8px;border-radius:var(--sat-upload-field-button-border-radius, var(--mat-sys-corner-medium));background-color:color-mix(in srgb,var(--mat-sys-primary) 8%,transparent);border:2px solid transparent;color:var(--mat-sys-on-surface-variant);outline:none;cursor:pointer}.sat-upload-field-interactive svg{display:block;margin-block-end:16px}.sat-upload-field-interactive img{position:absolute;z-index:1;inset:0;height:100%;width:100%;overflow:hidden;object-fit:cover;transition:opacity .3s ease-in-out}.sat-upload-field-interactive mat-icon,.sat-upload-field-interactive span,.sat-upload-field-interactive mat-hint{position:relative}.sat-upload-field-interactive span{font:var(--mat-sys-body-medium);text-decoration:underline;color:var(--mat-sys-primary);margin:0}.sat-upload-field-interactive mat-hint{font:var(--mat-sys-body-small)}.sat-upload-field-interactive.sat-upload-dragging,.sat-upload-field-interactive:focus-visible{border-color:var(--mat-sys-primary)}.sat-upload-field-interactive:hover{background-color:color-mix(in srgb,var(--mat-sys-primary) 12%,transparent)}.sat-upload-field-interactive:hover img,.sat-upload-field-interactive:focus-visible img,.sat-upload-field-dragging img{z-index:0;opacity:.1}.sat-upload-field-interactive:disabled{cursor:not-allowed;background-color:color-mix(in srgb,var(--mat-sys-on-surface-variant) 8%,transparent);color:var(--mat-sys-on-surface)}.sat-upload-field-interactive:disabled>*{opacity:.38}.sat-upload-field-interactive:disabled span{text-decoration:none;color:inherit}.sat-upload-field-error-wrapper{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font:var(--mat-sys-body-small)}.sat-upload-field-error-wrapper mat-error,.sat-upload-field-error-wrapper .mat-mdc-form-field-error{display:block;color:var(--mat-form-field-error-text-color, var(--mat-sys-error))}.sat-upload-field-error-wrapper mat-error mat-icon,.sat-upload-field-error-wrapper .mat-mdc-form-field-error mat-icon{display:inline-block;vertical-align:baseline;margin-block-start:-2px;margin-block-end:-4px;line-height:18px;width:18px;height:18px}.sat-upload-field-error-wrapper:empty{display:none}\n"], dependencies: [{ kind: "directive", type: SatUploadDirective, selector: "[satUpload]", inputs: ["input"], outputs: ["filesLoaded"], exportAs: ["satUpload"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatRippleModule }, { kind: "directive", type: i1.MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-upload-field', imports: [SatUploadDirective, MatFormFieldModule, MatRippleModule, TranslatePipe], host: {
                        class: 'sat-upload-field',
                        '[class.sat-upload-field-dragging]': 'isDragging()',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "@if (hasLabel()) {\n  <label [attr.for]=\"fileInput()?.nativeElement.id\" class=\"sat-upload-field-label\">\n    <ng-content select=\"mat-label\"></ng-content>\n    <!--\n      We set the required marker as a separate element, in order to make it easier to target if\n      apps want to override it and to be able to set `aria-hidden` so that screen readers don't\n      pick it up.\n    -->\n    @if (required()) {\n      <span aria-hidden=\"true\" class=\"sat-upload-field-required-marker\"></span>\n    }\n  </label>\n}\n<button\n  type=\"button\"\n  satUpload\n  matRipple\n  matRippleColor=\"color-mix(in srgb, var(--mat-sys-primary) 8%, transparent)\"\n  [input]=\"fileInput()?.nativeElement\"\n  (filesLoaded)=\"filesLoaded.emit($event)\"\n  [disabled]=\"disabled()\"\n  class=\"sat-upload-field-interactive\"\n  [attr.aria-describedby]=\"buttonDescribedBy()\"\n  [attr.aria-invalid]=\"isInvalid() || null\"\n>\n  <ng-content select=\"img\"></ng-content>\n  <ng-content select=\"mat-icon, svg\"></ng-content>\n  <ng-content>\n    <span>{{ 'sat-preview.upload-field.browse-or-drop' | translate }}</span>\n  </ng-content>\n  <ng-content select=\"mat-hint\"></ng-content>\n</button>\n<div #fileStatus [id]=\"fileStatusId\" aria-live=\"polite\" class=\"cdk-visually-hidden\">\n  @if (fileStatusContents(); as fileStatusContents) {\n    {{ 'sat-preview.upload-field.files-loaded' | translate : { files: fileStatusContents } }}\n  }\n</div>\n<ng-content select=\"input[type=file]\"></ng-content>\n<div class=\"sat-upload-field-error-wrapper\" aria-atomic=\"true\" aria-live=\"polite\">\n  <ng-content select=\"mat-error, [matError]\"></ng-content>\n</div>\n", styles: [".sat-upload-field{display:flex;gap:4px;flex-direction:column}.sat-upload-field-label{display:block;color:var(--mat-sys-on-surface-variant);font:var(--mat-sys-body-large)}.sat-upload-field-label:has(+.sat-upload-field-interactive:disabled){opacity:.38}.sat-upload-field-label:has(+.sat-upload-field-interactive.sat-upload-dragging),.sat-upload-field-label:has(+.sat-upload-field-interactive:focus-visible){color:var(--mat-sys-primary)}.sat-upload-field-required-marker:after{content:\"*\";margin-inline-start:1px;margin-inline-end:0}.sat-upload-field-interactive{appearance:none;display:flex;flex-direction:column;justify-content:center;width:var(--sat-upload-field-button-width, auto);height:var(--sat-upload-field-button-height, fit-content);min-height:var(--sat-upload-field-button-min-height, 0);align-items:center;padding:24px 16px;gap:8px;border-radius:var(--sat-upload-field-button-border-radius, var(--mat-sys-corner-medium));background-color:color-mix(in srgb,var(--mat-sys-primary) 8%,transparent);border:2px solid transparent;color:var(--mat-sys-on-surface-variant);outline:none;cursor:pointer}.sat-upload-field-interactive svg{display:block;margin-block-end:16px}.sat-upload-field-interactive img{position:absolute;z-index:1;inset:0;height:100%;width:100%;overflow:hidden;object-fit:cover;transition:opacity .3s ease-in-out}.sat-upload-field-interactive mat-icon,.sat-upload-field-interactive span,.sat-upload-field-interactive mat-hint{position:relative}.sat-upload-field-interactive span{font:var(--mat-sys-body-medium);text-decoration:underline;color:var(--mat-sys-primary);margin:0}.sat-upload-field-interactive mat-hint{font:var(--mat-sys-body-small)}.sat-upload-field-interactive.sat-upload-dragging,.sat-upload-field-interactive:focus-visible{border-color:var(--mat-sys-primary)}.sat-upload-field-interactive:hover{background-color:color-mix(in srgb,var(--mat-sys-primary) 12%,transparent)}.sat-upload-field-interactive:hover img,.sat-upload-field-interactive:focus-visible img,.sat-upload-field-dragging img{z-index:0;opacity:.1}.sat-upload-field-interactive:disabled{cursor:not-allowed;background-color:color-mix(in srgb,var(--mat-sys-on-surface-variant) 8%,transparent);color:var(--mat-sys-on-surface)}.sat-upload-field-interactive:disabled>*{opacity:.38}.sat-upload-field-interactive:disabled span{text-decoration:none;color:inherit}.sat-upload-field-error-wrapper{-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased;font:var(--mat-sys-body-small)}.sat-upload-field-error-wrapper mat-error,.sat-upload-field-error-wrapper .mat-mdc-form-field-error{display:block;color:var(--mat-form-field-error-text-color, var(--mat-sys-error))}.sat-upload-field-error-wrapper mat-error mat-icon,.sat-upload-field-error-wrapper .mat-mdc-form-field-error mat-icon{display:inline-block;vertical-align:baseline;margin-block-start:-2px;margin-block-end:-4px;line-height:18px;width:18px;height:18px}.sat-upload-field-error-wrapper:empty{display:none}\n"] }]
        }], propDecorators: { onWindowDragEnter: [{
                type: HostListener,
                args: ['window:dragenter', ['$event']]
            }], onWindowDragLeave: [{
                type: HostListener,
                args: ['window:dragleave', ['$event']]
            }], onWindowDragEnd: [{
                type: HostListener,
                args: ['window:dragend', ['$event']]
            }], onWindowDrop: [{
                type: HostListener,
                args: ['window:drop', ['$event']]
            }] } });

class SatUploadFieldModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadFieldModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatUploadFieldModule, imports: [SatUploadFieldComponent, SatUploadFieldInputDirective], exports: [SatUploadFieldComponent, SatUploadFieldInputDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadFieldModule, imports: [SatUploadFieldComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadFieldModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SatUploadFieldComponent, SatUploadFieldInputDirective],
                    exports: [SatUploadFieldComponent, SatUploadFieldInputDirective],
                    providers: [],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatUploadFieldComponent, SatUploadFieldInputDirective, SatUploadFieldModule };
//# sourceMappingURL=hylandsoftware-satori-preview-upload-field.mjs.map
