import * as i0 from '@angular/core';
import { Pipe, ViewEncapsulation, ChangeDetectionStrategy, Component, input, computed, signal, Injectable, inject, booleanAttribute, ElementRef, output, linkedSignal, viewChild, effect, HostListener, Directive, NgModule } from '@angular/core';
import * as i1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i1$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i2 from '@angular/cdk/menu';
import { CdkMenuModule, CdkMenu, CdkMenuItem } from '@angular/cdk/menu';
import * as i1$2 from '@angular/material/core';
import { MatRippleModule, MatPseudoCheckboxModule, MatRipple } from '@angular/material/core';
import * as i1$3 from '@angular/material/tooltip';
import { MatTooltip, MatTooltipModule } from '@angular/material/tooltip';
import { TranslatePipe } from '@ngx-translate/core';
import { hasModifierKey } from '@angular/cdk/keycodes';
import * as i4 from '@angular/cdk/observers';
import { ObserversModule } from '@angular/cdk/observers';
import { SatAvatarModule } from '@hylandsoftware/satori-ui/avatar';

/**
 * This pipe transforms a name or label into a set of uppercase initials, typically used to display fallback text inside avatar components. It helps maintain a consistent user experience when profile images are not available.
 *
 * > **ℹ️ Note -**
 * > We strongly recommend using the `satPlatformNavInitials` pipe to generate initials for avatars.
 * > This ensures consistent formatting and visual alignment across the navigation item and user profile areas.
 *
 * ```html
 * <sat-platform-nav-avatar>
 *   {{ user.name | satPlatformNavInitials }}
 * </sat-platform-nav-avatar>
 * ```
 *
 * **How It Works**
 *
 * - Extracts the first letter of each word (default: up to 2 words).
 * - For single-word names, returns the first two characters.
 * - Trims whitespace and safely handles empty or invalid strings.
 *
 * **Example Outputs**
 *
 * | Input          | Output |
 * | -------------- | ------ |
 * | John Doe       | JD     |
 * | Mary Ann Smith | MA     |
 * | " "            | ""     |
 *
 * **Optional Parameter**
 *
 * You can pass an optional maxWords parameter to control how many words are considered -
 *
 * ```html
 * <sat-platform-nav-avatar>
 *   {{ 'John David Smith' | satPlatformNavInitials: 1 }} <!-- Output: J -->
 * </sat-platform-nav-avatar>
 * ```
 */
class SatPlatformNavInitialsPipe {
    _maxWords = 2;
    /**
     * Transforms a name string into initials by taking the first letter
     * of each word (up to the first two words).
     *
     * @param value The name to transform into initials
     * @param maxWords Optional parameter to specify maximum number of words to use (default: 2)
     * @returns The generated initials as uppercase letters
     */
    transform(value, maxWords = this._maxWords) {
        if (!value || typeof value !== 'string')
            return '';
        const trimmedValue = value.trim();
        if (!trimmedValue)
            return '';
        const words = trimmedValue.split(/\s+/).slice(0, maxWords);
        if (words.length === 1) {
            return words[0].substring(0, maxWords).toUpperCase();
        }
        else {
            return words.map(word => word.charAt(0).toUpperCase()).join('');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavInitialsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavInitialsPipe, isStandalone: true, name: "satPlatformNavInitials" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavInitialsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'satPlatformNavInitials',
                    pure: true,
                }]
        }] });

/**
 * This component is a structural wrapper used to project and style app-icon content within a navigation menu item. This is an internal component that is not intended for direct use outside of the platform navigation context.
 *
 * Key features:
 * - Is typically used inside a nav menu item to display a user’s avatar or an associated icon.
 * - Relies entirely on content projection for flexibility.
 *
 * @internal
 */
class SatPlatformNavAppIconComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavAppIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatPlatformNavAppIconComponent, isStandalone: true, selector: "sat-platform-nav-app-icon", ngImport: i0, template: `
    <span class="sat-platform-nav-app-icon">
      <ng-content></ng-content>
    </span>
  `, isInline: true, styles: [".sat-platform-nav-app-icon{font-family:var(--sat-platform-nav-label-medium-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-label-medium-size, .75rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-medium-line-height, 1rem);letter-spacing:var(--sat-platform-nav-label-medium-tracking, .0031rem);display:flex;justify-content:center;align-items:center;width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px);border-radius:var(--sat-platform-nav-corner-extra-small, 4px);background-color:var(--sat-platform-nav-app-icon-color);color:var(--sat-platform-nav-on-background)}.sat-platform-nav-app-icon img{border-radius:var(--sat-platform-nav-corner-extra-small, 4px);aspect-ratio:1/1;object-fit:contain}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavAppIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-app-icon', template: `
    <span class="sat-platform-nav-app-icon">
      <ng-content></ng-content>
    </span>
  `, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: [".sat-platform-nav-app-icon{font-family:var(--sat-platform-nav-label-medium-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-label-medium-size, .75rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-medium-line-height, 1rem);letter-spacing:var(--sat-platform-nav-label-medium-tracking, .0031rem);display:flex;justify-content:center;align-items:center;width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px);border-radius:var(--sat-platform-nav-corner-extra-small, 4px);background-color:var(--sat-platform-nav-app-icon-color);color:var(--sat-platform-nav-on-background)}.sat-platform-nav-app-icon img{border-radius:var(--sat-platform-nav-corner-extra-small, 4px);aspect-ratio:1/1;object-fit:contain}\n"] }]
        }] });

/**
 * The `SatPlatformNavAvatarComponent` displays an avatar in the platform navigation.
 * It supports rendering an icon, image, or initials based on the provided navigation item.
 *
 * - If the navigation item has an `icon`, it renders a Material icon.
 * - If the navigation item has an `image`, it renders the image inside a custom app icon component.
 * - Otherwise, it renders the initials derived from the navigation item's label.
 */
class SatPlatformNavAvatarComponent {
    /**
     * The navigation item associated with this avatar.
     */
    item = input.required();
    /** @internal */
    icon = computed(() => {
        const item = this.item();
        return item && this.itemIsSatNavigationItemWithIcon(item) ? item.icon : null;
    });
    /** @internal */
    image = computed(() => {
        const item = this.item();
        return item && this.itemIsSatNavigationItemWithImage(item) ? item.image : null;
    });
    itemIsSatNavigationItemWithIcon(item) {
        return 'icon' in item && typeof item.icon === 'string';
    }
    itemIsSatNavigationItemWithImage(item) {
        return 'image' in item && typeof item.image === 'string';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatPlatformNavAvatarComponent, isStandalone: true, selector: "sat-platform-nav-avatar", inputs: { item: { classPropertyName: "item", publicName: "item", isSignal: true, isRequired: true, transformFunction: null } }, host: { classAttribute: "sat-platform-nav-avatar" }, ngImport: i0, template: `
    @if (icon()) {
      <mat-icon svgIcon="{{ icon() }}"></mat-icon>
    } @else if (image()) {
      <sat-platform-nav-app-icon>
        <img [src]="image()" [alt]="item().label" />
      </sat-platform-nav-app-icon>
    } @else {
      <sat-platform-nav-app-icon>{{ item().label | satPlatformNavInitials }}</sat-platform-nav-app-icon>
    }
  `, isInline: true, styles: [".sat-platform-nav-avatar{display:flex;justify-content:center;align-items:center;width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px)}.sat-platform-nav-avatar img{width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px)}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: SatPlatformNavAppIconComponent, selector: "sat-platform-nav-app-icon" }, { kind: "pipe", type: SatPlatformNavInitialsPipe, name: "satPlatformNavInitials" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavAvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-avatar', host: {
                        class: 'sat-platform-nav-avatar',
                    }, template: `
    @if (icon()) {
      <mat-icon svgIcon="{{ icon() }}"></mat-icon>
    } @else if (image()) {
      <sat-platform-nav-app-icon>
        <img [src]="image()" [alt]="item().label" />
      </sat-platform-nav-app-icon>
    } @else {
      <sat-platform-nav-app-icon>{{ item().label | satPlatformNavInitials }}</sat-platform-nav-app-icon>
    }
  `, imports: [MatIconModule, SatPlatformNavAppIconComponent, SatPlatformNavInitialsPipe], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: [".sat-platform-nav-avatar{display:flex;justify-content:center;align-items:center;width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px)}.sat-platform-nav-avatar img{width:var(--sat-platform-nav-width-medium, 28px);height:var(--sat-platform-nav-height-medium, 28px)}\n"] }]
        }] });

/**
 * This service manages the state of the Platform Nav sidebar.
 * It provides methods to toggle the collapsed state.
 */
class SatPlatformNavStateService {
    _collapsed = signal(true);
    /**
     * @internal
     * Whether the sidebar is currently collapsed.
     * You can use this in templates or components to update the UI.
     */
    collapsed = computed(() => this._collapsed());
    /**
     * Call this to toggle the sidebar between collapsed and expanded.
     */
    toggleCollapsed() {
        this._collapsed.update(() => !this._collapsed());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavStateService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavStateService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/**
 * @internal
 * This component provides a "Skip to main content" link that allows users to bypass navigation links and go directly to the main content of the page.
 * It is particularly useful for improving accessibility for keyboard and screen reader users.
 */
class SatSkipToContentComponent {
    /** @internal */
    visible = signal(false);
    /** @internal */
    display() {
        this.visible.set(true);
    }
    /** @internal */
    hide() {
        this.visible.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatSkipToContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatSkipToContentComponent, isStandalone: true, selector: "sat-skip-to-content", ngImport: i0, template: `
    <a
      mat-raised-button
      href="#main-content"
      tabindex="0"
      class="sat-skip-to-content-button"
      [class.sat-skip-to-content-button-visible]="visible()"
      (focus)="display()"
      (blur)="hide()"
    >
      Skip to main content
    </a>
  `, isInline: true, styles: [".sat-skip-to-content-button{position:absolute;top:-100%;left:-100%;z-index:2000;opacity:0}\n", ".sat-skip-to-content-button-visible{position:fixed;top:24px;left:24px;opacity:100}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatAnchor, selector: "a[mat-button], a[mat-raised-button], a[mat-flat-button], a[mat-stroked-button]", exportAs: ["matButton", "matAnchor"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatSkipToContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-skip-to-content', template: `
    <a
      mat-raised-button
      href="#main-content"
      tabindex="0"
      class="sat-skip-to-content-button"
      [class.sat-skip-to-content-button-visible]="visible()"
      (focus)="display()"
      (blur)="hide()"
    >
      Skip to main content
    </a>
  `, imports: [MatButtonModule], changeDetection: ChangeDetectionStrategy.OnPush, styles: [".sat-skip-to-content-button{position:absolute;top:-100%;left:-100%;z-index:2000;opacity:0}\n", ".sat-skip-to-content-button-visible{position:fixed;top:24px;left:24px;opacity:100}\n"] }]
        }] });

/**
 * This component defines the structural layout for vertical navigation-based applications. It enhances accessibility by supporting a "Skip to Content" feature and allows for flexible content projection. This enables developers to inject key layout elements—such as navigation sidebars and main content areas—while maintaining a clean and organized layout hierarchy.
 *
 * Key features:
 * - Displays a `sat-skip-to-content` element to allow users to quickly skip to the main content for better accessibility.
 * - Projects a `sat-platform-nav` element, typically used for the sidebar or navigation menu.
 * - Projects a `sat-platform-nav-main-content` element, typically used for the application’s main content area.
 * - Defines the main content container with `id="main-content"`, which serves as the target for skip-to-content navigation.
 *
 * @example
 * <sat-platform-nav-container>
 *   <sat-platform-nav>
 *     …
 *   </sat-platform-nav>
 *   <sat-platform-nav-main-content></sat-platform-nav-main-content>
 * </sat-platform-nav-container>
 *
 */
class SatPlatformNavContainerComponent {
    /** @internal */
    service = inject(SatPlatformNavStateService);
    /** @internal */
    closePlatformNav() {
        if (!this.service.collapsed()) {
            this.service.toggleCollapsed();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatPlatformNavContainerComponent, isStandalone: true, selector: "sat-platform-nav-container", host: { classAttribute: "sat-platform-nav-container" }, ngImport: i0, template: `
    <sat-skip-to-content></sat-skip-to-content>
    @if(!service.collapsed()) {
      <div class="sat-platform-nav-backdrop" tabindex="0" (click)="closePlatformNav()" (keypress)="closePlatformNav()"></div>
    }
    <ng-content select="sat-platform-nav"></ng-content>
    <!-- Element ID used by SatSkipToContentComponent: -->
    <main id="main-content" class="sat-platform-nav-main-content" [class.sat-platform-nav-prevent-pointer]="!service.collapsed()">
      <ng-content select="sat-platform-nav-main-content"></ng-content>
    </main>
  `, isInline: true, styles: [".sat-platform-nav-container{height:100vh;width:-webkit-fill-available;width:-moz-available;width:stretch;display:flex}.sat-platform-nav-main-content{flex-grow:1;height:100vh;overflow:auto;margin-left:var(--sat-platform-nav-collapsed-width, 56px)}@media(width<=675px){.sat-platform-nav-main-content{margin-left:0}}.sat-platform-nav-prevent-pointer{pointer-events:none}.sat-platform-nav-backdrop{position:fixed;top:0;left:0;width:100vw;height:100vh;background-color:color-mix(in srgb,var(--mat-sys-scrim, #000) 32%,transparent);z-index:999;transition:opacity var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1));cursor:pointer;pointer-events:auto}\n"], dependencies: [{ kind: "component", type: SatSkipToContentComponent, selector: "sat-skip-to-content" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-container', host: { class: 'sat-platform-nav-container' }, template: `
    <sat-skip-to-content></sat-skip-to-content>
    @if(!service.collapsed()) {
      <div class="sat-platform-nav-backdrop" tabindex="0" (click)="closePlatformNav()" (keypress)="closePlatformNav()"></div>
    }
    <ng-content select="sat-platform-nav"></ng-content>
    <!-- Element ID used by SatSkipToContentComponent: -->
    <main id="main-content" class="sat-platform-nav-main-content" [class.sat-platform-nav-prevent-pointer]="!service.collapsed()">
      <ng-content select="sat-platform-nav-main-content"></ng-content>
    </main>
  `, encapsulation: ViewEncapsulation.None, imports: [SatSkipToContentComponent], changeDetection: ChangeDetectionStrategy.OnPush, styles: [".sat-platform-nav-container{height:100vh;width:-webkit-fill-available;width:-moz-available;width:stretch;display:flex}.sat-platform-nav-main-content{flex-grow:1;height:100vh;overflow:auto;margin-left:var(--sat-platform-nav-collapsed-width, 56px)}@media(width<=675px){.sat-platform-nav-main-content{margin-left:0}}.sat-platform-nav-prevent-pointer{pointer-events:none}.sat-platform-nav-backdrop{position:fixed;top:0;left:0;width:100vw;height:100vh;background-color:color-mix(in srgb,var(--mat-sys-scrim, #000) 32%,transparent);z-index:999;transition:opacity var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1));cursor:pointer;pointer-events:auto}\n"] }]
        }] });

/** @internal */
class SatPlatformNavEnvironmentSwitcherItemComponent {
    /**
     * The value of the switcher item, which is used to identify the selected environment.
     */
    value = input.required();
    /**
     * Denotes whether the switcher item is currently active/selected.
     */
    active = input(false);
    /**
     * Denotes whether the switcher item is disabled.
     */
    disabled = input(false, { transform: booleanAttribute });
    _element = inject(ElementRef);
    /**
     * Event to notify parent when this item is clicked
     */
    selectionChange = output();
    /** @internal */
    onSelectionChange() {
        if (!this.disabled() && !this.active()) {
            // Emit the selection change event
            this.selectionChange.emit(this.value());
        }
    }
    /**
     * @internal
     * Handles keyboard interaction for accessibility:
     * Only responds to Enter and Space keys to select the option.
     */
    handleKeydown(event) {
        if (!this.disabled() &&
            !this.active() &&
            (event.code === 'Enter' || event.code === 'Space') &&
            !hasModifierKey(event)) {
            this.onSelectionChange();
            // Prevent the page from scrolling down and form submits.
            event.preventDefault();
        }
    }
    /** Gets the host DOM element. */
    _getHostElement() {
        return this._element.nativeElement;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavEnvironmentSwitcherItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatPlatformNavEnvironmentSwitcherItemComponent, isStandalone: true, selector: "sat-platform-nav-switcher-item", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange" }, host: { attributes: { "role": "option", "tabindex": "0" }, listeners: { "click": "onSelectionChange()", "keydown": "handleKeydown($event)" }, properties: { "attr.id": "value()", "attr.aria-selected": "active()", "attr.aria-disabled": "disabled()", "class.sat-platform-nav-switcher-item--selected": "active()", "class.sat-platform-nav-switcher-item--active": "active()", "class.sat-platform-nav-switcher-item--disabled": "disabled()" }, classAttribute: "sat-platform-nav-switcher-item" }, ngImport: i0, template: `
    <span class="sat-platform-nav-switcher-item-content">
      <ng-content></ng-content>
    </span>
    @if (active()) {
      <mat-pseudo-checkbox
        [disabled]="disabled()"
        state="checked"
        aria-hidden="true"
        appearance="minimal"
      ></mat-pseudo-checkbox>
    }

    <div class="sat-environment-switcher-item-ripple" aria-hidden="true" mat-ripple
      [matRippleTrigger]="_getHostElement()" [matRippleDisabled]="disabled()"></div>
  `, isInline: true, styles: [".sat-platform-nav-switcher-item{display:flex;justify-content:space-between;align-items:center;min-height:48px;padding:4px 16px;position:relative;color:var(--sat-platform-nav-on-surface);box-sizing:border-box;cursor:pointer;-webkit-user-select:none;user-select:none}.sat-platform-nav-switcher-item .sat-platform-nav-switcher-item-content{font-family:var(--sat-platform-nav-title-font, \"Noto Sans\", sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;font-weight:400;line-height:var(--sat-platform-nav-body-large-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-body-large-tracking, .031rem)}.sat-platform-nav-switcher-item .mat-pseudo-checkbox{margin-left:var(--sat-platform-nav-gap-large, 16px);flex-shrink:0}.sat-platform-nav-switcher-item:hover:not(.sat-platform-nav-switcher-item--disabled){background:var(--sat-environment-switcher-hover-layer-color)}.sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--active:not(.sat-platform-nav-switcher-item--disabled){background:var(--sat-platform-nav-secondary-container);color:var(--sat-platform-nav-on-secondary-container)}.sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--disabled{cursor:default;pointer-events:none}.sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--disabled .sat-platform-nav-switcher-item-content{opacity:.38}.mat-ripple.sat-environment-switcher-item-ripple{inset:0;position:absolute;pointer-events:none}\n"], dependencies: [{ kind: "ngmodule", type: MatRippleModule }, { kind: "directive", type: i1$2.MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "ngmodule", type: MatPseudoCheckboxModule }, { kind: "component", type: i1$2.MatPseudoCheckbox, selector: "mat-pseudo-checkbox", inputs: ["state", "disabled", "appearance"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavEnvironmentSwitcherItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-switcher-item', host: {
                        'role': 'option',
                        'tabindex': '0',
                        '[attr.id]': 'value()',
                        '[attr.aria-selected]': 'active()',
                        '[attr.aria-disabled]': 'disabled()',
                        '[class.sat-platform-nav-switcher-item--selected]': 'active()',
                        '[class.sat-platform-nav-switcher-item--active]': 'active()',
                        '[class.sat-platform-nav-switcher-item--disabled]': 'disabled()',
                        '(click)': 'onSelectionChange()',
                        '(keydown)': 'handleKeydown($event)',
                        'class': 'sat-platform-nav-switcher-item',
                    }, imports: [MatRippleModule, MatPseudoCheckboxModule], template: `
    <span class="sat-platform-nav-switcher-item-content">
      <ng-content></ng-content>
    </span>
    @if (active()) {
      <mat-pseudo-checkbox
        [disabled]="disabled()"
        state="checked"
        aria-hidden="true"
        appearance="minimal"
      ></mat-pseudo-checkbox>
    }

    <div class="sat-environment-switcher-item-ripple" aria-hidden="true" mat-ripple
      [matRippleTrigger]="_getHostElement()" [matRippleDisabled]="disabled()"></div>
  `, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: [".sat-platform-nav-switcher-item{display:flex;justify-content:space-between;align-items:center;min-height:48px;padding:4px 16px;position:relative;color:var(--sat-platform-nav-on-surface);box-sizing:border-box;cursor:pointer;-webkit-user-select:none;user-select:none}.sat-platform-nav-switcher-item .sat-platform-nav-switcher-item-content{font-family:var(--sat-platform-nav-title-font, \"Noto Sans\", sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;font-weight:400;line-height:var(--sat-platform-nav-body-large-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-body-large-tracking, .031rem)}.sat-platform-nav-switcher-item .mat-pseudo-checkbox{margin-left:var(--sat-platform-nav-gap-large, 16px);flex-shrink:0}.sat-platform-nav-switcher-item:hover:not(.sat-platform-nav-switcher-item--disabled){background:var(--sat-environment-switcher-hover-layer-color)}.sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--active:not(.sat-platform-nav-switcher-item--disabled){background:var(--sat-platform-nav-secondary-container);color:var(--sat-platform-nav-on-secondary-container)}.sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--disabled{cursor:default;pointer-events:none}.sat-platform-nav-switcher-item.sat-platform-nav-switcher-item--disabled .sat-platform-nav-switcher-item-content{opacity:.38}.mat-ripple.sat-environment-switcher-item-ripple{inset:0;position:absolute;pointer-events:none}\n"] }]
        }] });

/**
 * This component is used to display a switcher which allows the user to switch between different environments within the Platform Nav. It allows users to select their current working environment easily.
 */
class SatPlatformNavEnvironmentSwitcherComponent {
    /**
     * The currently selected environment.
     * This should match the `value` property of one of the provided environment objects.
     */
    value = input.required();
    /**
     * The available environments.
     * This input is required and should be provided with an array of environment objects.
     */
    environments = input.required();
    /**
     * Denotes whether the switcher is disabled.
     */
    disabled = input(false, { transform: booleanAttribute });
    /**
     * An event emitted when the environment is changed.
     * The value emitted is the currently selected environment.
     * @type SatPlatformNavEnvironmentType
     */
    environmentChange = output();
    /** @internal */
    satPlatformNavStateService = inject(SatPlatformNavStateService);
    /**
     * @internal User selection takes precedence over the initial selection.
     */
    selectedEnv = linkedSignal(() => {
        return this.environments()?.find((env) => env.value === this.value());
    });
    /**
     * @internal
     * Handle option selection
     */
    onSelect(environment) {
        if (!this.disabled()) {
            const wasSelected = this.selectedEnv()?.value === environment.value;
            const isEnvironmentInList = this.environments().some((env) => env.value === environment.value);
            if (isEnvironmentInList && !wasSelected) {
                this.selectedEnv.set(environment);
                this._propagateChanges();
            }
        }
    }
    // Propagates the selected environment change to the output event.
    _propagateChanges() {
        const selectedEnv = this.selectedEnv();
        if (selectedEnv) {
            this.environmentChange.emit(selectedEnv);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavEnvironmentSwitcherComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatPlatformNavEnvironmentSwitcherComponent, isStandalone: true, selector: "sat-platform-nav-switcher", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, environments: { classPropertyName: "environments", publicName: "environments", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { environmentChange: "environmentChange" }, host: { properties: { "attr.tabindex": "-1" } }, ngImport: i0, template: "<button\n  matRipple\n  matRippleColor=\"var(--sat-sys-on-primary-opacity-12)\"\n  id=\"sat-platform-nav-env-switcher-button\"\n  aria-haspopup=\"listbox\"\n  [attr.aria-expanded]=\"trigger.isOpen()\"\n  aria-controls=\"sat-platform-nav-env-switcher-menu\"\n  [attr.aria-label]=\"'sat-preview.platform-nav.environment-switcher.trigger-label' | translate\"\n  aria-describedby=\"sat-platform-nav-env-switcher-button-value\"\n  [matTooltip]=\"\n    satPlatformNavStateService.collapsed() && selectedEnv()\n    ? ('sat-preview.platform-nav.environment-switcher.trigger-tooltip-prefix' | translate)  + selectedEnv()?.label\n    : null\n  \"\n  matTooltipPosition=\"right\"\n  tabindex=\"0\"\n  [cdkMenuTriggerFor]=\"switcherMenu\"\n  [disabled]=\"disabled()\"\n  #trigger=\"cdkMenuTriggerFor\"\n  class=\"sat-platform-nav-switcher-button sat-platform-nav-item\"\n  [class.sat-platform-nav-switcher-button--disabled]=\"disabled()\"\n>\n  <div class=\"sat-platform-nav-switcher-button-text\">\n    <div class=\"sat-platform-nav-icon\">\n      <mat-icon svgIcon=\"cloud\" aria-hidden=\"true\"></mat-icon>\n    </div>\n\n    @if (!satPlatformNavStateService.collapsed()) {\n      <div class=\"sat-platform-nav-switcher-button-name\">\n        <span\n          class=\"sat-platform-nav-switcher-button-label\"\n          id=\"sat-platform-nav-env-switcher-button-label\"\n        >\n          {{ 'sat-preview.platform-nav.environment-switcher.trigger-label' | translate }}\n        </span>\n        <span\n          class=\"sat-platform-nav-switcher-button-value\"\n          id=\"sat-platform-nav-env-switcher-button-value\"\n        >\n          {{selectedEnv()?.label}}\n        </span>\n      </div>\n    }\n  </div>\n\n  <mat-icon\n    class=\"sat-platform-nav-switcher-button-suffix-icon\"\n    svgIcon=\"arrow_submenu_down\"\n    aria-hidden=\"true\"\n    iconPositionEnd\n  >\n  </mat-icon>\n</button>\n\n<ng-template #switcherMenu>\n  <div\n    cdkMenu\n    role=\"listbox\"\n    aria-multiselectable=\"false\"\n    [attr.aria-activedescendant]=\"selectedEnv()?.value\"\n    aria-labelledby=\"sat-platform-nav-env-switcher-button-label\"\n    id=\"sat-platform-nav-env-switcher-menu\"\n    [class.sat-platform-nav-switcher-menu--expanded]=\"!satPlatformNavStateService.collapsed()\"\n    class=\"sat-platform-nav-switcher-menu\"\n  >\n    <div cdkMenuGroup style=\"width: 100%;\">\n      @for (environment of environments(); track environment) {\n        <sat-platform-nav-switcher-item\n          cdkMenuItemRadio\n          [id]=\"environment.value\"\n          [value]=\"environment.value\"\n          [disabled]=\"environment.disabled\"\n          [active]=\"selectedEnv()?.value === environment.value\"\n          (selectionChange)=\"onSelect(environment)\"\n        >\n          {{ environment.label }}\n        </sat-platform-nav-switcher-item>\n      }\n    </div>\n  </div>\n</ng-template>\n", styles: [".sat-platform-nav-switcher-button{height:56px;gap:0;border-radius:0;width:100%;padding:4px 3px 4px 14px;background-color:var(--sat-platform-nav-primary-loud);color:var(--sat-platform-nav-on-background)}.sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text{display:flex;align-items:center;gap:12px;flex-grow:1}.sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name{display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name .sat-platform-nav-switcher-button-label{font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-body-small-size, .75rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-medium-line-height, 1rem);letter-spacing:var(--sat-platform-nav-label-medium-tracking, .031rem);-webkit-user-select:none;user-select:none}.sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name .sat-platform-nav-switcher-button-value{font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;width:100%;font-weight:400;text-align:left;line-height:var(--sat-platform-nav-body-large-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-body-large-tracking, .031rem);white-space:nowrap;overflow:hidden;-webkit-user-select:none;user-select:none;text-overflow:ellipsis}.sat-platform-nav-switcher-button--disabled{cursor:default;pointer-events:none;opacity:.38}.mat-icon.sat-platform-nav-switcher-button-suffix-icon{margin-left:-5px;width:16px;height:16px;flex-shrink:0}.sat-platform-nav-switcher-menu{display:flex;flex-direction:column;padding:8px 0;align-items:flex-start;align-self:stretch;border-radius:4px;min-width:112px;max-width:600px;background:var(--sat-platform-nav-surface-container);box-shadow:var(--sat-platform-nav-switcher-menu-container-elevation-shadow)}.sat-platform-nav-switcher-menu--expanded{min-width:300px;max-width:600px}\n"], dependencies: [{ kind: "directive", type: MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: CdkMenuModule }, { kind: "directive", type: i2.CdkMenu, selector: "[cdkMenu]", outputs: ["closed"], exportAs: ["cdkMenu"] }, { kind: "directive", type: i2.CdkMenuItemRadio, selector: "[cdkMenuItemRadio]", exportAs: ["cdkMenuItemRadio"] }, { kind: "directive", type: i2.CdkMenuTrigger, selector: "[cdkMenuTriggerFor]", inputs: ["cdkMenuTriggerFor", "cdkMenuPosition", "cdkMenuTriggerData"], outputs: ["cdkMenuOpened", "cdkMenuClosed"], exportAs: ["cdkMenuTriggerFor"] }, { kind: "directive", type: i2.CdkMenuGroup, selector: "[cdkMenuGroup]", exportAs: ["cdkMenuGroup"] }, { kind: "component", type: SatPlatformNavEnvironmentSwitcherItemComponent, selector: "sat-platform-nav-switcher-item", inputs: ["value", "active", "disabled"], outputs: ["selectionChange"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavEnvironmentSwitcherComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-switcher', host: {
                        '[attr.tabindex]': '-1',
                    }, imports: [
                        MatRipple,
                        MatButtonModule,
                        MatIconModule,
                        MatTooltip,
                        CdkMenuModule,
                        SatPlatformNavEnvironmentSwitcherItemComponent,
                        TranslatePipe,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<button\n  matRipple\n  matRippleColor=\"var(--sat-sys-on-primary-opacity-12)\"\n  id=\"sat-platform-nav-env-switcher-button\"\n  aria-haspopup=\"listbox\"\n  [attr.aria-expanded]=\"trigger.isOpen()\"\n  aria-controls=\"sat-platform-nav-env-switcher-menu\"\n  [attr.aria-label]=\"'sat-preview.platform-nav.environment-switcher.trigger-label' | translate\"\n  aria-describedby=\"sat-platform-nav-env-switcher-button-value\"\n  [matTooltip]=\"\n    satPlatformNavStateService.collapsed() && selectedEnv()\n    ? ('sat-preview.platform-nav.environment-switcher.trigger-tooltip-prefix' | translate)  + selectedEnv()?.label\n    : null\n  \"\n  matTooltipPosition=\"right\"\n  tabindex=\"0\"\n  [cdkMenuTriggerFor]=\"switcherMenu\"\n  [disabled]=\"disabled()\"\n  #trigger=\"cdkMenuTriggerFor\"\n  class=\"sat-platform-nav-switcher-button sat-platform-nav-item\"\n  [class.sat-platform-nav-switcher-button--disabled]=\"disabled()\"\n>\n  <div class=\"sat-platform-nav-switcher-button-text\">\n    <div class=\"sat-platform-nav-icon\">\n      <mat-icon svgIcon=\"cloud\" aria-hidden=\"true\"></mat-icon>\n    </div>\n\n    @if (!satPlatformNavStateService.collapsed()) {\n      <div class=\"sat-platform-nav-switcher-button-name\">\n        <span\n          class=\"sat-platform-nav-switcher-button-label\"\n          id=\"sat-platform-nav-env-switcher-button-label\"\n        >\n          {{ 'sat-preview.platform-nav.environment-switcher.trigger-label' | translate }}\n        </span>\n        <span\n          class=\"sat-platform-nav-switcher-button-value\"\n          id=\"sat-platform-nav-env-switcher-button-value\"\n        >\n          {{selectedEnv()?.label}}\n        </span>\n      </div>\n    }\n  </div>\n\n  <mat-icon\n    class=\"sat-platform-nav-switcher-button-suffix-icon\"\n    svgIcon=\"arrow_submenu_down\"\n    aria-hidden=\"true\"\n    iconPositionEnd\n  >\n  </mat-icon>\n</button>\n\n<ng-template #switcherMenu>\n  <div\n    cdkMenu\n    role=\"listbox\"\n    aria-multiselectable=\"false\"\n    [attr.aria-activedescendant]=\"selectedEnv()?.value\"\n    aria-labelledby=\"sat-platform-nav-env-switcher-button-label\"\n    id=\"sat-platform-nav-env-switcher-menu\"\n    [class.sat-platform-nav-switcher-menu--expanded]=\"!satPlatformNavStateService.collapsed()\"\n    class=\"sat-platform-nav-switcher-menu\"\n  >\n    <div cdkMenuGroup style=\"width: 100%;\">\n      @for (environment of environments(); track environment) {\n        <sat-platform-nav-switcher-item\n          cdkMenuItemRadio\n          [id]=\"environment.value\"\n          [value]=\"environment.value\"\n          [disabled]=\"environment.disabled\"\n          [active]=\"selectedEnv()?.value === environment.value\"\n          (selectionChange)=\"onSelect(environment)\"\n        >\n          {{ environment.label }}\n        </sat-platform-nav-switcher-item>\n      }\n    </div>\n  </div>\n</ng-template>\n", styles: [".sat-platform-nav-switcher-button{height:56px;gap:0;border-radius:0;width:100%;padding:4px 3px 4px 14px;background-color:var(--sat-platform-nav-primary-loud);color:var(--sat-platform-nav-on-background)}.sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text{display:flex;align-items:center;gap:12px;flex-grow:1}.sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name{display:flex;flex-direction:column;justify-content:center;align-items:flex-start}.sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name .sat-platform-nav-switcher-button-label{font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-body-small-size, .75rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-label-medium-line-height, 1rem);letter-spacing:var(--sat-platform-nav-label-medium-tracking, .031rem);-webkit-user-select:none;user-select:none}.sat-platform-nav-switcher-button .sat-platform-nav-switcher-button-text .sat-platform-nav-switcher-button-name .sat-platform-nav-switcher-button-value{font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;width:100%;font-weight:400;text-align:left;line-height:var(--sat-platform-nav-body-large-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-body-large-tracking, .031rem);white-space:nowrap;overflow:hidden;-webkit-user-select:none;user-select:none;text-overflow:ellipsis}.sat-platform-nav-switcher-button--disabled{cursor:default;pointer-events:none;opacity:.38}.mat-icon.sat-platform-nav-switcher-button-suffix-icon{margin-left:-5px;width:16px;height:16px;flex-shrink:0}.sat-platform-nav-switcher-menu{display:flex;flex-direction:column;padding:8px 0;align-items:flex-start;align-self:stretch;border-radius:4px;min-width:112px;max-width:600px;background:var(--sat-platform-nav-surface-container);box-shadow:var(--sat-platform-nav-switcher-menu-container-elevation-shadow)}.sat-platform-nav-switcher-menu--expanded{min-width:300px;max-width:600px}\n"] }]
        }] });

/**
 * A container component for platform navigation menu items.
 * This component provides a structured wrapper for navigation items within the platform navigation.
 */
class SatPlatformNavMenuComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatPlatformNavMenuComponent, isStandalone: true, selector: "sat-platform-nav-menu", host: { attributes: { "role": "menubar" }, classAttribute: "sat-platform-nav-menu" }, hostDirectives: [{ directive: i2.CdkMenu }], ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavMenuComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-platform-nav-menu',
                    template: `<ng-content></ng-content>`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    hostDirectives: [CdkMenu],
                    host: {
                        role: 'menubar',
                        class: 'sat-platform-nav-menu',
                    },
                }]
        }] });

/** @internal */
class SatPlatformNavTooltipService {
    _tooltipShownFirst = signal(false);
    /**
     * Whether the tooltip has already been shown.
     * Useful for showing tooltips with a delay only the first time.
     */
    tooltipShownFirst = computed(() => this._tooltipShownFirst());
    /**
     * Currently active tooltip instance.
     * Used to ensure only one tooltip is visible at a time.
     * When a new tooltip is triggered (via focus or hover), the previous one is hidden using this reference.
     */
    activateTooltip = null;
    /**
     * Marks that the tooltip has been shown at least once.
     * Call this after showing your tooltip so it doesn't repeat the delay.
     *
     * @param value A boolean indicating whether the tooltip has already been shown.
     */
    updateTooltipShownFirst(value) {
        this._tooltipShownFirst.set(value);
    }
    /**
     * Updates the currently active tooltip.
     * Call this whenever a tooltip is shown or hidden so the service can manage exclusive visibility.
     *
     * @param tooltip The tooltip instance to set as active, or null to clear it.
     */
    updateActiveTooltip(tooltip) {
        this.activateTooltip = tooltip;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavTooltipService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavTooltipService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavTooltipService, decorators: [{
            type: Injectable
        }] });

/**
 * This element represents an interactive item within the `sat-platform-nav` navigation panel. It supports icons, dynamic avatar generation, active state styling, and responsive behavior based on the collapsed state of the sidebar.
 *
 * The `SatPlatformNavMenuItemComponent` is designed to display a single item in the platform navigation.
 *
 * Key features:
 * - Accepts a projected mat-icon for visual representation of the item.
 * - Automatically generates a fallback avatar (initials-based) if no icon is present, using the SatPlatformNavInitialsPipe applied to the item’s label.
 * - Hides the text label when the navigation panel is collapsed, using SatPlatformNavService.
 * - Allows keyboard accessibility supporting navigation via keyboard.
 *
 * Prefer importing from the satori-cic package.
 * Example:
 *   import { SatPlatformNavMenuItemComponent } from '@hylandsoftware/satori-cic/platform-nav';
 * instead of:
 *   import { SatPlatformNavMenuItemComponent } from '@hylandsoftware/satori-ui/platform-nav';
 *
 * Deprecated usage: Importing from `satori-ui` is deprecated and will be removed in future versions.
 */
class SatPlatformNavMenuItemComponent {
    element = inject(ElementRef);
    /**
     * Determines whether the menu item should be rendered in an active/selected state.
     */
    active = input(false);
    /**
     * @internal
     * The text content of the label, used for tooltip and fallback initials.
     */
    labelText = signal(undefined);
    /** @internal */
    label = viewChild('label');
    /** @internal */
    computedLabel = computed(() => this.labelText() ?? this.label()?.nativeElement.textContent);
    /** @internal */
    labelHeight = computed(() => {
        // The minimum height of the element, used to ensure proper sizing when the label is hidden in collapsed state.
        const elementMinHeight = parseInt(window.getComputedStyle(this.element.nativeElement).minHeight, 10);
        // As we need to account for padding, we add 8px (4px top + 4px bottom) to the label height.
        return this.service.collapsed()
            ? `${elementMinHeight}px`
            : `${Math.max((this.label()?.nativeElement.offsetHeight || 0) + 8, elementMinHeight)}px`;
    });
    /** @internal */
    service = inject(SatPlatformNavStateService);
    tooltipService = inject(SatPlatformNavTooltipService);
    matTooltipService = inject(MatTooltip);
    matRippleService = inject(MatRipple);
    tooltipDelay = 600;
    tooltipTimer = null;
    constructor() {
        // Setup default properties for hostDirective MatTooltip
        this.matTooltipService.position = 'right';
        this.matTooltipService.message = this.computedLabel();
        this.matTooltipService.disabled = true;
        // Setup default properties for hostDirective MatRipple
        this.matRippleService.color = 'var(--sat-sys-on-primary-opacity-12)';
        effect(() => {
            const collapsed = this.service.collapsed();
            this.matTooltipService.message = collapsed ? this.computedLabel() : null;
        });
    }
    // Space should run click
    onSpaceKeyDown(event) {
        event.preventDefault();
        this.element.nativeElement.click();
    }
    /** @internal */
    onMouseEnter() {
        if (this.service.collapsed()) {
            const currentTooltip = this.matTooltipService;
            const previousTooltip = this.tooltipService.activateTooltip;
            if (previousTooltip && previousTooltip !== currentTooltip) {
                this.hidePreviousTooltip(previousTooltip);
            }
            const delayTime = this.tooltipService.tooltipShownFirst() ? 0 : this.tooltipDelay;
            if (delayTime) {
                this.tooltipTimer = setTimeout(() => {
                    this.showCurrentTooltip(currentTooltip);
                    this.tooltipService.updateTooltipShownFirst(true);
                }, delayTime);
            }
            else {
                this.showCurrentTooltip(currentTooltip);
            }
        }
    }
    /** @internal */
    onMouseLeave() {
        if (this.tooltipTimer) {
            clearTimeout(this.tooltipTimer);
            this.tooltipTimer = null;
        }
        const currentTooltip = this.matTooltipService;
        if (this.tooltipService.activateTooltip === currentTooltip) {
            this.hidePreviousTooltip(this.tooltipService.activateTooltip);
        }
    }
    /** @internal */
    labelChanged(event) {
        const text = event[0]?.target?.textContent;
        if (text) {
            this.labelText.set(text);
        }
    }
    hidePreviousTooltip(previousTooltip) {
        previousTooltip.disabled = true;
        previousTooltip.hide();
        this.tooltipService.updateActiveTooltip(null);
    }
    showCurrentTooltip(tooltip) {
        this.tooltipService.updateActiveTooltip(tooltip);
        tooltip.disabled = false;
        tooltip.show();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavMenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatPlatformNavMenuItemComponent, isStandalone: true, selector: "a[sat-platform-nav-menu-item], a[satPlatformNavMenuItem]", inputs: { active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "menuitem" }, listeners: { "keydown.space": "onSpaceKeyDown($event)", "mouseenter": "onMouseEnter()", "focus": "onMouseEnter()", "mouseleave": "onMouseLeave()", "blur": "onMouseLeave()" }, properties: { "style.maxHeight": "labelHeight()", "class.sat-platform-nav-item-active": "active()", "attr.aria-label": "computedLabel()" }, classAttribute: "sat-platform-nav-item" }, viewQueries: [{ propertyName: "label", first: true, predicate: ["label"], descendants: true, isSignal: true }], hostDirectives: [{ directive: i1$2.MatRipple }, { directive: i1$3.MatTooltip }, { directive: i2.CdkMenuItem }], ngImport: i0, template: `
    <div class="sat-platform-nav-icon" aria-hidden="true">
      <ng-container #iconContainer>
        <ng-content select="sat-platform-nav-avatar"></ng-content>
      </ng-container>
      @if (
        iconContainer?.previousElementSibling?.localName !== 'sat-platform-nav-avatar'
      ) {
        <sat-platform-nav-app-icon>
          {{ computedLabel() ?? '' | satPlatformNavInitials }}
        </sat-platform-nav-app-icon>
      }
    </div>
    <p #label
      class="sat-platform-nav-item-label"
      (cdkObserveContent)="labelChanged($event)"
    >
      <ng-content></ng-content>
    </p>
  `, isInline: true, dependencies: [{ kind: "component", type: SatPlatformNavAppIconComponent, selector: "sat-platform-nav-app-icon" }, { kind: "pipe", type: SatPlatformNavInitialsPipe, name: "satPlatformNavInitials" }, { kind: "ngmodule", type: ObserversModule }, { kind: "directive", type: i4.CdkObserveContent, selector: "[cdkObserveContent]", inputs: ["cdkObserveContentDisabled", "debounce"], outputs: ["cdkObserveContent"], exportAs: ["cdkObserveContent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavMenuItemComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/component-selector
                    selector: 'a[sat-platform-nav-menu-item], a[satPlatformNavMenuItem]',
                    template: `
    <div class="sat-platform-nav-icon" aria-hidden="true">
      <ng-container #iconContainer>
        <ng-content select="sat-platform-nav-avatar"></ng-content>
      </ng-container>
      @if (
        iconContainer?.previousElementSibling?.localName !== 'sat-platform-nav-avatar'
      ) {
        <sat-platform-nav-app-icon>
          {{ computedLabel() ?? '' | satPlatformNavInitials }}
        </sat-platform-nav-app-icon>
      }
    </div>
    <p #label
      class="sat-platform-nav-item-label"
      (cdkObserveContent)="labelChanged($event)"
    >
      <ng-content></ng-content>
    </p>
  `,
                    host: {
                        role: 'menuitem',
                        class: 'sat-platform-nav-item',
                        '[style.maxHeight]': 'labelHeight()',
                        '[class.sat-platform-nav-item-active]': 'active()',
                        '[attr.aria-label]': 'computedLabel()',
                        '(keydown.space)': 'onSpaceKeyDown($event)',
                    },
                    imports: [SatPlatformNavAppIconComponent, SatPlatformNavInitialsPipe, ObserversModule],
                    hostDirectives: [MatRipple, MatTooltip, CdkMenuItem],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { onMouseEnter: [{
                type: HostListener,
                args: ['mouseenter']
            }, {
                type: HostListener,
                args: ['focus']
            }], onMouseLeave: [{
                type: HostListener,
                args: ['mouseleave']
            }, {
                type: HostListener,
                args: ['blur']
            }] } });

/**
 * This component acts as a content projection outlet for the main area of the layout when using the platform navigation. It is intended to be placed adjacent to the vertical sidebar and wraps whatever content you insert within it using ng-content.
 * It serves as a flexible container for your app’s primary page content while structurally aligning with the sidebar layout (SatPlatformNavContainerComponent).
 *
 * Key features:
 * - Supports custom content projection via `ng-content`.
 * - Integrates seamlessly into layouts using `SatPlatformNav`.
 */
class SatPlatformNavMainContentComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavMainContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatPlatformNavMainContentComponent, isStandalone: true, selector: "sat-platform-nav-main-content", ngImport: i0, template: '<ng-content></ng-content>', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavMainContentComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-platform-nav-main-content',
                    template: '<ng-content></ng-content>',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

/**
 * This directive is applied to an Angular Material mat-menu to define a custom-styled user menu that appears when the user profile is clicked.
 *
 * Key features:
 * - Defines the dropdown menu that appears when the profile is clicked.
 * - Enhances mat-menu to match the Platform Nav’s user interface.
 * - Supports standard Angular Material menu behavior.
 * - This directive can apply specific styles, positioning, or behavior consistent with the platform’s design.
 */
class SatPlatformNavUserMenuDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavUserMenuDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: SatPlatformNavUserMenuDirective, isStandalone: true, selector: "[satPlatformNavUserMenu]", exportAs: ["satPlatformNavUserMenu"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavUserMenuDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satPlatformNavUserMenu]',
                    exportAs: 'satPlatformNavUserMenu',
                }]
        }] });

/**
 * This component displays a clickable user identity block, such as a name along with an avatar that can have initials or user profile image in the platform sidebar’s user section. It also has a responsive behavior based on the collapsed state of the sidebar.
 *
 * Key features:
 * - Typically used to show user info like names, emails, or avatar initials.
 * - Styled for sidebar placement within sat-platform-nav-user.
 */
class SatPlatformNavUserProfileComponent {
    /** @internal */
    service = inject(SatPlatformNavStateService);
    /** @internal */
    tooltipService = inject(MatTooltip);
    /**
     * @internal
     * The text content of the profile name, used for tooltip and fallback initials.
     */
    profileNameText = signal(undefined);
    /** @internal */
    profileName = viewChild('profileName');
    /** @internal */
    computedProfileName = computed(() => this.profileNameText() ?? this.profileName()?.nativeElement.innerText);
    constructor() {
        this.tooltipService.position = 'right';
        effect(() => {
            this.tooltipService.message = this.service.collapsed() ? this.computedProfileName() : null;
        });
    }
    /** @internal */
    profileNameChanged(event) {
        const text = event[0]?.target?.textContent;
        if (text) {
            this.profileNameText.set(text);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavUserProfileComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.19", type: SatPlatformNavUserProfileComponent, isStandalone: true, selector: "button[satPlatformNavUserProfile]", host: { attributes: { "id": "sat-platform-nav-user-profile" }, properties: { "attr.aria-haspopup": "\"menu\"", "attr.aria-label": "computedProfileName()" }, classAttribute: "sat-platform-nav-item" }, viewQueries: [{ propertyName: "profileName", first: true, predicate: ["profileName"], descendants: true, isSignal: true }], hostDirectives: [{ directive: i1$3.MatTooltip }], ngImport: i0, template: `
    <span class="sat-platform-nav-icon">
      <ng-container #avatarContainer>
        <ng-content select="sat-avatar"></ng-content>
      </ng-container>
    </span>
    <p #profileName
      class="sat-platform-nav-item-label"
      [class.sat-platform-nav-hidden]="service.collapsed()"
      (cdkObserveContent)="profileNameChanged($event)"
    >
      <ng-content></ng-content>
    </p>
  `, isInline: true, dependencies: [{ kind: "ngmodule", type: SatAvatarModule }, { kind: "ngmodule", type: ObserversModule }, { kind: "directive", type: i4.CdkObserveContent, selector: "[cdkObserveContent]", inputs: ["cdkObserveContentDisabled", "debounce"], outputs: ["cdkObserveContent"], exportAs: ["cdkObserveContent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavUserProfileComponent, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/component-selector
                    selector: 'button[satPlatformNavUserProfile]',
                    template: `
    <span class="sat-platform-nav-icon">
      <ng-container #avatarContainer>
        <ng-content select="sat-avatar"></ng-content>
      </ng-container>
    </span>
    <p #profileName
      class="sat-platform-nav-item-label"
      [class.sat-platform-nav-hidden]="service.collapsed()"
      (cdkObserveContent)="profileNameChanged($event)"
    >
      <ng-content></ng-content>
    </p>
  `,
                    imports: [SatAvatarModule, ObserversModule],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    host: {
                        '[attr.aria-haspopup]': '"menu"',
                        '[attr.aria-label]': 'computedProfileName()',
                        'id': 'sat-platform-nav-user-profile',
                        'class': 'sat-platform-nav-item',
                    },
                    hostDirectives: [MatTooltip],
                }]
        }], ctorParameters: () => [] });

/**
 * This serves as a container for user-related UI elements within the navigation. It wraps the `SatPlatformNavUserProfileComponent` and provides a slot (`satPlatformNavUserMenu`) for displaying a user menu, typically with dynamic items such as languages or logout options. This component ensures consistent layout and behavior for the user section in the navigation.
 *
 * Key features:
 * - Acts as the container for the user interaction section in the sidebar.
 * - Typically positioned at the bottom of the nav, separating navigation from account-related actions.
 * - Can act as a menu trigger using `[matMenuTriggerFor]`.
 *
 * @example
 * <sat-platform-nav-user>
 *   <button satPlatformNavUserProfile [matMenuTriggerFor]="userMenu">
 *     Lorem Ipsum
 *   </button>
 *   <mat-menu #userMenu="matMenu" satPlatformNavUserMenu>
 *     <button mat-menu-item>
 *       …
 *     </button>
 *   </mat-menu>
 * </sat-platform-nav-user>
 *
 */
class SatPlatformNavUserComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavUserComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatPlatformNavUserComponent, isStandalone: true, selector: "sat-platform-nav-user", ngImport: i0, template: `
    <div class="sat-platform-nav-user">
      <ng-content select="button[satPlatformNavUserProfile]"></ng-content>
    </div>
    <ng-content select="[satPlatformNavUserMenu]"></ng-content>
  `, isInline: true, styles: [".sat-platform-nav-user{margin:0 4px 8px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavUserComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav-user', template: `
    <div class="sat-platform-nav-user">
      <ng-content select="button[satPlatformNavUserProfile]"></ng-content>
    </div>
    <ng-content select="[satPlatformNavUserMenu]"></ng-content>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [".sat-platform-nav-user{margin:0 4px 8px}\n"] }]
        }] });

/**
 * This component renders the vertical navigation menu, used as a sidebar. It supports static and dynamic nav items. Designed to work inside sat-platform-nav-container, it helps create a well-structured layout for navigation items and an action button for accessing user profile details. It includes control for toggling the collapsed state of the navigation panel, a title that conditionally renders based on the state.
 *
 * Key features:
 * - Dynamically toggles between expanded and collapsed states when user clicks on the h_glyph icon.
 * - Displays the "Content Innovation Cloud" title only when the panel is expanded.
 * - Includes an action button intended to open a popup displaying user profile details.
 */
class SatPlatformNavComponent {
    /**
     * @internal
     */
    service = inject(SatPlatformNavStateService);
    /**
     * @internal
     */
    tooltipService = inject(SatPlatformNavTooltipService);
    /**
     * Activates the neutral look of the platform navigation dedicated to administration context.
     */
    neutralTheme = input(false);
    /**
     * Clears the active tooltip on mouse leave.
     * Resets the tooltipShownFirst flag, hides and disables the current activated tooltip.
     * @internal
     */
    onMouseLeave() {
        this.tooltipService.updateTooltipShownFirst(false);
        const activateTooltip = this.tooltipService.activateTooltip;
        if (activateTooltip) {
            activateTooltip.disabled = true;
            activateTooltip.hide();
        }
        this.tooltipService.updateActiveTooltip(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.19", type: SatPlatformNavComponent, isStandalone: true, selector: "sat-platform-nav", inputs: { neutralTheme: { classPropertyName: "neutralTheme", publicName: "neutralTheme", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div\n  class=\"sat-platform-nav-panel\"\n  [class.sat-neutral-theme]=\"neutralTheme()\"\n  [class.sat-platform-nav-panel-expanded]=\"!service.collapsed()\"\n>\n  <div class=\"sat-platform-nav-title-container\">\n    <button\n      matRipple\n      type=\"button\"\n      matRippleColor=\"var(--sat-sys-on-primary-opacity-12)\"\n      id=\"sat-platform-nav-title-icon\"\n      class=\"sat-platform-nav-item\"\n      [matTooltip]=\"(service.collapsed() ? 'sat-preview.platform-nav.expand' : 'sat-preview.platform-nav.collapse') | translate\"\n      matTooltipPosition=\"below\"\n      (click)=\"service.toggleCollapsed()\"\n      [attr.data-automation-id]=\"service.collapsed() ? 'platform-nav-expand-button' : 'platform-nav-collapse-button'\"\n      [attr.aria-pressed]=\"service.collapsed() ? false : true\"\n      [attr.aria-label]=\"(service.collapsed() ? 'sat-preview.platform-nav.expand' : 'sat-preview.platform-nav.collapse') | translate\"\n    >\n      <svg\n        xmlns=\"http://www.w3.org/2000/svg\"\n        width=\"32\"\n        height=\"32\"\n        viewBox=\"0 0 32 32\"\n        fill=\"none\"\n        class=\"sat-platform-nav-title-icon\"\n      >\n        <path d=\"M15.2736 8L10.6997 15.997H15.997L20.5708 8H15.2736Z\" fill=\"white\" />\n        <path d=\"M5.40245 15.9984L0.828857 23.9954H6.12612L10.6997 15.9984H5.40245Z\" fill=\"white\" />\n        <path d=\"M16.002 16.0028L11.4284 24H16.7257L21.2993 16.0028H16.002Z\" fill=\"white\" />\n        <path d=\"M25.8734 8.00474L21.2993 16.0027H26.5971L31.1712 8.00474H25.8734Z\" fill=\"white\" />\n      </svg>\n    </button>\n    <h2 class=\"sat-platform-nav-title\">Content Innovation Cloud</h2>\n    <button\n      mat-icon-button\n      class=\"sat-platform-nav-close-button\"\n      type=\"button\"\n      (click)=\"service.toggleCollapsed()\"\n      [attr.aria-label]=\"'sat-preview.platform-nav.collapse' | translate\"\n    >\n      <mat-icon svgIcon=\"x_large\"></mat-icon>\n    </button>\n  </div>\n  <ng-content select=\"sat-platform-nav-switcher\"></ng-content>\n  <nav\n    [attr.aria-label]=\"'sat-preview.platform-nav.label' | translate\"\n    class=\"sat-platform-nav-list\"\n    (mouseleave)=\"onMouseLeave()\"\n  >\n    <ng-content></ng-content>\n  </nav>\n  <ng-content select=\"sat-platform-nav-user\"></ng-content>\n</div>\n", styles: ["sat-platform-nav{color-scheme:light}sat-platform-nav .sat-platform-nav-panel{position:fixed;top:0;background-color:var(--sat-platform-nav-background);display:flex;flex-direction:column;height:var(--sat-platform-nav-height-max, 100%);width:var(--sat-platform-nav-collapsed-width, 56px);max-width:calc(100vw - 40px);z-index:1000;box-sizing:border-box;overflow:hidden;transition:width var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1))}@media(width<=675px){sat-platform-nav .sat-platform-nav-panel{width:0}}sat-platform-nav .sat-platform-nav-title-container{display:flex;align-items:center;margin:8px 4px;height:var(--sat-platform-nav-height-high, 48px);flex-shrink:0}sat-platform-nav .sat-platform-nav-title-container .sat-platform-nav-title-icon{width:32px;height:32px}sat-platform-nav .sat-platform-nav-title-container h2.sat-platform-nav-title{flex:0 0 calc(100vw - 96px);max-width:252px;color:var(--sat-platform-nav-on-background);font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-title-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-title-letter-spacing, .009rem);margin:0;opacity:0;overflow:hidden;transform:translate(-8px);pointer-events:none;transition:opacity var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1)),transform var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1))}@media(width<=675px){sat-platform-nav .sat-platform-nav-title-container h2.sat-platform-nav-title{flex:0 0 calc(100vw - 144px);max-width:204px}}sat-platform-nav .sat-platform-nav-close-button{color-scheme:dark;display:none}@media(width<=675px){sat-platform-nav .sat-platform-nav-close-button{display:block}}sat-platform-nav p.sat-platform-nav-item-label{flex:0 0 calc(100vw - 108px);max-width:240px;display:inline-block;font-family:var(--sat-platform-nav-label-large-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-label-large-size, .875rem);font-style:normal;font-weight:var(--sat-platform-nav-label-large-weight, 500);line-height:var(--sat-platform-nav-label-large-line-height, 1.25rem);letter-spacing:var(--sat-platform-nav-label-large-tracking, .006rem);margin:0;opacity:0;white-space:normal;overflow-wrap:anywhere;overflow:hidden;transform:translate(-8px);pointer-events:none;transition:opacity var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1)),transform var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1))}sat-platform-nav .sat-platform-nav-list{padding:0 4px 2px;flex-grow:1;overflow-x:hidden;overflow-y:hidden;-ms-overflow-style:auto}sat-platform-nav .sat-platform-nav-list:hover{overflow-y:scroll;padding-right:0}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar{width:4px;height:4px}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar-track{background:transparent}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar-thumb{background:var(--sat-platform-nav-outline);border-radius:1000rem}sat-platform-nav sat-platform-nav-switcher+.sat-platform-nav-list{padding-top:10px}sat-platform-nav .sat-platform-nav-title-container+.sat-platform-nav-list{padding-top:48px}sat-platform-nav .sat-platform-nav-item{position:relative;display:flex;align-items:center;text-align:left;padding:4px 10px;white-space:nowrap;text-decoration:none;background:none;box-sizing:border-box;border:none;gap:12px;min-height:var(--sat-platform-nav-height-high, 48px);width:var(--sat-platform-nav-width-max, 100%);flex-shrink:0;overflow:hidden;transition:max-height var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1));cursor:pointer;color:var(--sat-platform-nav-on-background);border-radius:var(--sat-platform-nav-corner-medium, 12px)}sat-platform-nav .sat-platform-nav-item:hover{background-color:var(--sat-platform-nav-on-primary-opacity-08)}sat-platform-nav .sat-platform-nav-item:active{background-color:var(--sat-platform-nav-on-primary-opacity-12)}sat-platform-nav .sat-platform-nav-item:focus-visible{outline:2px solid var(--sat-platform-nav-outline);outline-offset:-2px}sat-platform-nav .sat-platform-nav-item:before{content:\"\";display:none;position:absolute;top:50%;left:0;width:4px;height:20px;transform:translateY(-50%);border-radius:0 var(--sat-platform-nav-corner-large, 16px) var(--sat-platform-nav-corner-large, 16px) 0;background:var(--sat-platform-nav-on-background)}sat-platform-nav .sat-platform-nav-title-container .sat-platform-nav-item{width:var(--sat-platform-nav-width-high, 48px);padding:0 8px;border-radius:50%}sat-platform-nav .sat-platform-nav-item-active{background-color:var(--sat-platform-nav-on-primary-opacity-12)}sat-platform-nav .sat-platform-nav-item-active:focus,sat-platform-nav .sat-platform-nav-item-active:hover{background-color:var(--sat-platform-nav-on-primary-opacity-12)}sat-platform-nav .sat-platform-nav-item-active:focus-visible{outline:2px solid var(--sat-platform-nav-outline);outline-offset:-2px}sat-platform-nav .sat-platform-nav-item-active:active,sat-platform-nav .sat-platform-nav-item-active:focus:active,sat-platform-nav .sat-platform-nav-item-active:focus-visible:active{background-color:var(--sat-platform-nav-on-primary-opacity-08)}sat-platform-nav .sat-platform-nav-item-active:before{display:block}sat-platform-nav .sat-platform-nav-item-active p.sat-platform-nav-item-label{font-weight:var(--sat-platform-nav-label-large-weight-prominent, 600)}sat-platform-nav .sat-platform-nav-icon{height:var(--sat-platform-nav-height-medium, 28px);display:flex;justify-content:center;align-items:center;background:none;flex:0 0 var(--sat-platform-nav-width-medium, 28px);border:none;padding:0;cursor:pointer;flex-shrink:0;border-radius:var(--sat-platform-nav-corner-extra-small, 4px)}sat-platform-nav .sat-platform-nav-icon .mat-icon{width:var(--sat-platform-nav-width-small, 24px);height:var(--sat-platform-nav-height-small, 24px)}sat-platform-nav .sat-platform-nav-panel-expanded{width:308px}sat-platform-nav .sat-platform-nav-panel-expanded .sat-platform-nav-switcher-button{padding:4px 14px}sat-platform-nav .sat-platform-nav-panel-expanded .sat-platform-nav-switcher-button .mat-icon.sat-platform-nav-switcher-button-suffix-icon{margin-left:0;width:24px;height:24px}sat-platform-nav .sat-platform-nav-panel-expanded .sat-platform-nav-title-container h2.sat-platform-nav-title,sat-platform-nav .sat-platform-nav-panel-expanded p.sat-platform-nav-item-label{opacity:1;transform:translate(0);pointer-events:auto}@-moz-document url-prefix(){sat-platform-nav .sat-platform-nav-list{scrollbar-gutter:stable;scrollbar-width:thin;scrollbar-color:var(--sat-platform-nav-outline) transparent}sat-platform-nav .sat-platform-nav-list:hover{padding-right:4px!important}}\n"], dependencies: [{ kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i1$3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatRipple, selector: "[mat-ripple], [matRipple]", inputs: ["matRippleColor", "matRippleUnbounded", "matRippleCentered", "matRippleRadius", "matRippleAnimation", "matRippleDisabled", "matRippleTrigger"], exportAs: ["matRipple"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-platform-nav', imports: [MatTooltipModule, MatButtonModule, MatIconModule, MatRipple, TranslatePipe], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<div\n  class=\"sat-platform-nav-panel\"\n  [class.sat-neutral-theme]=\"neutralTheme()\"\n  [class.sat-platform-nav-panel-expanded]=\"!service.collapsed()\"\n>\n  <div class=\"sat-platform-nav-title-container\">\n    <button\n      matRipple\n      type=\"button\"\n      matRippleColor=\"var(--sat-sys-on-primary-opacity-12)\"\n      id=\"sat-platform-nav-title-icon\"\n      class=\"sat-platform-nav-item\"\n      [matTooltip]=\"(service.collapsed() ? 'sat-preview.platform-nav.expand' : 'sat-preview.platform-nav.collapse') | translate\"\n      matTooltipPosition=\"below\"\n      (click)=\"service.toggleCollapsed()\"\n      [attr.data-automation-id]=\"service.collapsed() ? 'platform-nav-expand-button' : 'platform-nav-collapse-button'\"\n      [attr.aria-pressed]=\"service.collapsed() ? false : true\"\n      [attr.aria-label]=\"(service.collapsed() ? 'sat-preview.platform-nav.expand' : 'sat-preview.platform-nav.collapse') | translate\"\n    >\n      <svg\n        xmlns=\"http://www.w3.org/2000/svg\"\n        width=\"32\"\n        height=\"32\"\n        viewBox=\"0 0 32 32\"\n        fill=\"none\"\n        class=\"sat-platform-nav-title-icon\"\n      >\n        <path d=\"M15.2736 8L10.6997 15.997H15.997L20.5708 8H15.2736Z\" fill=\"white\" />\n        <path d=\"M5.40245 15.9984L0.828857 23.9954H6.12612L10.6997 15.9984H5.40245Z\" fill=\"white\" />\n        <path d=\"M16.002 16.0028L11.4284 24H16.7257L21.2993 16.0028H16.002Z\" fill=\"white\" />\n        <path d=\"M25.8734 8.00474L21.2993 16.0027H26.5971L31.1712 8.00474H25.8734Z\" fill=\"white\" />\n      </svg>\n    </button>\n    <h2 class=\"sat-platform-nav-title\">Content Innovation Cloud</h2>\n    <button\n      mat-icon-button\n      class=\"sat-platform-nav-close-button\"\n      type=\"button\"\n      (click)=\"service.toggleCollapsed()\"\n      [attr.aria-label]=\"'sat-preview.platform-nav.collapse' | translate\"\n    >\n      <mat-icon svgIcon=\"x_large\"></mat-icon>\n    </button>\n  </div>\n  <ng-content select=\"sat-platform-nav-switcher\"></ng-content>\n  <nav\n    [attr.aria-label]=\"'sat-preview.platform-nav.label' | translate\"\n    class=\"sat-platform-nav-list\"\n    (mouseleave)=\"onMouseLeave()\"\n  >\n    <ng-content></ng-content>\n  </nav>\n  <ng-content select=\"sat-platform-nav-user\"></ng-content>\n</div>\n", styles: ["sat-platform-nav{color-scheme:light}sat-platform-nav .sat-platform-nav-panel{position:fixed;top:0;background-color:var(--sat-platform-nav-background);display:flex;flex-direction:column;height:var(--sat-platform-nav-height-max, 100%);width:var(--sat-platform-nav-collapsed-width, 56px);max-width:calc(100vw - 40px);z-index:1000;box-sizing:border-box;overflow:hidden;transition:width var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1))}@media(width<=675px){sat-platform-nav .sat-platform-nav-panel{width:0}}sat-platform-nav .sat-platform-nav-title-container{display:flex;align-items:center;margin:8px 4px;height:var(--sat-platform-nav-height-high, 48px);flex-shrink:0}sat-platform-nav .sat-platform-nav-title-container .sat-platform-nav-title-icon{width:32px;height:32px}sat-platform-nav .sat-platform-nav-title-container h2.sat-platform-nav-title{flex:0 0 calc(100vw - 96px);max-width:252px;color:var(--sat-platform-nav-on-background);font-family:var(--sat-platform-nav-title-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-title-medium-size, 1rem);font-style:normal;font-weight:500;line-height:var(--sat-platform-nav-title-line-height, 1.5rem);letter-spacing:var(--sat-platform-nav-title-letter-spacing, .009rem);margin:0;opacity:0;overflow:hidden;transform:translate(-8px);pointer-events:none;transition:opacity var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1)),transform var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1))}@media(width<=675px){sat-platform-nav .sat-platform-nav-title-container h2.sat-platform-nav-title{flex:0 0 calc(100vw - 144px);max-width:204px}}sat-platform-nav .sat-platform-nav-close-button{color-scheme:dark;display:none}@media(width<=675px){sat-platform-nav .sat-platform-nav-close-button{display:block}}sat-platform-nav p.sat-platform-nav-item-label{flex:0 0 calc(100vw - 108px);max-width:240px;display:inline-block;font-family:var(--sat-platform-nav-label-large-font, Noto Sans, sans-serif);font-size:var(--sat-platform-nav-label-large-size, .875rem);font-style:normal;font-weight:var(--sat-platform-nav-label-large-weight, 500);line-height:var(--sat-platform-nav-label-large-line-height, 1.25rem);letter-spacing:var(--sat-platform-nav-label-large-tracking, .006rem);margin:0;opacity:0;white-space:normal;overflow-wrap:anywhere;overflow:hidden;transform:translate(-8px);pointer-events:none;transition:opacity var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1)),transform var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1))}sat-platform-nav .sat-platform-nav-list{padding:0 4px 2px;flex-grow:1;overflow-x:hidden;overflow-y:hidden;-ms-overflow-style:auto}sat-platform-nav .sat-platform-nav-list:hover{overflow-y:scroll;padding-right:0}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar{width:4px;height:4px}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar-track{background:transparent}sat-platform-nav .sat-platform-nav-list::-webkit-scrollbar-thumb{background:var(--sat-platform-nav-outline);border-radius:1000rem}sat-platform-nav sat-platform-nav-switcher+.sat-platform-nav-list{padding-top:10px}sat-platform-nav .sat-platform-nav-title-container+.sat-platform-nav-list{padding-top:48px}sat-platform-nav .sat-platform-nav-item{position:relative;display:flex;align-items:center;text-align:left;padding:4px 10px;white-space:nowrap;text-decoration:none;background:none;box-sizing:border-box;border:none;gap:12px;min-height:var(--sat-platform-nav-height-high, 48px);width:var(--sat-platform-nav-width-max, 100%);flex-shrink:0;overflow:hidden;transition:max-height var(--sat-platform-nav-animation-duration, .4s) var(--sat-platform-nav-animation-curve, cubic-bezier(.25, .8, .25, 1));cursor:pointer;color:var(--sat-platform-nav-on-background);border-radius:var(--sat-platform-nav-corner-medium, 12px)}sat-platform-nav .sat-platform-nav-item:hover{background-color:var(--sat-platform-nav-on-primary-opacity-08)}sat-platform-nav .sat-platform-nav-item:active{background-color:var(--sat-platform-nav-on-primary-opacity-12)}sat-platform-nav .sat-platform-nav-item:focus-visible{outline:2px solid var(--sat-platform-nav-outline);outline-offset:-2px}sat-platform-nav .sat-platform-nav-item:before{content:\"\";display:none;position:absolute;top:50%;left:0;width:4px;height:20px;transform:translateY(-50%);border-radius:0 var(--sat-platform-nav-corner-large, 16px) var(--sat-platform-nav-corner-large, 16px) 0;background:var(--sat-platform-nav-on-background)}sat-platform-nav .sat-platform-nav-title-container .sat-platform-nav-item{width:var(--sat-platform-nav-width-high, 48px);padding:0 8px;border-radius:50%}sat-platform-nav .sat-platform-nav-item-active{background-color:var(--sat-platform-nav-on-primary-opacity-12)}sat-platform-nav .sat-platform-nav-item-active:focus,sat-platform-nav .sat-platform-nav-item-active:hover{background-color:var(--sat-platform-nav-on-primary-opacity-12)}sat-platform-nav .sat-platform-nav-item-active:focus-visible{outline:2px solid var(--sat-platform-nav-outline);outline-offset:-2px}sat-platform-nav .sat-platform-nav-item-active:active,sat-platform-nav .sat-platform-nav-item-active:focus:active,sat-platform-nav .sat-platform-nav-item-active:focus-visible:active{background-color:var(--sat-platform-nav-on-primary-opacity-08)}sat-platform-nav .sat-platform-nav-item-active:before{display:block}sat-platform-nav .sat-platform-nav-item-active p.sat-platform-nav-item-label{font-weight:var(--sat-platform-nav-label-large-weight-prominent, 600)}sat-platform-nav .sat-platform-nav-icon{height:var(--sat-platform-nav-height-medium, 28px);display:flex;justify-content:center;align-items:center;background:none;flex:0 0 var(--sat-platform-nav-width-medium, 28px);border:none;padding:0;cursor:pointer;flex-shrink:0;border-radius:var(--sat-platform-nav-corner-extra-small, 4px)}sat-platform-nav .sat-platform-nav-icon .mat-icon{width:var(--sat-platform-nav-width-small, 24px);height:var(--sat-platform-nav-height-small, 24px)}sat-platform-nav .sat-platform-nav-panel-expanded{width:308px}sat-platform-nav .sat-platform-nav-panel-expanded .sat-platform-nav-switcher-button{padding:4px 14px}sat-platform-nav .sat-platform-nav-panel-expanded .sat-platform-nav-switcher-button .mat-icon.sat-platform-nav-switcher-button-suffix-icon{margin-left:0;width:24px;height:24px}sat-platform-nav .sat-platform-nav-panel-expanded .sat-platform-nav-title-container h2.sat-platform-nav-title,sat-platform-nav .sat-platform-nav-panel-expanded p.sat-platform-nav-item-label{opacity:1;transform:translate(0);pointer-events:auto}@-moz-document url-prefix(){sat-platform-nav .sat-platform-nav-list{scrollbar-gutter:stable;scrollbar-width:thin;scrollbar-color:var(--sat-platform-nav-outline) transparent}sat-platform-nav .sat-platform-nav-list:hover{padding-right:4px!important}}\n"] }]
        }] });

const COMPONENTS = [
    SatPlatformNavComponent,
    SatPlatformNavContainerComponent,
    SatPlatformNavMainContentComponent,
    SatPlatformNavMenuComponent,
    SatPlatformNavMenuItemComponent,
    SatPlatformNavUserProfileComponent,
    SatPlatformNavUserComponent,
    SatPlatformNavAvatarComponent,
    SatPlatformNavEnvironmentSwitcherComponent,
];
const PIPES = [SatPlatformNavInitialsPipe];
const DIRECTIVES = [SatPlatformNavUserMenuDirective];
class SatPlatformNavModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavModule, imports: [SatPlatformNavComponent,
            SatPlatformNavContainerComponent,
            SatPlatformNavMainContentComponent,
            SatPlatformNavMenuComponent,
            SatPlatformNavMenuItemComponent,
            SatPlatformNavUserProfileComponent,
            SatPlatformNavUserComponent,
            SatPlatformNavAvatarComponent,
            SatPlatformNavEnvironmentSwitcherComponent, SatPlatformNavInitialsPipe, SatPlatformNavUserMenuDirective], exports: [SatPlatformNavComponent,
            SatPlatformNavContainerComponent,
            SatPlatformNavMainContentComponent,
            SatPlatformNavMenuComponent,
            SatPlatformNavMenuItemComponent,
            SatPlatformNavUserProfileComponent,
            SatPlatformNavUserComponent,
            SatPlatformNavAvatarComponent,
            SatPlatformNavEnvironmentSwitcherComponent, SatPlatformNavInitialsPipe, SatPlatformNavUserMenuDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavModule, providers: [SatPlatformNavTooltipService], imports: [SatPlatformNavComponent,
            SatPlatformNavContainerComponent,
            SatPlatformNavMenuItemComponent,
            SatPlatformNavUserProfileComponent,
            SatPlatformNavAvatarComponent,
            SatPlatformNavEnvironmentSwitcherComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatPlatformNavModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [...COMPONENTS, ...PIPES, ...DIRECTIVES],
                    exports: [...COMPONENTS, ...PIPES, ...DIRECTIVES],
                    providers: [SatPlatformNavTooltipService],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatPlatformNavAvatarComponent, SatPlatformNavComponent, SatPlatformNavContainerComponent, SatPlatformNavEnvironmentSwitcherComponent, SatPlatformNavInitialsPipe, SatPlatformNavMainContentComponent, SatPlatformNavMenuComponent, SatPlatformNavMenuItemComponent, SatPlatformNavModule, SatPlatformNavStateService, SatPlatformNavUserComponent, SatPlatformNavUserMenuDirective, SatPlatformNavUserProfileComponent };
//# sourceMappingURL=hylandsoftware-satori-preview-platform-nav.mjs.map
