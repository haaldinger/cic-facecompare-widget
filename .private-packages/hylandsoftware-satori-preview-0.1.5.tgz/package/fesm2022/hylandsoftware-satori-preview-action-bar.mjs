import * as i0 from '@angular/core';
import { input, inject, HostListener, ViewEncapsulation, ChangeDetectionStrategy, Component, signal, linkedSignal, computed, ElementRef, afterNextRender, effect, output, NgModule } from '@angular/core';
import { MatRipple } from '@angular/material/core';
import * as i4 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i2 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i3$1 from '@ngx-translate/core';
import { TranslatePipe, TranslateService, TranslateModule } from '@ngx-translate/core';

/**
 * Attribute selector component that styles buttons for the Action Bar.
 * Provides consistent visual language and behavior including ripple effects,
 * spacing, and disabled state handling.
 *
 * @example
 * ```html
 * <button satActionBarButton type="button" (click)="add()">
 *   <mat-icon svgIcon="circle_add"></mat-icon>
 *   Add
 * </button>
 * <button satActionBarButton type="button" (click)="add()" aria-label="Add">
 *   <mat-icon svgIcon="circle_add"></mat-icon>
 * </button>
 * ```
 */
class SatActionBarButtonComponent {
    /** Whether the button is disabled. */
    disabled = input(false);
    ripple = inject(MatRipple);
    launchRipple(event) {
        this.ripple.launch(event.x, event.y);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionBarButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.19", type: SatActionBarButtonComponent, isStandalone: true, selector: "[sat-action-bar-button], [satActionBarButton]", inputs: { disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "mousedown": "launchRipple($event)" }, properties: { "class.sat-action-bar-button-disabled": "disabled()" }, classAttribute: "sat-action-bar-button" }, providers: [MatRipple], ngImport: i0, template: `<ng-content select="mat-icon"></ng-content><span class="sat-action-bar-button-label"><ng-content></ng-content></span>`, isInline: true, styles: [".sat-action-bar-button{appearance:none;background:transparent;border:none;outline:none;cursor:pointer;position:relative;overflow:hidden;display:flex;align-items:center;padding:8px 12px;border-radius:12px;color:var(--mat-sys-on-surface-variant);font:var(--mat-sys-label-large)}.sat-action-bar-button .sat-action-bar-button-label:not(:empty){margin-left:6px;margin-right:4px}.sat-action-bar-button:hover:not(:disabled){background-color:hsl(from var(--mat-sys-on-surface-variant) h s l/var(--mat-sys-hover-state-layer-opacity))}.sat-action-bar-button:focus-visible:not(:disabled){background-color:hsl(from var(--mat-sys-on-surface-variant) h s l/var(--mat-sys-focus-state-layer-opacity))}.sat-action-bar-button:disabled{cursor:default;pointer-events:none;opacity:.38}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionBarButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: '[sat-action-bar-button], [satActionBarButton]', template: `<ng-content select="mat-icon"></ng-content><span class="sat-action-bar-button-label"><ng-content></ng-content></span>`, host: { class: 'sat-action-bar-button', '[class.sat-action-bar-button-disabled]': 'disabled()' }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, providers: [MatRipple], styles: [".sat-action-bar-button{appearance:none;background:transparent;border:none;outline:none;cursor:pointer;position:relative;overflow:hidden;display:flex;align-items:center;padding:8px 12px;border-radius:12px;color:var(--mat-sys-on-surface-variant);font:var(--mat-sys-label-large)}.sat-action-bar-button .sat-action-bar-button-label:not(:empty){margin-left:6px;margin-right:4px}.sat-action-bar-button:hover:not(:disabled){background-color:hsl(from var(--mat-sys-on-surface-variant) h s l/var(--mat-sys-hover-state-layer-opacity))}.sat-action-bar-button:focus-visible:not(:disabled){background-color:hsl(from var(--mat-sys-on-surface-variant) h s l/var(--mat-sys-focus-state-layer-opacity))}.sat-action-bar-button:disabled{cursor:default;pointer-events:none;opacity:.38}\n"] }]
        }], propDecorators: { launchRipple: [{
                type: HostListener,
                args: ['mousedown', ['$event']]
            }] } });

/**
 * Renders a row of action buttons with automatic overflow handling.
 * Collapses overflowing items into a "More" menu and provides keyboard navigation.
 *
 * Features:
 * - Responsive truncation based on available width
 * - Keyboard navigation with arrow keys
 * - Skips disabled items during navigation
 * - Menu trigger included in keyboard navigation sequence
 * - Tooltips for icon-only buttons
 *
 * @example
 * ```html
 * <sat-action-group [items]="actions" />
 * ```
 */
class SatActionGroupComponent {
    lastFocusedIndex = signal(0);
    items = input([]);
    /**
     * Signal for the items currently displayed in the group.
     * @internal
     */
    visibleItems = linkedSignal({
        computation: () => [...(this.items() || [])],
        source: this.items,
    });
    /**
     * Computed signal for the hidden items (collapsed into the menu).
     * @internal
     */
    hiddenItems = computed(() => (this.items() ?? []).filter(item => !this.visibleItems().includes(item)));
    /**
     * Computed signal for the initial focus index (first non-disabled item).
     * @internal
     */
    initialFocusIndex = computed(() => {
        const items = this.visibleItems();
        const firstEnabledIndex = items.findIndex(item => !item.disabled);
        return firstEnabledIndex === -1 ? 0 : firstEnabledIndex;
    });
    /**
     * Computed signal for the total number of focusable buttons (visible items + menu trigger if present).
     * @internal
     */
    totalFocusableButtons = computed(() => {
        const visibleCount = this.visibleItems().length;
        const hasMenuTrigger = this.hiddenItems().length > 0;
        return hasMenuTrigger ? visibleCount + 1 : visibleCount;
    });
    _element = inject(ElementRef);
    /**
     * Last registered width of the component
     */
    width = 0;
    truncationTimeout;
    resizeTimeout;
    resizeObserver = new ResizeObserver(entries => {
        for (const entry of entries) {
            this.debounceResize(entry.contentRect.width);
        }
    });
    constructor() {
        afterNextRender({
            read: () => {
                this.resizeObserver.observe(this._element.nativeElement);
                // Initialize lastFocusedIndex to the first non-disabled item
                this.lastFocusedIndex.set(this.initialFocusIndex());
            },
        });
        // Update lastFocusedIndex when items change if the current index is now disabled or out of bounds
        effect(() => {
            const items = this.visibleItems();
            const currentIndex = this.lastFocusedIndex();
            const totalButtons = this.totalFocusableButtons();
            if (currentIndex >= totalButtons ||
                (currentIndex < items.length && items[currentIndex]?.disabled)) {
                // Current index is invalid, find the first enabled item
                const newIndex = this.initialFocusIndex();
                this.lastFocusedIndex.set(newIndex);
            }
        });
    }
    ngOnDestroy() {
        this.resizeObserver?.disconnect();
        clearTimeout(this.resizeTimeout);
        clearTimeout(this.truncationTimeout);
    }
    /** @internal */
    focusNext(event, index) {
        event.preventDefault();
        const items = this.visibleItems();
        const totalButtons = this.totalFocusableButtons();
        let nextIndex = (index + 1) % totalButtons;
        // Skip disabled items (only relevant for visible items, not the menu trigger)
        let attempts = 0;
        while (nextIndex < items.length && items[nextIndex]?.disabled && attempts < totalButtons) {
            nextIndex = (nextIndex + 1) % totalButtons;
            attempts++;
        }
        // Only update and focus if we found a valid item
        this.lastFocusedIndex.set(nextIndex);
        const button = this._element.nativeElement.querySelectorAll('button')[nextIndex];
        button?.focus();
    }
    /** @internal */
    focusPrevious(event, index) {
        event.preventDefault();
        const items = this.visibleItems();
        const totalButtons = this.totalFocusableButtons();
        let previousIndex = (index - 1 + totalButtons) % totalButtons;
        // Skip disabled items (only relevant for visible items, not the menu trigger)
        let attempts = 0;
        while (previousIndex < items.length &&
            items[previousIndex]?.disabled &&
            attempts < totalButtons) {
            previousIndex = (previousIndex - 1 + totalButtons) % totalButtons;
            attempts++;
        }
        // Only update and focus if we found a valid item
        this.lastFocusedIndex.set(previousIndex);
        const button = this._element.nativeElement.querySelectorAll('button')[previousIndex];
        button?.focus();
    }
    /** @internal to resolve TypeScript lint errors in the template. */
    getMenuDisplayText(item) {
        return 'label' in item ? item.label : item.ariaLabel;
    }
    /** @internal to resolve TypeScript lint errors in the template. */
    getTooltip(item) {
        return 'ariaLabel' in item ? item.ariaLabel : null;
    }
    /** @internal to resolve TypeScript lint errors in the template. */
    hasLabel(item) {
        return 'label' in item;
    }
    /**
     * The resize event can fire frequently during user interactions, so we debounce it to trigger
     * only after resizing or layout changes have stopped. This prevents flickering effects during resizing.
     */
    debounceResize(width) {
        clearTimeout(this.resizeTimeout);
        this.resizeTimeout = setTimeout(() => {
            if (width > this.width) {
                this.visibleItems.set([...(this.items() || [])]);
            }
            this.width = width;
            this.debounceTruncation();
        }, 100);
    }
    /**
     * Recursively manages Action Group item overflow.
     * Uses a 0ms timeout to run immediately after the next render cycle,
     * ensuring the component measures its size accurately for each recursion step.
     */
    debounceTruncation() {
        clearTimeout(this.truncationTimeout);
        this.truncationTimeout = setTimeout(() => {
            if (!this._element) {
                return;
            }
            if (this._element.nativeElement.scrollWidth <= this._element.nativeElement.offsetWidth) {
                // It's not overflowing
                return;
            }
            const visibleItems = this.visibleItems();
            const itemsToDisplay = visibleItems.slice(0, -1);
            if (itemsToDisplay.length !== visibleItems.length) {
                this.visibleItems.set(itemsToDisplay);
                if (itemsToDisplay.length) {
                    // If there are still items to display, we need to check again for overflow.
                    this.debounceTruncation();
                }
            }
        }, 0);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionGroupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatActionGroupComponent, isStandalone: true, selector: "sat-action-group", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null } }, host: { classAttribute: "sat-action-group" }, ngImport: i0, template: "<div role=\"group\">\n  @for (item of visibleItems(); track item) {\n    <button\n      type=\"button\"\n      satActionBarButton\n      [matTooltip]=\"getTooltip(item)\"\n      (click)=\"item.action()\"\n      [attr.disabled]=\"item.disabled ?? null\"\n      [attr.tabindex]=\"item.disabled ? null : (lastFocusedIndex() === $index ? '0' : '-1')\"\n      [attr.aria-label]=\"hasLabel(item) ? null : getMenuDisplayText(item)\"\n      (keydown.arrowRight)=\"item.disabled ? null : focusNext($event, $index)\"\n      (keydown.arrowLeft)=\"item.disabled ? null : focusPrevious($event, $index)\"\n    >\n      <mat-icon [svgIcon]=\"item.icon\" aria-hidden></mat-icon>\n      @if (hasLabel(item)) {\n        {{item.label}}\n      }\n    </button>\n    @if (item.hasTrailingDivider && !$last) {\n      <mat-divider [vertical]=\"true\"></mat-divider>\n    }\n  }\n  @let hiddenItems = this.hiddenItems();\n  @if (hiddenItems.length) {\n    <button\n      satActionBarButton\n      [matMenuTriggerFor]=\"menu\"\n      [attr.aria-label]=\"'sat-preview.action-bar.action-group.more' | translate\"\n      [matTooltip]=\"'sat-preview.action-bar.action-group.more' | translate\"\n      [attr.tabindex]=\"lastFocusedIndex() === visibleItems().length ? '0' : '-1'\"\n      (keydown.arrowRight)=\"focusNext($event, visibleItems().length)\"\n      (keydown.arrowLeft)=\"focusPrevious($event, visibleItems().length)\"\n    >\n      <mat-icon svgIcon=\"more_vert\"></mat-icon>\n    </button>\n    <mat-menu #menu=\"matMenu\">\n      @for (item of hiddenItems; track item) {\n        <button mat-menu-item (click)=\"item.action()\" [disabled]=\"item.disabled\">\n          <mat-icon [svgIcon]=\"item.icon\" aria-hidden></mat-icon>\n          {{getMenuDisplayText(item)}}\n        </button>\n        @if (item.hasTrailingDivider && !$last) {\n          <mat-divider></mat-divider>\n        }\n      }\n    </mat-menu>\n  }\n</div>\n", styles: [".sat-action-group{display:inline-flex;max-width:100%;overflow:hidden}.sat-action-group div{display:flex;flex:1 0 100%;align-items:center;gap:2px;flex-wrap:nowrap}.sat-action-group div>*{flex:0 0 auto}.sat-action-group mat-divider{height:100%}\n"], dependencies: [{ kind: "component", type: SatActionBarButtonComponent, selector: "[sat-action-bar-button], [satActionBarButton]", inputs: ["disabled"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i3.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i3.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i3.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i4.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionGroupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-action-group', host: { class: 'sat-action-group' }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [
                        SatActionBarButtonComponent,
                        MatIconModule,
                        MatTooltipModule,
                        MatMenuModule,
                        TranslatePipe,
                        MatDividerModule,
                    ], template: "<div role=\"group\">\n  @for (item of visibleItems(); track item) {\n    <button\n      type=\"button\"\n      satActionBarButton\n      [matTooltip]=\"getTooltip(item)\"\n      (click)=\"item.action()\"\n      [attr.disabled]=\"item.disabled ?? null\"\n      [attr.tabindex]=\"item.disabled ? null : (lastFocusedIndex() === $index ? '0' : '-1')\"\n      [attr.aria-label]=\"hasLabel(item) ? null : getMenuDisplayText(item)\"\n      (keydown.arrowRight)=\"item.disabled ? null : focusNext($event, $index)\"\n      (keydown.arrowLeft)=\"item.disabled ? null : focusPrevious($event, $index)\"\n    >\n      <mat-icon [svgIcon]=\"item.icon\" aria-hidden></mat-icon>\n      @if (hasLabel(item)) {\n        {{item.label}}\n      }\n    </button>\n    @if (item.hasTrailingDivider && !$last) {\n      <mat-divider [vertical]=\"true\"></mat-divider>\n    }\n  }\n  @let hiddenItems = this.hiddenItems();\n  @if (hiddenItems.length) {\n    <button\n      satActionBarButton\n      [matMenuTriggerFor]=\"menu\"\n      [attr.aria-label]=\"'sat-preview.action-bar.action-group.more' | translate\"\n      [matTooltip]=\"'sat-preview.action-bar.action-group.more' | translate\"\n      [attr.tabindex]=\"lastFocusedIndex() === visibleItems().length ? '0' : '-1'\"\n      (keydown.arrowRight)=\"focusNext($event, visibleItems().length)\"\n      (keydown.arrowLeft)=\"focusPrevious($event, visibleItems().length)\"\n    >\n      <mat-icon svgIcon=\"more_vert\"></mat-icon>\n    </button>\n    <mat-menu #menu=\"matMenu\">\n      @for (item of hiddenItems; track item) {\n        <button mat-menu-item (click)=\"item.action()\" [disabled]=\"item.disabled\">\n          <mat-icon [svgIcon]=\"item.icon\" aria-hidden></mat-icon>\n          {{getMenuDisplayText(item)}}\n        </button>\n        @if (item.hasTrailingDivider && !$last) {\n          <mat-divider></mat-divider>\n        }\n      }\n    </mat-menu>\n  }\n</div>\n", styles: [".sat-action-group{display:inline-flex;max-width:100%;overflow:hidden}.sat-action-group div{display:flex;flex:1 0 100%;align-items:center;gap:2px;flex-wrap:nowrap}.sat-action-group div>*{flex:0 0 auto}.sat-action-group mat-divider{height:100%}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Displays the current selection count and provides actions for managing selected items.
 * Shows a clear button when items are selected and renders trailing actions via sat-action-group.
 *
 * @example
 * ```html
 * <sat-selection-bar
 *   [count]="selectedItems.length"
 *   [actions]="selectionActions"
 *   (cleared)="clearSelection()"
 * />
 * ```
 */
class SatSelectionBarComponent {
    /** Number of items currently selected. */
    count = input(0);
    /** Actions rendered inside the trailing action group. */
    actions = input([]);
    /**
     * Emitted when the clear button is activated.
     */
    cleared = output();
    hasSelection = computed(() => (this.count() ?? 0) > 0);
    translateService = inject(TranslateService);
    emitCleared() {
        this.cleared.emit();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatSelectionBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatSelectionBarComponent, isStandalone: true, selector: "sat-selection-bar", inputs: { count: { classPropertyName: "count", publicName: "count", isSignal: true, isRequired: false, transformFunction: null }, actions: { classPropertyName: "actions", publicName: "actions", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { cleared: "cleared" }, host: { attributes: { "role": "toolbar" }, properties: { "attr.aria-label": "this.translateService.instant('sat-preview.action-bar.selection-bar.label')" }, classAttribute: "sat-selection-bar" }, ngImport: i0, template: "<div class=\"sat-selection-bar-leading-content\">\n  <span class=\"sat-selection-bar-count\" [attr.aria-live]=\"hasSelection() ? 'polite' : null\">\n    {{ 'sat-preview.action-bar.selection-bar.count' | translate: { count: count() } }}\n  </span>\n  @if (hasSelection()) {\n    <button\n      satActionBarButton\n      type=\"button\"\n      (click)=\"emitCleared()\"\n      class=\"sat-selection-bar-clear\"\n      [attr.aria-label]=\"'sat-preview.action-bar.selection-bar.clear-aria-label' | translate: { count: count() }\"\n      [matTooltip]=\"'sat-preview.action-bar.selection-bar.clear-tooltip' | translate\"\n    >\n      <mat-icon svgIcon=\"x_large\"></mat-icon>\n    </button>\n  }\n</div>\n\n@if (actions().length) {\n  <sat-action-group [items]=\"actions()\"></sat-action-group>\n}\n", styles: [".sat-selection-bar{width:100%;display:flex;align-items:center}.sat-selection-bar-count{padding:0 4px 0 8px;font:var(--mat-sys-body-medium)}.sat-selection-bar-leading-content{display:flex;align-items:center;margin-right:40px;flex-shrink:0}.sat-action-group{flex-grow:1}.sat-action-group div[role=group]{justify-content:flex-end}@container action-bar (width > 768px){.sat-action-group div[role=group]{justify-content:flex-start}}\n"], dependencies: [{ kind: "component", type: SatActionBarButtonComponent, selector: "[sat-action-bar-button], [satActionBarButton]", inputs: ["disabled"] }, { kind: "component", type: SatActionGroupComponent, selector: "sat-action-group", inputs: ["items"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: TranslateModule }, { kind: "pipe", type: i3$1.TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatSelectionBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-selection-bar', host: {
                        class: 'sat-selection-bar',
                        role: 'toolbar',
                        '[attr.aria-label]': "this.translateService.instant('sat-preview.action-bar.selection-bar.label')",
                    }, imports: [
                        SatActionBarButtonComponent,
                        SatActionGroupComponent,
                        MatIconModule,
                        MatTooltipModule,
                        TranslateModule,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<div class=\"sat-selection-bar-leading-content\">\n  <span class=\"sat-selection-bar-count\" [attr.aria-live]=\"hasSelection() ? 'polite' : null\">\n    {{ 'sat-preview.action-bar.selection-bar.count' | translate: { count: count() } }}\n  </span>\n  @if (hasSelection()) {\n    <button\n      satActionBarButton\n      type=\"button\"\n      (click)=\"emitCleared()\"\n      class=\"sat-selection-bar-clear\"\n      [attr.aria-label]=\"'sat-preview.action-bar.selection-bar.clear-aria-label' | translate: { count: count() }\"\n      [matTooltip]=\"'sat-preview.action-bar.selection-bar.clear-tooltip' | translate\"\n    >\n      <mat-icon svgIcon=\"x_large\"></mat-icon>\n    </button>\n  }\n</div>\n\n@if (actions().length) {\n  <sat-action-group [items]=\"actions()\"></sat-action-group>\n}\n", styles: [".sat-selection-bar{width:100%;display:flex;align-items:center}.sat-selection-bar-count{padding:0 4px 0 8px;font:var(--mat-sys-body-medium)}.sat-selection-bar-leading-content{display:flex;align-items:center;margin-right:40px;flex-shrink:0}.sat-action-group{flex-grow:1}.sat-action-group div[role=group]{justify-content:flex-end}@container action-bar (width > 768px){.sat-action-group div[role=group]{justify-content:flex-start}}\n"] }]
        }] });

/**
 * Container component for action bars.
 * Provides a dedicated horizontal surface for bulk and contextual actions,
 * typically placed above or below data-heavy content like tables or lists.
 */
class SatActionBarComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatActionBarComponent, isStandalone: true, selector: "sat-action-bar", host: { classAttribute: "sat-action-bar" }, ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, styles: [".sat-action-bar{width:100%;height:56px;box-sizing:border-box;display:flex;align-items:center;padding:8px;border-radius:8px;background-color:hsl(from var(--mat-sys-primary-fixed-dim) h s l/var(--mat-sys-dragged-state-layer-opacity));container:action-bar/inline-size}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-action-bar', template: `<ng-content></ng-content>`, host: { class: 'sat-action-bar' }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: [".sat-action-bar{width:100%;height:56px;box-sizing:border-box;display:flex;align-items:center;padding:8px;border-radius:8px;background-color:hsl(from var(--mat-sys-primary-fixed-dim) h s l/var(--mat-sys-dragged-state-layer-opacity));container:action-bar/inline-size}\n"] }]
        }] });

class SatActionBarModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionBarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatActionBarModule, imports: [SatActionBarButtonComponent,
            SatActionGroupComponent,
            SatActionBarComponent,
            SatSelectionBarComponent], exports: [SatActionBarButtonComponent,
            SatActionGroupComponent,
            SatActionBarComponent,
            SatSelectionBarComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionBarModule, imports: [SatActionGroupComponent,
            SatSelectionBarComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatActionBarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SatActionBarButtonComponent,
                        SatActionGroupComponent,
                        SatActionBarComponent,
                        SatSelectionBarComponent,
                    ],
                    exports: [
                        SatActionBarButtonComponent,
                        SatActionGroupComponent,
                        SatActionBarComponent,
                        SatSelectionBarComponent,
                    ],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatActionBarButtonComponent, SatActionBarComponent, SatActionBarModule, SatActionGroupComponent, SatSelectionBarComponent };
//# sourceMappingURL=hylandsoftware-satori-preview-action-bar.mjs.map
