import * as i0 from '@angular/core';
import { input, inject, ElementRef, signal, HostListener, Directive, contentChildren, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { MatRipple } from '@angular/material/core';

/** A directive applied to anchor elements to create navigation tabs. */
class SatNavigationTabDirective {
    /** Whether the tab is active. */
    active = input(false);
    /** @internal */
    elementRef = inject(ElementRef);
    /** @internal */
    tabindex = signal(-1);
    ripple = inject(MatRipple);
    launchRipple(event) {
        const color = `
      background-color: hsl(
        from var(${this.active() ? '--mat-sys-on-primary-fixed' : '--mat-sys-on-surface'}) h s l / var(--mat-sys-pressed-state-layer-opacity)
      );`;
        this.ripple.launch(event.x, event.y, {
            color,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNavigationTabDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.19", type: SatNavigationTabDirective, isStandalone: true, selector: "a[satNavigationTab]", inputs: { active: { classPropertyName: "active", publicName: "active", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "tab" }, listeners: { "mousedown": "launchRipple($event)" }, properties: { "class.sat-navigation-tab-active": "active()", "attr.aria-selected": "active()", "attr.tabindex": "tabindex()" }, classAttribute: "sat-navigation-tab mat-title-small" }, providers: [MatRipple], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNavigationTabDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'a[satNavigationTab]',
                    host: {
                        class: 'sat-navigation-tab mat-title-small',
                        role: 'tab',
                        '[class.sat-navigation-tab-active]': 'active()',
                        '[attr.aria-selected]': 'active()',
                        '[attr.tabindex]': 'tabindex()',
                    },
                    providers: [MatRipple],
                }]
        }], propDecorators: { launchRipple: [{
                type: HostListener,
                args: ['mousedown', ['$event']]
            }] } });

/** Navigation tabs provide a tabbed interface for navigating between different views or sections. */
class SatNavigationTabsComponent {
    tabs = contentChildren(SatNavigationTabDirective);
    ngAfterContentInit() {
        const tabs = this.tabs();
        if (tabs.length > 0) {
            tabs[0].tabindex.set(0);
        }
    }
    onKeydown(event) {
        const tabs = this.tabs();
        if (tabs.length === 0)
            return;
        const currentIndex = tabs.findIndex(tab => tab.elementRef.nativeElement === document.activeElement);
        if (currentIndex === -1)
            return;
        let newIndex = null;
        switch (event.key) {
            case 'ArrowRight':
                newIndex = (currentIndex + 1) % tabs.length;
                break;
            case 'ArrowLeft':
                newIndex = (currentIndex - 1 + tabs.length) % tabs.length;
                break;
            case 'Home':
                newIndex = 0;
                break;
            case 'End':
                newIndex = tabs.length - 1;
                break;
            default:
                return;
        }
        event.preventDefault();
        tabs[currentIndex].tabindex.set(-1);
        tabs[newIndex].tabindex.set(0);
        tabs[newIndex].elementRef.nativeElement.focus();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNavigationTabsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.19", type: SatNavigationTabsComponent, isStandalone: true, selector: "sat-navigation-tabs", host: { attributes: { "role": "tablist" }, listeners: { "keydown": "onKeydown($event)" }, classAttribute: "sat-navigation-tabs" }, queries: [{ propertyName: "tabs", predicate: SatNavigationTabDirective, isSignal: true }], ngImport: i0, template: `<ng-content select="a[satNavigationTab]"></ng-content>`, isInline: true, styles: [".sat-navigation-tabs{display:flex;flex-wrap:wrap;gap:4px 0}.sat-navigation-tabs a.sat-navigation-tab{display:flex;justify-content:center;align-items:center;text-align:center;color:var(--mat-sys-on-surface-variant);box-sizing:border-box;min-height:40px;padding:10px 16px;border-radius:var(--mat-sys-corner-small);position:relative;text-decoration:none;overflow:hidden}.sat-navigation-tabs a.sat-navigation-tab:hover{background-color:hsl(from var(--mat-sys-on-surface-variant) h s l/var(--mat-sys-hover-state-layer-opacity))}.sat-navigation-tabs a.sat-navigation-tab:focus-visible{outline:none}.sat-navigation-tabs a.sat-navigation-tab:focus-visible:before{content:\"\";position:absolute;inset:5px;border:2px solid var(--mat-sys-primary);border-radius:var(--mat-sys-corner-small)}.sat-navigation-tabs a.sat-navigation-tab.sat-navigation-tab-active{background-color:var(--mat-sys-secondary-container)}.sat-navigation-tabs a.sat-navigation-tab.sat-navigation-tab-active:after{content:\"\";position:absolute;left:16px;right:16px;bottom:0;height:3px;background-color:var(--mat-sys-primary);border-radius:var(--mat-sys-corner-full) var(--mat-sys-corner-full) 0 0}.sat-navigation-tabs a.sat-navigation-tab.sat-navigation-tab-active:hover{background-color:color-mix(in srgb,var(--mat-sys-secondary-container) 100%,var(--mat-sys-on-secondary-container) 8%)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNavigationTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-navigation-tabs', template: `<ng-content select="a[satNavigationTab]"></ng-content>`, host: {
                        class: 'sat-navigation-tabs',
                        role: 'tablist',
                        '(keydown)': 'onKeydown($event)',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: [".sat-navigation-tabs{display:flex;flex-wrap:wrap;gap:4px 0}.sat-navigation-tabs a.sat-navigation-tab{display:flex;justify-content:center;align-items:center;text-align:center;color:var(--mat-sys-on-surface-variant);box-sizing:border-box;min-height:40px;padding:10px 16px;border-radius:var(--mat-sys-corner-small);position:relative;text-decoration:none;overflow:hidden}.sat-navigation-tabs a.sat-navigation-tab:hover{background-color:hsl(from var(--mat-sys-on-surface-variant) h s l/var(--mat-sys-hover-state-layer-opacity))}.sat-navigation-tabs a.sat-navigation-tab:focus-visible{outline:none}.sat-navigation-tabs a.sat-navigation-tab:focus-visible:before{content:\"\";position:absolute;inset:5px;border:2px solid var(--mat-sys-primary);border-radius:var(--mat-sys-corner-small)}.sat-navigation-tabs a.sat-navigation-tab.sat-navigation-tab-active{background-color:var(--mat-sys-secondary-container)}.sat-navigation-tabs a.sat-navigation-tab.sat-navigation-tab-active:after{content:\"\";position:absolute;left:16px;right:16px;bottom:0;height:3px;background-color:var(--mat-sys-primary);border-radius:var(--mat-sys-corner-full) var(--mat-sys-corner-full) 0 0}.sat-navigation-tabs a.sat-navigation-tab.sat-navigation-tab-active:hover{background-color:color-mix(in srgb,var(--mat-sys-secondary-container) 100%,var(--mat-sys-on-secondary-container) 8%)}\n"] }]
        }] });

class SatNavigationTabsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNavigationTabsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatNavigationTabsModule, imports: [SatNavigationTabsComponent, SatNavigationTabDirective], exports: [SatNavigationTabsComponent, SatNavigationTabDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNavigationTabsModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNavigationTabsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SatNavigationTabsComponent, SatNavigationTabDirective],
                    exports: [SatNavigationTabsComponent, SatNavigationTabDirective],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatNavigationTabDirective, SatNavigationTabsComponent, SatNavigationTabsModule };
//# sourceMappingURL=hylandsoftware-satori-preview-navigation-tabs.mjs.map
