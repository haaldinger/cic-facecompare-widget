import * as i0 from '@angular/core';
import { inject, ElementRef, Renderer2, input, output, signal, HostListener, Directive, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';

/**
 * Directive to enable file upload functionality via drag-and-drop or file input dialog.
 *
 * Usage:
 * - Attach to a button element to open file selector dialog.
 * - Supports drag-and-drop for file uploads.
 * - Emits selected or dropped files via the `filesLoaded` output.
 *
 * Features:
 * - Handles file selection via input element.
 * - Handles drag-and-drop events for file uploads.
 * - Adds/removes CSS class during drag events for visual feedback.
 * - Emits a custom event with selected files.
 */
class SatUploadDirective {
    element = inject(ElementRef);
    renderer = inject(Renderer2);
    /**
     * Reference to a file input element.
     * Needed to open the file system dialog when the element is clicked.
     * This input element could be hidden.
     */
    input = input();
    /**
     * Indicates if the host element should open the file system dialog on click.
     */
    isButton = false;
    /**
     * Emits an event containing the selected or dropped files.
     */
    filesLoaded = output();
    /**
     * CSS class name applied during drag events for visual feedback.
     */
    dragging = signal(false);
    /**
     * Handler for the file input change event.
     */
    clearChangeEventHandler;
    constructor() {
        this.isButton = this.element.nativeElement instanceof HTMLButtonElement;
    }
    ngOnInit() {
        const fileInput = this.input();
        if (fileInput) {
            this.clearChangeEventHandler = this.renderer.listen(fileInput, 'change', (event) => this.onSelectFiles(event));
        }
    }
    ngOnDestroy() {
        this.clearChangeEventHandler?.();
    }
    /** @internal */
    onClick(event) {
        const fileInput = this.input();
        if (!fileInput || !this.isButton) {
            return;
        }
        event.preventDefault();
        fileInput.click();
    }
    /** @internal */
    onDragEnter(event) {
        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = 'copy';
        }
        this.dragging.set(true);
    }
    /** @internal */
    onDragOver(event) {
        event.preventDefault();
        if (event.dataTransfer) {
            event.dataTransfer.dropEffect = 'copy';
        }
        this.dragging.set(true);
    }
    /** @internal */
    onDragLeave() {
        this.dragging.set(false);
    }
    /** @internal */
    onDrop(event) {
        event.preventDefault();
        this.dragging.set(false);
        const dataTransfer = event?.dataTransfer ?? null;
        if (dataTransfer) {
            this.onFilesLoaded(this.getFilesDropped(dataTransfer));
        }
    }
    /** @internal */
    onFilesLoaded(files) {
        if (!this.element.nativeElement.disabled && files.length > 0) {
            this.filesLoaded.emit(files);
        }
    }
    /**
     * Extract files from the DataTransfer object used to hold the data that is being dragged during a drag and drop operation.
     *
     * @internal
     * @param dataTransfer DataTransfer object
     * @returns a list of file info objects
     */
    getFilesDropped(dataTransfer) {
        if (!dataTransfer) {
            return [];
        }
        // Use DataTransferItemList interface to access the file(s)
        if (dataTransfer.items) {
            return Array.from(dataTransfer.items)
                .map(item => item.getAsFile())
                .filter((file) => file !== null);
        }
        // Safari or Firefox fallback
        return Array.from(dataTransfer.files || []);
    }
    /**
     * Invoked when user selects files or folders by means of File Dialog
     * @internal
     */
    onSelectFiles(event) {
        if (!this.input() || this.element.nativeElement.disabled) {
            return;
        }
        const input = event.currentTarget;
        if (!input.files) {
            return;
        }
        const files = Array.from(input.files || []);
        this.onFilesLoaded(files);
        // clear value
        input.value = '';
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.19", type: SatUploadDirective, isStandalone: true, selector: "[satUpload]", inputs: { input: { classPropertyName: "input", publicName: "input", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { filesLoaded: "filesLoaded" }, host: { listeners: { "click": "onClick($event)", "dragenter": "onDragEnter($event)", "dragover": "onDragOver($event)", "dragleave": "onDragLeave($event)", "drop": "onDrop($event)" }, properties: { "class.sat-upload-dragging": "dragging()" } }, exportAs: ["satUpload"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satUpload]',
                    exportAs: 'satUpload',
                    host: {
                        '[class.sat-upload-dragging]': 'dragging()',
                    },
                }]
        }], ctorParameters: () => [], propDecorators: { onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], onDragEnter: [{
                type: HostListener,
                args: ['dragenter', ['$event']]
            }], onDragOver: [{
                type: HostListener,
                args: ['dragover', ['$event']]
            }], onDragLeave: [{
                type: HostListener,
                args: ['dragleave', ['$event']]
            }], onDrop: [{
                type: HostListener,
                args: ['drop', ['$event']]
            }] } });

/**
 * A drag-and-drop upload area component.
 *
 * This component visually indicates when files are being dragged over the window,
 * and emits `filesLoaded` output via the `SatUploadDirective`. It uses Angular signals
 * to track drag state and updates its CSS classes accordingly.
 *
 * Host listeners are registered for drag events on the window to manage the drag state:
 * - `dragenter`: Activates the dragging state.
 * - `dragleave`: Deactivates dragging only when leaving the window/document.
 * - `dragend` and `drop`: Always deactivates dragging.
 */
class SatUploadAreaComponent {
    isDragging = signal(false);
    /** @internal */
    onWindowDragEnter() {
        if (!this.isDragging()) {
            this.isDragging.set(true);
        }
    }
    /** @internal */
    onWindowDragLeave(event) {
        // Only set false if leaving the document/window
        if (event.relatedTarget === null) {
            this.isDragging.set(false);
        }
    }
    /** @internal */
    onWindowDragEnd() {
        this.isDragging.set(false);
    }
    /** @internal */
    onWindowDrop(event) {
        event.preventDefault();
        event.stopPropagation();
        this.isDragging.set(false);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadAreaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatUploadAreaComponent, isStandalone: true, selector: "sat-upload-area", host: { listeners: { "window:dragenter": "onWindowDragEnter($event)", "window:dragleave": "onWindowDragLeave($event)", "window:dragend": "onWindowDragEnd($event)", "window:drop": "onWindowDrop($event)" }, properties: { "class.sat-upload-area-dragging": "isDragging()" }, classAttribute: "sat-upload-area" }, hostDirectives: [{ directive: SatUploadDirective, outputs: ["filesLoaded", "filesLoaded"] }], ngImport: i0, template: "<ng-content></ng-content>\n<div class=\"sat-upload-area-layer\">\n  <mat-icon [svgIcon]=\"'upload'\" aria-hidden=\"true\" />\n  Drop files here.\n</div>\n", styles: [".sat-upload-area{display:block;position:relative}.sat-upload-area-layer{display:none;position:absolute;align-items:center;justify-content:center;inset:0;background-color:var(--mat-sys-secondary-container);color:var(--mat-sys-on-secondary-container);border-radius:var(--mat-sys-corner-large);border:4px solid transparent;font:var(--mat-sys-headline-large);gap:12px;flex-direction:column}.sat-upload-area-layer mat-icon{width:48px;height:48px}.sat-upload-area.sat-upload-area-dragging .sat-upload-area-layer{display:flex}.sat-upload-area.sat-upload-dragging .sat-upload-area-layer{border-color:var(--mat-sys-primary)}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadAreaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-upload-area', imports: [MatIconModule], host: {
                        class: 'sat-upload-area',
                        '[class.sat-upload-area-dragging]': 'isDragging()',
                    }, hostDirectives: [
                        {
                            directive: SatUploadDirective,
                            outputs: ['filesLoaded'],
                        },
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<ng-content></ng-content>\n<div class=\"sat-upload-area-layer\">\n  <mat-icon [svgIcon]=\"'upload'\" aria-hidden=\"true\" />\n  Drop files here.\n</div>\n", styles: [".sat-upload-area{display:block;position:relative}.sat-upload-area-layer{display:none;position:absolute;align-items:center;justify-content:center;inset:0;background-color:var(--mat-sys-secondary-container);color:var(--mat-sys-on-secondary-container);border-radius:var(--mat-sys-corner-large);border:4px solid transparent;font:var(--mat-sys-headline-large);gap:12px;flex-direction:column}.sat-upload-area-layer mat-icon{width:48px;height:48px}.sat-upload-area.sat-upload-area-dragging .sat-upload-area-layer{display:flex}.sat-upload-area.sat-upload-dragging .sat-upload-area-layer{border-color:var(--mat-sys-primary)}\n"] }]
        }], propDecorators: { onWindowDragEnter: [{
                type: HostListener,
                args: ['window:dragenter', ['$event']]
            }], onWindowDragLeave: [{
                type: HostListener,
                args: ['window:dragleave', ['$event']]
            }], onWindowDragEnd: [{
                type: HostListener,
                args: ['window:dragend', ['$event']]
            }], onWindowDrop: [{
                type: HostListener,
                args: ['window:drop', ['$event']]
            }] } });

class SatUploadModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatUploadModule, imports: [SatUploadAreaComponent, SatUploadDirective], exports: [SatUploadAreaComponent, SatUploadDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadModule, imports: [SatUploadAreaComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatUploadModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SatUploadAreaComponent, SatUploadDirective],
                    exports: [SatUploadAreaComponent, SatUploadDirective],
                    providers: [],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatUploadAreaComponent, SatUploadDirective, SatUploadModule };
//# sourceMappingURL=hylandsoftware-satori-preview-upload.mjs.map
