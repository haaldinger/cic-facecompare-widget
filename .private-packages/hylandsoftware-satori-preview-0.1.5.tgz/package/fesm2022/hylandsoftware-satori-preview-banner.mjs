import * as i0 from '@angular/core';
import { input, inject, computed, ElementRef, Directive, InjectionToken, contentChild, signal, afterNextRender, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { DOCUMENT, NgTemplateOutlet } from '@angular/common';
import * as i1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import { toSignal } from '@angular/core/rxjs-interop';
import { TranslateService, TranslatePipe } from '@ngx-translate/core';

const FOCUSABLE_SELECTOR = 'a[href]:not([inert]), button:not([disabled]):not([inert]), input:not([disabled]):not([inert]), select:not([disabled]):not([inert]), textarea:not([disabled]):not([inert]), [tabindex]:not([tabindex="-1"]):not([inert])';
/** The dismiss button for a Banner. */
class SatBannerDismissButtonDirective {
    /** Overrides the default aria-label. */
    ariaLabel = input(null);
    /** @internal */
    translateService = inject(TranslateService);
    dismissLabel = toSignal(this.translateService.stream('sat-preview.banner.dismiss-label'));
    /** @internal */
    resolvedAriaLabel = computed(() => this.ariaLabel() || this.dismissLabel());
    elementRef = inject(ElementRef);
    document = inject(DOCUMENT);
    /** @internal */
    moveFocusToNextElement() {
        const focusableElements = Array.from(this.document.querySelectorAll(FOCUSABLE_SELECTOR)).filter(el => !el.closest('[inert]') && !el.closest('fieldset[disabled]'));
        let thisElementIndex = -1;
        for (let i = focusableElements.length - 1; i >= 0; i--) {
            if (focusableElements[i] === this.elementRef.nativeElement) {
                thisElementIndex = i;
                break;
            }
        }
        if (thisElementIndex !== -1 && thisElementIndex + 1 < focusableElements.length) {
            focusableElements[thisElementIndex + 1].focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerDismissButtonDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.19", type: SatBannerDismissButtonDirective, isStandalone: true, selector: "button[satBannerDismissButton]", inputs: { ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null } }, host: { listeners: { "click": "moveFocusToNextElement()" }, properties: { "attr.aria-label": "resolvedAriaLabel()" }, classAttribute: "sat-banner-dismiss-button" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerDismissButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: 'button[satBannerDismissButton]',
                    host: {
                        class: 'sat-banner-dismiss-button',
                        '[attr.aria-label]': 'resolvedAriaLabel()',
                        '(click)': 'moveFocusToNextElement()',
                    },
                }]
        }] });

let nextBannerId = 0;
/** Injection token for the parent banner component. */
const SAT_BANNER = new InjectionToken('SAT_BANNER');
/** A banner displays a prominent message and related optional actions. */
class SatBannerComponent {
    /** Unique ID for the banner message, used for aria-describedby. */
    messageId = `sat-banner-${nextBannerId++}-message`;
    /** Whether a dismiss button is projected into the banner. @internal */
    hasDismissButton = computed(() => !!this.dismissButton());
    dismissButton = contentChild(SatBannerDismissButtonDirective);
    /** Whether to display a border around the banner, defaults to `false`. */
    border = input(false);
    /** The variant style of the banner, corresponds to Satori status palettes, defaults to `info`. */
    variant = input('info');
    /**
     * The orientation of the banner. When not provided, the orientation is automatically
     * determined based on the available width. When explicitly set, the banner will not
     * respond to resize changes.
     */
    orientation = input();
    /** @internal */
    icon = computed(() => {
        const variant = this.variant();
        switch (variant) {
            case 'success':
                return 'circle_check';
            case 'warning':
                return 'critical';
            case 'important':
                return 'error';
            case 'info':
            default:
                return 'info';
        }
    });
    /** @internal */
    resolvedOrientation = computed(() => this.orientation() ?? this.autoOrientation());
    autoOrientation = signal('inline');
    elementRef = inject(ElementRef);
    resizeObserver = new ResizeObserver(() => {
        if (this.orientation() !== undefined) {
            return;
        }
        this.setOrientation();
    });
    width = 0;
    constructor() {
        this.resizeObserver.observe(this.elementRef.nativeElement);
        afterNextRender(() => {
            if (this.orientation() !== undefined) {
                return;
            }
            this.width = this.elementRef.nativeElement.clientWidth;
            if (this.isContentOverflowing()) {
                this.autoOrientation.set('stacked');
            }
        });
    }
    ngOnDestroy() {
        this.resizeObserver?.disconnect();
    }
    isContentOverflowing() {
        const bannerLine = this.elementRef.nativeElement.querySelector('[data-banner-first-line]');
        if (!bannerLine) {
            return false;
        }
        return bannerLine.scrollWidth > bannerLine.clientWidth;
    }
    setOrientation() {
        const newWidth = this.elementRef.nativeElement.clientWidth;
        if (newWidth < this.width && this.autoOrientation() === 'inline') {
            if (this.isContentOverflowing()) {
                this.autoOrientation.set('stacked');
            }
        }
        if (newWidth > this.width && this.autoOrientation() === 'stacked') {
            this.autoOrientation.set('inline');
            // After rerender as inline, check if for this width inline content fits and adjust if necessary:
            setTimeout(() => {
                if (this.isContentOverflowing()) {
                    this.autoOrientation.set('stacked');
                }
            }, 0);
        }
        this.width = newWidth;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatBannerComponent, isStandalone: true, selector: "sat-banner", inputs: { border: { classPropertyName: "border", publicName: "border", isSignal: true, isRequired: false, transformFunction: null }, variant: { classPropertyName: "variant", publicName: "variant", isSignal: true, isRequired: false, transformFunction: null }, orientation: { classPropertyName: "orientation", publicName: "orientation", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "status" }, properties: { "class.sat-banner-border": "border()", "class.sat-banner-inline": "resolvedOrientation() === 'inline'", "class.sat-banner-stacked": "resolvedOrientation() === 'stacked'", "style.--sat-banner-background": "`var(--sat-sys-${variant()}-container)`", "style.--sat-banner-color": "`var(--sat-sys-on-${variant()}-container)`", "style.--sat-banner-border": "`1px solid var(--sat-sys-${variant()}-icon)`" }, classAttribute: "sat-banner" }, providers: [{ provide: SAT_BANNER, useExisting: SatBannerComponent }], queries: [{ propertyName: "dismissButton", first: true, predicate: SatBannerDismissButtonDirective, descendants: true, isSignal: true }], ngImport: i0, template: `
    <ng-template #bannerActions>
      <div class="sat-banner-actions" data-banner-actions>
        <ng-content select="[satBannerAction]"></ng-content>
      </div>
    </ng-template>
    <div class="sat-banner-line sat-banner-first-line" [class.sat-banner-line--with-dismiss-button-spacing]="hasDismissButton()" data-banner-first-line>
      <div class="sat-banner-icon-and-message">
        <mat-icon [svgIcon]="icon()"></mat-icon>
        <ng-content select="sat-banner-message"></ng-content>
      </div>
      @if (resolvedOrientation() === 'inline') {
        <ng-template [ngTemplateOutlet]="bannerActions"></ng-template>
      }
    </div>
    @if (resolvedOrientation() === 'stacked') {
      <div class="sat-banner-line" data-banner-stacked-line>
        <ng-template [ngTemplateOutlet]="bannerActions"></ng-template>
      </div>
    }
    <ng-content select="[satBannerDismissButton]"></ng-content>
  `, isInline: true, styles: [".sat-banner{position:relative;box-sizing:border-box;padding:4px 0;display:block;border-radius:var(--mat-sys-corner-small);background-color:var(--sat-banner-background);color:var(--sat-banner-color)}.sat-banner.sat-banner-border{border:var(--sat-banner-border)}.sat-banner-line{display:flex;gap:8px;padding-inline-start:16px}.sat-banner-line.sat-banner-first-line{min-height:48px}.sat-banner-line--with-dismiss-button-spacing{padding-inline-end:56px}.sat-banner-icon-and-message{flex-grow:1;padding-top:12px;display:flex;gap:8px}.sat-banner-icon-and-message mat-icon{flex-shrink:0}.sat-banner-inline .sat-banner-message{text-wrap:nowrap}.sat-banner-actions{flex-shrink:0;flex-grow:1;display:flex;align-items:center;justify-content:flex-end;gap:8px}button.sat-banner-dismiss-button{position:absolute;top:4px;inset-inline-end:0;min-width:48px;margin-inline-start:8px}\n"], dependencies: [{ kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-banner', template: `
    <ng-template #bannerActions>
      <div class="sat-banner-actions" data-banner-actions>
        <ng-content select="[satBannerAction]"></ng-content>
      </div>
    </ng-template>
    <div class="sat-banner-line sat-banner-first-line" [class.sat-banner-line--with-dismiss-button-spacing]="hasDismissButton()" data-banner-first-line>
      <div class="sat-banner-icon-and-message">
        <mat-icon [svgIcon]="icon()"></mat-icon>
        <ng-content select="sat-banner-message"></ng-content>
      </div>
      @if (resolvedOrientation() === 'inline') {
        <ng-template [ngTemplateOutlet]="bannerActions"></ng-template>
      }
    </div>
    @if (resolvedOrientation() === 'stacked') {
      <div class="sat-banner-line" data-banner-stacked-line>
        <ng-template [ngTemplateOutlet]="bannerActions"></ng-template>
      </div>
    }
    <ng-content select="[satBannerDismissButton]"></ng-content>
  `, host: {
                        class: 'sat-banner',
                        role: 'status',
                        '[class.sat-banner-border]': 'border()',
                        '[class.sat-banner-inline]': "resolvedOrientation() === 'inline'",
                        '[class.sat-banner-stacked]': "resolvedOrientation() === 'stacked'",
                        '[style.--sat-banner-background]': '`var(--sat-sys-${variant()}-container)`',
                        '[style.--sat-banner-color]': '`var(--sat-sys-on-${variant()}-container)`',
                        '[style.--sat-banner-border]': '`1px solid var(--sat-sys-${variant()}-icon)`',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [MatIconModule, NgTemplateOutlet], providers: [{ provide: SAT_BANNER, useExisting: SatBannerComponent }], styles: [".sat-banner{position:relative;box-sizing:border-box;padding:4px 0;display:block;border-radius:var(--mat-sys-corner-small);background-color:var(--sat-banner-background);color:var(--sat-banner-color)}.sat-banner.sat-banner-border{border:var(--sat-banner-border)}.sat-banner-line{display:flex;gap:8px;padding-inline-start:16px}.sat-banner-line.sat-banner-first-line{min-height:48px}.sat-banner-line--with-dismiss-button-spacing{padding-inline-end:56px}.sat-banner-icon-and-message{flex-grow:1;padding-top:12px;display:flex;gap:8px}.sat-banner-icon-and-message mat-icon{flex-shrink:0}.sat-banner-inline .sat-banner-message{text-wrap:nowrap}.sat-banner-actions{flex-shrink:0;flex-grow:1;display:flex;align-items:center;justify-content:flex-end;gap:8px}button.sat-banner-dismiss-button{position:absolute;top:4px;inset-inline-end:0;min-width:48px;margin-inline-start:8px}\n"] }]
        }], ctorParameters: () => [] });

/** Marks a button as a banner action. Apply this directive to action buttons inside a Banner. */
class SatBannerActionDirective {
    /** @internal */
    banner = inject(SAT_BANNER);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerActionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: SatBannerActionDirective, isStandalone: true, selector: "[satBannerAction]", host: { properties: { "attr.aria-describedby": "banner.messageId" }, classAttribute: "sat-banner-action" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerActionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satBannerAction]',
                    host: {
                        class: 'sat-banner-action',
                        '[attr.aria-describedby]': 'banner.messageId',
                    },
                }]
        }] });

/** A prominent message for a Banner. */
class SatBannerMessageComponent {
    /** @internal */
    banner = inject(SAT_BANNER);
    /** @internal */
    variantKey = computed(() => `sat-preview.banner.${this.banner.variant()}`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerMessageComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatBannerMessageComponent, isStandalone: true, selector: "sat-banner-message", host: { properties: { "attr.id": "banner.messageId" }, classAttribute: "sat-banner-message" }, ngImport: i0, template: `<span class="cdk-visually-hidden">{{ variantKey() | translate }}</span><ng-content></ng-content>`, isInline: true, dependencies: [{ kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerMessageComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-banner-message',
                    template: `<span class="cdk-visually-hidden">{{ variantKey() | translate }}</span><ng-content></ng-content>`,
                    host: {
                        class: 'sat-banner-message',
                        '[attr.id]': 'banner.messageId',
                    },
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    imports: [TranslatePipe],
                }]
        }] });

class SatBannerModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatBannerModule, imports: [SatBannerComponent,
            SatBannerActionDirective,
            SatBannerMessageComponent,
            SatBannerDismissButtonDirective], exports: [SatBannerComponent,
            SatBannerActionDirective,
            SatBannerMessageComponent,
            SatBannerDismissButtonDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerModule, imports: [SatBannerComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBannerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SatBannerComponent,
                        SatBannerActionDirective,
                        SatBannerMessageComponent,
                        SatBannerDismissButtonDirective,
                    ],
                    exports: [
                        SatBannerComponent,
                        SatBannerActionDirective,
                        SatBannerMessageComponent,
                        SatBannerDismissButtonDirective,
                    ],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SAT_BANNER, SatBannerActionDirective, SatBannerComponent, SatBannerDismissButtonDirective, SatBannerMessageComponent, SatBannerModule };
//# sourceMappingURL=hylandsoftware-satori-preview-banner.mjs.map
