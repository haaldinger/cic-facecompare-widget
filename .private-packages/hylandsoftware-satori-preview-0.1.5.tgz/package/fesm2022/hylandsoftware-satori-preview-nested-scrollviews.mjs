import * as i0 from '@angular/core';
import { inject, computed, Directive, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { SatAppHeaderService } from '@hylandsoftware/satori-ui/app-header';

class SatLeadingNestedScrollviewDirective {
    appHeaderService = inject(SatAppHeaderService);
    /* @internal */
    topOffset = computed(() => this.appHeaderService.verticalSpace() ?? 0);
    style = {
        position: 'sticky',
        overflowY: 'auto',
        scrollbarGutter: 'stable',
        scrollbarWidth: 'thin',
        scrollbarColor: 'var(--mat-sys-outline) transparent',
        boxSizing: 'border-box',
        flexShrink: '0',
    };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatLeadingNestedScrollviewDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: SatLeadingNestedScrollviewDirective, isStandalone: true, selector: "[satLeadingNestedScrollview]", host: { properties: { "style": "style", "style.top": "topOffset() + \"px\"", "style.maxHeight": "\"calc(100vh - \" + topOffset() + \"px)\"" }, classAttribute: "sat-leading-nested-scrollview" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatLeadingNestedScrollviewDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satLeadingNestedScrollview]',
                    host: {
                        class: 'sat-leading-nested-scrollview',
                        '[style]': 'style',
                        '[style.top]': 'topOffset() + "px"',
                        '[style.maxHeight]': '"calc(100vh - " + topOffset() + "px)"',
                    },
                }]
        }] });

class SatTrailingNestedScrollviewDirective {
    appHeaderService = inject(SatAppHeaderService);
    /* @internal */
    topOffset = computed(() => this.appHeaderService.verticalSpace() ?? 0);
    style = {
        position: 'sticky',
        overflowY: 'auto',
        scrollbarWidth: 'thin',
        scrollbarColor: 'var(--mat-sys-outline) transparent',
        boxSizing: 'border-box',
        flexShrink: '0',
    };
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatTrailingNestedScrollviewDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: SatTrailingNestedScrollviewDirective, isStandalone: true, selector: "[satTrailingNestedScrollview]", host: { properties: { "style": "style", "style.top": "topOffset() + \"px\"", "style.maxHeight": "\"calc(100vh - \" + topOffset() + \"px)\"" }, classAttribute: "sat-trailing-nested-scrollview" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatTrailingNestedScrollviewDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satTrailingNestedScrollview]',
                    host: {
                        class: 'sat-trailing-nested-scrollview',
                        '[style]': 'style',
                        '[style.top]': 'topOffset() + "px"',
                        '[style.maxHeight]': '"calc(100vh - " + topOffset() + "px)"',
                    },
                }]
        }] });

class SatNestedScrollviewsComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNestedScrollviewsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatNestedScrollviewsComponent, isStandalone: true, selector: "sat-nested-scrollviews", host: { styleAttribute: "display: flex;" }, ngImport: i0, template: `
    <ng-content select="[satLeadingNestedScrollview]"></ng-content>
    <div style="flex-grow: 1;">
      <ng-content></ng-content>
    </div>
    <ng-content select="[satTrailingNestedScrollview]"></ng-content>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNestedScrollviewsComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-nested-scrollviews',
                    template: `
    <ng-content select="[satLeadingNestedScrollview]"></ng-content>
    <div style="flex-grow: 1;">
      <ng-content></ng-content>
    </div>
    <ng-content select="[satTrailingNestedScrollview]"></ng-content>
  `,
                    host: { style: 'display: flex;' },
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }] });

class SatNestedScrollviewsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNestedScrollviewsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatNestedScrollviewsModule, imports: [SatTrailingNestedScrollviewDirective,
            SatLeadingNestedScrollviewDirective,
            SatNestedScrollviewsComponent], exports: [SatTrailingNestedScrollviewDirective,
            SatLeadingNestedScrollviewDirective,
            SatNestedScrollviewsComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNestedScrollviewsModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatNestedScrollviewsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        SatTrailingNestedScrollviewDirective,
                        SatLeadingNestedScrollviewDirective,
                        SatNestedScrollviewsComponent,
                    ],
                    exports: [
                        SatTrailingNestedScrollviewDirective,
                        SatLeadingNestedScrollviewDirective,
                        SatNestedScrollviewsComponent,
                    ],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatLeadingNestedScrollviewDirective, SatNestedScrollviewsComponent, SatNestedScrollviewsModule, SatTrailingNestedScrollviewDirective };
//# sourceMappingURL=hylandsoftware-satori-preview-nested-scrollviews.mjs.map
