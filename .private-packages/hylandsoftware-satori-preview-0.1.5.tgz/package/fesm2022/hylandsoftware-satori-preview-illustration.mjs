import * as i0 from '@angular/core';
import { InjectionToken, makeEnvironmentProviders, provideAppInitializer, inject, ElementRef, ErrorHandler, input, effect, untracked, ViewEncapsulation, ChangeDetectionStrategy, Component, NgModule } from '@angular/core';
import { rxResource } from '@angular/core/rxjs-interop';
import { MatIconRegistry } from '@angular/material/icon';
import { take, catchError, of } from 'rxjs';
import { DomSanitizer } from '@angular/platform-browser';

const SAT_ILLUSTRATION_DEFAULT_CONFIG = {
    svgPath: 'satori-svg',
    namespace: 'sat-illustrations',
};
/**
 * Injection token for Satori illustration configuration.
 */
const SAT_ILLUSTRATION_CONFIG = new InjectionToken('SAT_ILLUSTRATION_CONFIG', {
    providedIn: 'root',
    factory: () => SAT_ILLUSTRATION_DEFAULT_CONFIG,
});
function provideSatoriIllustrations(config) {
    return makeEnvironmentProviders([
        config
            ? {
                provide: SAT_ILLUSTRATION_CONFIG,
                useValue: { ...SAT_ILLUSTRATION_DEFAULT_CONFIG, ...config },
            }
            : [],
        provideAppInitializer(() => {
            const registry = inject(MatIconRegistry);
            const sanitizer = inject(DomSanitizer);
            const illustrationConfig = inject(SAT_ILLUSTRATION_CONFIG);
            registry.addSvgIconResolver((name, namespace) => {
                if (namespace !== (illustrationConfig.namespace ?? SAT_ILLUSTRATION_DEFAULT_CONFIG.namespace)) {
                    return null;
                }
                const svgPath = illustrationConfig.svgPath ?? SAT_ILLUSTRATION_DEFAULT_CONFIG.svgPath;
                return sanitizer.bypassSecurityTrustResourceUrl(`${svgPath}/${name}.svg`);
            });
        }),
    ]);
}

class SatIllustrationComponent {
    _elementRef = inject(ElementRef);
    _iconRegistry = inject(MatIconRegistry);
    illustrationConfig = inject(SAT_ILLUSTRATION_CONFIG);
    _errorHandler = inject(ErrorHandler);
    /**
     * The size of the illustration.
     */
    size = input('large');
    /**
     * The name of the illustration to display.
     */
    illustration = input(null);
    constructor() {
        effect(() => {
            if (!this.svgResource.error()) {
                const svg = this.svgResource.value();
                untracked(() => {
                    if (!this.svgResource.isLoading()) {
                        this._setSvgElement(svg);
                    }
                });
            }
        });
    }
    // TODO: angular 20 migration: remove request and loader and fix types
    svgResource = rxResource({
        request: this.illustration,
        params: this.illustration,
        loader: ({ request }) => this._loadSvg(request),
        stream: ({ params }) => this._loadSvg(params),
    });
    _loadSvg(svgName) {
        return svgName
            ? this._iconRegistry.getNamedSvgIcon(svgName, this.illustrationConfig.namespace).pipe(take(1), catchError(err => {
                this._errorHandler.handleError(new Error(`Error retrieving icon "${svgName}"! ${err.message}`));
                return of(null);
            }))
            : of(null);
    }
    /** Clears out the current SVG element from the host element. */
    _clearSvgElement() {
        this._elementRef.nativeElement.querySelector('svg')?.remove();
    }
    /** Sets the current SVG element on the host element. */
    _setSvgElement(svg) {
        this._clearSvgElement();
        if (svg) {
            this._elementRef.nativeElement.appendChild(svg);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatIllustrationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.19", type: SatIllustrationComponent, isStandalone: true, selector: "sat-illustration", inputs: { size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, illustration: { classPropertyName: "illustration", publicName: "illustration", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "img" }, properties: { "class.sat-illustration-small": "size() === 'small'", "class.sat-illustration-medium": "size() === 'medium'", "class.sat-illustration-large": "size() === 'large'", "attr.data-sat-illustration-name": "svgResource.hasValue() ? illustration() : null" }, classAttribute: "sat-illustration" }, ngImport: i0, template: '', isInline: true, styles: [".sat-illustration{display:block;margin:0 auto}.sat-illustration>svg{display:block}.sat-illustration-small>svg{width:80px;height:80px}.sat-illustration-medium>svg{width:120px;height:120px}.sat-illustration-large>svg{width:200px;height:200px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatIllustrationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-illustration', template: '', host: {
                        'role': 'img',
                        'class': 'sat-illustration',
                        '[class.sat-illustration-small]': "size() === 'small'",
                        '[class.sat-illustration-medium]': "size() === 'medium'",
                        '[class.sat-illustration-large]': "size() === 'large'",
                        '[attr.data-sat-illustration-name]': 'svgResource.hasValue() ? illustration() : null',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: [".sat-illustration{display:block;margin:0 auto}.sat-illustration>svg{display:block}.sat-illustration-small>svg{width:80px;height:80px}.sat-illustration-medium>svg{width:120px;height:120px}.sat-illustration-large>svg{width:200px;height:200px}\n"] }]
        }], ctorParameters: () => [] });

class SatIllustrationModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatIllustrationModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatIllustrationModule, imports: [SatIllustrationComponent], exports: [SatIllustrationComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatIllustrationModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatIllustrationModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SatIllustrationComponent],
                    exports: [SatIllustrationComponent],
                    providers: [],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SAT_ILLUSTRATION_CONFIG, SAT_ILLUSTRATION_DEFAULT_CONFIG, SatIllustrationComponent, SatIllustrationModule, provideSatoriIllustrations };
//# sourceMappingURL=hylandsoftware-satori-preview-illustration.mjs.map
