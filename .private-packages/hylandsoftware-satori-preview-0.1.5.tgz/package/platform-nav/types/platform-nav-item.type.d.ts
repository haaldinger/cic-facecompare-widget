/** The base interface for navigation items. */
export interface SatBaseNavigationItem {
    /**
     * The label to display for the navigation item.
     * @required
     */
    label: string;
    /**
     * The path to navigate to when the item is clicked.
     * @required
     */
    path: string;
    /**
     * Determines whether the list item should be rendered in an active/selected state.
     */
    active?: boolean;
}
/** This interface extends `SatBaseNavigationItem`. This is used for navigation items that include an icon. */
export interface SatNavigationItemWithIcon extends SatBaseNavigationItem {
    /**
     * The icon to display for the navigation item.
     * @required
     */
    icon: string;
}
/** This interface extends `SatBaseNavigationItem`. This is used for navigation items that include an image. */
export interface SatNavigationItemWithImage extends SatBaseNavigationItem {
    /**
     * The image to display for the navigation item.
     * @required
     */
    image: string;
}
/**
 * The structure of a navigation item used within the platform navigation. It is an intersection of the `SatBaseNavigationItem` or `SatNavigationItemWithIcon` or `SatNavigationItemWithImage` interface. It includes properties for defining the label, path, icon or image, and active state of a navigation item.
 */
export type SatNavigationItem = SatBaseNavigationItem | SatNavigationItemWithIcon | SatNavigationItemWithImage;
