import * as i0 from "@angular/core";
/**
 * This component acts as a content projection outlet for the main area of the layout when using the platform navigation. It is intended to be placed adjacent to the vertical sidebar and wraps whatever content you insert within it using ng-content.
 * It serves as a flexible container for your app’s primary page content while structurally aligning with the sidebar layout (SatPlatformNavContainerComponent).
 *
 * Key features:
 * - Supports custom content projection via `ng-content`.
 * - Integrates seamlessly into layouts using `SatPlatformNav`.
 */
export declare class SatPlatformNavMainContentComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavMainContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavMainContentComponent, "sat-platform-nav-main-content", never, {}, {}, never, ["*"], true, never>;
}
