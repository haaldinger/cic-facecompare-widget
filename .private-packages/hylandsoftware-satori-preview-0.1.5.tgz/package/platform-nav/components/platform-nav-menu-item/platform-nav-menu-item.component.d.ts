import { ElementRef } from '@angular/core';
import { SatPlatformNavStateService } from '../../services/platform-nav-state.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/core";
import * as i2 from "@angular/material/tooltip";
import * as i3 from "@angular/cdk/menu";
/**
 * This element represents an interactive item within the `sat-platform-nav` navigation panel. It supports icons, dynamic avatar generation, active state styling, and responsive behavior based on the collapsed state of the sidebar.
 *
 * The `SatPlatformNavMenuItemComponent` is designed to display a single item in the platform navigation.
 *
 * Key features:
 * - Accepts a projected mat-icon for visual representation of the item.
 * - Automatically generates a fallback avatar (initials-based) if no icon is present, using the SatPlatformNavInitialsPipe applied to the item’s label.
 * - Hides the text label when the navigation panel is collapsed, using SatPlatformNavService.
 * - Allows keyboard accessibility supporting navigation via keyboard.
 *
 * Prefer importing from the satori-cic package.
 * Example:
 *   import { SatPlatformNavMenuItemComponent } from '@hylandsoftware/satori-cic/platform-nav';
 * instead of:
 *   import { SatPlatformNavMenuItemComponent } from '@hylandsoftware/satori-ui/platform-nav';
 *
 * Deprecated usage: Importing from `satori-ui` is deprecated and will be removed in future versions.
 */
export declare class SatPlatformNavMenuItemComponent {
    element: ElementRef<HTMLElement>;
    /**
     * Determines whether the menu item should be rendered in an active/selected state.
     */
    readonly active: import("@angular/core").InputSignal<boolean>;
    /**
     * @internal
     * The text content of the label, used for tooltip and fallback initials.
     */
    readonly labelText: import("@angular/core").WritableSignal<string | undefined>;
    /** @internal */
    readonly label: import("@angular/core").Signal<ElementRef<HTMLParagraphElement> | undefined>;
    /** @internal */
    readonly computedLabel: import("@angular/core").Signal<string | null | undefined>;
    /** @internal */
    readonly labelHeight: import("@angular/core").Signal<string>;
    /** @internal */
    readonly service: SatPlatformNavStateService;
    private readonly tooltipService;
    private readonly matTooltipService;
    private readonly matRippleService;
    private readonly tooltipDelay;
    private tooltipTimer;
    constructor();
    onSpaceKeyDown(event: KeyboardEvent): void;
    /** @internal */
    onMouseEnter(): void;
    /** @internal */
    onMouseLeave(): void;
    /** @internal */
    labelChanged(event: MutationRecord[]): void;
    private hidePreviousTooltip;
    private showCurrentTooltip;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavMenuItemComponent, "a[sat-platform-nav-menu-item], a[satPlatformNavMenuItem]", never, { "active": { "alias": "active"; "required": false; "isSignal": true; }; }, {}, never, ["sat-platform-nav-avatar", "*"], true, [{ directive: typeof i1.MatRipple; inputs: {}; outputs: {}; }, { directive: typeof i2.MatTooltip; inputs: {}; outputs: {}; }, { directive: typeof i3.CdkMenuItem; inputs: {}; outputs: {}; }]>;
}
