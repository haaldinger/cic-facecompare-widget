import * as i0 from "@angular/core";
/**
 * This serves as a container for user-related UI elements within the navigation. It wraps the `SatPlatformNavUserProfileComponent` and provides a slot (`satPlatformNavUserMenu`) for displaying a user menu, typically with dynamic items such as languages or logout options. This component ensures consistent layout and behavior for the user section in the navigation.
 *
 * Key features:
 * - Acts as the container for the user interaction section in the sidebar.
 * - Typically positioned at the bottom of the nav, separating navigation from account-related actions.
 * - Can act as a menu trigger using `[matMenuTriggerFor]`.
 *
 * @example
 * <sat-platform-nav-user>
 *   <button satPlatformNavUserProfile [matMenuTriggerFor]="userMenu">
 *     Lorem Ipsum
 *   </button>
 *   <mat-menu #userMenu="matMenu" satPlatformNavUserMenu>
 *     <button mat-menu-item>
 *       …
 *     </button>
 *   </mat-menu>
 * </sat-platform-nav-user>
 *
 */
export declare class SatPlatformNavUserComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavUserComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavUserComponent, "sat-platform-nav-user", never, {}, {}, never, ["button[satPlatformNavUserProfile]", "[satPlatformNavUserMenu]"], true, never>;
}
