import { ElementRef } from '@angular/core';
import { MatTooltip } from '@angular/material/tooltip';
import { SatPlatformNavStateService } from '../../services/platform-nav-state.service';
import * as i0 from "@angular/core";
import * as i1 from "@angular/material/tooltip";
/**
 * This component displays a clickable user identity block, such as a name along with an avatar that can have initials or user profile image in the platform sidebar’s user section. It also has a responsive behavior based on the collapsed state of the sidebar.
 *
 * Key features:
 * - Typically used to show user info like names, emails, or avatar initials.
 * - Styled for sidebar placement within sat-platform-nav-user.
 */
export declare class SatPlatformNavUserProfileComponent {
    /** @internal */
    readonly service: SatPlatformNavStateService;
    /** @internal */
    readonly tooltipService: MatTooltip;
    /**
     * @internal
     * The text content of the profile name, used for tooltip and fallback initials.
     */
    readonly profileNameText: import("@angular/core").WritableSignal<string | undefined>;
    /** @internal */
    readonly profileName: import("@angular/core").Signal<ElementRef<HTMLParagraphElement> | undefined>;
    /** @internal */
    readonly computedProfileName: import("@angular/core").Signal<string | undefined>;
    constructor();
    /** @internal */
    profileNameChanged(event: MutationRecord[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavUserProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavUserProfileComponent, "button[satPlatformNavUserProfile]", never, {}, {}, never, ["sat-avatar", "*"], true, [{ directive: typeof i1.MatTooltip; inputs: {}; outputs: {}; }]>;
}
