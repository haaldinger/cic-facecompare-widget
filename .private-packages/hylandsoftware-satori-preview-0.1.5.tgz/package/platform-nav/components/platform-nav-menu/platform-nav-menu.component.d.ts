import * as i0 from "@angular/core";
import * as i1 from "@angular/cdk/menu";
/**
 * A container component for platform navigation menu items.
 * This component provides a structured wrapper for navigation items within the platform navigation.
 */
export declare class SatPlatformNavMenuComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavMenuComponent, "sat-platform-nav-menu", never, {}, {}, never, ["*"], true, [{ directive: typeof i1.CdkMenu; inputs: {}; outputs: {}; }]>;
}
