import * as i0 from "@angular/core";
import * as i1 from "./platform-nav.component";
import * as i2 from "./components/platform-nav-container/platform-nav-container.component";
import * as i3 from "./components/platform-nav-main-content.component";
import * as i4 from "./components/platform-nav-menu/platform-nav-menu.component";
import * as i5 from "./components/platform-nav-menu-item/platform-nav-menu-item.component";
import * as i6 from "./components/platform-nav-user/platform-nav-user-profile.component";
import * as i7 from "./components/platform-nav-user/platform-nav-user.component";
import * as i8 from "./components/platform-nav-avatar/platform-nav-avatar.component";
import * as i9 from "./components/platform-nav-environment-switcher/platform-nav-environment-switcher.component";
import * as i10 from "./platform-nav-initials.pipe";
import * as i11 from "./components/platform-nav-user/platform-nav-user-menu.directive";
export declare class SatPlatformNavModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatPlatformNavModule, never, [typeof i1.SatPlatformNavComponent, typeof i2.SatPlatformNavContainerComponent, typeof i3.SatPlatformNavMainContentComponent, typeof i4.SatPlatformNavMenuComponent, typeof i5.SatPlatformNavMenuItemComponent, typeof i6.SatPlatformNavUserProfileComponent, typeof i7.SatPlatformNavUserComponent, typeof i8.SatPlatformNavAvatarComponent, typeof i9.SatPlatformNavEnvironmentSwitcherComponent, typeof i10.SatPlatformNavInitialsPipe, typeof i11.SatPlatformNavUserMenuDirective], [typeof i1.SatPlatformNavComponent, typeof i2.SatPlatformNavContainerComponent, typeof i3.SatPlatformNavMainContentComponent, typeof i4.SatPlatformNavMenuComponent, typeof i5.SatPlatformNavMenuItemComponent, typeof i6.SatPlatformNavUserProfileComponent, typeof i7.SatPlatformNavUserComponent, typeof i8.SatPlatformNavAvatarComponent, typeof i9.SatPlatformNavEnvironmentSwitcherComponent, typeof i10.SatPlatformNavInitialsPipe, typeof i11.SatPlatformNavUserMenuDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatPlatformNavModule>;
}
