import * as i0 from "@angular/core";
import * as i1 from "./trailing-nested-scrollview.directive";
import * as i2 from "./leading-nested-scrollview.directive";
import * as i3 from "./nested-scrollviews.component";
export declare class SatNestedScrollviewsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatNestedScrollviewsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatNestedScrollviewsModule, never, [typeof i1.SatTrailingNestedScrollviewDirective, typeof i2.SatLeadingNestedScrollviewDirective, typeof i3.SatNestedScrollviewsComponent], [typeof i1.SatTrailingNestedScrollviewDirective, typeof i2.SatLeadingNestedScrollviewDirective, typeof i3.SatNestedScrollviewsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatNestedScrollviewsModule>;
}
