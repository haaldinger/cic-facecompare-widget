import * as i0 from "@angular/core";
export declare class SatTrailingNestedScrollviewDirective {
    private readonly appHeaderService;
    readonly topOffset: import("@angular/core").Signal<number>;
    readonly style: {
        position: string;
        overflowY: string;
        scrollbarWidth: string;
        scrollbarColor: string;
        boxSizing: string;
        flexShrink: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<SatTrailingNestedScrollviewDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatTrailingNestedScrollviewDirective, "[satTrailingNestedScrollview]", never, {}, {}, never, never, true, never>;
}
