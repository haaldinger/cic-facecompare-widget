import * as i0 from "@angular/core";
export declare class SatLeadingNestedScrollviewDirective {
    private readonly appHeaderService;
    readonly topOffset: import("@angular/core").Signal<number>;
    readonly style: {
        position: string;
        overflowY: string;
        scrollbarGutter: string;
        scrollbarWidth: string;
        scrollbarColor: string;
        boxSizing: string;
        flexShrink: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<SatLeadingNestedScrollviewDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatLeadingNestedScrollviewDirective, "[satLeadingNestedScrollview]", never, {}, {}, never, never, true, never>;
}
