import * as i0 from "@angular/core";
export declare class SatNestedScrollviewsComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatNestedScrollviewsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatNestedScrollviewsComponent, "sat-nested-scrollviews", never, {}, {}, never, ["[satLeadingNestedScrollview]", "*", "[satTrailingNestedScrollview]"], true, never>;
}
