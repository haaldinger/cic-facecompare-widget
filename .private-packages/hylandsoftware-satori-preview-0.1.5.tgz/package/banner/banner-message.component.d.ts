import * as i0 from "@angular/core";
/** A prominent message for a Banner. */
export declare class SatBannerMessageComponent {
    /** @internal */
    protected readonly banner: import("./banner.component").SatBannerComponent;
    /** @internal */
    protected readonly variantKey: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatBannerMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatBannerMessageComponent, "sat-banner-message", never, {}, {}, never, ["*"], true, never>;
}
