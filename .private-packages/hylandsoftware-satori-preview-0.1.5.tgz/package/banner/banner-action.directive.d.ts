import * as i0 from "@angular/core";
/** Marks a button as a banner action. Apply this directive to action buttons inside a Banner. */
export declare class SatBannerActionDirective {
    /** @internal */
    protected readonly banner: import("./banner.component").SatBannerComponent;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatBannerActionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatBannerActionDirective, "[satBannerAction]", never, {}, {}, never, never, true, never>;
}
