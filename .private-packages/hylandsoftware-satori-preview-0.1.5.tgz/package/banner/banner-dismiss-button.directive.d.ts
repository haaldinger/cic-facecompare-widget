import { TranslateService } from '@ngx-translate/core';
import * as i0 from "@angular/core";
/** The dismiss button for a Banner. */
export declare class SatBannerDismissButtonDirective {
    /** Overrides the default aria-label. */
    readonly ariaLabel: import("@angular/core").InputSignal<string | null>;
    /** @internal */
    protected readonly translateService: TranslateService;
    private readonly dismissLabel;
    /** @internal */
    readonly resolvedAriaLabel: import("@angular/core").Signal<any>;
    private readonly elementRef;
    private readonly document;
    /** @internal */
    moveFocusToNextElement(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatBannerDismissButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatBannerDismissButtonDirective, "button[satBannerDismissButton]", never, { "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
