import { InjectionToken, OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/** Injection token for the parent banner component. */
export declare const SAT_BANNER: InjectionToken<SatBannerComponent>;
/** A banner displays a prominent message and related optional actions. */
export declare class SatBannerComponent implements OnDestroy {
    /** Unique ID for the banner message, used for aria-describedby. */
    readonly messageId: string;
    /** Whether a dismiss button is projected into the banner. @internal */
    readonly hasDismissButton: import("@angular/core").Signal<boolean>;
    private readonly dismissButton;
    /** Whether to display a border around the banner, defaults to `false`. */
    readonly border: import("@angular/core").InputSignal<boolean>;
    /** The variant style of the banner, corresponds to Satori status palettes, defaults to `info`. */
    readonly variant: import("@angular/core").InputSignal<"info" | "warning" | "important" | "success">;
    /**
     * The orientation of the banner. When not provided, the orientation is automatically
     * determined based on the available width. When explicitly set, the banner will not
     * respond to resize changes.
     */
    readonly orientation: import("@angular/core").InputSignal<"inline" | "stacked" | undefined>;
    /** @internal */
    readonly icon: import("@angular/core").Signal<"info" | "circle_check" | "critical" | "error">;
    /** @internal */
    readonly resolvedOrientation: import("@angular/core").Signal<"inline" | "stacked">;
    private readonly autoOrientation;
    private readonly elementRef;
    private readonly resizeObserver;
    private width;
    constructor();
    ngOnDestroy(): void;
    private isContentOverflowing;
    private setOrientation;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatBannerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatBannerComponent, "sat-banner", never, { "border": { "alias": "border"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "orientation": { "alias": "orientation"; "required": false; "isSignal": true; }; }, {}, ["dismissButton"], ["[satBannerAction]", "sat-banner-message", "[satBannerDismissButton]"], true, never>;
}
