import * as i0 from "@angular/core";
import * as i1 from "./banner.component";
import * as i2 from "./banner-action.directive";
import * as i3 from "./banner-message.component";
import * as i4 from "./banner-dismiss-button.directive";
export declare class SatBannerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatBannerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatBannerModule, never, [typeof i1.SatBannerComponent, typeof i2.SatBannerActionDirective, typeof i3.SatBannerMessageComponent, typeof i4.SatBannerDismissButtonDirective], [typeof i1.SatBannerComponent, typeof i2.SatBannerActionDirective, typeof i3.SatBannerMessageComponent, typeof i4.SatBannerDismissButtonDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatBannerModule>;
}
