export declare const versionsMocks: {
    sysver_isVersion: boolean;
    sysver_isCheckedIn: boolean;
    sys_version: number;
    sysver_created: string;
    sysver_creator: string;
    sysver_title: string;
    sysver_description: string;
    sys_changeToken: string;
    sys_contributors: {
        email: string;
        firstName: string;
        id: string;
        lastName: string;
    }[];
    sys_created: string;
    sys_creator: {
        email: string;
        firstName: string;
        id: string;
        lastName: string;
    };
    sys_effectivePermissions: string[];
    sys_hasLegalHold: boolean;
    sys_id: string;
    sys_isCheckedIn: boolean;
    sys_isFolderish: boolean;
    sys_isLatestVersion: boolean;
    sys_isProxy: boolean;
    sys_isRecord: boolean;
    sys_isTrashed: boolean;
    sys_isVersion: boolean;
    sys_lastContributor: {
        email: string;
        firstName: string;
        id: string;
        lastName: string;
    };
    sys_mixinTypes: string[];
    sys_modified: string;
    sys_name: string;
    sys_parentId: string;
    sys_parentPath: string;
    sys_path: string;
    sys_pathDepth: number;
    sys_primaryType: string;
    sys_repository: string;
    sys_title: string;
    sysfile_blob: {
        digest: string;
        filename: string;
        key: string;
        length: number;
        mimeType: string;
    };
}[];
