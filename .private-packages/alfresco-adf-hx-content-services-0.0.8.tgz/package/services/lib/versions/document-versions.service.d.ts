import { Observable, Subject } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { EditDocumentVersion, VersionableDocument } from '../manage-versions/models/extended-document.interface';
import * as i0 from "@angular/core";
export declare class DocumentVersionsService {
    versionDeleted$: Observable<void>;
    versionUpdated$: Observable<void>;
    protected versionDeletedSubject: Subject<void>;
    protected versionUpdatedSubject: Subject<void>;
    private searchService;
    private documentService;
    constructor();
    getVersions(document: Document): Observable<Document[]>;
    getCurrentDocument(document: VersionableDocument): Observable<Document>;
    updateVersion(updatePayload: EditDocumentVersion): Observable<boolean>;
    deleteVersion(document: VersionableDocument): Observable<boolean>;
    private getVersionsById;
    private buildQuery;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentVersionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentVersionsService>;
}
