import { InjectionToken } from '@angular/core';
export declare const IDENTITY_USER_SERVICE_TOKEN: InjectionToken<IIdentityUserService>;
export interface IdentityUserModel {
    id: string;
    username?: string;
    firstName?: string;
    lastName?: string;
    email?: string;
    readonly?: boolean;
}
export interface IIdentityUserService {
    getCurrentUserInfo(): IdentityUserModel;
    search(name?: string, filters?: any): any;
}
