import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class BlobDownloadService {
    private readonly downloadApi;
    downloadBlob(documentId: string, property?: string, repositoryId?: string): Observable<Blob>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BlobDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<BlobDownloadService>;
}
