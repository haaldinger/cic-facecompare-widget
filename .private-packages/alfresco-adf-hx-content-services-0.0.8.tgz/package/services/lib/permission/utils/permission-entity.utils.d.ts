import { Group, User } from '@hylandsoftware/hxcs-js-client';
import { PermissionEntity } from '../models/permissions-management-row.model';
export declare const getEntityPropertiesFromGroup: (entity: Group) => PermissionEntity;
export declare const getEntityPropertiesFromUser: (entity: User) => PermissionEntity;
