import { ACE } from '@hylandsoftware/hxcs-js-client';
import { PermissionEntity } from '../models/permissions-management-row.model';
import { DocumentAclData } from '../models/permission-checker.interface';
import * as i0 from "@angular/core";
interface PermissionEntityAcl {
    entity: PermissionEntity;
    local: ACE[];
    inherited: ACE[];
}
export declare class PermissionsParserHelper {
    getAclGroupedByPermissionsEntity({ sys_acl, sys_effectiveAcl }: DocumentAclData): PermissionEntityAcl[];
    private isValidAce;
    private getEntityFromAce;
    private isAcePresentInAcl;
    private isSameEntity;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsParserHelper, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionsParserHelper>;
}
export {};
