import * as i0 from "@angular/core";
export declare class PermissionsPanelRequestService {
    private readonly sidebarService;
    requestOpenPanel(): void;
    requestClosePanel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsPanelRequestService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionsPanelRequestService>;
}
