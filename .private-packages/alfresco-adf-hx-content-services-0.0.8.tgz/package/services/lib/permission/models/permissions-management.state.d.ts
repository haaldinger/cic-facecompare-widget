import { Document, Group, User } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { IdentityType, PermissionsManagementRow } from './permissions-management-row.model';
export interface PermissionsManagementState {
    document?: Document;
    permissions: PermissionsManagementRow[];
    loading: boolean;
    activeTab: IdentityType;
    searchUserField: string;
    searchGroupField: string;
    newUserField: string;
    newGroupField: string;
    suggestedUsers: User[];
    suggestedGroups: Group[];
    initialInheritance: boolean;
    isInheritanceEnabled: boolean;
}
export interface PublicApi {
    title$: Observable<string>;
    loading$: Observable<boolean>;
    activePermissionsManagementRows$: Observable<PermissionsManagementRow[]>;
    suggestedUsers$: Observable<User[]>;
    suggestedGroups$: Observable<Group[]>;
    isUntouched$: Observable<boolean>;
    permissionsManagementRows$: Observable<PermissionsManagementRow[]>;
    sys_id$: Observable<string | undefined>;
    initialInheritance$: Observable<boolean>;
    isInheritanceEnabled$: Observable<boolean>;
    hasLocalPermission$: Observable<boolean>;
}
export declare const initialState: Readonly<PermissionsManagementState>;
