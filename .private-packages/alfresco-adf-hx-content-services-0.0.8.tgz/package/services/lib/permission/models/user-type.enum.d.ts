export declare const UserType: {
    readonly GROUPS: "GROUPS";
    readonly USERS: "USERS";
    readonly ALL: "ALL";
};
export type UserType = typeof UserType[keyof typeof UserType];
