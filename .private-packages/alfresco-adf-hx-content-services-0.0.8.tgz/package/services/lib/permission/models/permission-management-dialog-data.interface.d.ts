import { Document } from '@hylandsoftware/hxcs-js-client';
export interface PermissionsManagementDialogData {
    document: Document;
    parentDocument?: Document;
}
export type PermissionsManagementComponentType = 'dialog' | 'panel';
