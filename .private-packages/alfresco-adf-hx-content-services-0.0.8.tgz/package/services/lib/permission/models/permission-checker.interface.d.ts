import { ActionContext } from '../../context-menu-actions/actions/action-context.interface';
import { Document } from '@hylandsoftware/hxcs-js-client';
export interface PermissionChecker {
    isAvailable(context: ActionContext): boolean;
}
export type DocumentAclData = Pick<Document, 'sys_acl' | 'sys_effectiveAcl'>;
