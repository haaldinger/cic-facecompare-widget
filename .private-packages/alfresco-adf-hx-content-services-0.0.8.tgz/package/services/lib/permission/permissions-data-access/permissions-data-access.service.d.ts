import { ACE } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { UserType } from '../models/user-type.enum';
import * as i0 from "@angular/core";
export declare class PermissionsDataAccessService {
    private readonly hxpNotificationService;
    private readonly documentService;
    updateDocument(id: string, acl: ACE[], restoreType?: UserType): Observable<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsDataAccessService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionsDataAccessService>;
}
