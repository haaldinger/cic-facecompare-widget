import { Subject } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export interface ContextActionConfiguration {
    data: Document;
    model: {
        key: string;
        icon: string;
        title: string;
        visible: boolean;
    };
    subject: Subject<any>;
}
export declare class ContextMenuActionsService {
    private readonly documentDeleteHandler;
    private readonly documentPermissionsHandler;
    private readonly documentShareHandler;
    private readonly documentSingleItemDownloadHandler;
    private readonly documentInfoHandler;
    private readonly documentCopyHandler?;
    private readonly documentMoveHandler?;
    private readonly replaceFileHander?;
    private readonly createVersionHander?;
    private readonly manageVersionsHandler?;
    getContextActions(data: Document, parentDocument?: Document): ContextActionConfiguration[];
    private toContextAction;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContextMenuActionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContextMenuActionsService>;
}
