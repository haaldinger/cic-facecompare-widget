import { Observable } from 'rxjs';
import { CopyResponse } from './models/copy-response.interface';
import * as i0 from "@angular/core";
export declare class SingleItemCopyService {
    private readonly copyApi;
    copy(copyDocumentId: string, name: string, targetParentId: string): Observable<CopyResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleItemCopyService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SingleItemCopyService>;
}
