import { Document } from '@hylandsoftware/hxcs-js-client';
import { CopyStatus } from './copy-status.enum';
export interface CopyResponse {
    document?: Document;
    status: CopyStatus;
}
