import { AsyncPipe } from '@angular/common';
import { UserResolverPipe } from './pipes/user-resolver.pipe';
import { DocumentService } from './document/document.service';
import { EnvironmentProviders, InjectionToken } from '@angular/core';
import { DocumentPropertiesService } from './document/document-properties/document-properties.service';
import { PermissionsManagementComponentType } from './permission/models/permission-management-dialog-data.interface';
export declare const PERMISSIONS_MANAGEMENT_COMPONENT_TYPE: InjectionToken<PermissionsManagementComponentType>;
export declare const USER_RESOLVER_PROVIDERS: (typeof UserResolverPipe | typeof AsyncPipe)[];
export declare const DOCUMENT_PROVIDERS: ({
    provide: InjectionToken<import("./document/document-token/document-token.service").SharedDocumentService>;
    useExisting: typeof DocumentService;
} | {
    provide: InjectionToken<import("./document/document-properties/shared-document-properties.service").SharedDocumentPropertiesService>;
    useExisting: typeof DocumentPropertiesService;
})[];
export declare function provideAdfEnterpriseAdfHxContentServicesServices(): EnvironmentProviders;
