import { RenditionsApi, Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class RenditionsService {
    protected readonly renditionsApi: RenditionsApi;
    getRendition(documentId: string, renditionId: string, repositoryId?: string): Observable<Document>;
    requestRenditionCreation(documentId: string, sysrendition_id: string, repositoryId?: string): Observable<Document>;
    listRenditions(documentId: string, repositoryId?: string): Observable<Document[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RenditionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RenditionsService>;
}
