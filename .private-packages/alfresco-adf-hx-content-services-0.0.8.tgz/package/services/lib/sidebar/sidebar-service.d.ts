import * as i0 from "@angular/core";
export type PanelType = 'property' | 'permission' | 'version' | null;
export declare class SidebarService {
    readonly panel: import("@angular/core").WritableSignal<PanelType>;
    togglePanel(panelType: PanelType): void;
    closePanel(): void;
    private isPanelOpened;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidebarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SidebarService>;
}
