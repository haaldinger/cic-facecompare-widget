export declare const DownloadStatus: {
    readonly REQUEST: "REQUEST";
    readonly SUCCESS: "SUCCESS";
    readonly ERROR: "ERROR";
};
export type DownloadStatus = typeof DownloadStatus[keyof typeof DownloadStatus];
