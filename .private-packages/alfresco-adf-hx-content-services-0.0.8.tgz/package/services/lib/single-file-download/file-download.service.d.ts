import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export declare class FileDownloadService {
    private readonly singleFileDownloadService;
    private readonly hxpNotificationService;
    private readonly isSingleDocumentWithMainBlobService;
    downloadFile(hxpSingleFileDownload: Document[]): void;
    private displayNotificationMessage;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FileDownloadService>;
}
