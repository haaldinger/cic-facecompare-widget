import { DownloadStatus } from '../models/download-status.enum';
export declare const downloadNotificationMessages: Record<DownloadStatus, string>;
