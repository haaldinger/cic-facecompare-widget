import { DefaultStatusSnackBarIcon } from '@alfresco/adf-hx-content-services/api';
import { DownloadStatus } from '../models/download-status.enum';
export declare const downloadSnackBarTypes: Record<DownloadStatus, DefaultStatusSnackBarIcon>;
