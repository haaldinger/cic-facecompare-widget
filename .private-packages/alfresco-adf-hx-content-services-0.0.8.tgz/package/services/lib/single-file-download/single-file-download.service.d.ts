import { Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { DownloadStatus } from './models/download-status.enum';
import * as i0 from "@angular/core";
export declare class SingleFileDownloadService {
    private readonly downloadService;
    private readonly blobDownloadService;
    download(document: Document): Observable<DownloadStatus>;
    private emitDownloadStatusError;
    private emitDownloadStatusSuccess;
    private emitDownloadStatusRequest;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleFileDownloadService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SingleFileDownloadService>;
}
