import * as i0 from "@angular/core";
export declare class RouterExtService {
    private previousUrl;
    private currentUrl;
    private readonly router;
    private readonly route;
    constructor();
    getPreviousUrl(): string;
    redirectToReferer(refererURL: string, defaultPath: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<RouterExtService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RouterExtService>;
}
