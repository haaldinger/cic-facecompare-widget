export declare const MoveStatus: {
    readonly SUCCESS: "SUCCESS";
    readonly ERROR: "ERROR";
};
export type MoveStatus = typeof MoveStatus[keyof typeof MoveStatus];
