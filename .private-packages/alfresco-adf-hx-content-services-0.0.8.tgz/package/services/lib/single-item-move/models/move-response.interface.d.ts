import { Document } from '@hylandsoftware/hxcs-js-client';
import { MoveStatus } from './move-status.enum';
export interface MoveResponse {
    document?: Document;
    status: MoveStatus;
}
