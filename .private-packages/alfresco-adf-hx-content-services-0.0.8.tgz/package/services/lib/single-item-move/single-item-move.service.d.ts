import { Observable } from 'rxjs';
import { MoveResponse } from './models/move-response.interface';
import * as i0 from "@angular/core";
export declare class SingleItemMoveService {
    private readonly moveApi;
    move(moveDocumentId: string, targetParentId: string): Observable<MoveResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleItemMoveService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SingleItemMoveService>;
}
