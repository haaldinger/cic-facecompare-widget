import { Pagination } from '@alfresco/js-api';
export interface SearchOptions {
    pagination?: Pagination;
    sort?: string[];
}
