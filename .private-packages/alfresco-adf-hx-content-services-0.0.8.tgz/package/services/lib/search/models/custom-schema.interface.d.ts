import { FieldType } from '@alfresco/adf-hx-content-services/api';
export interface CustomSchemaField {
    title: string;
    name: string;
    type: FieldType;
}
