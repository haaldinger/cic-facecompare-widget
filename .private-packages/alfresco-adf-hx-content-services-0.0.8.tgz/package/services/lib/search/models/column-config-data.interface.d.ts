import { FieldType } from '@alfresco/adf-hx-content-services/api';
import { TemplateRef } from '@angular/core';
export interface ColumnConfig {
    key: string;
    title: string;
    sortable: boolean;
    removable: boolean;
    type?: FieldType;
    templateRef?: TemplateRef<unknown>;
}
