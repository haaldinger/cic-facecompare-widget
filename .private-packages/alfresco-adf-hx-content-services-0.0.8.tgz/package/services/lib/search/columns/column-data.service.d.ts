import { Observable } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { DocumentModel } from '../../document/document-model/document-model.model';
import { FieldType } from '@alfresco/adf-hx-content-services/api';
import { ColumnKeys } from '../configs/column-keys.enum';
import { CustomSchemaField } from '../models/custom-schema.interface';
import * as i0 from "@angular/core";
export declare class ColumnDataService {
    private readonly adfFileSize;
    private readonly timeAgoService;
    private readonly userResolverService;
    private readonly translationService;
    private readonly permissionService;
    private readonly decimalNumberService;
    private readonly datePipe;
    private readonly propertyUtilService;
    doesColumnValueExist(document: Document, columnKey: string): boolean;
    getColumnValue(document: Document, columnKey: ColumnKeys): Observable<string>;
    getCustomColumnValue(document: Document, columnKey: string, model: DocumentModel, type: FieldType): Observable<any>;
    getCustomSchemaFields(model: DocumentModel): CustomSchemaField[];
    private generateCustomPropertyFields;
    private generateCustomPropertyFieldsComplexType;
    private getSchemaFieldNames;
    private getBlobFields;
    private formatDateWithUser;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnDataService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ColumnDataService>;
}
