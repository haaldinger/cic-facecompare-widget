import { IdentityUserModel, TranslationService } from '@alfresco/adf-core';
import { Observable } from 'rxjs';
import { ColumnConfig } from '../models/column-config-data.interface';
import * as i0 from "@angular/core";
export declare class ColumnConfigService {
    private readonly storageService;
    private readonly documentModeService;
    private readonly columnDataService;
    protected readonly translationService: TranslationService;
    private columnConfigsSubject;
    columnConfigs$: Observable<ColumnConfig[]>;
    getDefaultColumns(): ColumnConfig[];
    getSelectedColumnsForCurrentUser(userInfo: IdentityUserModel): ColumnConfig[];
    setCurrentSelectedColumnsForCurrentUser(userInfo: IdentityUserModel, columns: ColumnConfig[]): void;
    getCustomColumns(): Observable<ColumnConfig[]>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ColumnConfigService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ColumnConfigService>;
}
