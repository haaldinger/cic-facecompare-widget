export declare const ColumnKeys: {
    readonly Icon: "icon";
    readonly SysTitle: "sys_title";
    readonly SysFileBlobLength: "sysfile_blob/length";
    readonly SysCreated: "sys_created";
    readonly SysModified: "sys_modified";
    readonly SysEffectivePermissions: "sys_effectivePermissions";
    readonly SysParentPath: "sys_parentPath";
    readonly SysPrimaryType: "sys_primaryType";
};
export type ColumnKeys = typeof ColumnKeys[keyof typeof ColumnKeys];
