import { SearchFilterData } from './models/search-filter.data';
import { BaseSearchFilter } from './models/search-filter.interface';
import * as i0 from "@angular/core";
export declare class SearchFilterValueStoreService {
    readonly SEARCH_FILTER_VALUES_KEY = "hxp-search-filters-value-store";
    protected storedValues: Map<string, SearchFilterData>;
    private readonly identityUserService;
    private readonly storageService;
    constructor();
    private get storageKey();
    reset(): void;
    addValue(filter: BaseSearchFilter, data: SearchFilterData): void;
    deleteValue(filter: BaseSearchFilter): void;
    getValue(filter: BaseSearchFilter): SearchFilterData | undefined;
    hasValues(): boolean;
    private load;
    private save;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFilterValueStoreService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchFilterValueStoreService>;
}
