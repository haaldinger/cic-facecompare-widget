import { Subject } from 'rxjs';
import { BaseSearchFilter } from './models/search-filter.interface';
import { SearchFilterData } from './models/search-filter.data';
import * as i0 from "@angular/core";
interface AppliedFilterData {
    filter: BaseSearchFilter;
    value: SearchFilterData;
}
export declare class SearchFilterValueService {
    filterReset$: Subject<BaseSearchFilter>;
    filterApplied$: Subject<AppliedFilterData>;
    protected filterValuesByType: Map<BaseSearchFilter, SearchFilterData>;
    private readonly baseQuery;
    constructor();
    emptyFilters(): void;
    clearFilters(): void;
    clearFilter(filter: BaseSearchFilter): void;
    hasFilters(): boolean;
    toHXQL(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFilterValueService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchFilterValueService>;
}
export {};
