import { ExtensionElement } from '@alfresco/adf-extensions';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export interface SearchFiltersRef extends ExtensionElement {
    items?: Array<SearchFiltersRef>;
    component?: string;
    rules?: {
        [key: string]: string | undefined;
        enabled?: string;
        visible?: string;
        featureFlag?: string;
    };
}
export declare class SearchFiltersExtensionsService {
    private featureName;
    private actionType;
    private readonly extensionService;
    private readonly featuresService;
    getSearchFiltersItems(): Observable<SearchFiltersRef>;
    private hasFeatureConfig;
    private extractFeatureConfig;
    private filterItemsByFeatureFlag;
    private shouldIncludeItem;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFiltersExtensionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SearchFiltersExtensionsService>;
}
