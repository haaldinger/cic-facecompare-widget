export interface SearchFilterValue {
    label: string;
}
export interface SearchFilterData {
    values: SearchFilterValue[];
    isEquivalentTo(data?: SearchFilterData): boolean;
}
