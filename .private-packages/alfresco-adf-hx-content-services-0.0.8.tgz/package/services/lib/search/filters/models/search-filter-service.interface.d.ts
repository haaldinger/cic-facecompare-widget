import { SearchFilterData } from './search-filter.data';
export interface SearchFilterService {
    toHXQL(data: SearchFilterData): string;
}
