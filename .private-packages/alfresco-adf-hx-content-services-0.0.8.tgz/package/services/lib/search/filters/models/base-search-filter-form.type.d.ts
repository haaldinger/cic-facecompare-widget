export interface BaseFilterFormType {
    [key: string]: any;
}
