import { PipeTransform } from '@angular/core';
import { User } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
/**
 * A pipe that resolves the user data into a string representation of user names.
 * The user data can be a string representing a User id, a User object, an array of User ids or User objects, or undefined.
 *
 * @remarks
 * Developers using this pipe need to configure/provide the `userApiProvider` provider somewhere.
 *
 * @param userData - The user data to transform. It can be a string representing a User id, a User object, an array of User ids or User objects, or undefined.
 * @returns An Observable that emits a string representation of user names.
 *
 * @example
 * Users is a mixed array of User ids and User Objects:
 * ```typescript
 * users = ['user-id-1', 'user-id-2', { id: 'user-id-3', firstName: 'John', lastName: 'Doe' }];
 * ```
 * Pipe usage:
 * ```html
 * <div>{{ users | hxpUserResolverPipe }}</div>
 * ```
 */
export declare class UserResolverPipe implements PipeTransform {
    private readonly asyncPipe;
    private readonly userResolverService;
    transform(userData: string | User | Array<string | User> | undefined): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UserResolverPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UserResolverPipe, "hxpUserResolverPipe", true>;
}
