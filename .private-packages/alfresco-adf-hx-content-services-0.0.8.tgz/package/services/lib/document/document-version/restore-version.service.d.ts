import { Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class RestoreDocumentVersionService {
    private readonly versionApi;
    restore(versionId: string, repositoryId: string): Observable<Document>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RestoreDocumentVersionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RestoreDocumentVersionService>;
}
