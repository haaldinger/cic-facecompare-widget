import { CardViewItem } from '@alfresco/adf-core';
import { FieldType } from '@alfresco/adf-hx-content-services/api';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { SchemaExtractionOptions, SchemaTree, SharedDocumentPropertiesService } from './shared-document-properties.service';
import * as i0 from "@angular/core";
type SchemaPrefix = string;
type PrefixedProperty = string;
interface DocumentPropertiesFilteringOptions {
    exclude?: {
        properties?: PrefixedProperty[];
        schemas?: SchemaPrefix[];
    };
    include?: {
        properties?: PrefixedProperty[];
        schemas?: SchemaPrefix[];
    };
}
export declare class DocumentPropertiesService extends SharedDocumentPropertiesService {
    private model;
    private readonly documentModelService;
    private readonly propertyUtilService;
    getPropertiesFromDocument(document?: Document, options?: DocumentPropertiesFilteringOptions): Observable<CardViewItem[]>;
    getDefaultPropertiesFromDocument(document?: Document): Observable<CardViewItem[]>;
    isRequired(property: string): boolean;
    propertyType(property: string): FieldType | undefined;
    isFieldTypeArray(property: FieldType): boolean | undefined;
    /**
     * Extracts schema information for a given primary type.
     *
     * Returns an array of schema objects, each containing:
     * - schema: The schema name
     * - fields: A record of field names with their initialized values
     *
     * System schemas are always included. Custom schemas can be optionally included.
     *
     * @param primaryType - The primary type to extract schemas for (e.g., 'hyland:document')
     * @param options - Configuration options for schema extraction
     * @returns Observable that emits an array of schema tree objects
     *
     * @example
     * ```typescript
     * // Get system schemas only (default)
     * documentPropertiesService.extractSchemas('hyland:document')
     *   .subscribe(schemas => { ... });
     *
     * // Get both system and custom schemas
     * documentPropertiesService.extractSchemas('hyland:document', { includeCustomProperties: true })
     *   .subscribe(schemas => { ... });
     * ```
     */
    extractSchemas(primaryType: string, options?: SchemaExtractionOptions): Observable<SchemaTree>;
    /**
     * Extracts custom schema fields for a given primary type as a flat record.
     *
     * Returns a single flattened object containing all custom schema fields merged together,
     * with field names as keys and their initialized values.
     *
     * @param primaryType - The primary type to extract schema fields for (e.g., 'hyland:document')
     * @returns Observable that emits a flat record of custom schema fields
     *
     * @example
     * ```typescript
     * documentPropertiesService.extractCustomSchemaFields('hyland:document')
     *   .subscribe(fields => {
     *     console.log('All custom fields:', fields);
     *   });
     * ```
     */
    extractCustomSchemaFields(primaryType: string): Observable<Record<string, any>>;
    getRequiredProperties(): string[];
    private buildSchemaTree;
    private fetchModelAndSchemas;
    private getCustomSchemas;
    private getCustomSchemaFields;
    private extractCustomSchema;
    private populateCustomSchemaFields;
    private handleComplexFieldType;
    private getNestedFields;
    private fetchDocumentModel;
    private getCardItem;
    private createComplexCardItems;
    private filterProperty;
    private sortCardsByLabel;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentPropertiesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentPropertiesService>;
}
export {};
