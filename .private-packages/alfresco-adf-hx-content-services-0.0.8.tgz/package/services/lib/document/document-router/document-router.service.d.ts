import { NavigationExtras } from '@angular/router';
import { Document as HxcsDocument } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export interface DocumentRouterOptions {
    absolute?: boolean;
}
export declare class DocumentRouterService {
    private readonly location;
    private readonly router;
    private readonly document;
    /**
     * Returns the URL for the given document.
     * By default, the URL is relative to the current location, except when the `absolute` option is set to `true`.
     */
    urlFor(document: HxcsDocument, options?: DocumentRouterOptions): string;
    /**
     * Returns the URL for the parent of the given document.
     * By default, the URL is relative to the current location, except when the `absolute` option is set to `true`.
     */
    urlForParent(document: HxcsDocument, options?: DocumentRouterOptions): string;
    /**
     * Navigates to the given document.
     */
    navigateTo(document: HxcsDocument, extras?: NavigationExtras): void;
    /**
     * Returns the URL for the given document id.
     */
    private urlForId;
    private absoluteUrlForId;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentRouterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentRouterService>;
}
