import { ContentActionRef } from '@alfresco/adf-extensions';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class DocumentMoreMenuItemsFactoryService {
    private readonly extensionService;
    private readonly featuresService;
    getMoreMenuItems(): Observable<ContentActionRef>;
    private hasFeature;
    private filterItemsByFeatureFlag;
    private shouldIncludeItem;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentMoreMenuItemsFactoryService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentMoreMenuItemsFactoryService>;
}
