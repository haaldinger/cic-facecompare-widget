import { ModelApi } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import { DocumentModel } from './document-model.model';
import * as i0 from "@angular/core";
export declare class DocumentModelService {
    private model$;
    private errored;
    protected readonly modelApi: ModelApi;
    getModel(): Observable<DocumentModel>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentModelService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentModelService>;
}
