import { Model as HXCSModel } from '@hylandsoftware/hxcs-js-client';
import { FieldType } from '@alfresco/adf-hx-content-services/api';
interface ComplexPropertyField {
    name: string;
    type: FieldType;
}
export declare class DocumentModel {
    private model;
    SYS_ROOT: string;
    constructor(model: HXCSModel);
    get documentModel(): HXCSModel;
    getFieldConstraints(field: string): Record<string, unknown> | undefined;
    getFieldType(field: string): FieldType;
    isMultivaluedType(type: FieldType | undefined): boolean;
    isFieldTypeArray(fieldType: FieldType): boolean;
    getComplexFieldDetails(fieldName: string): ComplexPropertyField[];
    resolveType(type?: string): FieldType;
    getSubtypes(primaryType: string): string[];
    getFilishTypes(): string[];
    getFolderishTypes(): string[];
    hasMixin(primaryType: string, mixin: string): boolean;
    getAllTypes(): string[];
    isCustomSchema(schemaName: string): boolean;
    /**
     * Checks if a primary type inherits from a target type by recursively traversing the type hierarchy.
     * This method checks the entire inheritance chain, not just the immediate parent.
     *
     * The method includes circular reference detection to prevent infinite recursion.
     *
     * @param sourceType - The primary type to check
     * @param targetType - The target type to check inheritance from
     * @returns true if sourceType inherits from targetType (directly or transitively), false otherwise
     */
    inherits(sourceType: string, targetType: string): boolean;
    private checkInheritance;
    private getSchemaByPrefix;
    private hasResolver;
    private getResolverType;
    private getSchemas;
    private getFieldDefinition;
}
export {};
