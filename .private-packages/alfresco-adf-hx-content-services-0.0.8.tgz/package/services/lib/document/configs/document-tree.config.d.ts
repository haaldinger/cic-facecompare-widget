export declare const DEFAULT_ITEMS_PER_PAGE = 20;
