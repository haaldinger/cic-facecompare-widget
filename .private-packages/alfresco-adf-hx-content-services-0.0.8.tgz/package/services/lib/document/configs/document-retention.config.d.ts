export declare const RecordStatus: {
    readonly Incomplete: "Incomplete";
    readonly Ready: "Ready";
    readonly UnderRetention: "UnderRetention";
    readonly ReachedDisposition: "ReachedDisposition";
    readonly OnHold: "OnHold";
};
export type RecordStatusType = typeof RecordStatus[keyof typeof RecordStatus];
export declare const BLOCK_EDIT_STATUSES: RecordStatusType[];
export declare const BLOCK_DELETE_STATUSES: RecordStatusType[];
export declare const ViewMode: {
    readonly Cases: "Cases";
    readonly Records: "Records";
};
export type ViewMode = typeof ViewMode[keyof typeof ViewMode];
