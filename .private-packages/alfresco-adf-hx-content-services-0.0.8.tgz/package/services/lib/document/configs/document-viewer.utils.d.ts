import { MonoTypeOperatorFunction } from 'rxjs';
export declare const RenditionStatus: {
    readonly PENDING: "PENDING";
    readonly COMPLETED: "COMPLETED";
    readonly FAILED: "FAILED";
};
export type RenditionStatus = typeof RenditionStatus[keyof typeof RenditionStatus];
export declare const DEFAULT_RENDITION_ID = "pdfPreview";
/**
 * Resubscribes with the switchMapTo to the stream it's used on until the
 * `isPollingActive` function returns false or `maxAttempt` is exceeded.
 * @param {number} [pollInterval] delay between every re-subscription
 * @param {fn => boolean} [isPollingActive] function returning boolean value defining the stream should resubscribe
 * @param {number} [maxAttempts] how many tries should the poll do
 * @param {boolean} [emitOnlyLast] flag to determine if all returned by the subscription values should be emitted or
 * only the last one
 */
export declare function pollWhile<T>(pollInterval: number, isPollingActive: (res: T) => boolean, maxAttempts?: number, emitOnlyLast?: boolean): MonoTypeOperatorFunction<T>;
