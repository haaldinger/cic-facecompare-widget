import { Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class DocumentCacheService {
    private documentCache;
    private readonly documentService;
    constructor();
    getDocumentCache(): Map<string, Observable<Document>>;
    getDocument(documentId: string): Observable<Document>;
    invalidate(documentId: string): void;
    private fetchDocument;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentCacheService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentCacheService>;
}
