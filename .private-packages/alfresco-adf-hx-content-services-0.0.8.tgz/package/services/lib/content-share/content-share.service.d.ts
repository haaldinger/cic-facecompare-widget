import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export declare class ContentShareService {
    private readonly documentRouterService;
    getSingleContentShareLink(document?: Document): string | undefined;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentShareService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentShareService>;
}
