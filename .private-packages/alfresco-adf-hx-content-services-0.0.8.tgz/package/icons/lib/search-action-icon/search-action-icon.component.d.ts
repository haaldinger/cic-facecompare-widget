import { OnChanges } from '@angular/core';
import { SearchIcon } from '../configs/search-icons.config';
import * as i0 from "@angular/core";
/**
 * Component representing a search action icon.
 *
 * To use the `SearchActionIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { SearchActionIconComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         SearchActionIconComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *  <hxp-search-action-icon></hxp-search-action-icon>
 *
 */
export declare class SearchActionIconComponent implements OnChanges {
    /**
     * Icon to display: `SEARCH` or `CLEAR`.
     * @type {string}
     * @default 'SEARCH'
     *
     */
    actionIcon: SearchIcon;
    /**
     * A custom text for HTML <img> alt attribute.
     * @type {string}
     *
     */
    actionAlt: string;
    protected alt: string;
    protected iconAssetPath: string;
    private readonly translateService;
    private readonly matIconRegistry;
    private readonly domSanitizer;
    constructor();
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchActionIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchActionIconComponent, "hxp-search-action-icon", never, { "actionIcon": { "alias": "actionIcon"; "required": false; }; "actionAlt": { "alias": "actionAlt"; "required": false; }; }, {}, never, never, true, never>;
}
