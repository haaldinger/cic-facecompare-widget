import { DefaultIcon } from '../configs/icons.config';
import * as i0 from "@angular/core";
/**
 * Component representing a folder icon.
 *
 * To use the `FolderIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { FolderIconComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         FolderIconComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-folder-icon [isExpanded]="false"></hxp-folder-icon>
 */
export declare class FolderIconComponent {
    /**
     * Indicates whether the folder is expanded.
     * @type {boolean}
     */
    isExpanded: boolean;
    protected readonly folderIcon: DefaultIcon;
    protected readonly openFolderIcon: DefaultIcon;
    static ɵfac: i0.ɵɵFactoryDeclaration<FolderIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FolderIconComponent, "hxp-folder-icon", never, { "isExpanded": { "alias": "isExpanded"; "required": false; }; }, {}, never, never, true, never>;
}
