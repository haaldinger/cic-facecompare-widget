import { mimeTypeLinkedImages } from '../configs/mime-type.config';
export declare const DefaultIcon: {
    readonly UNKNOWN: "document";
    readonly FOLDER: "folder";
    readonly OPEN_FOLDER: "folder_open";
};
export type DefaultIcon = typeof DefaultIcon[keyof typeof DefaultIcon];
export type MimeType = keyof typeof mimeTypeLinkedImages;
