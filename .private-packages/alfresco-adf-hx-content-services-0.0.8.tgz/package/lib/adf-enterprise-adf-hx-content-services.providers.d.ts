import { EnvironmentProviders } from '@angular/core';
export declare function provideAdfEnterpriseAdfHxContentServices(): EnvironmentProviders;
