import { Configuration } from '@hylandsoftware/hxcs-js-client';
import { FactoryProvider } from '@angular/core';
import { BaseAPI } from '@hylandsoftware/hxcs-js-client/typings/base';
type IHxcsJsClientApiClass<T extends BaseAPI> = new (configuration?: Configuration, basePath?: string) => T;
export declare function getHxcsJsClientProvider<T extends BaseAPI>(tokenName: string, apiClass: IHxcsJsClientApiClass<T>): FactoryProvider;
export {};
