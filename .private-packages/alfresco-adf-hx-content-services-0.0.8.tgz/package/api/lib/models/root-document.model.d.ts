import { Document } from '@hylandsoftware/hxcs-js-client';
export declare const ROOT_DOCUMENT: Readonly<Document & Required<Pick<Document, 'sys_id'>>>;
