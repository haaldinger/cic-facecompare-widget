export declare const groupApiProvider: import("@angular/core").FactoryProvider;
export declare const GROUP_API_TOKEN: any;
