export declare const documentApiProvider: import("@angular/core").FactoryProvider;
export declare const DOCUMENT_API_TOKEN: any;
