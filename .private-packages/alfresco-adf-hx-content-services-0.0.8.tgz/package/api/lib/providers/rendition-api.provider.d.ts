export declare const renditionsApiProvider: import("@angular/core").FactoryProvider;
export declare const RENDITIONS_API_TOKEN: any;
