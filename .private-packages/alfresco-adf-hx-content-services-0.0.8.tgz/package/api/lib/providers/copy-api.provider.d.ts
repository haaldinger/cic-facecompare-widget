export declare const copyApiProvider: import("@angular/core").FactoryProvider;
export declare const COPY_API_TOKEN: any;
