export declare const queryApiProvider: import("@angular/core").FactoryProvider;
export declare const QUERY_API_TOKEN: any;
