export declare const userApiProvider: import("@angular/core").FactoryProvider;
export declare const USER_API_TOKEN: any;
