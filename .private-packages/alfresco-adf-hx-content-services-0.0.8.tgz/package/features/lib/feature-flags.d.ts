/**
 * @internal
 */
export declare const ADF_HX_CONTENT_SERVICES_INTERNAL: {
    readonly CIC_GOVERNANCE_DASHBOARD_FEATURE: "cic-governance-dashboard-feature";
    readonly CIC_WORKSPACE_DOCUMENT_LAYOUT_TOGGLE: "cic-workspace-document-layout-toggle";
    readonly SEARCH_RESULTS_100K: "cic-workspace-search-results-100k";
};
export type ADF_HX_CONTENT_SERVICES_INTERNAL = typeof ADF_HX_CONTENT_SERVICES_INTERNAL[keyof typeof ADF_HX_CONTENT_SERVICES_INTERNAL];
