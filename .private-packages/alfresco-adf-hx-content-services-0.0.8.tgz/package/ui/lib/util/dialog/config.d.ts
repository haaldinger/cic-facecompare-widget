export declare const DialogConfig: Readonly<{
    small: {
        width: string;
        height: string;
    };
    medium: {
        width: string;
        height: string;
    };
    large: {
        width: string;
        height: string;
    };
}>;
