import { CardViewItem } from '@alfresco/adf-core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { SchemaTree } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
interface GroupedProperty {
    schema: string;
    properties: CardViewItem[];
    expanded: boolean;
}
/**
 * Component presents document properties viewer container.
 *
 * To use the `MetadataSidebarContentComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { MetadataSidebarContentComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         MetadataSidebarContentComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-metadata-sidebar-content
 *    [document]="document"
 *    [editable]="editable"
 *    [copyToClipboardAction]="copyToClipboardAction"
 *    [displayEmpty]="displayEmpty"
 *    [useChipsForMultiValueProperty]="useChipsForMultiValueProperty">
 * </hxp-metadata-sidebar-content>
 */
export declare class MetadataSidebarContentComponent {
    /**
     * The document to display the properties for.
     * @type {Document}
     * @required
     */
    document: import("@angular/core").InputSignal<Document | undefined>;
    /**
     * The properties to display in the card view.
     * @type {CardViewItem[]}
     * @default []
     *
     * ```ts
     * export interface CardViewItem {
     *      label: string;
     *      value: any;
     *      key: string;
     *      default?: any;
     *      type: string;
     *      displayValue: any;
     *      editable?: boolean;
     *      icon?: string;
     * }
     * ```
     *
     */
    properties: import("@angular/core").InputSignal<CardViewItem[]>;
    propertiesGroups: import("@angular/core").InputSignal<SchemaTree>;
    /**
     * Toggles whether or not to enable copy to clipboard action.
     * @type {boolean}
     * @default true
     */
    copyToClipboardAction: import("@angular/core").InputSignal<boolean>;
    /**
     * Toggles whether to display empty values in the card view.
     * @type {boolean}
     * @default false
     */
    displayEmpty: import("@angular/core").InputSignal<boolean>;
    /**
     * Toggles whether the edit button should be shown
     * @type {boolean}
     * @default false
     */
    editable: import("@angular/core").InputSignal<boolean>;
    /**
     * Toggles whether or not to enable chips for multivalued properties.
     * @type {boolean}
     * @default true
     */
    useChipsForMultiValueProperty: import("@angular/core").InputSignal<boolean>;
    /**
     * Toggles whether to display properties in a collapsible accordion.
     * When true, properties are shown in an expandable accordion with the first property's label as the header.
     * When false, properties are displayed directly without accordion wrapping.
     * @type {boolean}
     * @default false
     */
    collapsible: import("@angular/core").InputSignal<boolean>;
    propertyUpdateRequest: import("@angular/core").OutputEmitterRef<boolean>;
    /**
     * Array of invalid field IDs that should trigger accordion expansion.
     * When set, accordions containing these fields will automatically expand.
     * @type {string[]}
     * @default []
     */
    invalidFieldIds: import("@angular/core").InputSignal<string[]>;
    private expansionPanels;
    private expandedStates;
    constructor();
    protected groupedProperties: import("@angular/core").Signal<GroupedProperty[]>;
    protected allExpanded: import("@angular/core").Signal<boolean>;
    private getPropertiesForGroup;
    protected readonly multiValueSeparator = ", ";
    protected onPanelExpandedChange(): void;
    protected toggleAllAccordions(): void;
    private expandAccordionsWithInvalidFields;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetadataSidebarContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MetadataSidebarContentComponent, "hxp-metadata-sidebar-content", never, { "document": { "alias": "document"; "required": false; "isSignal": true; }; "properties": { "alias": "properties"; "required": false; "isSignal": true; }; "propertiesGroups": { "alias": "propertiesGroups"; "required": false; "isSignal": true; }; "copyToClipboardAction": { "alias": "copyToClipboardAction"; "required": false; "isSignal": true; }; "displayEmpty": { "alias": "displayEmpty"; "required": false; "isSignal": true; }; "editable": { "alias": "editable"; "required": false; "isSignal": true; }; "useChipsForMultiValueProperty": { "alias": "useChipsForMultiValueProperty"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "invalidFieldIds": { "alias": "invalidFieldIds"; "required": false; "isSignal": true; }; }, { "propertyUpdateRequest": "propertyUpdateRequest"; }, never, never, true, never>;
}
export {};
