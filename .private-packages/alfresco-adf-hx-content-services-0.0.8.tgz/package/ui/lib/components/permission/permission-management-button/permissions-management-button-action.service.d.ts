import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class PermissionsButtonActionService extends DocumentActionService {
    private sidebarService;
    private readonly dialog;
    private readonly permissionsPanelRequestService;
    private readonly componentType;
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    private openPermissionsManagementDialog;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsButtonActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PermissionsButtonActionService>;
}
