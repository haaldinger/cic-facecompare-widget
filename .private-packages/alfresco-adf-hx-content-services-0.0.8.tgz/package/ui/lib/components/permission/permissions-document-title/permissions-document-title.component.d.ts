import * as i0 from "@angular/core";
export declare class PermissionsDocumentTitleComponent {
    title: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsDocumentTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionsDocumentTitleComponent, "hxp-permissions-document-title", never, { "title": { "alias": "title"; "required": false; }; }, {}, never, ["[close-button]"], true, never>;
}
