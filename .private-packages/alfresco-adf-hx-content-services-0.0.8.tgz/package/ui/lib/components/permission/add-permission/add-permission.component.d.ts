import { EventEmitter, OnChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { NewPermissionEntity, PermissionEntity, NewPermission, InheritedPermissionEntity } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
interface AddPermissionForm {
    search: FormControl<string>;
    permission: FormControl<NewPermission | undefined>;
}
export declare class AddPermissionComponent implements OnChanges {
    private destroyRef;
    suggestions: Array<InheritedPermissionEntity>;
    addButtonLabel: string;
    searchPlaceholderText: string;
    loading: boolean;
    addNewPermission: EventEmitter<NewPermissionEntity>;
    search: EventEmitter<string>;
    form: FormGroup<AddPermissionForm>;
    selectedSuggestion?: InheritedPermissionEntity;
    protected permissionLabels: Readonly<Record<NewPermission, string>>;
    private readonly suggestionsSubject;
    private readonly isSuggestedPermissionEntityValidator;
    constructor();
    ngOnChanges(): void;
    addPermission(): void;
    selectSuggestion(event: MatAutocompleteSelectedEvent): void;
    getEntityLabel(entity: PermissionEntity): string;
    originalOrder: () => number;
    protected suggestionTrackBy(_index: number, suggestion: PermissionEntity): string;
    private getAvailablePermissionsOptions;
    private getDisableValidator;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddPermissionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddPermissionComponent, "hxp-add-permission", never, { "suggestions": { "alias": "suggestions"; "required": false; }; "addButtonLabel": { "alias": "addButtonLabel"; "required": false; }; "searchPlaceholderText": { "alias": "searchPlaceholderText"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; }, { "addNewPermission": "addNewPermission"; "search": "search"; }, never, ["[title]"], true, never>;
}
export {};
