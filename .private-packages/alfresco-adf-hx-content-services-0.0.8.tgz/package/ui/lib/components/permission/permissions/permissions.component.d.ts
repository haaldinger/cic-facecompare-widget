import { NewPermission, Permission } from '@alfresco/adf-hx-content-services/services';
import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class PermissionsComponent {
    permission?: NewPermission;
    inheritedPermission: Permission;
    inheritanceEnabled: boolean;
    disabled: boolean;
    changePermission: EventEmitter<NewPermission>;
    protected readonly permissionLabels: Readonly<Record<import("@alfresco/adf-hx-content-services/services").PermissionLabel, string>>;
    protected readonly newPermissionLabels: Readonly<Record<NewPermission, string>>;
    protected onPermissionChange($event: NewPermission): void;
    protected isOptionDisabled: (permission: string) => boolean;
    protected originalOrder: () => number;
    protected optionTrackBy(index: number): number;
    private isPermissionLowerThanInherited;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionsComponent, "hxp-permissions", never, { "permission": { "alias": "permission"; "required": false; }; "inheritedPermission": { "alias": "inheritedPermission"; "required": false; }; "inheritanceEnabled": { "alias": "inheritanceEnabled"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "changePermission": "changePermission"; }, never, never, true, never>;
}
