import { DismissPermissionDialogData } from './cancel-permission-dialog.component';
import * as i0 from "@angular/core";
export declare class ClosePermissionDialogComponent {
    private readonly dialogRef;
    readonly dialogData: DismissPermissionDialogData<any>;
    reject(): void;
    confirm(): void;
    private closeDialog;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClosePermissionDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ClosePermissionDialogComponent, "ng-component", never, {}, {}, never, never, true, never>;
}
