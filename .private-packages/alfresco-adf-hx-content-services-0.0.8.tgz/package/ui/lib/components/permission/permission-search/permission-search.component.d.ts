import { EventEmitter } from '@angular/core';
import { PermissionsManagementRow } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class PermissionsSearchComponent {
    placeHolder: string;
    activePermissionsManagementRows: PermissionsManagementRow[];
    search: EventEmitter<string>;
    protected onKey(event: KeyboardEvent): void;
    protected emit(value: string): void;
    protected permissionsManagementRowTrackBy(_index: number, row: PermissionsManagementRow): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<PermissionsSearchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PermissionsSearchComponent, "hxp-permission-search", never, { "placeHolder": { "alias": "placeHolder"; "required": false; }; "activePermissionsManagementRows": { "alias": "activePermissionsManagementRows"; "required": false; }; }, { "search": "search"; }, never, never, true, never>;
}
