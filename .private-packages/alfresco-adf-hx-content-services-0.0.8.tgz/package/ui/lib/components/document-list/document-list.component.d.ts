import { EventEmitter, OnChanges } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { DataRowEvent, DataTableComponent, DataCellEvent, DataColumnListComponent, DataColumn } from '@alfresco/adf-core';
import * as i0 from "@angular/core";
/**
 * Component presents document breadcrumb.
 * To use the `HxpDocumentListComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpDocumentListComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         HxpDocumentListComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-document-list [isLoading]="isLoading" [documents]="documents" [schema]="schema">
 * </hxp-document-list>
 */
export declare class HxpDocumentListComponent implements OnChanges {
    /**
     * The list of documents to be displayed.
     * @type {Document[]}
     * @default []
     *
     */
    documents: Document[];
    /**
     * Indicates whether the document list is currently loading.
     * When set to `true`, a loading indicator may be displayed.
     * Defaults to `false`.
     * @type {boolean}
     * @default false
     */
    isLoading: boolean;
    /**
     * Indicates whether it is possible to select more than one document.
     * @type {boolean}
     * @default true
     */
    multiselect: boolean;
    /**
     * Indicates whether the context menu actions are enabled.
     * @type {boolean}
     * @default true
     */
    contextMenuActions: boolean;
    /**
     * The list of `DataColumnListComponent` to be displayed.
     * Set the parent component as following to pass the list of columns:
     * - add the columns in the template
     * - refer to them using the `ViewChild` or `ContentChild` decorator.
     * - pass the reference to the `inputColumnList` property.
     *
     * Alfresco documentation of `DataColumnListComponent` can be found here:
     * https://www.alfresco.com/abn/adf/docs/core/components/data-column.component/
     * @optional
     * @type {DataColumnListComponent}
     *
     *
     */
    inputColumnList?: DataColumnListComponent;
    /**
     * The `DataColumn` schema representing the columns to be displayed.
     * Alfresco doc: https://www.alfresco.com/abn/adf/docs/core/components/data-column.component/
     * @type {DataColumn[]}
     * @default []
     *
     */
    schema: DataColumn[] | undefined;
    /**
     * Event emitter that notifies the list of selected documents whenever it changes.
     *
     * @event selectedDocuments
     */
    selectedDocuments: EventEmitter<Document[]>;
    /**
     * Emit the Document associated with the clicked row, when the row is clicked.
     *
     * @event rowClicked
     */
    rowClicked: EventEmitter<Document>;
    /**
     * Event emitter that notifies when sorting the Document List.
     * The emitted value is a string in the form of `<column name> <direction>`
     *
     * @event sortingClicked
     */
    sortingClicked: EventEmitter<string[]>;
    /**
     * Event emitter that notifies when columns are resized.
     * The event payload is an array of `DataColumn` objects with updated width.
     *
     * @event columnsResized
     */
    columnsResized: EventEmitter<DataColumn[]>;
    protected evaluatedSchema: DataColumn[];
    private readonly documentListElement;
    protected projectedColumnList?: DataColumnListComponent;
    private parentDocument;
    private readonly documentCache;
    private readonly contextMenuActionsService;
    private readonly contextMenuOverlayService;
    private contextMenuLocation?;
    /**
     * Property to access the underlying Alfresco `DataTableComponent` instance.
     * https://www.alfresco.com/abn/adf/docs/core/components/datatable.component/
     */
    get table(): DataTableComponent;
    ngOnChanges(): void;
    /**
     * Resets the selection of the document list.
     */
    resetSelection(): void;
    /**
     * Resets the sorting of the document list.
     */
    resetSorting(): void;
    protected onShowContextMenu(event: MouseEvent): void;
    protected handleRowClicked(event: DataRowEvent): void;
    protected handleSortingChanged(event: Event): void;
    protected setSelectedRows(event: Event): void;
    protected onColumnsWidthChange(columns: DataColumn[]): void;
    protected onShowRowContextMenu(event: DataCellEvent): void;
    private updateDocumentList;
    private fetchCommonParentDocument;
    private refreshCachedDocument;
    private configureSchema;
    private getContextActions;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpDocumentListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpDocumentListComponent, "hxp-document-list", never, { "documents": { "alias": "documents"; "required": false; }; "isLoading": { "alias": "isLoading"; "required": false; }; "multiselect": { "alias": "multiselect"; "required": false; }; "contextMenuActions": { "alias": "contextMenuActions"; "required": false; }; "inputColumnList": { "alias": "inputColumnList"; "required": false; }; "schema": { "alias": "schema"; "required": false; }; }, { "selectedDocuments": "selectedDocuments"; "rowClicked": "rowClicked"; "sortingClicked": "sortingClicked"; "columnsResized": "columnsResized"; }, ["projectedColumnList"], ["*"], true, never>;
}
