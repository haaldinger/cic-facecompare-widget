import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class SingleItemDownloadButtonActionService extends DocumentActionService {
    private readonly fileDownloadService;
    private readonly isSingleDocumentWithMainBlobService;
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleItemDownloadButtonActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SingleItemDownloadButtonActionService>;
}
