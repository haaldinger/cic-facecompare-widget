import { ActionContext } from '@alfresco/adf-hx-content-services/services';
import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Component icon button that downloads a `Document` file. Success or error action result status is notified to the user.
 *
 * To display the component:
 * - the `actionContext` input property must provide only one `Document` in the `documents` array;
 * - the `Document` must have a valid blob to download;
 * - the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `SingleItemDownloadButtonComponent`, import the component in your module
 *
 * ```ts
 * import { SingleItemDownloadButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         SingleItemDownloadButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-single-item-download [actionContext]="actionContext"></hxp-single-item-download>
 *
 */
export declare class SingleItemDownloadButtonComponent implements OnChanges {
    /**
     * Input property which specifies an `ActionContext` object
     * The `ActionContext` object should provide an array containing only one `Document`.
     * @type {ActionContext}
     *
     * @example
     * interface ActionContext {
     *     documents: Document[];
     * }
     *
     */
    actionContext: ActionContext;
    protected isAvailable: boolean;
    private readonly singleItemDownloadButtonActionService;
    ngOnChanges(): void;
    protected onDownload(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SingleItemDownloadButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SingleItemDownloadButtonComponent, "hxp-single-item-download", never, { "actionContext": { "alias": "actionContext"; "required": false; }; }, {}, never, never, true, never>;
}
