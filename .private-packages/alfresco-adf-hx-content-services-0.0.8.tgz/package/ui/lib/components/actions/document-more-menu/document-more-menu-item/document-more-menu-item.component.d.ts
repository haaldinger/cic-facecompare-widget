import { ContentActionRef } from '@alfresco/adf-extensions';
import { OnInit } from '@angular/core';
import { ActionContext } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class DocumentMoreMenuItemComponent implements OnInit {
    item?: ContentActionRef;
    actionContext: ActionContext;
    private dynamicComponent;
    protected appComponent: string;
    get isAvailable(): boolean;
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentMoreMenuItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DocumentMoreMenuItemComponent, "hxp-document-more-menu-item", never, { "item": { "alias": "item"; "required": false; }; "actionContext": { "alias": "actionContext"; "required": false; }; }, {}, never, never, true, never>;
}
