import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export interface DialogData {
    sharedDocument: Document;
}
export declare class ContentShareDialogComponent {
    readonly shareDocumentForm: import("@angular/forms").FormGroup<{
        shared_link: import("@angular/forms").FormControl<string | null>;
    }>;
    private readonly _fb;
    private readonly data;
    private readonly contentShareService;
    private readonly clipboard;
    private readonly hxpNotificationService;
    constructor();
    onCopy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentShareDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentShareDialogComponent, "hxp-alfresco-dbp-content-share-dialog", never, {}, {}, never, never, true, never>;
}
