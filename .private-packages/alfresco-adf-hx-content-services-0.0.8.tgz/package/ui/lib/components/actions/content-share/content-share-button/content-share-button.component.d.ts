import { OnChanges } from '@angular/core';
import { ActionContext } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
/**
 * Component icon button that shows a dialog to share a `Document` url.
 *
 * To display the component, the `actionContext` input property must provide only one `Document` in the `documents` array,
 * and the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `ContentShareButtonComponent`, import the component in your module
 *
 * ```ts
 * import { ContentShareButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentShareButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-single-file-share [actionContext]="actionContext"></hxp-single-file-share>
 *
 */
export declare class ContentShareButtonComponent implements OnChanges {
    /**
     * Input property which specifies an `ActionContext` object
     * The `ActionContext` object should provide an array containing only one `Document`.
     * @type {ActionContext}
     *
     * @example
     * interface ActionContext {
     *     documents: Document[];
     * }
     *
     */
    actionContext: ActionContext;
    protected isAvailable: boolean;
    private readonly contentShareButtonActionService;
    ngOnChanges(): void;
    protected onShare(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentShareButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentShareButtonComponent, "hxp-single-file-share", never, { "actionContext": { "alias": "actionContext"; "required": false; }; }, {}, never, never, true, never>;
}
