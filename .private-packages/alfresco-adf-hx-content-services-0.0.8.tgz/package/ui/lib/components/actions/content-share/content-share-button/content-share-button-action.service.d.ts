import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class ContentShareButtonActionService extends DocumentActionService {
    private readonly dialog;
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentShareButtonActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentShareButtonActionService>;
}
