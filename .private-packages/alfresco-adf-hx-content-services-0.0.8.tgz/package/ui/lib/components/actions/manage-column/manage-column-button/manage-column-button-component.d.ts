import { ActionContext } from '@alfresco/adf-hx-content-services/services';
import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ManageColumnButtonComponent implements OnChanges {
    actionContext: ActionContext;
    isAvailable: boolean;
    private readonly manageColumnActionService;
    ngOnChanges(): void;
    onCopy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManageColumnButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ManageColumnButtonComponent, "hxp-manage-column-button", never, { "actionContext": { "alias": "actionContext"; "required": false; }; "isAvailable": { "alias": "isAvailable"; "required": false; }; }, {}, never, never, true, never>;
}
