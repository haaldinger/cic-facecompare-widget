import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class ContentPropertyViewerActionService extends DocumentActionService {
    private readonly sidebarService;
    isAvailable(context: ActionContext): boolean;
    execute(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentPropertyViewerActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ContentPropertyViewerActionService>;
}
