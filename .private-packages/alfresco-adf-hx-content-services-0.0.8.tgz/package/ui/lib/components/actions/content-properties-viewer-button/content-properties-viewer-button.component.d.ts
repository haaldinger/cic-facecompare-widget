import { OnChanges } from '@angular/core';
import { ActionContext } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
/**
 * Component icon button that triggers an event to display the Document Properties Sidebar.
 *
 * To display the component, the `actionContext` input property must provide only one `Document` in the `documents` array,
 * and the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `ContentPropertiesViewerButtonComponent`, import the component in your module along with `HxpMetadataSidebarComponent`.
 *
 * ```ts
 * import { ContentPropertiesViewerButtonComponent, HxpMetadataSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentPropertiesViewerButtonComponent,
 *         HxpMetadataSidebarComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Inject the `ContentPropertyViewerActionService` in your component as shown in the example below.
 * Subscribe to `showPropertyPanel$` service stream to update the `ActionContext` object with the new value.
 *
 * ```ts
 * import { ActionContext, ContentPropertyViewerActionService, HXP_DOCUMENT_INFO_ACTION_SERVICE } from '@alfresco/adf-hx-content-services/services';
 * import { Subject } from 'rxjs';
 * import { takeUntil } from 'rxjs/operators';
 *
 * @Component({
 *   template: '
 *       <hxp-content-properties-viewer-button [actionContext]="actionContext"></hxp-content-properties-viewer-button>
 *       <hxp-metadata-sidebar
 *           *ngIf="actionContext?.showPanel === 'property'"
 *           [document]="actionContext?.documents[0]"
 *           (closePropertySidebar)="closePropertiesSidebar()"
 *           >
 *        </hxp-metadata-sidebar>
 * ',
 * })
 * export class YourComponent implements OnDestroy {
 *
 *     actionContext: ActionContext = { documents: [] };
 *
 *     private destroyed$: Subject<void> = new Subject<void>();
 *     private readonly contentPropertyViewerActionService = inject<ContentPropertyViewerActionService>(HXP_DOCUMENT_INFO_ACTION_SERVICE);
 *
 *     constructor() {
 *         this.subscribeToShowPropertyPanelStatus();
 *     }
 *
 *     ngOnDestroy() {
 *         this.destroyed$.next();
 *         this.destroyed$.complete();
 *     }
 *
 *     [...]
 *
 *     closePropertiesSidebar(): void {
 *         this.actionContext = { ...this.actionContext, showPanel: undefined };
 *         this.contentPropertyViewerActionService.execute(this.actionContext);
 *     }
 *
 *     private subscribeToShowPropertyPanelStatus(): void {
 *         this.contentPropertyViewerActionService.showPropertyPanel$
 *             .pipe(takeUntil(this.destroyed$))
 *             .subscribe({
 *                  next: (showPropertyPanel) => {
 *                      this.actionContext = { ...this.actionContext, showPanel : showPropertyPanel ? 'property' : undefined };
 *                  },
 *                  error: (error) => console.error(error)
 *         });
 *     }
 * }
 * ```
 *
 */
export declare class ContentPropertiesViewerButtonComponent implements OnChanges {
    /**
     * Input property which specifies an `ActionContext` object
     * The `ActionContext` object should provide an array containing only one `Document`.
     *
     * Optionally the object can provide the `showPanel` to forcefully trigger an event to display or hidden the Properties Viewer.
     * @type {ActionContext}
     *
     * @example
     * interface ActionContext {
     *     documents: Document[];
     *     showPanel?: 'property' | 'version';
     * }
     *
     */
    actionContext: ActionContext;
    protected isAvailable: boolean;
    private readonly contentPropertyViewerActionService;
    ngOnChanges(): void;
    protected showInfo(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentPropertiesViewerButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentPropertiesViewerButtonComponent, "hxp-content-properties-viewer-button", never, { "actionContext": { "alias": "actionContext"; "required": false; }; }, {}, never, never, true, never>;
}
