import { DeletedStatus } from './deleted-status.enum';
interface MessageStructure {
    SINGLE: string;
    MULTI: string;
}
export declare const deleteItemNotificationMessages: Record<DeletedStatus, MessageStructure>;
export {};
