import { OnChanges } from '@angular/core';
import { ActionContext } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
/**
 * Component icon button that delete a `Document` file. Success or error action result status is notified to the user.
 *
 * To display the component:
 * - the `actionContext` input property must provide a list of `Document` to delete in the `documents` array;
 * - current logged in user must have `DELETE` permission on every `Document` in the list;
 * - current logged in user must have `DELETE_CHILD` permission on the parent `Document`.
 *
 * To use the `ContentDeleteButtonComponent`, import the component in your module
 *
 * ```ts
 * import { ContentDeleteButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentDeleteButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-content-delete [actionContext]="actionContext"></hxp-content-delete>
 *
 */
export declare class ContentDeleteButtonComponent implements OnChanges {
    /**
     * Input property which specifies an `ActionContext` object
     * An `ActionContext` object that provides
     * - a list of documents to delete.
     * - the parent document.
     * - a flag to indicate if it should redirect to the parent document after deletion.
     * @type {ActionContext}
     *
     * @example
     * interface ActionContext {
     *     documents: Document[];
     *     parentDocument: Document;
     *     shouldRedirect: boolean (default: false);
     * }
     *
     */
    actionContext: ActionContext;
    protected isAvailable: boolean;
    private readonly deleteButtonActionService;
    private readonly documentCache;
    ngOnChanges(): void;
    protected onDelete(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentDeleteButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentDeleteButtonComponent, "hxp-content-delete", never, { "actionContext": { "alias": "actionContext"; "required": false; }; }, {}, never, never, true, never>;
}
