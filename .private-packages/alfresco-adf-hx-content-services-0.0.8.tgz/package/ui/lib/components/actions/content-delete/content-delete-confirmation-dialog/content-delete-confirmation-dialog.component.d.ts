import * as i0 from "@angular/core";
export declare class ContentDeleteConfirmationDialogComponent {
    protected dialogTitle: string;
    protected dialogDescription: string;
    protected isDeleting: boolean;
    private readonly deleteDocument$;
    private readonly documents;
    private readonly shouldRedirect;
    private readonly refererURL;
    private readonly dialogData;
    private readonly dialogRef;
    private readonly hxpNotificationService;
    private readonly documentService;
    private readonly documentRouterService;
    private readonly routerExtService;
    private readonly translate;
    constructor();
    protected onDelete(): void;
    private redirectToReferer;
    private processDeletionResultsAndNotify;
    private displayNotificationMessage;
    private populateDialogTitleAndDescription;
    static ɵfac: i0.ɵɵFactoryDeclaration<ContentDeleteConfirmationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ContentDeleteConfirmationDialogComponent, "hxp-content-delete-confirmation-dialog", never, {}, {}, never, never, true, never>;
}
