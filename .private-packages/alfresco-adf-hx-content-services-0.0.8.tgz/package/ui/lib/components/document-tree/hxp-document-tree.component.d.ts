import { AfterContentChecked, EventEmitter, OnChanges, OnInit, SimpleChanges, TemplateRef } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { ContextActionConfiguration, DocumentTreeDatabaseService, DocumentTreeNode } from '@alfresco/adf-hx-content-services/services';
import { MatMenuTrigger } from '@angular/material/menu';
import { SelectionModel } from '@angular/cdk/collections';
import * as i0 from "@angular/core";
/**
 * Component that displays a tree of documents.
 *
 * To use the `HxpDocumentTreeComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpDocumentTreeComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *    imports: [
 *       HxpDocumentTreeComponent,
 *      ...
 *   ],
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-document-tree></hxp-document-tree>
 *
 */
export declare class HxpDocumentTreeComponent implements OnChanges, OnInit, AfterContentChecked {
    private destroyRef;
    private readonly documentService;
    private readonly contextMenuActionsService;
    private readonly changeDetectorRef;
    readonly dataSource: DocumentTreeDatabaseService;
    /**
     * The root document of the tree.
     */
    rootDocument: Readonly<Document & Required<Pick<Document, "sys_id">>>;
    /**
     * The list of selected documents in the tree.
     */
    documents: Document[];
    /**
     * If true, the tree allows multiple document selection.
     */
    multiSelection: boolean;
    /**
     * Emits the document that has been selected or unselected.
     */
    selectedDocument: EventEmitter<Document>;
    protected contextActionMenuTemplateRef: TemplateRef<any> | null;
    protected menuTrigger?: MatMenuTrigger;
    protected hiddenTrigger: MatMenuTrigger;
    protected readonly DEFAULT_ITEMS_PER_PAGE = 20;
    protected selection: SelectionModel<Document>;
    protected treeControl: import("@angular/cdk/tree").FlatTreeControl<DocumentTreeNode, DocumentTreeNode>;
    protected contextMenuPosition: {
        x: string;
        y: string;
    };
    protected contextActions: ContextActionConfiguration[];
    protected isInitialTreeLoad: boolean;
    protected contextMenuOpenedDocument: Document | null;
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterContentChecked(): void;
    protected onContextMenu(event: MouseEvent, document: Document): void;
    protected openContextMenu(_: Event, document: Document): void;
    protected onContextMenuClosed(): void;
    protected hasVisibleActions(document: Document): boolean;
    protected hasChild: (_: number, _nodeData: DocumentTreeNode) => boolean;
    protected onDocumentSelected(document: Document, e?: MouseEvent): void;
    protected isDocumentExpandable(document: Document): boolean;
    protected onNodeExpand(event: MouseEvent): void;
    private loadInitialData;
    private getContextActions;
    private openNodes;
    private scrollTreeNodeIntoView;
    private loadSelectedDocumentsAncestors;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpDocumentTreeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpDocumentTreeComponent, "hxp-document-tree", never, { "rootDocument": { "alias": "rootDocument"; "required": false; }; "documents": { "alias": "documents"; "required": false; }; "multiSelection": { "alias": "multiSelection"; "required": false; }; }, { "selectedDocument": "selectedDocument"; }, ["contextActionMenuTemplateRef"], never, true, never>;
}
