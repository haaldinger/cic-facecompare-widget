import * as i0 from "@angular/core";
export declare class HxpCancelMetadataSidebarEditDialogComponent {
    discardChanges: import("@angular/core").OutputEmitterRef<void>;
    saveChanges: import("@angular/core").OutputEmitterRef<void>;
    private readonly dialogRef;
    protected onDiscardChanges(): void;
    protected onSaveAndExit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpCancelMetadataSidebarEditDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpCancelMetadataSidebarEditDialogComponent, "hxp-cancel-metadata-sidebar-edit-dialog", never, {}, { "discardChanges": "discardChanges"; "saveChanges": "saveChanges"; }, never, never, true, never>;
}
