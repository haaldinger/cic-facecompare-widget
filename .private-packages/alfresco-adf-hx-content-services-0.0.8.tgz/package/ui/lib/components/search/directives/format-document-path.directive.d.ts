import { AfterViewInit, SimpleChanges, OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FormatDocumentPathDirective implements OnChanges, AfterViewInit {
    columnWidths: {
        [key: string]: number;
    };
    private originalText;
    private readonly el;
    private readonly renderer;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private truncatePath;
    static ɵfac: i0.ɵɵFactoryDeclaration<FormatDocumentPathDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FormatDocumentPathDirective, "[hxpFormatDocumentPath]", never, { "columnWidths": { "alias": "hxpFormatDocumentPath"; "required": false; }; }, {}, never, never, true, never>;
}
