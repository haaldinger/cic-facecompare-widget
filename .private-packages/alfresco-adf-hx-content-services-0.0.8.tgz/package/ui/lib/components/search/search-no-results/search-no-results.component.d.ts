import * as i0 from "@angular/core";
export declare class SearchNoResultsComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchNoResultsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchNoResultsComponent, "hxp-search-no-results", never, {}, {}, never, never, true, never>;
}
