import { BaseFilterFormType } from '@alfresco/adf-hx-content-services/services';
export interface CreatedDateFormType extends BaseFilterFormType {
    defaultOption: Date;
    isCustomDate: boolean;
    afterDate: Date;
    beforeDate: Date;
}
