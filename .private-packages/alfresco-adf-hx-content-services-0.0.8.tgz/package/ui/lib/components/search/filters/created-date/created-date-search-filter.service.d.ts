import { SearchFilterService } from '@alfresco/adf-hx-content-services/services';
import { CreatedDateSearchFilterData } from './created-date-search-filter.data';
import * as i0 from "@angular/core";
export declare class CreatedDateSearchFilterService implements SearchFilterService {
    toHXQL(data: CreatedDateSearchFilterData): string;
    private formatCreatedDateToHXQL;
    private formatLastPeriodToHXQL;
    static ɵfac: i0.ɵɵFactoryDeclaration<CreatedDateSearchFilterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CreatedDateSearchFilterService>;
}
