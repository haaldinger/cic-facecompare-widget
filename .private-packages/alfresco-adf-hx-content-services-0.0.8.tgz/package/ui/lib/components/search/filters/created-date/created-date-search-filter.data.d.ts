import { SearchFilterData, SearchFilterValue } from '@alfresco/adf-hx-content-services/services';
export declare class CreatedDateSearchFilterValue implements SearchFilterValue {
    label: string;
    date?: string;
    beforeDate?: Date;
    afterDate?: Date;
}
export declare class CreatedDateSearchFilterData implements SearchFilterData {
    values: CreatedDateSearchFilterValue[];
    constructor(values?: CreatedDateSearchFilterValue[]);
    isEquivalentTo(data?: CreatedDateSearchFilterData): boolean;
}
