import { BaseFilterFormType } from '@alfresco/adf-hx-content-services/services';
export interface DocumentCategoryFormType extends BaseFilterFormType {
    selectedCategories: string[];
}
