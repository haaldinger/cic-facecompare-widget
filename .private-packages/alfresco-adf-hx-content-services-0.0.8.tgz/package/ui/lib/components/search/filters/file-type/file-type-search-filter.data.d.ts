import { SearchFilterValue, SearchFilterData } from '@alfresco/adf-hx-content-services/services';
export declare class FileTypeSearchFilterValue implements SearchFilterValue {
    label: string;
    value: string[];
    fileTypeId: string;
}
export declare class FileTypeSearchFilterData implements SearchFilterData {
    values: FileTypeSearchFilterValue[];
    constructor(values?: FileTypeSearchFilterValue[]);
    isEquivalentTo(data?: FileTypeSearchFilterData): boolean;
}
