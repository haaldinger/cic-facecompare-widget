import { SearchFilterService } from '@alfresco/adf-hx-content-services/services';
import { DocumentCategorySearchFilterData } from './document-category-search-filter.data';
import * as i0 from "@angular/core";
export declare class DocumentCategorySearchFilterService implements SearchFilterService {
    toHXQL(data: DocumentCategorySearchFilterData): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<DocumentCategorySearchFilterService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DocumentCategorySearchFilterService>;
}
