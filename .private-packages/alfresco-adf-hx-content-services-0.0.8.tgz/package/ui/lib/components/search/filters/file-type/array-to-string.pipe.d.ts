import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ArrayToStringPipe implements PipeTransform {
    transform(value?: string[], prefix?: string, separator?: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ArrayToStringPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ArrayToStringPipe, "arrayToString", true>;
}
