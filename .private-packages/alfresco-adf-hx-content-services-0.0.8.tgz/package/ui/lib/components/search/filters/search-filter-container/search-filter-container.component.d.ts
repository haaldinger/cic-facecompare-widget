import { ConnectedPosition, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { AfterViewInit, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { SearchFilterData } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class SearchFilterContainerComponent implements AfterViewInit, OnChanges {
    name: string;
    filterForm: FormGroup;
    selectedValue?: SearchFilterData;
    /**
     * Event emitted when the filter overlay is closed without any explicit action (e.g. clear or apply filter)
     */
    overlayClosed: EventEmitter<void>;
    filterCleared: EventEmitter<void>;
    filterApplied: EventEmitter<SearchFilterData | undefined>;
    private template;
    private chip?;
    data?: SearchFilterData;
    selectionLabel: string;
    hiddenValuesCount: number;
    protected isFilterOverlayOpened: boolean;
    protected overlayPosition: ConnectedPosition[];
    protected overlayRef?: OverlayRef;
    protected templatePortal?: TemplatePortal<any>;
    private readonly destroyRef;
    private readonly overlay;
    private readonly viewContainerRef;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    applyChanges(): void;
    clearChanges(): void;
    protected clearFilter(event: Event): void;
    protected applyFilter(event: Event): void;
    protected computeLabelVisibility(): void;
    protected hasPendingChanges(): boolean;
    protected discardPendingChanges(): void;
    protected openFilterOverlay(): void;
    protected closeOverlay(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchFilterContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchFilterContainerComponent, "hxp-search-filter-container", never, { "name": { "alias": "name"; "required": false; }; "filterForm": { "alias": "filterForm"; "required": false; }; "selectedValue": { "alias": "selectedValue"; "required": false; }; }, { "overlayClosed": "overlayClosed"; "filterCleared": "filterCleared"; "filterApplied": "filterApplied"; }, never, ["*"], true, never>;
}
