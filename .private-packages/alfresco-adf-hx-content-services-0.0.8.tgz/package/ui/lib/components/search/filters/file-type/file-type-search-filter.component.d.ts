import { FilterId } from '@alfresco/adf-hx-content-services/services';
import { AbstractControl } from '@angular/forms';
import { FileTypeSearchFilterFormType } from './file-type-search-filter.type';
import { FileTypeSearchFilterData } from './file-type-search-filter.data';
import { SelectionModel } from '@angular/cdk/collections';
import { FileTypeFlatNode } from './tree/file-type-search-filter-file-type-node';
import { BaseSearchFilterDirective } from '../../directives/base-search-filter.directive';
import * as i0 from "@angular/core";
export declare class FileTypeSearchFilterComponent extends BaseSearchFilterDirective<FileTypeSearchFilterFormType> {
    protected searchTerm: string;
    protected selection: SelectionModel<FileTypeFlatNode>;
    private searchFilterInputComponent;
    private fileTypeSearchFilterTreeComponent;
    private readonly fileTypeSearchFilterService;
    private readonly arrayToStringPipe;
    get id(): FilterId;
    toHXQL(data: FileTypeSearchFilterData): string;
    setData(data: FileTypeSearchFilterData): void;
    applyFilter(): void;
    clearFilter(): void;
    overlayClosed(): void;
    protected filteredSearch(searchTerm: string): void;
    protected getFormControls(): {
        [key: string]: AbstractControl;
    };
    protected onSelectedFileType(selectedFileTypes: FileTypeFlatNode[]): void;
    protected toggleSelection(fileTypeNode: FileTypeFlatNode): void;
    protected clearSearchInput(): void;
    private toggleNodeSelectionFromId;
    private setSelectedValue;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTypeSearchFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileTypeSearchFilterComponent, "hxp-file-type-search-filter", never, {}, {}, never, never, true, never>;
}
