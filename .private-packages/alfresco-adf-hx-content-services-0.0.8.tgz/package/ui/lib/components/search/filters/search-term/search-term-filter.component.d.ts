import { EventEmitter, OnChanges } from '@angular/core';
import { AbstractControl } from '@angular/forms';
import { ShowOnDirtyErrorStateMatcher } from '@angular/material/core';
import { SearchTermFormType } from './search-term-filter.type';
import { SearchTermFilterData } from './search-term-filter.data';
import { SearchType, FilterId } from '@alfresco/adf-hx-content-services/services';
import { BaseSearchFilterDirective } from '../../directives/base-search-filter.directive';
import * as i0 from "@angular/core";
export declare class SearchTermFilterComponent extends BaseSearchFilterDirective<SearchTermFormType> implements OnChanges {
    searchType: SearchType;
    searchTerm: string;
    searchTermChanged: EventEmitter<string>;
    protected readonly SearchTypeEnum: {
        readonly BASIC: "basic";
        readonly HXQL: "hxql";
    };
    protected errorStateMatcher: ShowOnDirtyErrorStateMatcher;
    private readonly searchTermFilterService;
    ngOnChanges(): void;
    get id(): FilterId;
    toHXQL(data: SearchTermFilterData): string;
    onInput(): void;
    onClear(): void;
    onSearch(event?: Event): void;
    protected getFormControls(): {
        [key: string]: AbstractControl;
    };
    protected setData(data: SearchTermFilterData): void;
    private emitSearchTermChanged;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchTermFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchTermFilterComponent, "hxp-search-term-filter", never, { "searchType": { "alias": "searchType"; "required": false; }; "searchTerm": { "alias": "searchTerm"; "required": false; }; }, { "searchTermChanged": "searchTermChanged"; }, never, never, true, never>;
}
