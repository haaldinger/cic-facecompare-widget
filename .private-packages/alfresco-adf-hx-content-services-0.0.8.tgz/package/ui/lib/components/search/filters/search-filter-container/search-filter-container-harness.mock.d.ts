import { ComponentHarness } from '@angular/cdk/testing';
import { MatButtonHarness } from '@angular/material/button/testing';
import { MatIconHarness } from '@angular/material/icon/testing';
export declare class SearchFilterHarness extends ComponentHarness {
    static hostSelector: string;
    getLabel: () => Promise<import("@angular/cdk/harness-environment.d-BbFzIFDE").T | null>;
    getExpandIcon: () => Promise<MatIconHarness | null>;
    getBadge: () => Promise<import("@angular/cdk/harness-environment.d-BbFzIFDE").T | null>;
    getApplyButton: () => Promise<MatButtonHarness | null>;
    getClearButton: () => Promise<MatButtonHarness | null>;
    getOverlayBackdrop: () => Promise<import("@angular/cdk/harness-environment.d-BbFzIFDE").T | null>;
    protected getChip: () => Promise<import("@angular/cdk/harness-environment.d-BbFzIFDE").T | null>;
    protected getOverlayContainer: () => Promise<import("@angular/cdk/harness-environment.d-BbFzIFDE").T | null>;
    isOpen(): Promise<boolean>;
    open(): Promise<void | undefined>;
}
