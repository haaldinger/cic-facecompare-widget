import { SearchFilterValue, SearchFilterData } from '@alfresco/adf-hx-content-services/services';
export declare class DocumentCategorySearchFilterValue implements SearchFilterValue {
    label: string;
    value: string;
}
export declare class DocumentCategorySearchFilterData implements SearchFilterData {
    values: DocumentCategorySearchFilterValue[];
    constructor(values?: DocumentCategorySearchFilterValue[]);
    isEquivalentTo(data?: DocumentCategorySearchFilterData): boolean;
}
