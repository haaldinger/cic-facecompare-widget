import { EventEmitter, OnChanges } from '@angular/core';
import { SelectionModel } from '@angular/cdk/collections';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { FileTypeFlatNode, FileTypeNode } from './file-type-search-filter-file-type-node';
import * as i0 from "@angular/core";
export declare class FileTypeSearchFilterTreeComponent implements OnChanges {
    protected flatNodeMap: Map<FileTypeFlatNode, FileTypeNode>;
    protected nestedNodeMap: Map<FileTypeNode, FileTypeFlatNode>;
    protected selectedParent: FileTypeFlatNode | null;
    protected treeControl: FlatTreeControl<FileTypeFlatNode>;
    protected treeFlattener: MatTreeFlattener<FileTypeNode, FileTypeFlatNode>;
    protected dataSource: MatTreeFlatDataSource<FileTypeNode, FileTypeFlatNode>;
    protected fileTypeSelection: SelectionModel<FileTypeFlatNode>;
    filteredFileType: string;
    selectedFileTypes: EventEmitter<FileTypeFlatNode[]>;
    constructor();
    ngOnChanges(): void;
    fileTypeSelectionToggleById(nodeId: string): void;
    fileTypeSelectionToggle(node: FileTypeFlatNode): void;
    clearSelection(): void;
    protected onNodeExpand(event: Event): void;
    protected getLevel: (node: FileTypeFlatNode) => number;
    protected isExpandable: (node: FileTypeFlatNode) => boolean;
    protected getChildren: (node: FileTypeNode) => FileTypeNode[];
    protected hasChild: (_: number, _nodeData: FileTypeFlatNode) => boolean | undefined;
    protected hasNoContent: (_: number, _nodeData: FileTypeFlatNode) => boolean;
    /**
     * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
     */
    protected transformer: (node: FileTypeNode, level: number) => FileTypeFlatNode;
    protected descendantsAllSelected(node: FileTypeFlatNode): boolean;
    protected descendantsPartiallySelected(node: FileTypeFlatNode): boolean;
    protected leafItemSelectionToggle(node: FileTypeFlatNode): void;
    protected checkAllParentsSelection(node: FileTypeFlatNode): void;
    protected checkRootNodeSelection(node: FileTypeFlatNode): void;
    private getParentNode;
    private filterTree;
    private filterRecursive;
    /**
     * Expands all selected nodes to make inner nodes visible.
     */
    private expandSelectedNodes;
    static ɵfac: i0.ɵɵFactoryDeclaration<FileTypeSearchFilterTreeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FileTypeSearchFilterTreeComponent, "hxp-file-type-search-filter-tree", never, { "filteredFileType": { "alias": "filteredFileType"; "required": false; }; }, { "selectedFileTypes": "selectedFileTypes"; }, never, never, true, never>;
}
