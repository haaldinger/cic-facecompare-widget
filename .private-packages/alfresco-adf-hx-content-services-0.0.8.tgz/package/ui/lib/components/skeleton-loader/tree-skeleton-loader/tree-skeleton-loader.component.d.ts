import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Component representing a skeleton to display during content loading.
 *
 * To use the `TreeSkeletonLoaderComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { TreeSkeletonLoaderComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         TreeSkeletonLoaderComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-tree-skeleton-loader></hxp-tree-skeleton-loader>
 */
export declare class TreeSkeletonLoaderComponent implements OnChanges {
    /**
     * Default value of skeleton tree rows to display.
     * @readonly
     * @type {number}
     */
    protected static readonly DEFAULT_SKELETON_ROWS = 10;
    /**
     * Indicates the number of rows to display in the skeleton tree.
     * @type {number}
     * @default 10
     */
    skeletonRows: number;
    protected skeletonRowArray: number[];
    ngOnChanges(): void;
    protected skeletonRowTrackBy(index: number): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeSkeletonLoaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TreeSkeletonLoaderComponent, "hxp-tree-skeleton-loader", never, { "skeletonRows": { "alias": "skeletonRows"; "required": false; }; }, {}, never, never, true, never>;
}
