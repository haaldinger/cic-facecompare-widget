import { ElementRef } from '@angular/core';
import { CardViewItem } from '@alfresco/adf-core';
import { Subject } from 'rxjs';
import * as i0 from "@angular/core";
export declare class HxpMetadataSidebarAdditionalInfoComponent {
    nonEditableSystemProperties: import("@angular/core").InputSignal<CardViewItem[]>;
    pathContent: import("@angular/core").Signal<ElementRef<any> | undefined>;
    protected pathProperty: import("@angular/core").Signal<CardViewItem | undefined>;
    protected isClamped: boolean;
    protected isOverflowing: boolean;
    protected hasOverflowed: boolean;
    protected checkOverflow$: Subject<void>;
    private readonly clipboard;
    private readonly hxpNotificationService;
    constructor();
    protected toggleClamp(): void;
    protected onCopyPath(): void;
    private checkOverflow;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpMetadataSidebarAdditionalInfoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpMetadataSidebarAdditionalInfoComponent, "hxp-metadata-sidebar-additional-info", never, { "nonEditableSystemProperties": { "alias": "nonEditableSystemProperties"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
