import { ActionContext } from '@alfresco/adf-hx-content-services/services';
import { OnChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class VersionDeleteButtonComponent implements OnChanges {
    actionContext: ActionContext;
    protected isAvailable: boolean;
    private readonly versionDeleteActionService;
    ngOnChanges(): void;
    protected onDelete(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionDeleteButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VersionDeleteButtonComponent, "hxp-version-delete-button", never, { "actionContext": { "alias": "actionContext"; "required": false; }; }, {}, never, never, true, never>;
}
