import * as i0 from "@angular/core";
export declare class VersionDeleteConfirmationDialogComponent {
    protected isDeleting: boolean;
    private readonly version;
    private readonly parentId;
    private readonly dialogData;
    private readonly dialogRef;
    private readonly documentVersionsService;
    private readonly documentService;
    private readonly hxpNotificationService;
    private readonly documentRouterService;
    constructor();
    protected onDelete(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionDeleteConfirmationDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VersionDeleteConfirmationDialogComponent, "hxp-version-delete-confirmation-dialog", never, {}, {}, never, never, true, never>;
}
