import { Document } from '@hylandsoftware/hxcs-js-client';
import { VersionableDocument, ContextActionConfiguration } from '@alfresco/adf-hx-content-services/services';
import { EventEmitter, OnChanges, TemplateRef, OnInit } from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import * as i0 from "@angular/core";
export declare class ManageVersionsSidebarComponent implements OnInit, OnChanges {
    /**
     * The document to display the versions for
     * @type {Document}
     */
    document?: Document;
    /**
     * Emits an event when the sidebar is closed
     */
    closeVersionsSidebar: EventEmitter<void>;
    documentVersions: VersionableDocument[];
    isLoading: boolean;
    protected workingCopy: VersionableDocument | undefined;
    protected selectedDocument: VersionableDocument | undefined;
    protected contextActionMenuTemplateRef: TemplateRef<any> | null;
    protected menuTrigger?: MatMenuTrigger;
    protected hiddenTrigger: MatMenuTrigger;
    protected contextMenuPosition: {
        x: string;
        y: string;
    };
    protected contextActions: ContextActionConfiguration[];
    private readonly documentRouterService;
    private readonly documentVersionsService;
    private readonly versionContextMenuActionsService;
    ngOnInit(): void;
    ngOnChanges(): void;
    redirectToVersion(document: Document): void;
    protected onClose(): void;
    protected onContextMenu(event: MouseEvent, version: VersionableDocument): void;
    private getContextActions;
    private loadVersions;
    static ɵfac: i0.ɵɵFactoryDeclaration<ManageVersionsSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ManageVersionsSidebarComponent, "hxp-manage-versions-sidebar", never, { "document": { "alias": "document"; "required": false; }; }, { "closeVersionsSidebar": "closeVersionsSidebar"; }, ["contextActionMenuTemplateRef"], never, true, never>;
}
