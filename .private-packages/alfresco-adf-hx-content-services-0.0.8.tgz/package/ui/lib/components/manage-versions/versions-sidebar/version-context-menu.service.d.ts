import { Subject } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
export interface VersionContextActionConfiguration {
    data: Document;
    model: {
        key: string;
        icon: string;
        title: string;
        visible: boolean;
    };
    subject: Subject<any>;
}
export declare class VersionContextMenuActionsService {
    private readonly documentSingleItemDownloadHandler;
    private readonly documentShareHandler;
    private readonly documentVersionRestoreHandler;
    private readonly documentVersionEditHandler;
    private readonly documentVersionDeleteHandler;
    getVersionContextActions(data: Document, parentDocument?: Document): VersionContextActionConfiguration[];
    private toContextAction;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionContextMenuActionsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VersionContextMenuActionsService>;
}
