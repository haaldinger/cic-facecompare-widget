import { VersionableDocument } from '@alfresco/adf-hx-content-services/services';
import { OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import * as i0 from "@angular/core";
export declare class VersionEditDialogComponent implements OnInit {
    protected isUpdating: boolean;
    protected form: FormGroup;
    private dateFormat;
    readonly version: VersionableDocument;
    private readonly fb;
    private readonly datePipe;
    private readonly hxpNotificationService;
    private readonly dialogRef;
    private readonly documentVersionService;
    ngOnInit(): void;
    protected onSave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionEditDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VersionEditDialogComponent, "hxp-version-edit-dialog", never, {}, {}, never, never, true, never>;
}
