import { ActionContext, DocumentActionService } from '@alfresco/adf-hx-content-services/services';
import * as i0 from "@angular/core";
export declare class VersionRestoreActionService extends DocumentActionService {
    private readonly hxpNotificationService;
    private readonly documentService;
    isAvailable(context: ActionContext): boolean;
    execute(context: ActionContext): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VersionRestoreActionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VersionRestoreActionService>;
}
