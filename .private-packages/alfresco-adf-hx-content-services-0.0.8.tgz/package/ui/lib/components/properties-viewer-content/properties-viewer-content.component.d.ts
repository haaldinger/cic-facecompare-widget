import { CardViewItem } from '@alfresco/adf-core';
import { EventEmitter, OnChanges } from '@angular/core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
/**
 * Component presents document properties viewer content.
 *
 * To use the `PropertiesViewerContentComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { PropertiesViewerContentComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         PropertiesViewerContentComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-properties-viewer-content
 *    [document]="document"
 *    [properties]="defaultProperties"
 *    [editable]="editable"
 *    [expanded]="expanded"
 *    [copyToClipboardAction]="copyToClipboardAction"
 *    [displayDefaultProperties]="displayDefaultProperties"
 *    [displayEmpty]="displayEmpty"
 *    [multi]="multi"
 *    [useChipsForMultiValueProperty]="useChipsForMultiValueProperty">
 * </hxp-properties-viewer-content>
 */
export declare class PropertiesViewerContentComponent implements OnChanges {
    /**
     * An attribute representing a text to display in the header. Can be a key to translate.
     */
    headerText: string;
    private readonly destroyRef;
    private readonly documentService;
    private readonly cardViewUpdateService;
    private readonly hxpNotificationService;
    private readonly documentPropertiesService;
    /**
     * The document to display the properties for.
     * @type {Document}
     * @required
     */
    document: Document | undefined;
    /**
     * The properties to display in the card view.
     * @type {CardViewItem[]}
     * @default []
     *
     * ```ts
     * export interface CardViewItem {
     *      label: string;
     *      value: any;
     *      key: string;
     *      default?: any;
     *      type: string;
     *      displayValue: any;
     *      editable?: boolean;
     *      icon?: string;
     * }
     * ```
     *
     */
    properties: CardViewItem[];
    /**
     * Toggles whether or not to enable copy to clipboard action.
     * @type {boolean}
     * @default true
     */
    copyToClipboardAction: boolean;
    /**
     * Toggles whether the metadata properties should be shown.
     * @type {boolean}
     * @default true
     */
    displayDefaultProperties: boolean;
    /**
     * Toggles whether to display empty values in the card view.
     * @type {boolean}
     * @default false
     */
    displayEmpty: boolean;
    /**
     * Toggles whether the edit button should be shown
     * @type {boolean}
     * @default false
     */
    editable: boolean;
    /**
     * Expand or collapse the panel.
     * @type {boolean}
     * @default false
     */
    expanded: boolean;
    /**
     * The multi parameter of the underlying material expansion panel, set to true to allow multi accordion to be expanded at the same time.
     * @type {boolean}
     * @default false
     */
    multi: boolean;
    /**
     * Toggles whether or not to enable chips for multivalued properties.
     * @type {boolean}
     * @default true
     */
    useChipsForMultiValueProperty: boolean;
    propertyUpdateRequest: EventEmitter<boolean>;
    protected editMode: boolean;
    protected workingCopy: boolean;
    protected isEditableRecord: boolean;
    private cardValueValidationMap;
    private documentPropertiesToUpdate;
    private requiredProperties;
    constructor(
    /**
     * An attribute representing a text to display in the header. Can be a key to translate.
     */
    headerText?: string);
    ngOnChanges(): void;
    protected onSaveProperties(): void;
    protected toggleEditMode(): void;
    protected hasBeenModified(): boolean;
    protected allCardValuesAreValid(): boolean;
    private respondToCardUpdate;
    private getUpdatedComplexProperty;
    private validateCardValue;
    private isComplexProperty;
    private isEmptyProperty;
    private handleEmptyProperty;
    static ɵfac: i0.ɵɵFactoryDeclaration<PropertiesViewerContentComponent, [{ attribute: "headerText"; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PropertiesViewerContentComponent, "hxp-properties-viewer-content", never, { "document": { "alias": "document"; "required": false; }; "properties": { "alias": "properties"; "required": false; }; "copyToClipboardAction": { "alias": "copyToClipboardAction"; "required": false; }; "displayDefaultProperties": { "alias": "displayDefaultProperties"; "required": false; }; "displayEmpty": { "alias": "displayEmpty"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "multi": { "alias": "multi"; "required": false; }; "useChipsForMultiValueProperty": { "alias": "useChipsForMultiValueProperty"; "required": false; }; }, { "propertyUpdateRequest": "propertyUpdateRequest"; }, never, never, true, never>;
}
