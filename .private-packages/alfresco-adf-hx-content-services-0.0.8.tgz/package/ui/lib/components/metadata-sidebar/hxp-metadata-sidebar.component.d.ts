import { CardViewItem } from '@alfresco/adf-core';
import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { SchemaTree } from '@alfresco/adf-hx-content-services/services';
import { Observable } from 'rxjs';
import { Document } from '@hylandsoftware/hxcs-js-client';
import * as i0 from "@angular/core";
/**
 * Sidebar component to display and edit a Document properties.
 *
 * To use the `HxpMetadataSidebarComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpMetadataSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         HxpMetadataSidebarComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-metadata-sidebar [editable]="false" [document]="document" (closePropertySidebar)="onClose()">
 */
export declare class HxpMetadataSidebarComponent implements OnChanges {
    private readonly destroyRef;
    private readonly envInjector;
    private readonly metadataSidebarService;
    /**
     * The document to display the properties for
     * @type {Document}
     */
    document?: Document;
    /**
     * Input property to enable or disable edit mode availability
     * @type {boolean}
     * @default true
     */
    editable: boolean;
    /**
     * Emits an event when the sidebar is closed
     */
    closePropertySidebar: EventEmitter<void>;
    protected propertyLoading: boolean;
    protected selectedDocument: Document;
    protected editableSystemProperties$: Observable<CardViewItem[]>;
    protected nonEditableSystemProperties$: Observable<CardViewItem[]>;
    protected customProperties$: Observable<CardViewItem[]>;
    protected allEditableProperties$: Observable<CardViewItem[]>;
    protected workingCopy: boolean;
    protected isEditableRecord: boolean;
    protected editMode: boolean;
    protected hasPendingChanges: boolean;
    protected isUpdateInProgress: boolean;
    protected propertiesGroups: SchemaTree;
    private cardValueValidationMap;
    private documentPropertiesToUpdate;
    private readonly requiredProperties;
    private dialogRef;
    private editableNonNullableProperties;
    private contentTypeSchemas;
    private requiredCustomFieldLabel;
    private isContentTypeChanged;
    protected invalidFieldIds: import("@angular/core").WritableSignal<string[]>;
    private readonly documentService;
    private readonly hxpNotificationService;
    private readonly cardViewUpdateService;
    private readonly dialog;
    private readonly translateService;
    private readonly cacheService;
    private readonly documentPropertiesService;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    private hasDocumentChanged;
    private initializeRequiredFieldsState;
    private buildRequiredPropertiesLists;
    private markRequiredFieldsInDom;
    private handleContentTypeChangeValidation;
    private markHtmlElementAsRequiredField;
    onEscKeyUp(event: Event): void;
    protected onCancel(): void;
    protected handlePropertyUpdate(propertyUpdated: boolean): void;
    protected onClose(): void;
    protected onOutsideClick(): void;
    protected onTabChange(event: any): void;
    private openCancelDialog;
    private exitEditMode;
    private contentTypeHasChanged;
    private subscribeToDocumentUpdates;
    private loadDocumentProperties;
    private fetchDocumentProperties;
    private fetchCustomSchemaFields;
    private flatSchemaTree;
    private initializeDocumentWithSchema;
    private addSchemaFieldsToDocument;
    private fetchNonEditableProperties;
    private fetchAllEditableProperties;
    private fetchEditableProperties;
    private fetchCustomProperties;
    private mapCachedProperties;
    private updateAllEditableProperties;
    private respondToCardUpdate;
    private updateInvalidFields;
    private validateCardValue;
    private isComplexProperty;
    private isEmptyProperty;
    private isPropertyRequired;
    private getUpdatedComplexProperty;
    protected enableEditMode(): void;
    protected hasBeenModified(): boolean;
    protected allCardValuesAreValid(): boolean;
    private allRequiredPropertiesAreSet;
    protected onSaveProperties(): void;
    private updateContentType;
    private displayToastForRequiredFields;
    private onSidebarKeyUp;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpMetadataSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HxpMetadataSidebarComponent, "hxp-metadata-sidebar", never, { "document": { "alias": "document"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; }, { "closePropertySidebar": "closePropertySidebar"; }, never, never, true, never>;
}
