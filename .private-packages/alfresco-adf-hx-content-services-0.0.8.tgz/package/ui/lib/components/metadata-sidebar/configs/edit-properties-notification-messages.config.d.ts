import { EditPropertiesStatus } from './edit-properties-status.enum';
export declare const editPropertiesNotificationMessages: Record<EditPropertiesStatus, string>;
