import * as i0 from "@angular/core";
export interface KeyValuePairs {
    [key: string]: any;
}
export declare class HxpMetadataCacheService {
    private readonly globalCache;
    /**
     * Retrieves a cached value by its key if it has been updated.
     * If the value exists in the cache, it returns the value.
     * If the key does not exist in the cache, it returns the provided fallback value (if any) and stores it in the cache.
     * @param key The key to look up in the cache.
     * @param fallbackValue The value to return and store if the key is not found.
     * @returns The cached value or the fallback value.
     */
    getCachedValue<T>(key: string, fallbackValue?: T): T | undefined;
    getAllCachedValues(): KeyValuePairs;
    updateCache(keyValuePairs: KeyValuePairs): void;
    invalidateCache(): void;
    getUpdatedValues(): KeyValuePairs;
    getUpdatedValuesForSchemas(schema: string[]): KeyValuePairs;
    private setValueToObject;
    private updateGlobalCache;
    private isComplexValue;
    /**
     * Verify that CachedItem originalValue and value properties represent the same value.
     * @param originalValue It is initialised with a value coming from the backend,
     * which might be a number, a string, a string representing a Date in ISO format or an Array.
     * Objects (complex properties) are stored as nested key-value pairs in the cache using dot notation.
     * @param value The value coming from the UI might be a string, a Date object or an Array.
     * @returns true if both values are the same, false otherwise.
     */
    private isSameValue;
    private isSameDate;
    private isSameArray;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpMetadataCacheService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<HxpMetadataCacheService>;
}
