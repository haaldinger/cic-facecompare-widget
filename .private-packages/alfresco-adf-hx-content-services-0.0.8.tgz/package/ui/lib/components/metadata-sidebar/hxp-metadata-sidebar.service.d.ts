import { CardViewItem } from '@alfresco/adf-core';
import { Document } from '@hylandsoftware/hxcs-js-client';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export declare class MetadataSidebarService {
    private readonly EDITABLE_DEFAULT_PROPERTIES;
    private readonly NON_EDITABLE_DEFAULT_PROPERTIES;
    private readonly documentPropertiesService;
    getEditableSystemPropertiesFromDocument(document?: Document): Observable<CardViewItem[]>;
    getNonEditableSystemPropertiesFromDocument(document?: Document): Observable<CardViewItem[]>;
    getCustomProperties(document?: Document): Observable<CardViewItem[]>;
    private filterAndSortProperties;
    static ɵfac: i0.ɵɵFactoryDeclaration<MetadataSidebarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MetadataSidebarService>;
}
