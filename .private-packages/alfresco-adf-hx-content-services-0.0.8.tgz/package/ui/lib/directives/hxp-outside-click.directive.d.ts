import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * This directive is used to detect clicks outside the element.
 *
 * Example:
 * <div (hxpOutsideClick)="close()"></div>
 *
 */
export declare class HxpOutsideClickDirective implements OnInit {
    private readonly ngZone;
    private readonly elementRef;
    private readonly overlayContainer;
    private readonly documentClick$;
    private readonly destroyRef$;
    readonly hxpOutsideClick: import("@angular/core").OutputEmitterRef<Event>;
    ngOnInit(): void;
    private getClickOutsideSubject;
    private isInsideOverlay;
    static ɵfac: i0.ɵɵFactoryDeclaration<HxpOutsideClickDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<HxpOutsideClickDirective, "[hxpOutsideClick]", never, {}, { "hxpOutsideClick": "hxpOutsideClick"; }, never, never, true, never>;
}
