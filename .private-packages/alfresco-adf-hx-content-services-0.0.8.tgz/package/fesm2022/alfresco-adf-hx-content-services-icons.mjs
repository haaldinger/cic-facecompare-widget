import * as i0 from '@angular/core';
import { inject, Input, Component } from '@angular/core';
import { MatIconRegistry, MatIcon } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { SATORI_ICONS } from '@hylandsoftware/satori-icons';
import { TranslateService } from '@ngx-translate/core';

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DefaultIcon = {
    UNKNOWN: 'document',
    FOLDER: 'folder',
    OPEN_FOLDER: 'folder_open',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a mime type icon.
 *
 * To use the `MimeTypeIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { MimeTypeIconComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         MimeTypeIconComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-mime-type-icon [mimeType]="'image/png'"></hxp-mime-type-icon>
 *
 */
class MimeTypeIconComponent {
    get svgIcon() {
        if (this.mimeType === this.folderIcon) {
            return `${this.satoriNamespace}:${this.mimeType}`;
        }
        return this.mimeType || 'document';
    }
    constructor() {
        /**
          * A string representing a valid mime type.
          * @type {string}
          *
          * <details>
          * <summary>Supported mime types</summary>
          *
          * - 'image/png'
          * - 'image/jpeg'
          * - 'image/gif'
          * - 'image/bmp'
          * - 'image/cgm'
          * - 'image/ief'
          * - 'image/jp2'
          * - 'image/tiff'
          * - 'image/vnd.adobe.photoshop'
          * - 'image/vnd.adobe.premiere'
          * - 'image/x-cmu-raster'
          * - 'image/x-dwt'
          * - 'image/x-portable-anymap'
          * - 'image/x-portable-bitmap'
          * - 'image/x-portable-graymap'
          * - 'image/x-portable-pixmap'
          * - 'image/x-raw-adobe'
          * - 'image/x-raw-canon'
          * - 'image/x-raw-fuji'
          * - 'image/x-raw-hasselblad'
          * - 'image/x-raw-kodak'
          * - 'image/x-raw-leica'
          * - 'image/x-raw-minolta'
          * - 'image/x-raw-nikon'
          * - 'image/x-raw-olympus'
          * - 'image/x-raw-panasonic'
          * - 'image/x-raw-pentax'
          * - 'image/x-raw-red'
          * - 'image/x-raw-sigma'
          * - 'image/x-raw-sony'
          * - 'image/x-xbitmap'
          * - 'image/x-xpixmap'
          * - 'image/x-xwindowdump'
          * - 'image/svg+xml'
          * - 'application/eps'
          * - 'application/illustrator'
          * - 'application/pdf'
          * - 'application/vnd.ms-excel'
          * - 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
          * - 'application/vnd.openxmlformats-officedocument.spreadsheetml.template'
          * - 'application/vnd.ms-excel.addin.macroenabled.12'
          * - 'application/vnd.ms-excel.sheet.binary.macroenabled.12'
          * - 'application/vnd.ms-excel.sheet.macroenabled.12'
          * - 'application/vnd.ms-excel.template.macroenabled.12'
          * - 'application/vnd.sun.xml.calc'
          * - 'application/vnd.sun.xml.calc.template'
          * - 'application/vnd.ms-outlook'
          * - 'application/msword'
          * - 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
          * - 'application/vnd.openxmlformats-officedocument.wordprocessingml.template'
          * - 'application/vnd.ms-word.document.macroenabled.12'
          * - 'application/vnd.ms-word.template.macroenabled.12'
          * - 'application/vnd.sun.xml.writer'
          * - 'application/vnd.sun.xml.writer.template'
          * - 'application/rtf'
          * - 'text/rtf'
          * - 'application/vnd.ms-powerpoint'
          * - 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
          * - 'application/vnd.openxmlformats-officedocument.presentationml.template'
          * - 'application/vnd.openxmlformats-officedocument.presentationml.slideshow'
          * - 'application/vnd.oasis.opendocument.presentation'
          * - 'application/vnd.oasis.opendocument.presentation-template'
          * - 'application/vnd.openxmlformats-officedocument.presentationml.slide'
          * - 'application/vnd.sun.xml.impress'
          * - 'application/vnd.sun.xml.impress.template'
          * - 'application/vnd.oasis.opendocument.spreadsheet'
          * - 'application/vnd.oasis.opendocument.spreadsheet-template'
          * - 'application/vnd.ms-powerpoint.addin.macroenabled.12'
          * - 'application/vnd.ms-powerpoint.presentation.macroenabled.12'
          * - 'application/vnd.ms-powerpoint.slide.macroenabled.12'
          * - 'application/vnd.ms-powerpoint.slideshow.macroenabled.12'
          * - 'application/vnd.ms-powerpoint.template.macroenabled.12'
          * - 'video/mp4'
          * - 'video/3gpp'
          * - 'video/3gpp2'
          * - 'video/mp2t'
          * - 'video/mpeg'
          * - 'video/mpeg2'
          * - 'video/ogg'
          * - 'video/quicktime'
          * - 'video/webm'
          * - 'video/x-flv'
          * - 'video/x-m4v'
          * - 'video/x-ms-asf'
          * - 'video/x-ms-wmv'
          * - 'video/x-msvideo'
          * - 'video/x-rad-screenplay'
          * - 'video/x-sgi-movie'
          * - 'video/x-matroska'
          * - 'audio/mpeg'
          * - 'audio/ogg'
          * - 'audio/wav'
          * - 'audio/basic'
          * - 'audio/mp3'
          * - 'audio/mp4'
          * - 'audio/vnd.adobe.soundbooth'
          * - 'audio/vorbis'
          * - 'audio/x-aiff'
          * - 'audio/x-flac'
          * - 'audio/x-ms-wma'
          * - 'audio/x-wav'
          * - 'x-world/x-vrml'
          * - 'text/plain'
          * - 'application/vnd.oasis.opendocument.text'
          * - 'application/vnd.oasis.opendocument.text-template'
          * - 'application/x-javascript'
          * - 'application/json'
          * - 'text/csv'
          * - 'text/xml'
          * - 'text/html'
          * - 'text/css'
          * - 'application/x-compressed'
          * - 'application/x-zip-compressed'
          * - 'application/zip'
          * - 'application/x-tar'
          * - 'application/vnd.apple.keynote'
          * - 'application/vnd.apple.pages'
          * - 'application/vnd.apple.numbers'
          * - 'application/vnd.visio'
          * - 'application/wordperfect'
          * - 'application/x-cpio'
          * - 'multipart/related'
          *
          * </details>
          *
          *
          */
        this.mimeType = DefaultIcon.UNKNOWN;
        this.satoriNamespace = 'satori';
        this.folderIcon = DefaultIcon.FOLDER;
        const registry = inject(MatIconRegistry);
        const sanitizer = inject(DomSanitizer);
        const folderSvg = SATORI_ICONS.match(/<svg[^>]*id="folder"[\s\S]*?<\/svg>/)?.[0] ?? '';
        registry.addSvgIconLiteralInNamespace(this.satoriNamespace, this.folderIcon, sanitizer.bypassSecurityTrustHtml(folderSvg));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: MimeTypeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: MimeTypeIconComponent, isStandalone: true, selector: "hxp-mime-type-icon", inputs: { mimeType: "mimeType" }, ngImport: i0, template: "<mat-icon\n    class=\"hxp-mime-type-icon\"\n    [svgIcon]=\"svgIcon\"\n/>\n", styles: ["img{all:inherit}.hxp-mime-type-icon{display:flex;justify-content:center}\n"], dependencies: [{ kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: MimeTypeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-mime-type-icon', imports: [MatIcon], template: "<mat-icon\n    class=\"hxp-mime-type-icon\"\n    [svgIcon]=\"svgIcon\"\n/>\n", styles: ["img{all:inherit}.hxp-mime-type-icon{display:flex;justify-content:center}\n"] }]
        }], ctorParameters: () => [], propDecorators: { mimeType: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a folder icon.
 *
 * To use the `FolderIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { FolderIconComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         FolderIconComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-folder-icon [isExpanded]="false"></hxp-folder-icon>
 */
class FolderIconComponent {
    constructor() {
        /**
         * Indicates whether the folder is expanded.
         * @type {boolean}
         */
        this.isExpanded = false;
        this.folderIcon = DefaultIcon.FOLDER;
        this.openFolderIcon = DefaultIcon.OPEN_FOLDER;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FolderIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: FolderIconComponent, isStandalone: true, selector: "hxp-folder-icon", inputs: { isExpanded: "isExpanded" }, ngImport: i0, template: "<hxp-mime-type-icon [mimeType]=\"isExpanded ? openFolderIcon : folderIcon\" />\n", dependencies: [{ kind: "component", type: MimeTypeIconComponent, selector: "hxp-mime-type-icon", inputs: ["mimeType"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FolderIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-folder-icon', imports: [MimeTypeIconComponent], template: "<hxp-mime-type-icon [mimeType]=\"isExpanded ? openFolderIcon : folderIcon\" />\n" }]
        }], propDecorators: { isExpanded: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const SearchIconAssets = {
    SEARCH: 'assets/search-icons/Search.svg',
    CLEAR: 'assets/search-icons/Clear.svg',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a search action icon.
 *
 * To use the `SearchActionIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { SearchActionIconComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         SearchActionIconComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *  <hxp-search-action-icon></hxp-search-action-icon>
 *
 */
class SearchActionIconComponent {
    constructor() {
        /**
         * A custom text for HTML <img> alt attribute.
         * @type {string}
         *
         */
        this.actionAlt = '';
        this.alt = '';
        this.translateService = inject(TranslateService);
        this.matIconRegistry = inject(MatIconRegistry);
        this.domSanitizer = inject(DomSanitizer);
        this.actionIcon = 'SEARCH';
        this.iconAssetPath = SearchIconAssets[this.actionIcon];
        const icons = {
            search_calendar: 'assets/search-icons/Calendar_search.svg',
            search_clear: 'assets/search-icons/Clear.svg',
            search_glass: 'assets/search-icons/Search.svg',
            search_arrow_left: 'assets/search-icons/Arrow_left.svg',
            repository_search: 'assets/search-icons/Repository_search.svg',
        };
        for (const [iconName, iconPath] of Object.entries(icons)) {
            this.matIconRegistry.addSvgIcon(iconName, this.domSanitizer.bypassSecurityTrustResourceUrl(iconPath));
        }
    }
    ngOnChanges() {
        this.iconAssetPath = SearchIconAssets[this.actionIcon];
        this.alt =
            this.actionAlt ||
                (this.actionIcon === 'SEARCH'
                    ? this.translateService.instant('SEARCH.ICON.SEARCH')
                    : this.translateService.instant('SEARCH.ICON.CLEAR_INPUT'));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchActionIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: SearchActionIconComponent, isStandalone: true, selector: "hxp-search-action-icon", inputs: { actionIcon: "actionIcon", actionAlt: "actionAlt" }, usesOnChanges: true, ngImport: i0, template: "<img\n    [src]=\"iconAssetPath\"\n    [alt]=\"alt\"\n/>\n", styles: ["img{display:block}\n"] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchActionIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-action-icon', template: "<img\n    [src]=\"iconAssetPath\"\n    [alt]=\"alt\"\n/>\n", styles: ["img{display:block}\n"] }]
        }], ctorParameters: () => [], propDecorators: { actionIcon: [{
                type: Input
            }], actionAlt: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
// standalone components

/**
 * Generated bundle index. Do not edit.
 */

export { DefaultIcon, FolderIconComponent, MimeTypeIconComponent, SearchActionIconComponent, SearchIconAssets };
//# sourceMappingURL=alfresco-adf-hx-content-services-icons.mjs.map
