import * as i0 from '@angular/core';
import { Input, Component, inject, Injectable, Pipe, DestroyRef, ChangeDetectorRef, EventEmitter, ViewChild, ContentChild, Output, ViewEncapsulation, ChangeDetectionStrategy, HostListener, Attribute, input, output, viewChildren, signal, computed, effect, viewChild, afterNextRender, NgZone, ElementRef, Directive, EnvironmentInjector, runInInjectionContext, afterRenderEffect, Renderer2, ViewContainerRef } from '@angular/core';
import { from, of, BehaviorSubject, filter as filter$1, take, switchMap as switchMap$1, EMPTY, map as map$1, Subject, fromEvent, combineLatest, iif, defer, merge, finalize as finalize$1 } from 'rxjs';
import { filter, finalize, switchMap, catchError, mergeMap, map, toArray, debounceTime, shareReplay, take as take$1, takeUntil } from 'rxjs/operators';
import { DocumentActionService, FileDownloadService, IsSingleDocumentWithMainBlobService, hasPermission, DocumentPermissions, DocumentService, isRoot, ContextMenuActionsService, DocumentTreeDatabaseService, DEFAULT_ITEMS_PER_PAGE, isFolder, HXP_DOCUMENT_INFO_ACTION_SERVICE, HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE, HxpNotificationService, DocumentRouterService, RouterExtService, getRetentionStatus, BLOCK_DELETE_STATUSES, isVersion, ContentShareService, PermissionsPanelRequestService, getHighestPermission, IsSuggestedPermissionEntityValidator, PermissionsManagementFacade, PermissionsManagementStateService, UserType, SidebarService, PERMISSIONS_MANAGEMENT_COMPONENT_TYPE, DocumentVersionsService, ColumnConfigService, IDENTITY_USER_SERVICE_TOKEN, HXP_DOCUMENT_PERMISSIONS_ACTION_SERVICE, HXP_DOCUMENT_DELETE_ACTION_SERVICE, HXP_DOCUMENT_SHARE_ACTION_SERVICE, HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE, HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE, HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE, HXP_MANAGE_COLUMN_ACTION_SERVICE, DocumentCacheService, isPermissionError, hasBlob, DOCUMENT_SERVICE, DOCUMENT_PROPERTIES_SERVICE, BLOCK_EDIT_STATUSES, BlobDownloadService, RenditionsService, hasRenditionBlob, RenditionStatus, DEFAULT_RENDITION_ID, pollWhile, UserResolverPipe, SearchFilterValueService, DocumentModelService, SearchType } from '@alfresco/adf-hx-content-services/services';
import { TranslatePipe, TranslateService } from '@ngx-translate/core';
import { ROOT_DOCUMENT, FieldType } from '@alfresco/adf-hx-content-services/api';
import * as i4 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import { SelectionModel } from '@angular/cdk/collections';
import * as i3 from '@angular/material/icon';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import * as i3$1 from '@angular/material/progress-spinner';
import { MatProgressSpinnerModule, MatProgressSpinner } from '@angular/material/progress-spinner';
import * as i2 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i6 from '@angular/material/tree';
import { MatTreeModule, MatTreeFlattener, MatTreeFlatDataSource } from '@angular/material/tree';
import { FolderIconComponent, DefaultIcon, MimeTypeIconComponent } from '@alfresco/adf-hx-content-services/icons';
import * as i1$4 from '@angular/common';
import { NgFor, NgIf, NgTemplateOutlet, KeyValuePipe, CommonModule, AsyncPipe, DatePipe, DOCUMENT, NgSwitch, NgSwitchCase } from '@angular/common';
import * as i1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { takeUntilDestroyed, toSignal } from '@angular/core/rxjs-interop';
import { TranslationService, ContextMenuOverlayService, DataColumnListComponent, NoContentTemplateDirective, EmptyContentComponent, DataTableComponent, LoadingContentTemplateDirective, provideTranslations, CardViewUpdateService, CardViewComponent, InfoDrawerLayoutComponent, InfoDrawerContentDirective, ViewUtilService, ViewerComponent, ViewerToolbarComponent, ViewerSidebarComponent, CustomEmptyContentTemplateDirective } from '@alfresco/adf-core';
import * as i1$1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule, MatDialog } from '@angular/material/dialog';
import * as i3$2 from '@angular/forms';
import { FormControlName, FormBuilder, Validators, ReactiveFormsModule, FormsModule, FormGroup, FormControl } from '@angular/forms';
import { Clipboard } from '@angular/cdk/clipboard';
import * as i2$2 from '@angular/material/tooltip';
import { MatTooltipModule, MatTooltip } from '@angular/material/tooltip';
import * as i4$1 from '@angular/material/form-field';
import { MatFormFieldModule } from '@angular/material/form-field';
import * as i5 from '@angular/material/input';
import { MatInputModule } from '@angular/material/input';
import * as i3$5 from '@angular/material/radio';
import { MatRadioModule } from '@angular/material/radio';
import * as i3$4 from '@angular/material/tabs';
import { MatTabsModule } from '@angular/material/tabs';
import * as i1$2 from '@angular/material/table';
import { MatTableModule } from '@angular/material/table';
import * as i3$3 from '@angular/material/autocomplete';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatOptionModule, ShowOnDirtyErrorStateMatcher } from '@angular/material/core';
import * as i2$1 from '@angular/material/select';
import { MatSelectModule } from '@angular/material/select';
import { SatIconModule } from '@hylandsoftware/satori-ui';
import * as i1$3 from '@angular/material/slide-toggle';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import * as i8 from '@angular/cdk/drag-drop';
import { moveItemInArray, DragDropModule } from '@angular/cdk/drag-drop';
import * as i6$1 from '@angular/cdk/text-field';
import { FeaturesServiceToken } from '@alfresco/adf-core/feature-flags';
import { ADF_HX_CONTENT_SERVICES_INTERNAL } from '@alfresco/adf-hx-content-services/features';
import * as i1$5 from '@angular/material/expansion';
import { MatExpansionModule, MatExpansionPanel } from '@angular/material/expansion';
import * as i4$2 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import { BreadcrumbComponent, BreadcrumbItemComponent } from '@alfresco/adf-core/breadcrumbs';
import { RouterLink } from '@angular/router';
import { OverlayContainer, Overlay, OverlayConfig, OverlayModule } from '@angular/cdk/overlay';
import { DynamicExtensionComponent } from '@alfresco/adf-extensions';
import { DomSanitizer } from '@angular/platform-browser';
import * as i5$1 from '@angular/material/datepicker';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { startOfDay, formatISO, startOfToday, sub, isBefore, isAfter, parse, isValid } from 'date-fns';
import * as i9 from '@angular/material/list';
import { MatListModule, MatSelectionList } from '@angular/material/list';
import { TemplatePortal, PortalModule } from '@angular/cdk/portal';
import * as i2$3 from '@angular/material/chips';
import { MatChipsModule } from '@angular/material/chips';
import { FlatTreeControl } from '@angular/cdk/tree';
import { ComponentHarness } from '@angular/cdk/testing';
import { MatButtonHarness } from '@angular/material/button/testing';
import { MatIconHarness } from '@angular/material/icon/testing';

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a skeleton to display during content loading.
 *
 * To use the `TreeSkeletonLoaderComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { TreeSkeletonLoaderComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         TreeSkeletonLoaderComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-tree-skeleton-loader></hxp-tree-skeleton-loader>
 */
class TreeSkeletonLoaderComponent {
    constructor() {
        /**
         * Indicates the number of rows to display in the skeleton tree.
         * @type {number}
         * @default 10
         */
        this.skeletonRows = TreeSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    /**
     * Default value of skeleton tree rows to display.
     * @readonly
     * @type {number}
     */
    static { this.DEFAULT_SKELETON_ROWS = 10; }
    ngOnChanges() {
        if (!this.skeletonRows && this.skeletonRows !== 0) {
            this.skeletonRows = TreeSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        }
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    skeletonRowTrackBy(index) {
        return index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: TreeSkeletonLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: TreeSkeletonLoaderComponent, isStandalone: true, selector: "hxp-tree-skeleton-loader", inputs: { skeletonRows: "skeletonRows" }, usesOnChanges: true, ngImport: i0, template: "<table class=\"hxp-skeleton-table\">\n    <tbody>\n        <tr *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n            <td class=\"hxp-skeleton-icon-cell\">\n                <div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div>\n            </td>\n            <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n        </tr>\n    </tbody>\n</table>\n", styles: [".hxp-skeleton-table{width:100%;border-collapse:collapse;table-layout:fixed}tbody td{padding:5px 15px;text-align:left}.hxp-skeleton-box{background-color:var(--mat-sys-surface-container-highest);border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-icon{width:30px;height:30px}.hxp-skeleton-text-100{width:100%;height:30px}.hxp-skeleton-icon-cell{width:2%;padding:8px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"], dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: TreeSkeletonLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-tree-skeleton-loader', imports: [NgFor], template: "<table class=\"hxp-skeleton-table\">\n    <tbody>\n        <tr *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n            <td class=\"hxp-skeleton-icon-cell\">\n                <div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div>\n            </td>\n            <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n        </tr>\n    </tbody>\n</table>\n", styles: [".hxp-skeleton-table{width:100%;border-collapse:collapse;table-layout:fixed}tbody td{padding:5px 15px;text-align:left}.hxp-skeleton-box{background-color:var(--mat-sys-surface-container-highest);border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-icon{width:30px;height:30px}.hxp-skeleton-text-100{width:100%;height:30px}.hxp-skeleton-icon-cell{width:2%;padding:8px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"] }]
        }], propDecorators: { skeletonRows: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SingleItemDownloadButtonActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.fileDownloadService = inject(FileDownloadService);
        this.isSingleDocumentWithMainBlobService = inject(IsSingleDocumentWithMainBlobService);
    }
    isAvailable(context) {
        return (context?.documents &&
            this.isSingleDocumentWithMainBlobService.validate(context.documents) &&
            hasPermission(context.documents?.[0], DocumentPermissions.READ));
    }
    execute(context) {
        if (context?.documents[0]) {
            this.fileDownloadService.downloadFile(context?.documents);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemDownloadButtonActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemDownloadButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemDownloadButtonActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CacheLabelService {
    constructor() {
        this.cache = new Map();
        this.translationService = inject(TranslationService);
        this.documentService = inject(DocumentService);
        // Automatically update cache when documents are updated
        this.documentService.documentUpdated$
            .pipe(filter(({ document }) => !!document?.sys_id))
            .subscribe(({ document }) => {
            if (document) {
                this.updateCacheOnDocumentUpdate(document);
            }
        });
    }
    getCache() {
        return this.cache;
    }
    getTranslation(doc, rootTranslationKey) {
        const key = doc.sys_id ?? this.generateUniqueKey(doc);
        if (this.cache.has(key)) {
            return this.cache.get(key);
        }
        const translatedValue = this.getLabel(doc, rootTranslationKey);
        this.cache.set(key, translatedValue);
        return translatedValue;
    }
    updateCacheOnDocumentUpdate(document, rootTranslationKey = 'DOCUMENT_BREADCRUMB.ROOT') {
        if (!document.sys_id) {
            return; // Skip documents without sys_id as they cannot be reliably cached
        }
        const updatedLabel = this.getLabel(document, rootTranslationKey);
        this.cache.set(document.sys_id, updatedLabel);
    }
    getLabel(doc, rootTranslationKey) {
        return isRoot(doc) ? this.translationService.instant(rootTranslationKey) : doc.sys_title || doc.sys_name || '';
    }
    generateUniqueKey(doc) {
        const sortedEntries = Object.entries(doc).sort(([keyA], [keyB]) => keyA.localeCompare(keyB));
        const keyString = sortedEntries
            .map(([key, value]) => {
            return `${key}=${value ?? ''}`;
        })
            .join('|');
        return keyString;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CacheLabelService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CacheLabelService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CacheLabelService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class BreadcrumbLabelPipe {
    constructor() {
        this.cacheLabelService = inject(CacheLabelService);
    }
    transform(doc, translationKey) {
        if (!doc) {
            return '';
        }
        return this.cacheLabelService.getTranslation(doc, translationKey);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: BreadcrumbLabelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.20", ngImport: i0, type: BreadcrumbLabelPipe, isStandalone: true, name: "breadcrumbLabel" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: BreadcrumbLabelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'breadcrumbLabel',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component that displays a tree of documents.
 *
 * To use the `HxpDocumentTreeComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpDocumentTreeComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *    imports: [
 *       HxpDocumentTreeComponent,
 *      ...
 *   ],
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-document-tree></hxp-document-tree>
 *
 */
class HxpDocumentTreeComponent {
    constructor() {
        this.destroyRef = inject(DestroyRef);
        this.documentService = inject(DocumentService);
        this.contextMenuActionsService = inject(ContextMenuActionsService);
        this.changeDetectorRef = inject(ChangeDetectorRef);
        this.dataSource = inject(DocumentTreeDatabaseService);
        /**
         * The root document of the tree.
         */
        this.rootDocument = ROOT_DOCUMENT;
        /**
         * The list of selected documents in the tree.
         */
        this.documents = [];
        /**
         * If true, the tree allows multiple document selection.
         */
        this.multiSelection = false;
        /**
         * Emits the document that has been selected or unselected.
         */
        this.selectedDocument = new EventEmitter();
        this.contextActionMenuTemplateRef = null;
        this.DEFAULT_ITEMS_PER_PAGE = DEFAULT_ITEMS_PER_PAGE;
        this.selection = new SelectionModel(true, [], true, (doc1, doc2) => doc1?.sys_id === doc2?.sys_id);
        this.treeControl = this.dataSource.treeControl;
        this.contextMenuPosition = { x: '0px', y: '0px' };
        this.contextActions = [];
        this.isInitialTreeLoad = false;
        this.contextMenuOpenedDocument = null;
        this.hasChild = (_, _nodeData) => _nodeData.isExpandable;
    }
    ngOnInit() {
        this.loadInitialData();
        this.destroyRef.onDestroy(() => {
            this.dataSource.disconnect();
        });
    }
    ngOnChanges(changes) {
        if (changes['documents'] && this.documents) {
            this.selection.clear();
            for (const doc of this.documents) {
                this.selection.toggle(doc);
            }
            this.loadSelectedDocumentsAncestors(this.documents);
        }
    }
    ngAfterContentChecked() {
        this.changeDetectorRef.detectChanges();
    }
    onContextMenu(event, document) {
        if (this.multiSelection || !this.contextActionMenuTemplateRef) {
            return;
        }
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuPosition.x = event.clientX + 'px';
        this.contextMenuPosition.y = event.clientY + 'px';
        const targetHtmlElement = event.target;
        if (targetHtmlElement.tagName !== 'BUTTON' && targetHtmlElement.tagName !== 'MAT-ICON') {
            const node = targetHtmlElement.closest('mat-tree-node');
            const trigger = node?.querySelector('.hxp-menu-trigger');
            this.contextActions = this.getContextActions(document);
            if (this.contextActions.some((action) => action.model?.visible)) {
                this.contextMenuOpenedDocument = document;
                trigger?.dispatchEvent(new MouseEvent('click'));
            }
        }
    }
    openContextMenu(_, document) {
        if (this.contextActionMenuTemplateRef && !this.multiSelection) {
            this.contextActions = this.getContextActions(document);
            this.contextMenuOpenedDocument = document;
        }
    }
    onContextMenuClosed() {
        this.contextMenuOpenedDocument = null;
    }
    hasVisibleActions(document) {
        const contextActions = this.getContextActions(document);
        return contextActions.some((action) => action.model?.visible);
    }
    onDocumentSelected(document, e) {
        if (this.multiSelection && isRoot(document)) {
            return;
        }
        // To prevent selecting the same document multiple times
        if (!this.multiSelection && this.documents?.length === 1 && this.documents[0]?.sys_id === document.sys_id) {
            return;
        }
        if (!this.multiSelection) {
            this.selection.clear();
        }
        this.selection.toggle(document);
        this.documents = [...this.selection.selected];
        this.selectedDocument.emit(document);
        if (e?.target) {
            this.scrollTreeNodeIntoView(e);
        }
    }
    isDocumentExpandable(document) {
        return isRoot(document) || isFolder(document);
    }
    onNodeExpand(event) {
        this.scrollTreeNodeIntoView(event);
        event.preventDefault();
        event.stopPropagation();
    }
    loadInitialData() {
        this.isInitialTreeLoad = true;
        this.dataSource
            .dataChanges()
            .pipe(takeUntilDestroyed(this.destroyRef), finalize(() => {
            this.isInitialTreeLoad = false;
        }))
            .subscribe({
            next: () => {
                if (this.dataSource.treeControl.dataNodes?.length > 0) {
                    this.isInitialTreeLoad = false;
                    this.changeDetectorRef.detectChanges();
                }
            },
            error: (err) => {
                console.error(err);
            },
        });
        this.dataSource.setDocumentTreeRoot(this.rootDocument);
        this.dataSource.openNodeAtIndex(0);
    }
    getContextActions(document) {
        return this.contextMenuActionsService.getContextActions(document, this.documents[0]);
    }
    openNodes(documents) {
        if (!this.multiSelection && Array.isArray(documents) && documents.length > 0) {
            this.dataSource.openNodes(documents);
        }
    }
    scrollTreeNodeIntoView(e) {
        const el = e.target;
        const treeNode = el.closest('mat-tree-node');
        if (treeNode) {
            treeNode.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'end' });
        }
    }
    loadSelectedDocumentsAncestors(documents = []) {
        if (documents.length === 0) {
            return;
        }
        from(documents)
            .pipe(filter((doc) => !!doc), switchMap((doc) => this.documentService.getAncestors(doc?.sys_id || '').pipe(catchError(() => of([{ ...ROOT_DOCUMENT }])))))
            .subscribe({
            next: (docs) => this.openNodes(docs),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpDocumentTreeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: HxpDocumentTreeComponent, isStandalone: true, selector: "hxp-document-tree", inputs: { rootDocument: "rootDocument", documents: "documents", multiSelection: "multiSelection" }, outputs: { selectedDocument: "selectedDocument" }, providers: [
            /*  We're hiding info action since it's based on a selection mechanism that's
            non-existing in the document tree
            */
            {
                provide: HXP_DOCUMENT_INFO_ACTION_SERVICE,
                useValue: {
                    isAvailable: () => false,
                    execute: () => { },
                },
            },
            {
                provide: HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE,
                useClass: SingleItemDownloadButtonActionService,
            },
            ContextMenuActionsService,
            DocumentTreeDatabaseService,
        ], queries: [{ propertyName: "contextActionMenuTemplateRef", first: true, predicate: ["contextActionMenu"], descendants: true }], viewQueries: [{ propertyName: "menuTrigger", first: true, predicate: ["trigger"], descendants: true }, { propertyName: "hiddenTrigger", first: true, predicate: ["hiddenTrigger"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\n    class=\"hxp-tree-container\"\n    #treeContainer\n>\n    <mat-tree\n        [dataSource]=\"dataSource\"\n        [treeControl]=\"treeControl\"\n        class=\"hxp-document-tree hxp-fill\"\n        *ngIf=\"!isInitialTreeLoad\"\n    >\n        <mat-tree-node\n            *matTreeNodeDef=\"let node\"\n            matTreeNodePadding\n            class=\"hxp-document-tree-node\"\n            [class.hxp-selected]=\"!multiSelection && !node.isSkeleton && selection.isSelected(node.document)\"\n            (click)=\"!node.isSkeleton && onDocumentSelected(node.document, $event)\"\n        >\n            <ng-container *ngIf=\"!node.isSkeleton; else skeletonTemplate\">\n                <ng-container *ngIf=\"node.isLoading; else showFolderIcon\">\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"30\"\n                    />\n                </ng-container>\n\n                <ng-template #showFolderIcon>\n                    <hxp-folder-icon\n                        *ngIf=\"isDocumentExpandable(node.document)\"\n                        [isExpanded]=\"treeControl.isExpanded(node)\"\n                    />\n                </ng-template>\n                <span\n                    (click)=\"onDocumentSelected(node.document, $event)\"\n                    class=\"hxp-node-label\"\n                    [class.hxp-has-contextmenu]=\"contextActionMenuTemplateRef\"\n                >\n                    {{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\n                </span>\n            </ng-container>\n\n            <ng-template #skeletonTemplate>\n                <hxp-tree-skeleton-loader [skeletonRows]=\"1\" />\n            </ng-template>\n        </mat-tree-node>\n\n        <mat-tree-node\n            *matTreeNodeDef=\"let node; when: hasChild\"\n            matTreeNodePadding\n            class=\"hxp-document-tree-node\"\n            [class.hxp-selected]=\"!multiSelection && selection.isSelected(node.document)\"\n            [class.hxp-node-context-opened]=\"contextMenuOpenedDocument?.sys_id === node.document?.sys_id\"\n        >\n            <button\n                mat-icon-button\n                data-automation-id=\"document-tree-toggle-button\"\n                [attr.aria-label]=\"('DOCUMENT_TREE.TOGGLE_ARIA-LABEL ' | translate) + node.name\"\n                [attr.aria-expanded]=\"treeControl.isExpanded(node)\"\n                matTreeNodeToggle\n                (click)=\"onNodeExpand($event)\"\n            >\n                <mat-icon\n                    class=\"mat-icon-rtl-mirror\"\n                    [svgIcon]=\"treeControl.isExpanded(node) ? 'chevron_down' : 'chevron_right'\"\n                />\n            </button>\n\n            <mat-checkbox\n                *ngIf=\"multiSelection && node.isSelectable\"\n                class=\"hxp-node-selection-checkbox\"\n                (change)=\"onDocumentSelected(node.document)\"\n                [checked]=\"selection.isSelected(node.document)\"\n            />\n\n            <ng-container>\n                <div\n                    class=\"hxp-node-container\"\n                    (click)=\"onDocumentSelected(node.document, $event)\"\n                    (contextmenu)=\"onContextMenu($event, node.document)\"\n                >\n                    <ng-container *ngIf=\"node.isLoading; else showFolderIcon\">\n                        <mat-progress-spinner\n                            mode=\"indeterminate\"\n                            diameter=\"30\"\n                        />\n                    </ng-container>\n\n                    <ng-template #showFolderIcon>\n                        <hxp-folder-icon\n                            *ngIf=\"isDocumentExpandable(node.document)\"\n                            [isExpanded]=\"treeControl.isExpanded(node)\"\n                        />\n                    </ng-template>\n\n                    <span\n                        class=\"hxp-node-label\"\n                        [class.hxp-has-contextmenu]=\"contextActionMenuTemplateRef\"\n                        title=\"{{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\"\n                    >\n                        {{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\n                    </span>\n                </div>\n\n                <div\n                    class=\"hxp-context-btn\"\n                    *ngIf=\"!multiSelection && contextActionMenuTemplateRef\"\n                >\n                    <button\n                        mat-icon-button\n                        data-automation-id=\"document-tree-context-menu-button\"\n                        #trigger=\"matMenuTrigger\"\n                        role=\"button\"\n                        *ngIf=\"hasVisibleActions(node.document)\"\n                        [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                        [matMenuTriggerFor]=\"contextMenu\"\n                        [matMenuTriggerData]=\"{ actions: contextActions }\"\n                        [class.hxp-menu-opened]=\"trigger.menuOpen || hiddenTrigger.menuOpen\"\n                        (click)=\"openContextMenu($event, node.document)\"\n                    >\n                        <mat-icon\n                            aria-hidden=\"true\"\n                            svgIcon=\"more_vert\"\n                        />\n                    </button>\n                </div>\n\n                <div\n                    #hiddenTrigger=\"matMenuTrigger\"\n                    class=\"hxp-menu-trigger\"\n                    [style.left]=\"contextMenuPosition.x\"\n                    [style.top]=\"contextMenuPosition.y\"\n                    [matMenuTriggerFor]=\"contextMenu\"\n                    [matMenuTriggerData]=\"{ actions: contextActions }\"\n                ></div>\n            </ng-container>\n        </mat-tree-node>\n    </mat-tree>\n\n    <hxp-tree-skeleton-loader\n        *ngIf=\"isInitialTreeLoad\"\n        [skeletonRows]=\"DEFAULT_ITEMS_PER_PAGE\"\n    />\n</div>\n<mat-menu\n    #contextMenu=\"matMenu\"\n    class=\"hxp-context-menu\"\n    (closed)=\"onContextMenuClosed()\"\n>\n    <ng-container *ngTemplateOutlet=\"contextActionMenuTemplateRef; context: { $implicit: contextActions }\" />\n</mat-menu>\n", styles: [".hxp-context-btn{flex-shrink:0;width:0;overflow:hidden}.hxp-context-btn button{opacity:0}.hxp-context-btn button.hxp-menu-opened{opacity:1}.hxp-document-tree{overflow-y:auto;overflow-x:auto;width:100%;height:100%;display:flex;flex-direction:column}.hxp-document-tree-node{border-radius:var(--mat-sys-corner-medium);min-height:48px;text-wrap:wrap;width:calc(100% - 40px)}.hxp-document-tree-node[aria-level=\"1\"]{width:100%}.hxp-document-tree-node:not([aria-level=\"1\"]){padding-right:12px}.hxp-document-tree-node.hxp-node-context-opened{background-color:var(--mat-sys-surface-container);opacity:.9}.hxp-document-tree-node.hxp-node-context-opened .hxp-context-btn{width:auto}.hxp-document-tree-node button{display:flex;align-items:center}.hxp-document-tree-node:hover{background-color:var(--mat-sys-surface-container);opacity:.9;cursor:pointer}.hxp-document-tree-node:hover .hxp-context-btn{width:auto}.hxp-document-tree-node:hover .hxp-context-btn button{opacity:1}.hxp-document-tree-node>button{transform:scale(.9);flex-shrink:0}.hxp-selected{background-color:var(--mat-sys-secondary-container)}.hxp-node-label{flex:1;min-width:0;margin-left:10px;overflow:hidden;text-overflow:ellipsis;word-wrap:normal;white-space:nowrap}.hxp-node-container{display:flex;flex:1;align-items:center;min-width:0;overflow:hidden}.hxp-menu-trigger{visibility:hidden;position:fixed}.hxp-fill{height:100%;min-height:100%;min-width:100%;width:100%}.hxp-node-selection-checkbox{margin:0 24px 0 12px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: FolderIconComponent, selector: "hxp-folder-icon", inputs: ["isExpanded"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i4.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i4.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i3$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "ngmodule", type: MatTreeModule }, { kind: "directive", type: i6.MatTreeNodeDef, selector: "[matTreeNodeDef]", inputs: ["matTreeNodeDefWhen", "matTreeNode"] }, { kind: "directive", type: i6.MatTreeNodePadding, selector: "[matTreeNodePadding]", inputs: ["matTreeNodePadding", "matTreeNodePaddingIndent"] }, { kind: "directive", type: i6.MatTreeNodeToggle, selector: "[matTreeNodeToggle]", inputs: ["matTreeNodeToggleRecursive"] }, { kind: "component", type: i6.MatTree, selector: "mat-tree", exportAs: ["matTree"] }, { kind: "directive", type: i6.MatTreeNode, selector: "mat-tree-node", inputs: ["tabIndex", "disabled"], outputs: ["activation", "expandedChange"], exportAs: ["matTreeNode"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "ngmodule", type: MatSnackBarModule }, { kind: "component", type: TreeSkeletonLoaderComponent, selector: "hxp-tree-skeleton-loader", inputs: ["skeletonRows"] }, { kind: "pipe", type: BreadcrumbLabelPipe, name: "breadcrumbLabel" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpDocumentTreeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-tree', providers: [
                        /*  We're hiding info action since it's based on a selection mechanism that's
                        non-existing in the document tree
                        */
                        {
                            provide: HXP_DOCUMENT_INFO_ACTION_SERVICE,
                            useValue: {
                                isAvailable: () => false,
                                execute: () => { },
                            },
                        },
                        {
                            provide: HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE,
                            useClass: SingleItemDownloadButtonActionService,
                        },
                        ContextMenuActionsService,
                        DocumentTreeDatabaseService,
                    ], imports: [
                        NgIf,
                        NgTemplateOutlet,
                        FolderIconComponent,
                        MatButtonModule,
                        MatCheckboxModule,
                        MatIconModule,
                        MatMenuModule,
                        MatProgressSpinnerModule,
                        MatTreeModule,
                        TranslatePipe,
                        MatSnackBarModule,
                        TreeSkeletonLoaderComponent,
                        BreadcrumbLabelPipe,
                    ], template: "<div\n    class=\"hxp-tree-container\"\n    #treeContainer\n>\n    <mat-tree\n        [dataSource]=\"dataSource\"\n        [treeControl]=\"treeControl\"\n        class=\"hxp-document-tree hxp-fill\"\n        *ngIf=\"!isInitialTreeLoad\"\n    >\n        <mat-tree-node\n            *matTreeNodeDef=\"let node\"\n            matTreeNodePadding\n            class=\"hxp-document-tree-node\"\n            [class.hxp-selected]=\"!multiSelection && !node.isSkeleton && selection.isSelected(node.document)\"\n            (click)=\"!node.isSkeleton && onDocumentSelected(node.document, $event)\"\n        >\n            <ng-container *ngIf=\"!node.isSkeleton; else skeletonTemplate\">\n                <ng-container *ngIf=\"node.isLoading; else showFolderIcon\">\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"30\"\n                    />\n                </ng-container>\n\n                <ng-template #showFolderIcon>\n                    <hxp-folder-icon\n                        *ngIf=\"isDocumentExpandable(node.document)\"\n                        [isExpanded]=\"treeControl.isExpanded(node)\"\n                    />\n                </ng-template>\n                <span\n                    (click)=\"onDocumentSelected(node.document, $event)\"\n                    class=\"hxp-node-label\"\n                    [class.hxp-has-contextmenu]=\"contextActionMenuTemplateRef\"\n                >\n                    {{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\n                </span>\n            </ng-container>\n\n            <ng-template #skeletonTemplate>\n                <hxp-tree-skeleton-loader [skeletonRows]=\"1\" />\n            </ng-template>\n        </mat-tree-node>\n\n        <mat-tree-node\n            *matTreeNodeDef=\"let node; when: hasChild\"\n            matTreeNodePadding\n            class=\"hxp-document-tree-node\"\n            [class.hxp-selected]=\"!multiSelection && selection.isSelected(node.document)\"\n            [class.hxp-node-context-opened]=\"contextMenuOpenedDocument?.sys_id === node.document?.sys_id\"\n        >\n            <button\n                mat-icon-button\n                data-automation-id=\"document-tree-toggle-button\"\n                [attr.aria-label]=\"('DOCUMENT_TREE.TOGGLE_ARIA-LABEL ' | translate) + node.name\"\n                [attr.aria-expanded]=\"treeControl.isExpanded(node)\"\n                matTreeNodeToggle\n                (click)=\"onNodeExpand($event)\"\n            >\n                <mat-icon\n                    class=\"mat-icon-rtl-mirror\"\n                    [svgIcon]=\"treeControl.isExpanded(node) ? 'chevron_down' : 'chevron_right'\"\n                />\n            </button>\n\n            <mat-checkbox\n                *ngIf=\"multiSelection && node.isSelectable\"\n                class=\"hxp-node-selection-checkbox\"\n                (change)=\"onDocumentSelected(node.document)\"\n                [checked]=\"selection.isSelected(node.document)\"\n            />\n\n            <ng-container>\n                <div\n                    class=\"hxp-node-container\"\n                    (click)=\"onDocumentSelected(node.document, $event)\"\n                    (contextmenu)=\"onContextMenu($event, node.document)\"\n                >\n                    <ng-container *ngIf=\"node.isLoading; else showFolderIcon\">\n                        <mat-progress-spinner\n                            mode=\"indeterminate\"\n                            diameter=\"30\"\n                        />\n                    </ng-container>\n\n                    <ng-template #showFolderIcon>\n                        <hxp-folder-icon\n                            *ngIf=\"isDocumentExpandable(node.document)\"\n                            [isExpanded]=\"treeControl.isExpanded(node)\"\n                        />\n                    </ng-template>\n\n                    <span\n                        class=\"hxp-node-label\"\n                        [class.hxp-has-contextmenu]=\"contextActionMenuTemplateRef\"\n                        title=\"{{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\"\n                    >\n                        {{ node.document | breadcrumbLabel: 'DOCUMENT_TREE.ROOT' }}\n                    </span>\n                </div>\n\n                <div\n                    class=\"hxp-context-btn\"\n                    *ngIf=\"!multiSelection && contextActionMenuTemplateRef\"\n                >\n                    <button\n                        mat-icon-button\n                        data-automation-id=\"document-tree-context-menu-button\"\n                        #trigger=\"matMenuTrigger\"\n                        role=\"button\"\n                        *ngIf=\"hasVisibleActions(node.document)\"\n                        [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                        [matMenuTriggerFor]=\"contextMenu\"\n                        [matMenuTriggerData]=\"{ actions: contextActions }\"\n                        [class.hxp-menu-opened]=\"trigger.menuOpen || hiddenTrigger.menuOpen\"\n                        (click)=\"openContextMenu($event, node.document)\"\n                    >\n                        <mat-icon\n                            aria-hidden=\"true\"\n                            svgIcon=\"more_vert\"\n                        />\n                    </button>\n                </div>\n\n                <div\n                    #hiddenTrigger=\"matMenuTrigger\"\n                    class=\"hxp-menu-trigger\"\n                    [style.left]=\"contextMenuPosition.x\"\n                    [style.top]=\"contextMenuPosition.y\"\n                    [matMenuTriggerFor]=\"contextMenu\"\n                    [matMenuTriggerData]=\"{ actions: contextActions }\"\n                ></div>\n            </ng-container>\n        </mat-tree-node>\n    </mat-tree>\n\n    <hxp-tree-skeleton-loader\n        *ngIf=\"isInitialTreeLoad\"\n        [skeletonRows]=\"DEFAULT_ITEMS_PER_PAGE\"\n    />\n</div>\n<mat-menu\n    #contextMenu=\"matMenu\"\n    class=\"hxp-context-menu\"\n    (closed)=\"onContextMenuClosed()\"\n>\n    <ng-container *ngTemplateOutlet=\"contextActionMenuTemplateRef; context: { $implicit: contextActions }\" />\n</mat-menu>\n", styles: [".hxp-context-btn{flex-shrink:0;width:0;overflow:hidden}.hxp-context-btn button{opacity:0}.hxp-context-btn button.hxp-menu-opened{opacity:1}.hxp-document-tree{overflow-y:auto;overflow-x:auto;width:100%;height:100%;display:flex;flex-direction:column}.hxp-document-tree-node{border-radius:var(--mat-sys-corner-medium);min-height:48px;text-wrap:wrap;width:calc(100% - 40px)}.hxp-document-tree-node[aria-level=\"1\"]{width:100%}.hxp-document-tree-node:not([aria-level=\"1\"]){padding-right:12px}.hxp-document-tree-node.hxp-node-context-opened{background-color:var(--mat-sys-surface-container);opacity:.9}.hxp-document-tree-node.hxp-node-context-opened .hxp-context-btn{width:auto}.hxp-document-tree-node button{display:flex;align-items:center}.hxp-document-tree-node:hover{background-color:var(--mat-sys-surface-container);opacity:.9;cursor:pointer}.hxp-document-tree-node:hover .hxp-context-btn{width:auto}.hxp-document-tree-node:hover .hxp-context-btn button{opacity:1}.hxp-document-tree-node>button{transform:scale(.9);flex-shrink:0}.hxp-selected{background-color:var(--mat-sys-secondary-container)}.hxp-node-label{flex:1;min-width:0;margin-left:10px;overflow:hidden;text-overflow:ellipsis;word-wrap:normal;white-space:nowrap}.hxp-node-container{display:flex;flex:1;align-items:center;min-width:0;overflow:hidden}.hxp-menu-trigger{visibility:hidden;position:fixed}.hxp-fill{height:100%;min-height:100%;min-width:100%;width:100%}.hxp-node-selection-checkbox{margin:0 24px 0 12px}\n"] }]
        }], propDecorators: { rootDocument: [{
                type: Input
            }], documents: [{
                type: Input
            }], multiSelection: [{
                type: Input
            }], selectedDocument: [{
                type: Output
            }], contextActionMenuTemplateRef: [{
                type: ContentChild,
                args: ['contextActionMenu', { static: false }]
            }], menuTrigger: [{
                type: ViewChild,
                args: ['trigger', { static: false }]
            }], hiddenTrigger: [{
                type: ViewChild,
                args: ['hiddenTrigger', { static: false }]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DeletedStatus = {
    REQUEST: 'REQUEST',
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const deleteItemNotificationMessages = {
    [DeletedStatus.REQUEST]: {
        SINGLE: 'DOCUMENT_DELETE.SNACKBAR.DELETE.ITEM.REQUEST',
        MULTI: 'DOCUMENT_DELETE.SNACKBAR.DELETE.MULTIPLE_ITEMS.REQUEST',
    },
    [DeletedStatus.SUCCESS]: {
        SINGLE: 'DOCUMENT_DELETE.SNACKBAR.DELETE.ITEM.SUCCESS',
        MULTI: 'DOCUMENT_DELETE.SNACKBAR.DELETE.MULTIPLE_ITEMS.SUCCESS',
    },
    [DeletedStatus.ERROR]: {
        SINGLE: 'DOCUMENT_DELETE.SNACKBAR.DELETE.ITEM.ERROR',
        MULTI: 'DOCUMENT_DELETE.SNACKBAR.DELETE.MULTIPLE_ITEMS.ERROR',
    },
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const deleteSnackBarTypes = {
    [DeletedStatus.REQUEST]: 'info',
    [DeletedStatus.SUCCESS]: 'done',
    [DeletedStatus.ERROR]: 'error',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ContentDeleteConfirmationDialogComponent {
    constructor() {
        this.documents = [];
        this.dialogData = inject(MAT_DIALOG_DATA);
        this.dialogRef = inject(MatDialogRef);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.documentService = inject(DocumentService);
        this.documentRouterService = inject(DocumentRouterService);
        this.routerExtService = inject(RouterExtService);
        this.translate = inject(TranslateService);
        this.shouldRedirect = this.dialogData?.shouldRedirect;
        this.refererURL = this.dialogData?.refererURL;
        this.isDeleting = false;
        this.documents = this.dialogData?.documents ?? [];
        this.populateDialogTitleAndDescription();
        this.deleteDocument$ = from(this.documents).pipe(filter((document) => !!document?.sys_id), mergeMap((document) => this.documentService.deleteDocument(document.sys_id).pipe(map((docId) => ({
            success: true,
            docId,
        })), catchError((error) => of({
            success: false,
            error: error,
            docId: document.sys_id,
        })))), toArray());
    }
    onDelete() {
        this.isDeleting = true;
        this.deleteDocument$.subscribe({
            next: (results) => {
                this.processDeletionResultsAndNotify(results);
            },
            error: () => {
                this.displayNotificationMessage('DOCUMENT_DELETE.SNACKBAR.DELETE.ERROR', DeletedStatus.ERROR);
            },
            complete: () => {
                this.isDeleting = false;
                this.dialogRef.close();
                if (this.shouldRedirect) {
                    this.redirectToReferer();
                }
            },
        });
    }
    redirectToReferer() {
        this.routerExtService.redirectToReferer(this.refererURL, this.documentRouterService.urlForParent(this.documents[0]));
    }
    processDeletionResultsAndNotify(results) {
        const successCount = results.filter((res) => res.success).length;
        const errorCount = results.length - successCount;
        const messages = [];
        if (successCount > 0) {
            const successMessageKey = successCount === 1
                ? deleteItemNotificationMessages[DeletedStatus.SUCCESS].SINGLE
                : deleteItemNotificationMessages[DeletedStatus.SUCCESS].MULTI;
            messages.push(this.translate.instant(successMessageKey).replace('{count}', successCount.toString()));
        }
        if (errorCount > 0) {
            const errorMessageKey = errorCount === 1
                ? deleteItemNotificationMessages[DeletedStatus.ERROR].SINGLE
                : deleteItemNotificationMessages[DeletedStatus.ERROR].MULTI;
            messages.push(this.translate.instant(errorMessageKey).replace('{count}', errorCount.toString()));
        }
        const finalMessage = messages.join(' ');
        let status;
        if (successCount > 0 && errorCount > 0) {
            status = DeletedStatus.REQUEST;
        }
        else if (successCount > 0) {
            status = DeletedStatus.SUCCESS;
        }
        else {
            status = DeletedStatus.ERROR;
        }
        if (finalMessage) {
            this.displayNotificationMessage(finalMessage, status);
        }
    }
    displayNotificationMessage(message, status) {
        this.hxpNotificationService.openSnackBar(message, deleteSnackBarTypes[status]);
    }
    populateDialogTitleAndDescription() {
        this.dialogTitle =
            this.documents.length > 1 ? 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.MULTIPLE_ITEMS.TITLE' : 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.ITEM.TITLE';
        this.dialogDescription =
            this.documents.length > 1
                ? 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.MULTIPLE_ITEMS.DESCRIPTION'
                : 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.ITEM.DESCRIPTION';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentDeleteConfirmationDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: ContentDeleteConfirmationDialogComponent, isStandalone: true, selector: "hxp-content-delete-confirmation-dialog", ngImport: i0, template: "<h2 mat-dialog-title>{{ dialogTitle | translate }}</h2>\n<mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n    {{ dialogDescription | translate }}\n</mat-dialog-content>\n<mat-dialog-actions align=\"end\">\n    <button\n        mat-button\n        mat-dialog-close\n    >\n        {{ 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.BUTTONS.CANCEL' | translate }}\n    </button>\n    <button\n        mat-flat-button\n        class=\"hxp-confirm-delete-button\"\n        [class.hxp-disable-btn]=\"isDeleting\"\n        (click)=\"onDelete()\"\n    >\n        <span class=\"hxp-confirm-delete-button-label\">\n            @if (isDeleting) {\n                <mat-progress-spinner\n                    mode=\"indeterminate\"\n                    diameter=\"15\"\n                />\n            }\n            {{ dialogTitle | translate }}\n        </span>\n    </button>\n</mat-dialog-actions>\n", styles: [".hxp-confirm-delete-button{--mdc-filled-button-container-color: var(--sat-sys-important-loud-container);--mdc-filled-button-label-text-color: var(--sat-sys-on-important-loud-container);--mdc-circular-progress-active-indicator-color: var(--sat-sys-on-important-loud-container)}.hxp-confirm-delete-button .hxp-confirm-delete-button-label{display:flex;align-items:center;gap:10px}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i3$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentDeleteConfirmationDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-content-delete-confirmation-dialog', encapsulation: ViewEncapsulation.None, imports: [MatDialogModule, MatIconModule, MatButtonModule, MatProgressSpinnerModule, TranslatePipe], template: "<h2 mat-dialog-title>{{ dialogTitle | translate }}</h2>\n<mat-dialog-content class=\"hxp-fixed-dialog-content-height\">\n    {{ dialogDescription | translate }}\n</mat-dialog-content>\n<mat-dialog-actions align=\"end\">\n    <button\n        mat-button\n        mat-dialog-close\n    >\n        {{ 'DOCUMENT_DELETE.APP.DIALOGS.DELETE.BUTTONS.CANCEL' | translate }}\n    </button>\n    <button\n        mat-flat-button\n        class=\"hxp-confirm-delete-button\"\n        [class.hxp-disable-btn]=\"isDeleting\"\n        (click)=\"onDelete()\"\n    >\n        <span class=\"hxp-confirm-delete-button-label\">\n            @if (isDeleting) {\n                <mat-progress-spinner\n                    mode=\"indeterminate\"\n                    diameter=\"15\"\n                />\n            }\n            {{ dialogTitle | translate }}\n        </span>\n    </button>\n</mat-dialog-actions>\n", styles: [".hxp-confirm-delete-button{--mdc-filled-button-container-color: var(--sat-sys-important-loud-container);--mdc-filled-button-label-text-color: var(--sat-sys-on-important-loud-container);--mdc-circular-progress-active-indicator-color: var(--sat-sys-on-important-loud-container)}.hxp-confirm-delete-button .hxp-confirm-delete-button-label{display:flex;align-items:center;gap:10px}\n"] }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DeleteButtonActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.dialog = inject(MatDialog);
    }
    isAvailable(context) {
        const docs = context.documents ?? [];
        const parent = context.parentDocument;
        if (!parent || docs.length === 0) {
            return false;
        }
        const hasRequiredPermissions = docs.every((doc) => hasPermission(doc, DocumentPermissions.DELETE)) && hasPermission(parent, DocumentPermissions.DELETE_CHILD);
        const isAnyRetainedOrHold = docs.some((doc) => {
            const status = getRetentionStatus(doc);
            return status && BLOCK_DELETE_STATUSES.includes(status);
        });
        const isAnyVersion = isVersion(docs[0]);
        return hasRequiredPermissions && !isAnyRetainedOrHold && !isAnyVersion;
    }
    execute(context) {
        if (this.canOpenConfirmationDialog(context)) {
            this.dialog.open(ContentDeleteConfirmationDialogComponent, {
                data: {
                    documents: context.documents,
                    shouldRedirect: context.shouldRedirect || false,
                    refererURL: context.refererURL || '',
                },
            });
        }
    }
    canOpenConfirmationDialog(context) {
        return context.documents?.length > 0;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DeleteButtonActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DeleteButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DeleteButtonActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const originFormControlNameNgOnChanges = FormControlName.prototype.ngOnChanges;
FormControlName.prototype.ngOnChanges = function (...arg) {
    const result = originFormControlNameNgOnChanges.apply(this, arg);
    this.control.nativeElement = this.valueAccessor?._elementRef?.nativeElement;
    return result;
};
class ContentShareDialogComponent {
    constructor() {
        this._fb = inject(FormBuilder);
        this.data = inject(MAT_DIALOG_DATA);
        this.contentShareService = inject(ContentShareService);
        this.clipboard = inject(Clipboard);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.shareDocumentForm = this._fb.group({
            shared_link: ['', Validators.required],
        });
        if (this.data?.sharedDocument) {
            const sharedLink = this.contentShareService.getSingleContentShareLink(this.data.sharedDocument);
            this.shareDocumentForm.patchValue({ shared_link: sharedLink });
        }
    }
    onCopy() {
        this.clipboard.copy(this.shareDocumentForm.value.shared_link ?? '');
        this.shareDocumentForm.get('shared_link').nativeElement.select();
        this.hxpNotificationService.openSnackBar('DOCUMENT_SHARE.SNACKBAR.SHARE.SUCCESS', 'done');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: ContentShareDialogComponent, isStandalone: true, selector: "hxp-alfresco-dbp-content-share-dialog", ngImport: i0, template: "<h1 mat-dialog-title>{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.SHARED_ITEM' | translate }}</h1>\n<div mat-dialog-content>\n    <form [formGroup]=\"shareDocumentForm\">\n        <mat-form-field\n            class=\"hxp-share-dialog-form-field\"\n            hideRequiredMarker\n        >\n            <mat-label>{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.LINK' | translate }}</mat-label>\n            <input\n                #sharedLinkInput\n                matInput\n                [attr.aria-label]=\"'DOCUMENT_SHARE.DIALOGS.SHARE.LINK' | translate\"\n                formControlName=\"shared_link\"\n                type=\"text\"\n                readonly\n                md-select-on-focus\n            />\n            <button\n                mat-icon-button\n                matSuffix\n                data-automation-id=\"hxp-share-link-copy-button\"\n                (click)=\"onCopy()\"\n            >\n                <mat-icon\n                    aria-hidden=\"true\"\n                    svgIcon=\"copy\"\n                />\n            </button>\n        </mat-form-field>\n    </form>\n</div>\n<mat-dialog-actions [align]=\"'end'\">\n    <button\n        mat-button\n        mat-dialog-close\n    >\n        {{ 'DOCUMENT_SHARE.DIALOGS.BUTTON.CLOSE.LABEL' | translate }}\n    </button>\n</mat-dialog-actions>\n", styles: [".hxp-share-dialog-form-field{display:flex;flex-direction:column;margin-top:10px}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i3$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i3$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i3$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "ngmodule", type: MatSnackBarModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-alfresco-dbp-content-share-dialog', imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        MatIconModule,
                        MatFormFieldModule,
                        ReactiveFormsModule,
                        MatInputModule,
                        TranslatePipe,
                        MatSnackBarModule,
                    ], template: "<h1 mat-dialog-title>{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.SHARED_ITEM' | translate }}</h1>\n<div mat-dialog-content>\n    <form [formGroup]=\"shareDocumentForm\">\n        <mat-form-field\n            class=\"hxp-share-dialog-form-field\"\n            hideRequiredMarker\n        >\n            <mat-label>{{ 'DOCUMENT_SHARE.DIALOGS.SHARE.LINK' | translate }}</mat-label>\n            <input\n                #sharedLinkInput\n                matInput\n                [attr.aria-label]=\"'DOCUMENT_SHARE.DIALOGS.SHARE.LINK' | translate\"\n                formControlName=\"shared_link\"\n                type=\"text\"\n                readonly\n                md-select-on-focus\n            />\n            <button\n                mat-icon-button\n                matSuffix\n                data-automation-id=\"hxp-share-link-copy-button\"\n                (click)=\"onCopy()\"\n            >\n                <mat-icon\n                    aria-hidden=\"true\"\n                    svgIcon=\"copy\"\n                />\n            </button>\n        </mat-form-field>\n    </form>\n</div>\n<mat-dialog-actions [align]=\"'end'\">\n    <button\n        mat-button\n        mat-dialog-close\n    >\n        {{ 'DOCUMENT_SHARE.DIALOGS.BUTTON.CLOSE.LABEL' | translate }}\n    </button>\n</mat-dialog-actions>\n", styles: [".hxp-share-dialog-form-field{display:flex;flex-direction:column;margin-top:10px}\n"] }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ContentShareButtonActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.dialog = inject(MatDialog);
    }
    isAvailable(context) {
        return context.documents?.length === 1 && hasPermission(context.documents[0], DocumentPermissions.READ);
    }
    execute(context) {
        const DIALOG_MIN_WIDTH = '750px';
        if (context.documents?.[0]?.sys_id) {
            this.dialog.open(ContentShareDialogComponent, {
                width: DIALOG_MIN_WIDTH,
                data: { sharedDocument: context.documents[0] },
            });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareButtonActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareButtonActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DismissPermission {
}
class CancelPermissionDialogComponent {
    constructor() {
        this.dialogRef = inject(MatDialogRef);
        this.dialogData = inject(MAT_DIALOG_DATA);
        this.permissionsPanelRequestService = inject(PermissionsPanelRequestService);
    }
    reject() {
        this.dialogRef.close();
    }
    confirm() {
        this.dialogRef.close();
        if (this.dialogData?.permissionDialogRef) {
            this.dialogData.permissionDialogRef.close();
        }
        else {
            this.permissionsPanelRequestService.requestClosePanel();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CancelPermissionDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: CancelPermissionDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: "<div class=\"hxp-cancel-permission-dialog\">\n    <h1 mat-dialog-title>{{ dialogData.dialogTitle | translate }}</h1>\n    <div mat-dialog-content>\n        <p>{{ dialogData.dialogDescription | translate }}</p>\n    </div>\n    <div\n        mat-dialog-actions\n        [align]=\"'end'\"\n    >\n        <button\n            mat-flat-button\n            disableRipple\n            class=\"hxp-permission-dialog-reject-button\"\n            (click)=\"reject()\"\n        >\n            {{ dialogData.dialogRejectButton | translate }}\n        </button>\n        <button\n            mat-button\n            class=\"hxp-permission-dialog-confirm-button\"\n            (click)=\"confirm()\"\n        >\n            {{ dialogData.dialogConfirmButton | translate }}\n        </button>\n    </div>\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatRadioModule }, { kind: "ngmodule", type: FormsModule }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CancelPermissionDialogComponent, decorators: [{
            type: Component,
            args: [{ encapsulation: ViewEncapsulation.None, imports: [MatDialogModule, MatButtonModule, MatRadioModule, FormsModule, TranslatePipe], template: "<div class=\"hxp-cancel-permission-dialog\">\n    <h1 mat-dialog-title>{{ dialogData.dialogTitle | translate }}</h1>\n    <div mat-dialog-content>\n        <p>{{ dialogData.dialogDescription | translate }}</p>\n    </div>\n    <div\n        mat-dialog-actions\n        [align]=\"'end'\"\n    >\n        <button\n            mat-flat-button\n            disableRipple\n            class=\"hxp-permission-dialog-reject-button\"\n            (click)=\"reject()\"\n        >\n            {{ dialogData.dialogRejectButton | translate }}\n        </button>\n        <button\n            mat-button\n            class=\"hxp-permission-dialog-confirm-button\"\n            (click)=\"confirm()\"\n        >\n            {{ dialogData.dialogConfirmButton | translate }}\n        </button>\n    </div>\n</div>\n" }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DialogConfig = {
    small: {
        width: '500px',
        height: '640px',
    },
    medium: {
        width: '700px',
        height: '640px',
    },
    large: {
        width: '900px',
        height: '640px',
    },
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ClosePermissionDialogComponent {
    constructor() {
        this.dialogRef = inject(MatDialogRef);
        this.dialogData = inject(MAT_DIALOG_DATA);
    }
    reject() {
        this.closeDialog();
    }
    confirm() {
        this.closeDialog(true);
    }
    closeDialog(save = false) {
        this.dialogRef.close({ save });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ClosePermissionDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: ClosePermissionDialogComponent, isStandalone: true, selector: "ng-component", ngImport: i0, template: "<div class=\"hxp-cancel-permission-dialog\">\n    <h1 mat-dialog-title>{{ dialogData.dialogTitle | translate}}</h1>\n    <div mat-dialog-content>\n        <p>{{ dialogData.dialogDescription | translate}}</p>\n    </div>\n    <div mat-dialog-actions [align]=\"'end'\">\n        <button mat-flat-button disableRipple class=\"hxp-permission-dialog-reject-button\" (click)=\"reject()\">\n            {{ dialogData.dialogRejectButton | translate}}\n        </button>\n        <button mat-button class=\"hxp-permission-dialog-confirm-button\" (click)=\"confirm()\">\n            {{ dialogData.dialogConfirmButton | translate}}\n        </button>\n    </div>\n</div>\n", dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ClosePermissionDialogComponent, decorators: [{
            type: Component,
            args: [{ encapsulation: ViewEncapsulation.None, imports: [MatDialogModule, MatButtonModule, TranslatePipe], template: "<div class=\"hxp-cancel-permission-dialog\">\n    <h1 mat-dialog-title>{{ dialogData.dialogTitle | translate}}</h1>\n    <div mat-dialog-content>\n        <p>{{ dialogData.dialogDescription | translate}}</p>\n    </div>\n    <div mat-dialog-actions [align]=\"'end'\">\n        <button mat-flat-button disableRipple class=\"hxp-permission-dialog-reject-button\" (click)=\"reject()\">\n            {{ dialogData.dialogRejectButton | translate}}\n        </button>\n        <button mat-button class=\"hxp-permission-dialog-confirm-button\" (click)=\"confirm()\">\n            {{ dialogData.dialogConfirmButton | translate}}\n        </button>\n    </div>\n</div>\n" }]
        }] });

class PermissionsTableComponent {
    constructor() {
        this.title = '';
        this.activePermissionsManagementRows = [];
        // HEADER INJECTED CONTENTS
        // unicorn/no-null rule is disabled because TemplateRef cannot be undefined, unless a default ref is provided in the template.
        // Headers have no default reference
        this.entityColumnHeaderTemplateRef = null;
        this.inheritedPermissionColumnHeaderTemplateRef = null;
        this.fileColumnHeaderTemplateRef = null;
        this.inheritedPermissionCellTemplateRef = null;
        this.displayedColumns = ['permissionEntity', 'permission'];
    }
    ngAfterContentChecked() {
        this.displayedColumns = this.getAvailableColumns();
    }
    getAvailableColumns() {
        return this.inheritedPermissionCellTemplateRef
            ? ['permissionEntity', 'inheritedPermission', 'permission']
            : ['permissionEntity', 'permission'];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionsTableComponent, isStandalone: true, selector: "hxp-permissions-table", inputs: { title: "title", activePermissionsManagementRows: "activePermissionsManagementRows" }, queries: [{ propertyName: "entityColumnHeaderTemplateRef", first: true, predicate: ["entityColumnHeader"], descendants: true }, { propertyName: "inheritedPermissionColumnHeaderTemplateRef", first: true, predicate: ["inheritedPermissionColumnHeader"], descendants: true }, { propertyName: "fileColumnHeaderTemplateRef", first: true, predicate: ["fileColumnHeader"], descendants: true }, { propertyName: "emptyTableTemplateRef", first: true, predicate: ["emptyTable"], descendants: true }, { propertyName: "entityCellTemplateRef", first: true, predicate: ["entityCell"], descendants: true }, { propertyName: "inheritedPermissionCellTemplateRef", first: true, predicate: ["inheritedPermissionCell"], descendants: true }, { propertyName: "fileCellTemplateRef", first: true, predicate: ["fileCell"], descendants: true }], ngImport: i0, template: "<ng-content select=\"[permission-search]\" />\n\n<div\n    id=\"who-access\"\n    class=\"hxp-permission-dialog-who\"\n>\n    {{ title | translate }}\n</div>\n\n<div class=\"hxp-user-table\">\n    <table\n        *ngIf=\"activePermissionsManagementRows.length > 0; else emptyTable\"\n        mat-table\n        [dataSource]=\"activePermissionsManagementRows\"\n        class=\"hxp-permission-dialog-list mat-elevation-z0\"\n        aria-describedby=\"who-access\"\n    >\n        <ng-container matColumnDef=\"permissionEntity\">\n            <th\n                mat-header-cell\n                *matHeaderCellDef\n            >\n                <ng-template *ngTemplateOutlet=\"entityColumnHeaderTemplateRef\" />\n            </th>\n            <td\n                mat-cell\n                *matCellDef=\"let element\"\n            >\n                <ng-template\n                    #defaultUserGroupCell\n                    let-element\n                >\n                    {{ element.entityLabel }}\n                </ng-template>\n\n                <ng-container *ngTemplateOutlet=\"entityCellTemplateRef || defaultUserGroupCell; context: { $implicit: element }\" />\n            </td>\n        </ng-container>\n        <ng-container matColumnDef=\"inheritedPermission\">\n            <th\n                mat-header-cell\n                *matHeaderCellDef\n            >\n                <ng-template *ngTemplateOutlet=\"inheritedPermissionColumnHeaderTemplateRef\" />\n            </th>\n            <td\n                mat-cell\n                *matCellDef=\"let element\"\n            >\n                <ng-container *ngTemplateOutlet=\"inheritedPermissionCellTemplateRef; context: { $implicit: element }\" />\n            </td>\n        </ng-container>\n        <ng-container matColumnDef=\"permission\">\n            <th\n                mat-header-cell\n                *matHeaderCellDef\n            >\n                <ng-template *ngTemplateOutlet=\"fileColumnHeaderTemplateRef\" />\n            </th>\n            <td\n                mat-cell\n                *matCellDef=\"let element\"\n            >\n                <ng-template\n                    #defaultPermissionCell\n                    let-element\n                >\n                    {{ element.permission }}\n                </ng-template>\n\n                <ng-container *ngTemplateOutlet=\"fileCellTemplateRef || defaultPermissionCell; context: { $implicit: element }\" />\n            </td>\n        </ng-container>\n        <tr\n            mat-header-row\n            *matHeaderRowDef=\"displayedColumns\"\n        ></tr>\n        <tr\n            mat-row\n            *matRowDef=\"let row; columns: displayedColumns\"\n            class=\"hxp-permission-row\"\n        ></tr>\n    </table>\n</div>\n\n<ng-template #defaultEmptyTable>\n    <div class=\"hxp-no-permission\">\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.DEFAULT' | translate }}\n    </div>\n</ng-template>\n\n<ng-template #emptyTable>\n    <ng-template *ngTemplateOutlet=\"emptyTableTemplateRef || defaultEmptyTable\" />\n</ng-template>\n", styles: [":host{display:flex;flex-direction:column;flex:1;min-height:0}.hxp-permission-dialog-who{font:var(--mat-sys-title-small);color:var(--mat-sys-on-surface);margin:24px 0 16px}.hxp-no-permission{font:var(--mat-sys-body-medium);color:var(--mat-sys-on-surface);margin-top:15px;padding:0 10px}.hxp-user-table{display:flex;align-items:center;justify-content:center;flex:1;min-height:220px;max-height:220px;border:1px solid var(--mat-sys-outline);border-radius:12px;overflow-y:auto;position:relative}.hxp-user-table table{width:100%;table-layout:fixed;align-self:flex-start;border-collapse:collapse}.hxp-user-table tr{border:none}.hxp-user-table td,.hxp-user-table th{border:none;padding:8px 12px}.hxp-user-table th:nth-child(1),.hxp-user-table td:nth-child(1){width:22%;max-width:25%;overflow:hidden}.hxp-user-table th:nth-child(2),.hxp-user-table td:nth-child(2){width:18%;max-width:30%;text-align:center}.hxp-user-table th:nth-child(3),.hxp-user-table td:nth-child(3){width:31%;max-width:60%}.hxp-user-table thead tr{position:sticky;top:0;background-color:var(--mat-sys-surface-container-low);border-bottom:1px solid var(--mat-sys-outline-variant);z-index:1}.hxp-user-table tbody{padding-bottom:10px}.hxp-permission-row:hover{background-color:var(--mat-sys-surface-container)}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: i1$2.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i1$2.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i1$2.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i1$2.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i1$2.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i1$2.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i1$2.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i1$2.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i1$2.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i1$2.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-table', encapsulation: ViewEncapsulation.None, imports: [NgIf, MatTableModule, NgTemplateOutlet, TranslatePipe], template: "<ng-content select=\"[permission-search]\" />\n\n<div\n    id=\"who-access\"\n    class=\"hxp-permission-dialog-who\"\n>\n    {{ title | translate }}\n</div>\n\n<div class=\"hxp-user-table\">\n    <table\n        *ngIf=\"activePermissionsManagementRows.length > 0; else emptyTable\"\n        mat-table\n        [dataSource]=\"activePermissionsManagementRows\"\n        class=\"hxp-permission-dialog-list mat-elevation-z0\"\n        aria-describedby=\"who-access\"\n    >\n        <ng-container matColumnDef=\"permissionEntity\">\n            <th\n                mat-header-cell\n                *matHeaderCellDef\n            >\n                <ng-template *ngTemplateOutlet=\"entityColumnHeaderTemplateRef\" />\n            </th>\n            <td\n                mat-cell\n                *matCellDef=\"let element\"\n            >\n                <ng-template\n                    #defaultUserGroupCell\n                    let-element\n                >\n                    {{ element.entityLabel }}\n                </ng-template>\n\n                <ng-container *ngTemplateOutlet=\"entityCellTemplateRef || defaultUserGroupCell; context: { $implicit: element }\" />\n            </td>\n        </ng-container>\n        <ng-container matColumnDef=\"inheritedPermission\">\n            <th\n                mat-header-cell\n                *matHeaderCellDef\n            >\n                <ng-template *ngTemplateOutlet=\"inheritedPermissionColumnHeaderTemplateRef\" />\n            </th>\n            <td\n                mat-cell\n                *matCellDef=\"let element\"\n            >\n                <ng-container *ngTemplateOutlet=\"inheritedPermissionCellTemplateRef; context: { $implicit: element }\" />\n            </td>\n        </ng-container>\n        <ng-container matColumnDef=\"permission\">\n            <th\n                mat-header-cell\n                *matHeaderCellDef\n            >\n                <ng-template *ngTemplateOutlet=\"fileColumnHeaderTemplateRef\" />\n            </th>\n            <td\n                mat-cell\n                *matCellDef=\"let element\"\n            >\n                <ng-template\n                    #defaultPermissionCell\n                    let-element\n                >\n                    {{ element.permission }}\n                </ng-template>\n\n                <ng-container *ngTemplateOutlet=\"fileCellTemplateRef || defaultPermissionCell; context: { $implicit: element }\" />\n            </td>\n        </ng-container>\n        <tr\n            mat-header-row\n            *matHeaderRowDef=\"displayedColumns\"\n        ></tr>\n        <tr\n            mat-row\n            *matRowDef=\"let row; columns: displayedColumns\"\n            class=\"hxp-permission-row\"\n        ></tr>\n    </table>\n</div>\n\n<ng-template #defaultEmptyTable>\n    <div class=\"hxp-no-permission\">\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.DEFAULT' | translate }}\n    </div>\n</ng-template>\n\n<ng-template #emptyTable>\n    <ng-template *ngTemplateOutlet=\"emptyTableTemplateRef || defaultEmptyTable\" />\n</ng-template>\n", styles: [":host{display:flex;flex-direction:column;flex:1;min-height:0}.hxp-permission-dialog-who{font:var(--mat-sys-title-small);color:var(--mat-sys-on-surface);margin:24px 0 16px}.hxp-no-permission{font:var(--mat-sys-body-medium);color:var(--mat-sys-on-surface);margin-top:15px;padding:0 10px}.hxp-user-table{display:flex;align-items:center;justify-content:center;flex:1;min-height:220px;max-height:220px;border:1px solid var(--mat-sys-outline);border-radius:12px;overflow-y:auto;position:relative}.hxp-user-table table{width:100%;table-layout:fixed;align-self:flex-start;border-collapse:collapse}.hxp-user-table tr{border:none}.hxp-user-table td,.hxp-user-table th{border:none;padding:8px 12px}.hxp-user-table th:nth-child(1),.hxp-user-table td:nth-child(1){width:22%;max-width:25%;overflow:hidden}.hxp-user-table th:nth-child(2),.hxp-user-table td:nth-child(2){width:18%;max-width:30%;text-align:center}.hxp-user-table th:nth-child(3),.hxp-user-table td:nth-child(3){width:31%;max-width:60%}.hxp-user-table thead tr{position:sticky;top:0;background-color:var(--mat-sys-surface-container-low);border-bottom:1px solid var(--mat-sys-outline-variant);z-index:1}.hxp-user-table tbody{padding-bottom:10px}.hxp-permission-row:hover{background-color:var(--mat-sys-surface-container)}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], activePermissionsManagementRows: [{
                type: Input
            }], entityColumnHeaderTemplateRef: [{
                type: ContentChild,
                args: ['entityColumnHeader', { static: false }]
            }], inheritedPermissionColumnHeaderTemplateRef: [{
                type: ContentChild,
                args: ['inheritedPermissionColumnHeader', { static: false }]
            }], fileColumnHeaderTemplateRef: [{
                type: ContentChild,
                args: ['fileColumnHeader', { static: false }]
            }], emptyTableTemplateRef: [{
                type: ContentChild,
                args: ['emptyTable', { static: false }]
            }], entityCellTemplateRef: [{
                type: ContentChild,
                args: ['entityCell', { static: false }]
            }], 
        // in this case the column is optional, therefore there is no default ref.
        inheritedPermissionCellTemplateRef: [{
                type: ContentChild,
                args: ['inheritedPermissionCell', { static: false }]
            }], fileCellTemplateRef: [{
                type: ContentChild,
                args: ['fileCell', { static: false }]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsSearchComponent {
    constructor() {
        this.placeHolder = '';
        this.activePermissionsManagementRows = [];
        // eslint-disable-next-line @angular-eslint/no-output-native
        this.search = new EventEmitter();
    }
    onKey(event) {
        this.emit(event.target.value);
    }
    emit(value) {
        this.search.emit(value);
    }
    permissionsManagementRowTrackBy(_index, row) {
        return row.index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsSearchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionsSearchComponent, isStandalone: true, selector: "hxp-permission-search", inputs: { placeHolder: "placeHolder", activePermissionsManagementRows: "activePermissionsManagementRows" }, outputs: { search: "search" }, ngImport: i0, template: "<div class=\"hxp-permission-dialog-search-holder\">\n    <mat-form-field class=\"hxp-permission-dialog-search-holder-form-field\">\n        <input\n            id=\"hxp-permission-user-search\"\n            class=\"hxp-permission-dialog-search\"\n            matInput\n            placeholder=\"{{ placeHolder }}\"\n            type=\"text\"\n            [matAutocomplete]=\"auto\"\n            (keyup)=\"onKey($event)\"\n        />\n\n        <mat-icon\n            matSuffix\n            svgIcon=\"search\"\n        />\n\n        <mat-autocomplete\n            autoActiveFirstOption\n            #auto=\"matAutocomplete\"\n        >\n            <mat-option\n                *ngFor=\"let option of activePermissionsManagementRows; trackBy: permissionsManagementRowTrackBy\"\n                [value]=\"option.entityLabel\"\n                (click)=\"emit(option.entityLabel)\"\n            >\n                {{ option.entityLabel }}\n            </mat-option>\n        </mat-autocomplete>\n    </mat-form-field>\n</div>\n", styles: [".hxp-permission-dialog-search-holder{display:flex;margin-top:24px}.hxp-permission-dialog-search-holder-form-field{flex:1}\n"], dependencies: [{ kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i3$3.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i3$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i3$3.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: MatOptionModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsSearchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permission-search', imports: [MatInputModule, MatAutocompleteModule, NgFor, MatOptionModule, MatIconModule, MatFormFieldModule], template: "<div class=\"hxp-permission-dialog-search-holder\">\n    <mat-form-field class=\"hxp-permission-dialog-search-holder-form-field\">\n        <input\n            id=\"hxp-permission-user-search\"\n            class=\"hxp-permission-dialog-search\"\n            matInput\n            placeholder=\"{{ placeHolder }}\"\n            type=\"text\"\n            [matAutocomplete]=\"auto\"\n            (keyup)=\"onKey($event)\"\n        />\n\n        <mat-icon\n            matSuffix\n            svgIcon=\"search\"\n        />\n\n        <mat-autocomplete\n            autoActiveFirstOption\n            #auto=\"matAutocomplete\"\n        >\n            <mat-option\n                *ngFor=\"let option of activePermissionsManagementRows; trackBy: permissionsManagementRowTrackBy\"\n                [value]=\"option.entityLabel\"\n                (click)=\"emit(option.entityLabel)\"\n            >\n                {{ option.entityLabel }}\n            </mat-option>\n        </mat-autocomplete>\n    </mat-form-field>\n</div>\n", styles: [".hxp-permission-dialog-search-holder{display:flex;margin-top:24px}.hxp-permission-dialog-search-holder-form-field{flex:1}\n"] }]
        }], propDecorators: { placeHolder: [{
                type: Input
            }], activePermissionsManagementRows: [{
                type: Input
            }], search: [{
                type: Output
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const NewPermissionLabels = {
    Read: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.READ',
    ReadWrite: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.READ_WRITE',
    Everything: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.EVERYTHING',
};
const PermissionLabels = {
    None: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.NO_ACCESS',
    Blocked: 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.BLOCKED',
    ...NewPermissionLabels,
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsComponent {
    constructor() {
        this.inheritedPermission = 'None';
        this.inheritanceEnabled = true;
        this.disabled = false;
        this.changePermission = new EventEmitter();
        this.permissionLabels = PermissionLabels;
        this.newPermissionLabels = NewPermissionLabels;
        this.isOptionDisabled = (permission) => {
            return this.inheritanceEnabled && this.inheritedPermission !== 'None' && this.isPermissionLowerThanInherited(permission);
        };
        this.originalOrder = () => 0;
    }
    onPermissionChange($event) {
        this.changePermission.emit($event);
    }
    optionTrackBy(index) {
        return index;
    }
    isPermissionLowerThanInherited(permission) {
        return getHighestPermission(permission, this.inheritedPermission) === this.inheritedPermission;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionsComponent, isStandalone: true, selector: "hxp-permissions", inputs: { permission: "permission", inheritedPermission: "inheritedPermission", inheritanceEnabled: "inheritanceEnabled", disabled: "disabled" }, outputs: { changePermission: "changePermission" }, ngImport: i0, template: "<div class=\"hxp-permission-select\">\n    <mat-form-field\n        class=\"hxp-permission-select-field\"\n        *ngIf=\"!disabled; else disabledField\"\n        subscriptSizing=\"dynamic\"\n    >\n        <mat-select\n            id=\"hxp-user-permission\"\n            [placeholder]=\"'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.PLACEHOLDER' | translate\"\n            [ngModel]=\"permission\"\n            (ngModelChange)=\"onPermissionChange($event)\"\n            class=\"hxp-select-permission\"\n            [panelWidth]=\"''\"\n            panelClass=\"hxp-permission-select-panel\"\n        >\n            <mat-option *ngIf=\"!!permission\">\n                <ng-container *ngIf=\"!inheritedPermission || inheritedPermission === 'None'; else clearPermission\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.NO_ACCESS' | translate }}\n                </ng-container>\n                <ng-template #clearPermission>\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.CLEAR' | translate }}\n                </ng-template>\n            </mat-option>\n            <mat-option\n                *ngFor=\"let options of newPermissionLabels | keyvalue: originalOrder; trackBy: optionTrackBy\"\n                [value]=\"options.key\"\n                [disabled]=\"isOptionDisabled(options.key)\"\n                [class.hxp-permission-selected-option]=\"options.key === permission\"\n            >\n                {{ options.value | translate\n                }}{{\n                    inheritanceEnabled && options.key === inheritedPermission\n                        ? ' - ' + ('PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.INHERITED' | translate)\n                        : ''\n                }}\n            </mat-option>\n        </mat-select>\n    </mat-form-field>\n    <ng-template #disabledField>\n        <div class=\"hxp-select-permission hxp-disabled\">\n            <div *ngIf=\"permission; else disabledInheritedPermission\">{{ newPermissionLabels[permission] | translate }}</div>\n            <ng-template #disabledInheritedPermission>\n                <div *ngIf=\"inheritedPermission\">{{ permissionLabels[inheritedPermission] | translate }}</div>\n            </ng-template>\n        </div>\n    </ng-template>\n</div>\n", styles: [".hxp-permission-select,.hxp-permission-select .hxp-permission-select-field{width:100%}.hxp-permission-select .hxp-select-permission{font-size:var(--mat-sys-body-medium-size);padding-left:5px}.hxp-permission-select .hxp-select-permission.hxp-disabled{padding-left:0}.hxp-permission-select .hxp-select-permission.hxp-disabled>div{padding:5px 10px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$1.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "component", type: i3$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: MatOptionModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions', encapsulation: ViewEncapsulation.None, imports: [NgIf, MatFormFieldModule, MatSelectModule, FormsModule, NgFor, MatOptionModule, MatIconModule, KeyValuePipe, TranslatePipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"hxp-permission-select\">\n    <mat-form-field\n        class=\"hxp-permission-select-field\"\n        *ngIf=\"!disabled; else disabledField\"\n        subscriptSizing=\"dynamic\"\n    >\n        <mat-select\n            id=\"hxp-user-permission\"\n            [placeholder]=\"'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.PLACEHOLDER' | translate\"\n            [ngModel]=\"permission\"\n            (ngModelChange)=\"onPermissionChange($event)\"\n            class=\"hxp-select-permission\"\n            [panelWidth]=\"''\"\n            panelClass=\"hxp-permission-select-panel\"\n        >\n            <mat-option *ngIf=\"!!permission\">\n                <ng-container *ngIf=\"!inheritedPermission || inheritedPermission === 'None'; else clearPermission\">\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.NO_ACCESS' | translate }}\n                </ng-container>\n                <ng-template #clearPermission>\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.CLEAR' | translate }}\n                </ng-template>\n            </mat-option>\n            <mat-option\n                *ngFor=\"let options of newPermissionLabels | keyvalue: originalOrder; trackBy: optionTrackBy\"\n                [value]=\"options.key\"\n                [disabled]=\"isOptionDisabled(options.key)\"\n                [class.hxp-permission-selected-option]=\"options.key === permission\"\n            >\n                {{ options.value | translate\n                }}{{\n                    inheritanceEnabled && options.key === inheritedPermission\n                        ? ' - ' + ('PERMISSIONS_MANAGEMENT_ACTION.DROPDOWN.LABEL.INHERITED' | translate)\n                        : ''\n                }}\n            </mat-option>\n        </mat-select>\n    </mat-form-field>\n    <ng-template #disabledField>\n        <div class=\"hxp-select-permission hxp-disabled\">\n            <div *ngIf=\"permission; else disabledInheritedPermission\">{{ newPermissionLabels[permission] | translate }}</div>\n            <ng-template #disabledInheritedPermission>\n                <div *ngIf=\"inheritedPermission\">{{ permissionLabels[inheritedPermission] | translate }}</div>\n            </ng-template>\n        </div>\n    </ng-template>\n</div>\n", styles: [".hxp-permission-select,.hxp-permission-select .hxp-permission-select-field{width:100%}.hxp-permission-select .hxp-select-permission{font-size:var(--mat-sys-body-medium-size);padding-left:5px}.hxp-permission-select .hxp-select-permission.hxp-disabled{padding-left:0}.hxp-permission-select .hxp-select-permission.hxp-disabled>div{padding:5px 10px}\n"] }]
        }], propDecorators: { permission: [{
                type: Input
            }], inheritedPermission: [{
                type: Input
            }], inheritanceEnabled: [{
                type: Input
            }], disabled: [{
                type: Input
            }], changePermission: [{
                type: Output
            }] } });

const InheritedPermissionLabels = {
    Read: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.READ',
    ReadWrite: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.READ_WRITE',
    Everything: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.EVERYTHING',
    None: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.NO_ACCESS',
    Blocked: 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED.LABEL.BLOCKED',
};
class InheritedPermissionComponent {
    constructor() {
        this.permission = 'None';
        this.inheritanceEnabled = true;
        this.label = InheritedPermissionLabels[this.permission];
    }
    ngOnChanges() {
        this.label = this.inheritanceEnabled ? InheritedPermissionLabels[this.permission] : InheritedPermissionLabels['Blocked'];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: InheritedPermissionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: InheritedPermissionComponent, isStandalone: true, selector: "hxp-inherited-permission", inputs: { permission: "permission", inheritanceEnabled: "inheritanceEnabled" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-inherited-permission\">\n    {{ label | translate }}\n</div>\n", styles: [".hxp-inherited-permission{display:flex;height:100%;align-items:center;color:var(--sat-sys-on-neutral-container)}\n"], dependencies: [{ kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: InheritedPermissionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-inherited-permission', imports: [TranslatePipe], template: "<div class=\"hxp-inherited-permission\">\n    {{ label | translate }}\n</div>\n", styles: [".hxp-inherited-permission{display:flex;height:100%;align-items:center;color:var(--sat-sys-on-neutral-container)}\n"] }]
        }], propDecorators: { permission: [{
                type: Input
            }], inheritanceEnabled: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class AddPermissionComponent {
    constructor() {
        this.destroyRef = inject(DestroyRef);
        this.suggestions = [];
        this.addButtonLabel = '';
        this.searchPlaceholderText = '';
        this.loading = false;
        this.addNewPermission = new EventEmitter();
        // eslint-disable-next-line @angular-eslint/no-output-native
        this.search = new EventEmitter();
        this.permissionLabels = NewPermissionLabels;
        this.suggestionsSubject = new BehaviorSubject([]);
        this.isSuggestedPermissionEntityValidator = inject(IsSuggestedPermissionEntityValidator);
        this.originalOrder = () => 0;
        this.form = new FormGroup({
            search: new FormControl('', {
                validators: Validators.required,
                asyncValidators: this.isSuggestedPermissionEntityValidator.createValidator(this.suggestionsSubject.asObservable()),
                nonNullable: true,
            }),
            permission: new FormControl({ value: undefined, disabled: true }, {
                validators: Validators.required,
                nonNullable: true,
            }),
        }, { validators: this.getDisableValidator.bind(this) });
        this.form.controls.search.valueChanges
            .pipe(filter((text) => typeof text === 'string'), takeUntilDestroyed(this.destroyRef))
            .subscribe({
            next: (text) => {
                this.search.emit(text.trim());
            },
        });
        this.destroyRef.onDestroy(() => {
            this.suggestionsSubject.complete();
        });
    }
    ngOnChanges() {
        this.suggestionsSubject.next(this.suggestions);
    }
    addPermission() {
        if (this.selectedSuggestion) {
            const { inheritedPermission, ...suggestedEntity } = this.selectedSuggestion;
            const newPermission = {
                ...suggestedEntity,
                permission: this.form.controls.permission.value,
            };
            this.form.controls.search.patchValue('');
            this.form.controls.search.markAsUntouched();
            this.form.controls.permission.patchValue(undefined);
            this.form.controls.permission.markAsUntouched();
            this.selectedSuggestion = undefined;
            this.form.controls.permission.disable();
            this.addNewPermission.emit(newPermission);
        }
    }
    selectSuggestion(event) {
        this.selectedSuggestion = event.option.value;
        if (this.selectedSuggestion) {
            this.permissionLabels = this.getAvailablePermissionsOptions(this.selectedSuggestion.inheritedPermission);
            this.form.controls.permission.enable();
        }
    }
    getEntityLabel(entity) {
        return entity?.entityLabel ?? '';
    }
    suggestionTrackBy(_index, suggestion) {
        return suggestion.entityId;
    }
    getAvailablePermissionsOptions(permission) {
        if (!permission) {
            return NewPermissionLabels;
        }
        const levels = ['None', 'Read', 'ReadWrite', 'Everything'];
        const currentLevel = levels.indexOf(permission);
        const availableOptions = {};
        for (const [key, value] of Object.entries(NewPermissionLabels)) {
            const level = levels.indexOf(key);
            if (level > currentLevel) {
                availableOptions[key] = value;
            }
        }
        return availableOptions;
    }
    getDisableValidator() {
        if (this.form?.controls?.permission?.disabled) {
            return { isStillDisabled: true };
        }
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: AddPermissionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: AddPermissionComponent, isStandalone: true, selector: "hxp-add-permission", inputs: { suggestions: "suggestions", addButtonLabel: "addButtonLabel", searchPlaceholderText: "searchPlaceholderText", loading: "loading" }, outputs: { addNewPermission: "addNewPermission", search: "search" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-add-permission\">\n    <div class=\"hxp-permission-dialog-input-area\">\n        <mat-form-field\n            hideRequiredMarker\n            class=\"hxp-permission-dialog-input-area-form-field\"\n        >\n            <mat-label>\n                <ng-content select=\"[title]\" />\n            </mat-label>\n            <input\n                matInput\n                id=\"hxp-add-permissions-text-search\"\n                [formControl]=\"form.controls.search\"\n                type=\"text\"\n                [matAutocomplete]=\"auto\"\n                md-select-on-focus\n            />\n            <mat-icon\n                svgIcon=\"arrow_submenu_down\"\n                matSuffix\n            />\n\n            <mat-autocomplete\n                autoActiveFirstOption\n                #auto=\"matAutocomplete\"\n                (optionSelected)=\"selectSuggestion($event)\"\n                [displayWith]=\"getEntityLabel\"\n                class=\"hxp-user-panel\"\n            >\n                <mat-option *ngIf=\"loading; else display_suggestions\">\n                    <mat-spinner diameter=\"25\" />\n                </mat-option>\n                <ng-template #display_suggestions>\n                    <mat-option\n                        *ngFor=\"let suggestion of suggestions; trackBy: suggestionTrackBy\"\n                        [value]=\"suggestion\"\n                    >\n                        {{ suggestion.entityLabel }}\n                    </mat-option>\n                </ng-template>\n            </mat-autocomplete>\n            <mat-hint>{{ searchPlaceholderText }}</mat-hint>\n            <mat-error>{{ searchPlaceholderText }}</mat-error>\n        </mat-form-field>\n    </div>\n    <div class=\"hxp-permission-dialog-input-area\">\n        <mat-form-field\n            hideRequiredMarker\n            class=\"hxp-permission-dialog-input-area-form-field\"\n        >\n            <mat-label>\n                {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.LABEL.PERMISSION' | translate }}\n            </mat-label>\n            <mat-select\n                id=\"hxp-permission-select\"\n                class=\"hxp-permission-dialog-input\"\n                [formControl]=\"form.controls.permission\"\n                [disableOptionCentering]=\"true\"\n                panelClass=\"hxp-permission-panel\"\n            >\n                <mat-option\n                    *ngFor=\"let permission of permissionLabels | keyvalue: originalOrder\"\n                    [value]=\"permission.key\"\n                >\n                    {{ permission.value | translate }}\n                </mat-option>\n            </mat-select>\n            <mat-hint>{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_PERMISSION' | translate }}</mat-hint>\n            <mat-error>{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_PERMISSION' | translate }}</mat-error>\n        </mat-form-field>\n    </div>\n    <button\n        (click)=\"addPermission()\"\n        id=\"hxp-add-permission-button\"\n        class=\"hxp-permission-dialog-button\"\n        mat-stroked-button\n        [disabled]=\"!form.valid\"\n    >\n        {{ addButtonLabel }}\n    </button>\n</div>\n", styles: [".hxp-add-permission{display:flex;flex-direction:column}.hxp-add-permission .hxp-permission-dialog-input-area{margin-top:24px}.hxp-add-permission .hxp-permission-dialog-button{align-self:flex-end;margin-top:15px}.hxp-add-permission .hxp-permission-dialog-input-area-form-field{display:flex;flex-direction:column}\n"], dependencies: [{ kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4$1.MatHint, selector: "mat-hint", inputs: ["align", "id"] }, { kind: "directive", type: i4$1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "ngmodule", type: MatAutocompleteModule }, { kind: "component", type: i3$3.MatAutocomplete, selector: "mat-autocomplete", inputs: ["aria-label", "aria-labelledby", "displayWith", "autoActiveFirstOption", "autoSelectActiveOption", "requireSelection", "panelWidth", "disableRipple", "class", "hideSingleSelectionIndicator"], outputs: ["optionSelected", "opened", "closed", "optionActivated"], exportAs: ["matAutocomplete"] }, { kind: "component", type: i3$3.MatOption, selector: "mat-option", inputs: ["value", "id", "disabled"], outputs: ["onSelectionChange"], exportAs: ["matOption"] }, { kind: "directive", type: i3$3.MatAutocompleteTrigger, selector: "input[matAutocomplete], textarea[matAutocomplete]", inputs: ["matAutocomplete", "matAutocompletePosition", "matAutocompleteConnectedTo", "autocomplete", "matAutocompleteDisabled"], exportAs: ["matAutocompleteTrigger"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3$2.FormControlDirective, selector: "[formControl]", inputs: ["formControl", "disabled", "ngModel"], outputs: ["ngModelChange"], exportAs: ["ngForm"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatOptionModule }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i3$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "component", type: i2$1.MatSelect, selector: "mat-select", inputs: ["aria-describedby", "panelClass", "disabled", "disableRipple", "tabIndex", "hideSingleSelectionIndicator", "placeholder", "required", "multiple", "disableOptionCentering", "compareWith", "value", "aria-label", "aria-labelledby", "errorStateMatcher", "typeaheadDebounceInterval", "sortComparator", "id", "panelWidth", "canSelectNullableOptions"], outputs: ["openedChange", "opened", "closed", "selectionChange", "valueChange"], exportAs: ["matSelect"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "pipe", type: KeyValuePipe, name: "keyvalue" }, { kind: "ngmodule", type: SatIconModule }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: AddPermissionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-add-permission', encapsulation: ViewEncapsulation.None, imports: [
                        MatFormFieldModule,
                        MatInputModule,
                        FormsModule,
                        MatAutocompleteModule,
                        ReactiveFormsModule,
                        MatIconModule,
                        NgIf,
                        MatOptionModule,
                        MatProgressSpinnerModule,
                        NgFor,
                        MatSelectModule,
                        MatButtonModule,
                        KeyValuePipe,
                        SatIconModule,
                        TranslatePipe,
                    ], template: "<div class=\"hxp-add-permission\">\n    <div class=\"hxp-permission-dialog-input-area\">\n        <mat-form-field\n            hideRequiredMarker\n            class=\"hxp-permission-dialog-input-area-form-field\"\n        >\n            <mat-label>\n                <ng-content select=\"[title]\" />\n            </mat-label>\n            <input\n                matInput\n                id=\"hxp-add-permissions-text-search\"\n                [formControl]=\"form.controls.search\"\n                type=\"text\"\n                [matAutocomplete]=\"auto\"\n                md-select-on-focus\n            />\n            <mat-icon\n                svgIcon=\"arrow_submenu_down\"\n                matSuffix\n            />\n\n            <mat-autocomplete\n                autoActiveFirstOption\n                #auto=\"matAutocomplete\"\n                (optionSelected)=\"selectSuggestion($event)\"\n                [displayWith]=\"getEntityLabel\"\n                class=\"hxp-user-panel\"\n            >\n                <mat-option *ngIf=\"loading; else display_suggestions\">\n                    <mat-spinner diameter=\"25\" />\n                </mat-option>\n                <ng-template #display_suggestions>\n                    <mat-option\n                        *ngFor=\"let suggestion of suggestions; trackBy: suggestionTrackBy\"\n                        [value]=\"suggestion\"\n                    >\n                        {{ suggestion.entityLabel }}\n                    </mat-option>\n                </ng-template>\n            </mat-autocomplete>\n            <mat-hint>{{ searchPlaceholderText }}</mat-hint>\n            <mat-error>{{ searchPlaceholderText }}</mat-error>\n        </mat-form-field>\n    </div>\n    <div class=\"hxp-permission-dialog-input-area\">\n        <mat-form-field\n            hideRequiredMarker\n            class=\"hxp-permission-dialog-input-area-form-field\"\n        >\n            <mat-label>\n                {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.LABEL.PERMISSION' | translate }}\n            </mat-label>\n            <mat-select\n                id=\"hxp-permission-select\"\n                class=\"hxp-permission-dialog-input\"\n                [formControl]=\"form.controls.permission\"\n                [disableOptionCentering]=\"true\"\n                panelClass=\"hxp-permission-panel\"\n            >\n                <mat-option\n                    *ngFor=\"let permission of permissionLabels | keyvalue: originalOrder\"\n                    [value]=\"permission.key\"\n                >\n                    {{ permission.value | translate }}\n                </mat-option>\n            </mat-select>\n            <mat-hint>{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_PERMISSION' | translate }}</mat-hint>\n            <mat-error>{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_PERMISSION' | translate }}</mat-error>\n        </mat-form-field>\n    </div>\n    <button\n        (click)=\"addPermission()\"\n        id=\"hxp-add-permission-button\"\n        class=\"hxp-permission-dialog-button\"\n        mat-stroked-button\n        [disabled]=\"!form.valid\"\n    >\n        {{ addButtonLabel }}\n    </button>\n</div>\n", styles: [".hxp-add-permission{display:flex;flex-direction:column}.hxp-add-permission .hxp-permission-dialog-input-area{margin-top:24px}.hxp-add-permission .hxp-permission-dialog-button{align-self:flex-end;margin-top:15px}.hxp-add-permission .hxp-permission-dialog-input-area-form-field{display:flex;flex-direction:column}\n"] }]
        }], ctorParameters: () => [], propDecorators: { suggestions: [{
                type: Input
            }], addButtonLabel: [{
                type: Input
            }], searchPlaceholderText: [{
                type: Input
            }], loading: [{
                type: Input
            }], addNewPermission: [{
                type: Output
            }], search: [{
                type: Output
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionEmptyTableComponent {
    constructor() {
        this.message = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionEmptyTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionEmptyTableComponent, isStandalone: true, selector: "hxp-permissions-empty-table", inputs: { message: "message" }, ngImport: i0, template: "<div class=\"hxp-empty-table\">\n    <img\n        src=\"./assets/adf-enterprise-adf-hx-content-services-ui/images/EmptyTable.svg\"\n        [alt]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.EMPTY_TABLE_IMAGE' | translate\"\n    />\n    <div class=\"hxp-no-permission-msg\">{{ message }}</div>\n</div>\n", styles: [".hxp-empty-table{display:flex;flex-direction:column;justify-content:center;align-items:center;height:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionEmptyTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-empty-table', imports: [CommonModule, TranslatePipe], template: "<div class=\"hxp-empty-table\">\n    <img\n        src=\"./assets/adf-enterprise-adf-hx-content-services-ui/images/EmptyTable.svg\"\n        [alt]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.EMPTY_TABLE_IMAGE' | translate\"\n    />\n    <div class=\"hxp-no-permission-msg\">{{ message }}</div>\n</div>\n", styles: [".hxp-empty-table{display:flex;flex-direction:column;justify-content:center;align-items:center;height:100%}\n"] }]
        }], propDecorators: { message: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsDocumentTitleComponent {
    constructor() {
        this.title = '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsDocumentTitleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionsDocumentTitleComponent, isStandalone: true, selector: "hxp-permissions-document-title", inputs: { title: "title" }, ngImport: i0, template: "<div\n    class=\"hxp-permission-dialog-title\"\n    mat-dialog-title\n>\n    <div class=\"hxp-permissions-title\">\n        <span class=\"hxp-permission-document-title mat-title-large\">\n            {{ title }}\n        </span>\n        <div role=\"button\"><ng-content select=\"[close-button]\" /></div>\n    </div>\n    <div class=\"hxp-permission-dialog-sub-title mat-title-medium\">\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.MANAGE_PERMISSION' | translate }}\n    </div>\n</div>\n", styles: [".hxp-permission-dialog-title{display:flex;flex-direction:column;padding-left:0;padding-right:0}.hxp-permission-dialog-title:before{content:none!important}.hxp-permissions-title{display:flex;align-items:center;flex-direction:row;flex:1;padding-bottom:16px}.hxp-permission-document-title{word-break:break-all;flex:1}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsDocumentTitleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-document-title', imports: [MatDialogModule, TranslatePipe], template: "<div\n    class=\"hxp-permission-dialog-title\"\n    mat-dialog-title\n>\n    <div class=\"hxp-permissions-title\">\n        <span class=\"hxp-permission-document-title mat-title-large\">\n            {{ title }}\n        </span>\n        <div role=\"button\"><ng-content select=\"[close-button]\" /></div>\n    </div>\n    <div class=\"hxp-permission-dialog-sub-title mat-title-medium\">\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.MANAGE_PERMISSION' | translate }}\n    </div>\n</div>\n", styles: [".hxp-permission-dialog-title{display:flex;flex-direction:column;padding-left:0;padding-right:0}.hxp-permission-dialog-title:before{content:none!important}.hxp-permissions-title{display:flex;align-items:center;flex-direction:row;flex:1;padding-bottom:16px}.hxp-permission-document-title{word-break:break-all;flex:1}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionInheritanceToggleComponent {
    constructor() {
        this.isInheritanceEnabled = true;
        this.toggleChange = new EventEmitter();
    }
    onToggleChange(isEnabled) {
        this.toggleChange.emit(isEnabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionInheritanceToggleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionInheritanceToggleComponent, isStandalone: true, selector: "hxp-permissions-inheritance-toggle", inputs: { isInheritanceEnabled: "isInheritanceEnabled" }, outputs: { toggleChange: "toggleChange" }, ngImport: i0, template: "<div class=\"hxp-inheritance-toggle-container\">\n    <mat-slide-toggle\n        [disableRipple]=\"true\"\n        [disabledInteractive]=\"true\"\n        [checked]=\"isInheritanceEnabled\"\n        (change)=\"onToggleChange($event.checked)\"\n        [hideIcon]=\"true\"\n        [labelPosition]=\"'before'\"\n        class=\"hxp-slide-toggle-inheritance\"\n    >\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.BLOCK_INHERITANCE.TITLE' | translate }}\n    </mat-slide-toggle>\n</div>\n", styles: [".hxp-inheritance-toggle-container{margin:8px 0}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatSlideToggleModule }, { kind: "component", type: i1$3.MatSlideToggle, selector: "mat-slide-toggle", inputs: ["name", "id", "labelPosition", "aria-label", "aria-labelledby", "aria-describedby", "required", "color", "disabled", "disableRipple", "tabIndex", "checked", "hideIcon", "disabledInteractive"], outputs: ["change", "toggleChange"], exportAs: ["matSlideToggle"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionInheritanceToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-inheritance-toggle', imports: [CommonModule, MatSlideToggleModule, TranslatePipe], encapsulation: ViewEncapsulation.None, template: "<div class=\"hxp-inheritance-toggle-container\">\n    <mat-slide-toggle\n        [disableRipple]=\"true\"\n        [disabledInteractive]=\"true\"\n        [checked]=\"isInheritanceEnabled\"\n        (change)=\"onToggleChange($event.checked)\"\n        [hideIcon]=\"true\"\n        [labelPosition]=\"'before'\"\n        class=\"hxp-slide-toggle-inheritance\"\n    >\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.BLOCK_INHERITANCE.TITLE' | translate }}\n    </mat-slide-toggle>\n</div>\n", styles: [".hxp-inheritance-toggle-container{margin:8px 0}\n"] }]
        }], propDecorators: { isInheritanceEnabled: [{
                type: Input
            }], toggleChange: [{
                type: Output
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionManagementContainerComponent {
    constructor() {
        this.destroyRef = inject(DestroyRef);
        this.permissionsManagementFacade = inject(PermissionsManagementFacade);
        this.documentService = inject(DocumentService);
        this.cancelEvent = new EventEmitter();
        this.closeEvent = new EventEmitter();
        this.restoreEvent = new EventEmitter();
        this.suggestedGroups$ = this.permissionsManagementFacade.suggestedGroups$;
        this.suggestedIndividuals$ = this.permissionsManagementFacade.suggestedIndividuals$;
        this.title$ = this.permissionsManagementFacade.api.title$;
        this.activePermissionsManagementRows$ = this.permissionsManagementFacade.api.activePermissionsManagementRows$;
        this.isUntouched$ = this.permissionsManagementFacade.api.isUntouched$;
        this.loading$ = this.permissionsManagementFacade.api.loading$;
        this.edited = false;
        this.isInheritanceEnabled$ = this.permissionsManagementFacade.api.isInheritanceEnabled$;
        this.hasLocalPermission$ = this.permissionsManagementFacade.api.hasLocalPermission$;
    }
    ngOnInit() {
        this.permissionsManagementFacade.onInitializePermissionsManagement(this.document, this.parentDocument, this.destroyRef);
        this.isUntouched$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
            next: (untouched) => (this.edited = !untouched),
            error: () => (this.edited = true),
        });
    }
    savePermissions() {
        this.saveDocumentPermissions()
            .pipe(filter$1(Boolean))
            .subscribe({
            next: () => {
                this.documentService.requestReload();
                this.closeEvent.emit();
            },
        });
    }
    restorePermissions(restoreOption) {
        this.restoreDocumentPermissions(restoreOption)
            .pipe(filter$1(Boolean))
            .subscribe({
            next: () => {
                this.documentService.requestReload();
                this.closeEvent.emit();
            },
        });
    }
    cancel() {
        this.cancelEvent.emit(this.edited);
    }
    closePermission() {
        this.closeEvent.emit(this.edited);
    }
    restore() {
        this.restoreEvent.emit();
    }
    onTabSelection(index) {
        const identityTypes = ['group', 'user'];
        this.permissionsManagementFacade.onUpdateActiveTab(identityTypes[index]);
    }
    onAddNewPermissionsManagementRow(newPermission) {
        this.permissionsManagementFacade.onAddNewPermissionsManagementRow(newPermission);
    }
    onEditPermissionsManagementRow(permission, permissionsManagementRow) {
        this.permissionsManagementFacade.onEditPermissionsManagementRow({ ...permissionsManagementRow, permission });
    }
    filterPermissionsManagementRowsByIndividual($event) {
        this.permissionsManagementFacade.onSearchUserField($event);
    }
    filterPermissionsManagementRowsByGroup($event) {
        this.permissionsManagementFacade.onSearchGroupField($event);
    }
    searchGroups($event) {
        this.permissionsManagementFacade.onNewGroupField($event);
    }
    searchIndividuals($event) {
        this.permissionsManagementFacade.onNewUserField($event);
    }
    onInheritanceStateChange(isEnabled) {
        this.permissionsManagementFacade.onUpdateInheritanceState(isEnabled);
    }
    saveDocumentPermissions() {
        return this.permissionsManagementFacade.updateDocumentAcl();
    }
    restoreDocumentPermissions(restoreOption) {
        return this.permissionsManagementFacade.restorePermissionsToInherited(restoreOption);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionManagementContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionManagementContainerComponent, isStandalone: true, selector: "hxp-permission-management-container", inputs: { document: "document", parentDocument: "parentDocument" }, outputs: { cancelEvent: "cancelEvent", closeEvent: "closeEvent", restoreEvent: "restoreEvent" }, providers: [PermissionsManagementFacade, PermissionsManagementStateService], queries: [{ propertyName: "titleTemplateRef", first: true, predicate: ["title"], descendants: true }], ngImport: i0, template: "<ng-template\n    #defaultTitle\n    let-title\n>\n    <hxp-permissions-document-title [title]=\"title || ''\">\n        <button\n            mat-icon-button\n            close-button\n            class=\"hxp-permission-dialog-cross\"\n            (click)=\"closePermission()\"\n        >\n            <mat-icon svgIcon=\"x_large\" />\n        </button>\n    </hxp-permissions-document-title>\n</ng-template>\n\n<ng-template *ngTemplateOutlet=\"titleTemplateRef || defaultTitle; context: { $implicit: (title$ | async) }\" />\n\n<hxp-permissions-inheritance-toggle\n    [isInheritanceEnabled]=\"isInheritanceEnabled$ | async\"\n    (toggleChange)=\"onInheritanceStateChange($event)\"\n/>\n<form class=\"hxp-permissions-form\">\n    <mat-tab-group\n        dynamicHeight\n        mat-stretch-tabs=\"true\"\n        (selectedIndexChange)=\"onTabSelection($event)\"\n        animationDuration=\"0ms\"\n    >\n        <mat-tab\n            class=\"hxp-permission-tabs\"\n            label=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.GROUPS' | translate }}\"\n        >\n            <hxp-permissions-table\n                *ngIf=\"activePermissionsManagementRows$ | async as activePermissionsManagementRows\"\n                [title]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ACCESS_LEVEL.GROUP' | translate\"\n                [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n            >\n                <hxp-permission-search\n                    permission-search\n                    id=\"hxp-permission-search-group\"\n                    [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                    placeHolder=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SEARCH_GROUP' | translate }}\"\n                    (search)=\"filterPermissionsManagementRowsByGroup($event)\"\n                />\n\n                <ng-template #entityColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.GROUPS' | translate\n                }}</ng-template>\n                <ng-template #inheritedPermissionColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.INHERITED' | translate\n                }}</ng-template>\n                <ng-template #fileColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.FILE_LEVEL' | translate\n                }}</ng-template>\n\n                <ng-template\n                    #entityCell\n                    let-row\n                >\n                    <div class=\"hxp-entity-details\">\n                        <div\n                            class=\"hxp-group-details-label\"\n                            [class.hxp-disabled-entity]=\"row.inheritedPermission === 'Everything'\"\n                        >\n                            <mat-icon svgIcon=\"user_group\" />\n                            <span\n                                class=\"hxp-entity-label\"\n                                [matTooltip]=\"row.entityLabel\"\n                                >{{ row.entityLabel }}</span\n                            >\n                        </div>\n                    </div>\n                </ng-template>\n\n                <ng-template\n                    #inheritedPermissionCell\n                    let-row\n                >\n                    <hxp-inherited-permission\n                        [permission]=\"row.inheritedPermission\"\n                        [inheritanceEnabled]=\"isInheritanceEnabled$ | async\"\n                    />\n                </ng-template>\n\n                <ng-template\n                    #fileCell\n                    let-row\n                >\n                    <ng-container *ngIf=\"(isInheritanceEnabled$ | async) === true && row.inheritedPermission === 'Everything'; else editableField\">\n                        <div class=\"hxp-cannot-be-changed\">{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.CANNOT_BE_CHANGED' | translate }}</div>\n                    </ng-container>\n\n                    <ng-template #editableField>\n                        <hxp-permissions\n                            [permission]=\"row.permission\"\n                            [inheritedPermission]=\"row.inheritedPermission\"\n                            [inheritanceEnabled]=\"(isInheritanceEnabled$ | async) || false\"\n                            (changePermission)=\"onEditPermissionsManagementRow($event, row)\"\n                        />\n                    </ng-template>\n                </ng-template>\n\n                <ng-template #emptyTable>\n                    <hxp-permissions-empty-table [message]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.GROUP' | translate\" />\n                </ng-template>\n            </hxp-permissions-table>\n\n            <hxp-add-permission\n                id=\"hxp-add-user-group\"\n                [suggestions]=\"(suggestedGroups$ | async) || []\"\n                [loading]=\"(loading$ | async) || false\"\n                searchPlaceholderText=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_GROUP' | translate }}\"\n                addButtonLabel=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_GROUP' | translate }}\"\n                (search)=\"searchGroups($event)\"\n                (addNewPermission)=\"onAddNewPermissionsManagementRow($event)\"\n            >\n                <ng-container title>\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.LABEL.GROUP' | translate }}\n                </ng-container>\n            </hxp-add-permission>\n        </mat-tab>\n\n        <mat-tab label=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.USERS' | translate }}\">\n            <div class=\"hxp-tab-content\">\n                <hxp-permissions-table\n                    *ngIf=\"activePermissionsManagementRows$ | async as activePermissionsManagementRows\"\n                    [title]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ACCESS_LEVEL.USER' | translate\"\n                    [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                >\n                    <hxp-permission-search\n                        permission-search\n                        id=\"hxp-permission-search-user\"\n                        [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                        placeHolder=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SEARCH_USER' | translate }}\"\n                        (search)=\"filterPermissionsManagementRowsByIndividual($event)\"\n                    />\n\n                    <ng-template #entityColumnHeader>{{\n                        'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.USERS' | translate\n                    }}</ng-template>\n                    <ng-template #fileColumnHeader>{{\n                        'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.FILE_ACCESS' | translate\n                    }}</ng-template>\n\n                    <ng-template\n                        #entityCell\n                        let-row\n                    >\n                        <div class=\"hxp-entity-details\">\n                            <div\n                                class=\"hxp-entity-label\"\n                                [matTooltip]=\"row.entityLabel\"\n                            >\n                                {{ row.entityLabel }}\n                            </div>\n                            <div\n                                *ngIf=\"row.inherited\"\n                                class=\"hxp-users-icon\"\n                            >\n                                <mat-icon svgIcon=\"user\" />\n                                <ng-container *ngIf=\"!row.overridden; else overriddenPermission\">\n                                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED_PERMISSION' | translate }}\n                                </ng-container>\n                                <ng-template #overriddenPermission>\n                                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.OVERRIDDEN_PERMISSION' | translate }}\n                                </ng-template>\n                            </div>\n                        </div>\n                    </ng-template>\n\n                    <ng-template\n                        #fileCell\n                        let-row\n                    >\n                        <hxp-permissions\n                            [permission]=\"row.permission\"\n                            [disabled]=\"!row.overridden && row.inherited\"\n                            [inheritedPermission]=\"row.inheritedPermission\"\n                            (changePermission)=\"onEditPermissionsManagementRow($event, row)\"\n                        />\n                    </ng-template>\n\n                    <ng-template #emptyTable>\n                        <hxp-permissions-empty-table [message]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.USER' | translate\" />\n                    </ng-template>\n                </hxp-permissions-table>\n\n                <hxp-add-permission\n                    id=\"hxp-add-user\"\n                    [suggestions]=\"(suggestedIndividuals$ | async) || []\"\n                    [loading]=\"(loading$ | async) || false\"\n                    searchPlaceholderText=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_USER' | translate }}\"\n                    addButtonLabel=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_USER' | translate }}\"\n                    (search)=\"searchIndividuals($event)\"\n                    (addNewPermission)=\"onAddNewPermissionsManagementRow($event)\"\n                >\n                    <ng-container title>\n                        {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.LABEL.USER' | translate }}\n                    </ng-container>\n                </hxp-add-permission>\n            </div>\n        </mat-tab>\n    </mat-tab-group>\n</form>\n<div class=\"hxp-permissions-actions\">\n    <div class=\"hxp-left-actions\">\n        <button\n            mat-button\n            class=\"hxp-restore-button\"\n            [disabled]=\"(hasLocalPermission$ | async) === false\"\n            (click)=\"restore()\"\n        >\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.RESTORE' | translate }}\n        </button>\n    </div>\n    <div class=\"hxp-right-actions\">\n        <button\n            mat-button\n            class=\"hxp-cancel-button\"\n            (click)=\"cancel()\"\n        >\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.CANCEL' | translate }}\n        </button>\n\n        <button\n            class=\"hxp-save-permission-button\"\n            mat-flat-button\n            [disabled]=\"isUntouched$ | async\"\n            (click)=\"savePermissions()\"\n        >\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.SAVE' | translate }}\n        </button>\n    </div>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%;overflow:hidden}.hxp-permissions-form{flex:1;display:flex;flex-direction:column;overflow-y:auto;min-height:0;padding-bottom:18px}.hxp-permissions-form .hxp-permissions-tabs{flex:1;display:grid;grid-template-rows:auto 1fr;overflow:hidden;min-height:0}.hxp-tab-content{overflow:hidden}.hxp-permissions-actions{display:flex;justify-content:space-between;text-align:center;flex-shrink:0;padding-top:20px;border-top:1px solid var(--mat-sys-outline-variant)}.hxp-permissions-actions .hxp-left-actions{display:flex;align-items:center}.hxp-permissions-actions .hxp-right-actions{display:flex;gap:8px;align-items:center}.hxp-permission-container{display:flex;width:100%}.hxp-entity-label{overflow:hidden;text-overflow:ellipsis}.hxp-entity-details{display:flex;flex-direction:column;justify-content:center;height:100%}.hxp-entity-details .hxp-group-details-label{display:flex;flex-wrap:wrap;align-items:center;gap:8px}.hxp-users-icon{display:flex;flex-direction:row;align-items:center;gap:8px;color:var(--mat-sys-primary);font-size:var(--mat-body-small-size)}.hxp-disabled-entity{color:var(--mat-disabled-text-color)}.hxp-cannot-be-changed{color:var(--sat-sys-on-neutral-container);font-size:var(--mat-body-small-size);white-space:nowrap}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "component", type: i3$4.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i3$4.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "component", type: PermissionsTableComponent, selector: "hxp-permissions-table", inputs: ["title", "activePermissionsManagementRows"] }, { kind: "component", type: PermissionsSearchComponent, selector: "hxp-permission-search", inputs: ["placeHolder", "activePermissionsManagementRows"], outputs: ["search"] }, { kind: "component", type: PermissionsComponent, selector: "hxp-permissions", inputs: ["permission", "inheritedPermission", "inheritanceEnabled", "disabled"], outputs: ["changePermission"] }, { kind: "component", type: InheritedPermissionComponent, selector: "hxp-inherited-permission", inputs: ["permission", "inheritanceEnabled"] }, { kind: "component", type: AddPermissionComponent, selector: "hxp-add-permission", inputs: ["suggestions", "addButtonLabel", "searchPlaceholderText", "loading"], outputs: ["addNewPermission", "search"] }, { kind: "ngmodule", type: MatSnackBarModule }, { kind: "component", type: PermissionEmptyTableComponent, selector: "hxp-permissions-empty-table", inputs: ["message"] }, { kind: "component", type: PermissionsDocumentTitleComponent, selector: "hxp-permissions-document-title", inputs: ["title"] }, { kind: "component", type: PermissionInheritanceToggleComponent, selector: "hxp-permissions-inheritance-toggle", inputs: ["isInheritanceEnabled"], outputs: ["toggleChange"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$4.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionManagementContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permission-management-container', imports: [
                        NgIf,
                        AsyncPipe,
                        MatDialogModule,
                        MatButtonModule,
                        MatTabsModule,
                        MatIconModule,
                        MatTooltip,
                        TranslatePipe,
                        PermissionsTableComponent,
                        PermissionsSearchComponent,
                        PermissionsComponent,
                        InheritedPermissionComponent,
                        AddPermissionComponent,
                        MatSnackBarModule,
                        PermissionEmptyTableComponent,
                        PermissionsDocumentTitleComponent,
                        MatIconModule,
                        PermissionInheritanceToggleComponent,
                        CommonModule,
                    ], providers: [PermissionsManagementFacade, PermissionsManagementStateService], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-template\n    #defaultTitle\n    let-title\n>\n    <hxp-permissions-document-title [title]=\"title || ''\">\n        <button\n            mat-icon-button\n            close-button\n            class=\"hxp-permission-dialog-cross\"\n            (click)=\"closePermission()\"\n        >\n            <mat-icon svgIcon=\"x_large\" />\n        </button>\n    </hxp-permissions-document-title>\n</ng-template>\n\n<ng-template *ngTemplateOutlet=\"titleTemplateRef || defaultTitle; context: { $implicit: (title$ | async) }\" />\n\n<hxp-permissions-inheritance-toggle\n    [isInheritanceEnabled]=\"isInheritanceEnabled$ | async\"\n    (toggleChange)=\"onInheritanceStateChange($event)\"\n/>\n<form class=\"hxp-permissions-form\">\n    <mat-tab-group\n        dynamicHeight\n        mat-stretch-tabs=\"true\"\n        (selectedIndexChange)=\"onTabSelection($event)\"\n        animationDuration=\"0ms\"\n    >\n        <mat-tab\n            class=\"hxp-permission-tabs\"\n            label=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.GROUPS' | translate }}\"\n        >\n            <hxp-permissions-table\n                *ngIf=\"activePermissionsManagementRows$ | async as activePermissionsManagementRows\"\n                [title]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ACCESS_LEVEL.GROUP' | translate\"\n                [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n            >\n                <hxp-permission-search\n                    permission-search\n                    id=\"hxp-permission-search-group\"\n                    [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                    placeHolder=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SEARCH_GROUP' | translate }}\"\n                    (search)=\"filterPermissionsManagementRowsByGroup($event)\"\n                />\n\n                <ng-template #entityColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.GROUPS' | translate\n                }}</ng-template>\n                <ng-template #inheritedPermissionColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.INHERITED' | translate\n                }}</ng-template>\n                <ng-template #fileColumnHeader>{{\n                    'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.FILE_LEVEL' | translate\n                }}</ng-template>\n\n                <ng-template\n                    #entityCell\n                    let-row\n                >\n                    <div class=\"hxp-entity-details\">\n                        <div\n                            class=\"hxp-group-details-label\"\n                            [class.hxp-disabled-entity]=\"row.inheritedPermission === 'Everything'\"\n                        >\n                            <mat-icon svgIcon=\"user_group\" />\n                            <span\n                                class=\"hxp-entity-label\"\n                                [matTooltip]=\"row.entityLabel\"\n                                >{{ row.entityLabel }}</span\n                            >\n                        </div>\n                    </div>\n                </ng-template>\n\n                <ng-template\n                    #inheritedPermissionCell\n                    let-row\n                >\n                    <hxp-inherited-permission\n                        [permission]=\"row.inheritedPermission\"\n                        [inheritanceEnabled]=\"isInheritanceEnabled$ | async\"\n                    />\n                </ng-template>\n\n                <ng-template\n                    #fileCell\n                    let-row\n                >\n                    <ng-container *ngIf=\"(isInheritanceEnabled$ | async) === true && row.inheritedPermission === 'Everything'; else editableField\">\n                        <div class=\"hxp-cannot-be-changed\">{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.CANNOT_BE_CHANGED' | translate }}</div>\n                    </ng-container>\n\n                    <ng-template #editableField>\n                        <hxp-permissions\n                            [permission]=\"row.permission\"\n                            [inheritedPermission]=\"row.inheritedPermission\"\n                            [inheritanceEnabled]=\"(isInheritanceEnabled$ | async) || false\"\n                            (changePermission)=\"onEditPermissionsManagementRow($event, row)\"\n                        />\n                    </ng-template>\n                </ng-template>\n\n                <ng-template #emptyTable>\n                    <hxp-permissions-empty-table [message]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.GROUP' | translate\" />\n                </ng-template>\n            </hxp-permissions-table>\n\n            <hxp-add-permission\n                id=\"hxp-add-user-group\"\n                [suggestions]=\"(suggestedGroups$ | async) || []\"\n                [loading]=\"(loading$ | async) || false\"\n                searchPlaceholderText=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_GROUP' | translate }}\"\n                addButtonLabel=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_GROUP' | translate }}\"\n                (search)=\"searchGroups($event)\"\n                (addNewPermission)=\"onAddNewPermissionsManagementRow($event)\"\n            >\n                <ng-container title>\n                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.LABEL.GROUP' | translate }}\n                </ng-container>\n            </hxp-add-permission>\n        </mat-tab>\n\n        <mat-tab label=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.USERS' | translate }}\">\n            <div class=\"hxp-tab-content\">\n                <hxp-permissions-table\n                    *ngIf=\"activePermissionsManagementRows$ | async as activePermissionsManagementRows\"\n                    [title]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ACCESS_LEVEL.USER' | translate\"\n                    [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                >\n                    <hxp-permission-search\n                        permission-search\n                        id=\"hxp-permission-search-user\"\n                        [activePermissionsManagementRows]=\"activePermissionsManagementRows\"\n                        placeHolder=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SEARCH_USER' | translate }}\"\n                        (search)=\"filterPermissionsManagementRowsByIndividual($event)\"\n                    />\n\n                    <ng-template #entityColumnHeader>{{\n                        'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.USERS' | translate\n                    }}</ng-template>\n                    <ng-template #fileColumnHeader>{{\n                        'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.COLUMN_HEADER.FILE_ACCESS' | translate\n                    }}</ng-template>\n\n                    <ng-template\n                        #entityCell\n                        let-row\n                    >\n                        <div class=\"hxp-entity-details\">\n                            <div\n                                class=\"hxp-entity-label\"\n                                [matTooltip]=\"row.entityLabel\"\n                            >\n                                {{ row.entityLabel }}\n                            </div>\n                            <div\n                                *ngIf=\"row.inherited\"\n                                class=\"hxp-users-icon\"\n                            >\n                                <mat-icon svgIcon=\"user\" />\n                                <ng-container *ngIf=\"!row.overridden; else overriddenPermission\">\n                                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.INHERITED_PERMISSION' | translate }}\n                                </ng-container>\n                                <ng-template #overriddenPermission>\n                                    {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.OVERRIDDEN_PERMISSION' | translate }}\n                                </ng-template>\n                            </div>\n                        </div>\n                    </ng-template>\n\n                    <ng-template\n                        #fileCell\n                        let-row\n                    >\n                        <hxp-permissions\n                            [permission]=\"row.permission\"\n                            [disabled]=\"!row.overridden && row.inherited\"\n                            [inheritedPermission]=\"row.inheritedPermission\"\n                            (changePermission)=\"onEditPermissionsManagementRow($event, row)\"\n                        />\n                    </ng-template>\n\n                    <ng-template #emptyTable>\n                        <hxp-permissions-empty-table [message]=\"'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.NO_PERMISSION.USER' | translate\" />\n                    </ng-template>\n                </hxp-permissions-table>\n\n                <hxp-add-permission\n                    id=\"hxp-add-user\"\n                    [suggestions]=\"(suggestedIndividuals$ | async) || []\"\n                    [loading]=\"(loading$ | async) || false\"\n                    searchPlaceholderText=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.SELECT_USER' | translate }}\"\n                    addButtonLabel=\"{{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.ADD_USER' | translate }}\"\n                    (search)=\"searchIndividuals($event)\"\n                    (addNewPermission)=\"onAddNewPermissionsManagementRow($event)\"\n                >\n                    <ng-container title>\n                        {{ 'PERMISSIONS_MANAGEMENT_ACTION.PERMISSIONS_TABLE.LABEL.USER' | translate }}\n                    </ng-container>\n                </hxp-add-permission>\n            </div>\n        </mat-tab>\n    </mat-tab-group>\n</form>\n<div class=\"hxp-permissions-actions\">\n    <div class=\"hxp-left-actions\">\n        <button\n            mat-button\n            class=\"hxp-restore-button\"\n            [disabled]=\"(hasLocalPermission$ | async) === false\"\n            (click)=\"restore()\"\n        >\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.RESTORE' | translate }}\n        </button>\n    </div>\n    <div class=\"hxp-right-actions\">\n        <button\n            mat-button\n            class=\"hxp-cancel-button\"\n            (click)=\"cancel()\"\n        >\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.CANCEL' | translate }}\n        </button>\n\n        <button\n            class=\"hxp-save-permission-button\"\n            mat-flat-button\n            [disabled]=\"isUntouched$ | async\"\n            (click)=\"savePermissions()\"\n        >\n            {{ 'PERMISSIONS_MANAGEMENT_ACTION.DIALOG.SAVE' | translate }}\n        </button>\n    </div>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%;overflow:hidden}.hxp-permissions-form{flex:1;display:flex;flex-direction:column;overflow-y:auto;min-height:0;padding-bottom:18px}.hxp-permissions-form .hxp-permissions-tabs{flex:1;display:grid;grid-template-rows:auto 1fr;overflow:hidden;min-height:0}.hxp-tab-content{overflow:hidden}.hxp-permissions-actions{display:flex;justify-content:space-between;text-align:center;flex-shrink:0;padding-top:20px;border-top:1px solid var(--mat-sys-outline-variant)}.hxp-permissions-actions .hxp-left-actions{display:flex;align-items:center}.hxp-permissions-actions .hxp-right-actions{display:flex;gap:8px;align-items:center}.hxp-permission-container{display:flex;width:100%}.hxp-entity-label{overflow:hidden;text-overflow:ellipsis}.hxp-entity-details{display:flex;flex-direction:column;justify-content:center;height:100%}.hxp-entity-details .hxp-group-details-label{display:flex;flex-wrap:wrap;align-items:center;gap:8px}.hxp-users-icon{display:flex;flex-direction:row;align-items:center;gap:8px;color:var(--mat-sys-primary);font-size:var(--mat-body-small-size)}.hxp-disabled-entity{color:var(--mat-disabled-text-color)}.hxp-cannot-be-changed{color:var(--sat-sys-on-neutral-container);font-size:var(--mat-body-small-size);white-space:nowrap}\n"] }]
        }], propDecorators: { document: [{
                type: Input
            }], parentDocument: [{
                type: Input
            }], cancelEvent: [{
                type: Output
            }], closeEvent: [{
                type: Output
            }], restoreEvent: [{
                type: Output
            }], titleTemplateRef: [{
                type: ContentChild,
                args: ['title', { static: false }]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class RestorePermissionDialogComponent {
    constructor() {
        this.restoreOption = UserType.ALL;
        this.dialogRef = inject(MatDialogRef);
    }
    reject() {
        this.dialogRef.close();
    }
    confirm() {
        this.dialogRef.close({ restore: true, option: this.restoreOption });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RestorePermissionDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: RestorePermissionDialogComponent, isStandalone: true, selector: "hxp-restore-permission-dialog", ngImport: i0, template: "<h1 mat-dialog-title>{{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.TITLE' | translate }}</h1>\n<div mat-dialog-content>\n    <p>{{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.DESCRIPTION' | translate }}</p>\n    <ng-container>\n        <mat-radio-group\n            [(ngModel)]=\"restoreOption\"\n            class=\"hxp-permission-reset-options\"\n        >\n            <mat-radio-button value=\"ALL\">\n                {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.ALL' | translate }}\n            </mat-radio-button>\n            <mat-radio-button value=\"GROUPS\">\n                {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.GROUP' | translate }}\n            </mat-radio-button>\n            <mat-radio-button value=\"USERS\">\n                {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.USER' | translate }}\n            </mat-radio-button>\n        </mat-radio-group>\n    </ng-container>\n</div>\n<mat-dialog-actions>\n    <button\n        mat-button\n        class=\"hxp-permission-dialog-reject-button\"\n        (click)=\"reject()\"\n    >\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.REJECT' | translate }}\n    </button>\n    <button\n        mat-flat-button\n        class=\"hxp-permission-dialog-confirm-button\"\n        (click)=\"confirm()\"\n    >\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.CONFIRM' | translate }}\n    </button>\n</mat-dialog-actions>\n", dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatRadioModule }, { kind: "directive", type: i3$5.MatRadioGroup, selector: "mat-radio-group", inputs: ["color", "name", "labelPosition", "value", "selected", "disabled", "required", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioGroup"] }, { kind: "component", type: i3$5.MatRadioButton, selector: "mat-radio-button", inputs: ["id", "name", "aria-label", "aria-labelledby", "aria-describedby", "disableRipple", "tabIndex", "checked", "value", "labelPosition", "disabled", "required", "color", "disabledInteractive"], outputs: ["change"], exportAs: ["matRadioButton"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RestorePermissionDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-restore-permission-dialog', encapsulation: ViewEncapsulation.None, imports: [MatDialogModule, MatButtonModule, MatRadioModule, FormsModule, TranslatePipe], template: "<h1 mat-dialog-title>{{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.TITLE' | translate }}</h1>\n<div mat-dialog-content>\n    <p>{{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.DESCRIPTION' | translate }}</p>\n    <ng-container>\n        <mat-radio-group\n            [(ngModel)]=\"restoreOption\"\n            class=\"hxp-permission-reset-options\"\n        >\n            <mat-radio-button value=\"ALL\">\n                {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.ALL' | translate }}\n            </mat-radio-button>\n            <mat-radio-button value=\"GROUPS\">\n                {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.GROUP' | translate }}\n            </mat-radio-button>\n            <mat-radio-button value=\"USERS\">\n                {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.RESTORE_OPTION.USER' | translate }}\n            </mat-radio-button>\n        </mat-radio-group>\n    </ng-container>\n</div>\n<mat-dialog-actions>\n    <button\n        mat-button\n        class=\"hxp-permission-dialog-reject-button\"\n        (click)=\"reject()\"\n    >\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.REJECT' | translate }}\n    </button>\n    <button\n        mat-flat-button\n        class=\"hxp-permission-dialog-confirm-button\"\n        (click)=\"confirm()\"\n    >\n        {{ 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_RESTORE_DIALOG.CONFIRM' | translate }}\n    </button>\n</mat-dialog-actions>\n" }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DIALOG_MIN_WIDTH = 436;
/**
 * This component is responsible for managing the permissions in the form of dialog.
 * The dialog overlay prevent the user to interact with the rest of the application.
 *
 * It includes functionalities to add, edit, and display permissions to `User`s and `Group`s.
 *
 * Available permissions are `Read`, `Write` and `Everything`.
 *
 * Permissions are inherited from the parent `Document`.
 * It's possible to only upgrade a inherited permission.
 *
 * To use the `PermissionsManagementPanelComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { MatDialog } from '@angular/material/dialog';
 * import { PermissionsManagementPanelComponent } from '@alfresco/adf-hx-content-services/ui';
 * import { PermissionsManagementDialogData } from '@alfresco/adf-hx-content-services/services';
 *
 * @Component({
 *     template: '<button (click)="openPermissionsManagementDialog(document)">{{ document.sys_title }}</button>',
 * })
 * class OpenDialogButtonComponent {
 *
 *     constructor(
 *         private dialog: MatDialog,
 *     ) {}
 *
 *     openPermissionsManagementDialog(document: Document) {
 *         this.dialog.open<
 *             PermissionsManagementDialogComponent,
 *             PermissionsManagementDialogData
 *         >(PermissionsManagementDialogComponent, {
 *             data: { document }
 *          });
 *     }
 * }
 * ```
 */
class PermissionsManagementDialogComponent extends DismissPermission {
    constructor() {
        super(...arguments);
        this.data = inject(MAT_DIALOG_DATA);
        this.dialog = inject(MatDialog);
        this.dialogRef = inject(MatDialogRef);
        /**
         * The `Document` to display and manage permissions for.
         *
         * To pass the `Document` open the dialog and provide `MAT_DIALOG_DATA` as `PermissionsManagementDialogData`.
         *
         * ```ts
         * interface PermissionsManagementDialogData {
         *     document: Document;
         *     parentDocument?: Document;
         * }
         * ```
         *
         * @type {Document}
         */
        this.document = this.data.document;
        this.parentDocument = this.data.parentDocument;
    }
    cancel(isEdited) {
        if (!isEdited) {
            return this.dialogRef.close();
        }
        this.dialog.open(CancelPermissionDialogComponent, {
            width: DialogConfig.small.width,
            data: {
                dialogTitle: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.TITLE',
                dialogDescription: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.DESCRIPTION',
                dialogRejectButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.REJECT',
                dialogConfirmButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.CONFIRM',
                permissionDialogRef: this.dialogRef,
            },
        });
    }
    close(isEdited) {
        if (!isEdited) {
            return this.dialogRef.close();
        }
        const closeDialogRef = this.dialog.open(ClosePermissionDialogComponent, {
            width: DialogConfig.small.width,
            data: {
                dialogTitle: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_SAVE_DIALOG.TITLE',
                dialogDescription: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_SAVE_DIALOG.DESCRIPTION',
                dialogRejectButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_SAVE_DIALOG.REJECT',
                dialogConfirmButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_SAVE_DIALOG.CONFIRM',
            },
        });
        closeDialogRef.afterClosed().subscribe((result) => {
            this.dialogRef.close();
            if (result.save) {
                this.container.savePermissions();
            }
        });
    }
    restore() {
        const restoreDialogRef = this.dialog.open(RestorePermissionDialogComponent, {
            width: DialogConfig.small.width,
        });
        restoreDialogRef.afterClosed().subscribe((result) => {
            if (result?.restore) {
                this.container.restorePermissions(result.option);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementDialogComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionsManagementDialogComponent, isStandalone: true, selector: "hxp-permissions-management-dialog", providers: [PermissionsManagementStateService], viewQueries: [{ propertyName: "container", first: true, predicate: PermissionManagementContainerComponent, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div\n    mat-dialog-content\n    class=\"hxp-permissions-management-dialog\"\n>\n    <hxp-permission-management-container\n        [document]=\"document\"\n        [parentDocument]=\"parentDocument\"\n        (cancelEvent)=\"cancel($event)\"\n        (closeEvent)=\"close($event)\"\n        (restoreEvent)=\"restore()\"\n    />\n</div>\n", styles: [":host{display:block;height:100%}.hxp-permissions-management-dialog{display:flex;flex-direction:column;height:100vh;max-height:100vh;overflow:hidden}.hxp-permissions-management-dialog hxp-permission-management-container{flex:1;display:flex;flex-direction:column;min-height:0}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "component", type: PermissionManagementContainerComponent, selector: "hxp-permission-management-container", inputs: ["document", "parentDocument"], outputs: ["cancelEvent", "closeEvent", "restoreEvent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-management-dialog', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatDialogModule, PermissionManagementContainerComponent], providers: [PermissionsManagementStateService], template: "<div\n    mat-dialog-content\n    class=\"hxp-permissions-management-dialog\"\n>\n    <hxp-permission-management-container\n        [document]=\"document\"\n        [parentDocument]=\"parentDocument\"\n        (cancelEvent)=\"cancel($event)\"\n        (closeEvent)=\"close($event)\"\n        (restoreEvent)=\"restore()\"\n    />\n</div>\n", styles: [":host{display:block;height:100%}.hxp-permissions-management-dialog{display:flex;flex-direction:column;height:100vh;max-height:100vh;overflow:hidden}.hxp-permissions-management-dialog hxp-permission-management-container{flex:1;display:flex;flex-direction:column;min-height:0}\n"] }]
        }], propDecorators: { container: [{
                type: ViewChild,
                args: [PermissionManagementContainerComponent]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsButtonActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.sidebarService = inject(SidebarService);
        this.dialog = inject(MatDialog);
        this.permissionsPanelRequestService = inject(PermissionsPanelRequestService);
        this.componentType = inject(PERMISSIONS_MANAGEMENT_COMPONENT_TYPE, { optional: true }) ?? 'dialog';
    }
    isAvailable(context) {
        return (context.documents?.length > 0 &&
            hasPermission(context.documents[0], DocumentPermissions.WRITE) &&
            hasPermission(context.documents[0], DocumentPermissions.MANAGE_SECURITY) &&
            !isVersion(context.documents[0]));
    }
    execute(context) {
        if (context.documents?.length > 0) {
            const isDialog = this.componentType === 'dialog';
            if (isDialog) {
                this.openPermissionsManagementDialog({
                    document: context.documents[0],
                    parentDocument: context.parentDocument,
                });
                this.sidebarService.closePanel();
            }
            else {
                this.permissionsPanelRequestService.requestOpenPanel();
            }
        }
    }
    openPermissionsManagementDialog(permissionsManagementDialogData) {
        this.dialog.open(PermissionsManagementDialogComponent, {
            width: DIALOG_MIN_WIDTH + 'px',
            height: '100vh',
            position: { top: '0px', right: '0px' },
            data: permissionsManagementDialogData,
            disableClose: true,
            panelClass: 'hxp-right-aligned-dialog',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsButtonActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsButtonActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ContentPropertyViewerActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.sidebarService = inject(SidebarService);
    }
    isAvailable(context) {
        return context.documents?.length === 1 && hasPermission(context.documents[0], DocumentPermissions.READ);
    }
    execute() {
        this.sidebarService.togglePanel('property');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentPropertyViewerActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentPropertyViewerActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentPropertyViewerActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionDeleteConfirmationDialogComponent {
    constructor() {
        this.isDeleting = false;
        this.dialogData = inject(MAT_DIALOG_DATA);
        this.dialogRef = inject(MatDialogRef);
        this.documentVersionsService = inject(DocumentVersionsService);
        this.documentService = inject(DocumentService);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.documentRouterService = inject(DocumentRouterService);
        this.version = this.dialogData.version;
        this.parentId = this.dialogData.parentId;
    }
    onDelete() {
        this.isDeleting = true;
        let success = false;
        this.documentVersionsService.deleteVersion(this.version).subscribe({
            next: () => {
                this.hxpNotificationService.showSuccess('MANAGE_VERSIONS.DELETE_DIALOG.NOTIFICATION.SUCCESS');
                success = true;
            },
            error: (error) => {
                console.error(error);
                this.hxpNotificationService.showError('MANAGE_VERSIONS.DELETE_DIALOG.NOTIFICATION.ERROR');
                this.isDeleting = false;
            },
            complete: () => {
                this.isDeleting = false;
                this.dialogRef.close();
                if (success) {
                    this.documentService.documentLoaded$
                        .pipe(take(1), switchMap$1((document) => document?.sys_id === this.version.sys_id ? this.documentService.getDocumentById(this.parentId).pipe(take(1)) : EMPTY), map$1((parentDocument) => parentDocument))
                        // eslint-disable-next-line rxjs/no-nested-subscribe
                        .subscribe((parentDocument) => {
                        if (parentDocument) {
                            this.documentRouterService.navigateTo(parentDocument);
                        }
                    });
                }
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionDeleteConfirmationDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: VersionDeleteConfirmationDialogComponent, isStandalone: true, selector: "hxp-version-delete-confirmation-dialog", ngImport: i0, template: "<h1 mat-dialog-title>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.TITLE' | translate }}</h1>\n<div\n    mat-dialog-content\n    class=\"hxp-fixed-dialog-content-height\"\n>\n    <p>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.DESCRIPTION' | translate }}</p>\n</div>\n<mat-dialog-actions [align]=\"'end'\">\n    <button\n        mat-button\n        mat-dialog-close\n    >\n        {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.CANCEL' | translate }}\n    </button>\n    <button\n        mat-flat-button\n        class=\"hxp-version-delete-button\"\n        [class.hxp-disable-btn]=\"isDeleting\"\n        (click)=\"onDelete()\"\n    >\n        <span class=\"hxp-version-delete-button-label\">\n            @if (isDeleting) {\n                <mat-progress-spinner\n                    mode=\"indeterminate\"\n                    diameter=\"15\"\n                />\n            }\n            {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.DELETE' | translate }}\n        </span>\n    </button>\n</mat-dialog-actions>\n", styles: [".hxp-version-delete-button{--mdc-filled-button-container-color: var(--sat-sys-important-loud-container);--mdc-filled-button-label-text-color: var(--sat-sys-on-important-loud-container);--mdc-circular-progress-active-indicator-color: var(--sat-sys-on-important-loud-container)}.hxp-version-delete-button .hxp-version-delete-button-label{display:flex;align-items:center;gap:10px}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i3$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionDeleteConfirmationDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-version-delete-confirmation-dialog', imports: [MatDialogModule, MatIconModule, MatButtonModule, MatProgressSpinnerModule, TranslatePipe], template: "<h1 mat-dialog-title>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.TITLE' | translate }}</h1>\n<div\n    mat-dialog-content\n    class=\"hxp-fixed-dialog-content-height\"\n>\n    <p>{{ 'MANAGE_VERSIONS.DELETE_DIALOG.DESCRIPTION' | translate }}</p>\n</div>\n<mat-dialog-actions [align]=\"'end'\">\n    <button\n        mat-button\n        mat-dialog-close\n    >\n        {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.CANCEL' | translate }}\n    </button>\n    <button\n        mat-flat-button\n        class=\"hxp-version-delete-button\"\n        [class.hxp-disable-btn]=\"isDeleting\"\n        (click)=\"onDelete()\"\n    >\n        <span class=\"hxp-version-delete-button-label\">\n            @if (isDeleting) {\n                <mat-progress-spinner\n                    mode=\"indeterminate\"\n                    diameter=\"15\"\n                />\n            }\n            {{ 'MANAGE_VERSIONS.DELETE_DIALOG.BUTTONS.DELETE' | translate }}\n        </span>\n    </button>\n</mat-dialog-actions>\n", styles: [".hxp-version-delete-button{--mdc-filled-button-container-color: var(--sat-sys-important-loud-container);--mdc-filled-button-label-text-color: var(--sat-sys-on-important-loud-container);--mdc-circular-progress-active-indicator-color: var(--sat-sys-on-important-loud-container)}.hxp-version-delete-button .hxp-version-delete-button-label{display:flex;align-items:center;gap:10px}\n"] }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionDeleteButtonActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.dialog = inject(MatDialog);
    }
    isAvailable(context) {
        return (!!context.documents &&
            context.documents.length === 1 &&
            isVersion(context.documents[0]) &&
            hasPermission(context.documents[0], DocumentPermissions.DELETE) &&
            !!context.parentDocument &&
            hasPermission(context.parentDocument, DocumentPermissions.DELETE_CHILD));
    }
    execute(context) {
        const document = context.documents[0];
        this.dialog.open(VersionDeleteConfirmationDialogComponent, {
            data: {
                version: document,
                shouldRedirect: context.shouldRedirect || false,
                parentId: document.sys_parentId || '',
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionDeleteButtonActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionDeleteButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionDeleteButtonActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionEditDialogComponent {
    constructor() {
        this.isUpdating = false;
        this.dateFormat = 'medium';
        this.version = inject(MAT_DIALOG_DATA);
        this.fb = inject(FormBuilder);
        this.datePipe = inject(DatePipe);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.dialogRef = inject(MatDialogRef);
        this.documentVersionService = inject(DocumentVersionsService);
    }
    ngOnInit() {
        this.form = this.fb.group({
            sysver_title: [
                this.version?.sysver_title ||
                    this.datePipe.transform(this.version.sys_modified, this.dateFormat) ||
                    this.datePipe.transform(this.version.sysver_created, this.dateFormat) ||
                    '',
                Validators.required,
            ],
            sysver_description: [this.version?.sysver_description || ''],
        });
    }
    onSave() {
        if (this.form.invalid) {
            return;
        }
        this.isUpdating = true;
        const updatedVersion = {
            sys_id: this.version.sys_id,
            sysver_title: this.form.get('sysver_title')?.value,
            sysver_description: this.form.get('sysver_description')?.value,
        };
        this.documentVersionService.updateVersion(updatedVersion).subscribe({
            next: () => {
                this.hxpNotificationService.showSuccess('MANAGE_VERSIONS.EDIT_DIALOG.NOTIFICATION.SUCCESS');
            },
            error: (error) => {
                console.error(error);
                this.hxpNotificationService.showError('MANAGE_VERSIONS.EDIT_DIALOG.NOTIFICATION.ERROR');
                this.isUpdating = false;
            },
            complete: () => {
                this.isUpdating = false;
                this.dialogRef.close();
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionEditDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: VersionEditDialogComponent, isStandalone: true, selector: "hxp-version-edit-dialog", ngImport: i0, template: "<div class=\"hxp-version-edit-dialog\">\n    <h1 mat-dialog-title>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.TITLE' | translate }}</h1>\n    <mat-dialog-content>\n        <form\n            [formGroup]=\"form\"\n            class=\"hxp-version-edit-dialog-form\"\n        >\n            <mat-form-field\n                class=\"hxp-edit-form-field\"\n                data-automation-id=\"hxp-document-version-edit-title\"\n            >\n                <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.FIELD_TITLE' | translate }}</mat-label>\n                <input\n                    matInput\n                    formControlName=\"sysver_title\"\n                    (keydown)=\"$event.stopPropagation()\"\n                />\n            </mat-form-field>\n            <mat-form-field\n                class=\"hxp-edit-form-field\"\n                data-automation-id=\"hxp-document-version-edit-description\"\n                hideRequiredMarker\n            >\n                <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.DESCRIPTION' | translate }}</mat-label>\n                <textarea\n                    matInput\n                    formControlName=\"sysver_description\"\n                    placeholder=\"{{ 'MANAGE_VERSIONS.EDIT_DIALOG.PLACEHOLDER_DESCRIPTION' | translate }}\"\n                    (keydown)=\"$event.stopPropagation()\"\n                    rows=\"5\"\n                >\n                </textarea>\n            </mat-form-field>\n        </form>\n    </mat-dialog-content>\n    <mat-dialog-actions\n        [align]=\"'end'\"\n        class=\"hxp-version-edit-dialog-footer-action\"\n    >\n        <button\n            mat-button\n            mat-dialog-close\n        >\n            {{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.CANCEL' | translate }}\n        </button>\n        <button\n            mat-flat-button\n            [disabled]=\"form.invalid || isUpdating\"\n            (click)=\"onSave()\"\n            data-automation-id=\"hxp-document-version-edit-save\"\n        >\n            <span class=\"hxp-version-edit-dialog-save-btn-label\">\n                @if (isUpdating) {\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"15\"\n                    />\n                }\n                <span class=\"hxp-version-edit-dialog-save-btn-title\">\n                    {{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.SAVE' | translate }}\n                </span>\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-version-edit-dialog-form{display:flex;flex-direction:column;margin-top:24px;gap:24px}.hxp-version-edit-dialog-save-btn-label{display:flex;justify-content:space-between;align-items:center;gap:10px}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i3$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i3$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i3$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$1.MatLabel, selector: "mat-label" }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "component", type: MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionEditDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-version-edit-dialog', imports: [
                        MatDialogModule,
                        MatIconModule,
                        MatButtonModule,
                        ReactiveFormsModule,
                        MatFormFieldModule,
                        MatInputModule,
                        MatProgressSpinner,
                        TranslatePipe,
                    ], template: "<div class=\"hxp-version-edit-dialog\">\n    <h1 mat-dialog-title>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.TITLE' | translate }}</h1>\n    <mat-dialog-content>\n        <form\n            [formGroup]=\"form\"\n            class=\"hxp-version-edit-dialog-form\"\n        >\n            <mat-form-field\n                class=\"hxp-edit-form-field\"\n                data-automation-id=\"hxp-document-version-edit-title\"\n            >\n                <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.FIELD_TITLE' | translate }}</mat-label>\n                <input\n                    matInput\n                    formControlName=\"sysver_title\"\n                    (keydown)=\"$event.stopPropagation()\"\n                />\n            </mat-form-field>\n            <mat-form-field\n                class=\"hxp-edit-form-field\"\n                data-automation-id=\"hxp-document-version-edit-description\"\n                hideRequiredMarker\n            >\n                <mat-label>{{ 'MANAGE_VERSIONS.EDIT_DIALOG.DESCRIPTION' | translate }}</mat-label>\n                <textarea\n                    matInput\n                    formControlName=\"sysver_description\"\n                    placeholder=\"{{ 'MANAGE_VERSIONS.EDIT_DIALOG.PLACEHOLDER_DESCRIPTION' | translate }}\"\n                    (keydown)=\"$event.stopPropagation()\"\n                    rows=\"5\"\n                >\n                </textarea>\n            </mat-form-field>\n        </form>\n    </mat-dialog-content>\n    <mat-dialog-actions\n        [align]=\"'end'\"\n        class=\"hxp-version-edit-dialog-footer-action\"\n    >\n        <button\n            mat-button\n            mat-dialog-close\n        >\n            {{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.CANCEL' | translate }}\n        </button>\n        <button\n            mat-flat-button\n            [disabled]=\"form.invalid || isUpdating\"\n            (click)=\"onSave()\"\n            data-automation-id=\"hxp-document-version-edit-save\"\n        >\n            <span class=\"hxp-version-edit-dialog-save-btn-label\">\n                @if (isUpdating) {\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"15\"\n                    />\n                }\n                <span class=\"hxp-version-edit-dialog-save-btn-title\">\n                    {{ 'MANAGE_VERSIONS.EDIT_DIALOG.BUTTONS.SAVE' | translate }}\n                </span>\n            </span>\n        </button>\n    </mat-dialog-actions>\n</div>\n", styles: [".hxp-version-edit-dialog-form{display:flex;flex-direction:column;margin-top:24px;gap:24px}.hxp-version-edit-dialog-save-btn-label{display:flex;justify-content:space-between;align-items:center;gap:10px}\n"] }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionEditButtonActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.dialog = inject(MatDialog);
    }
    isAvailable(context) {
        return (!!context.documents &&
            context.documents.length === 1 &&
            hasPermission(context.documents[0], DocumentPermissions.WRITE) &&
            hasPermission(context.documents[0], DocumentPermissions.WRITE_VERSION) &&
            isVersion(context.documents[0]));
    }
    execute(context) {
        const document = context.documents[0];
        this.dialog.open(VersionEditDialogComponent, {
            width: DialogConfig.small.width,
            data: document,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionEditButtonActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionEditButtonActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionEditButtonActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionRestoreActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.documentService = inject(DocumentService);
    }
    isAvailable(context) {
        return (!!context.documents &&
            isVersion(context.documents[0]) &&
            hasPermission(context.documents[0], DocumentPermissions.READ) &&
            !!context.parentDocument &&
            hasPermission(context.parentDocument, DocumentPermissions.WRITE));
    }
    execute(context) {
        const document = context.documents[0];
        if (!document?.sys_id) {
            this.hxpNotificationService.showError('DOCUMENT_VERSION.SNACKBAR.RESTORE_ERROR');
            return;
        }
        this.documentService.restoreVersion(document.sys_id).subscribe({
            next: () => {
                this.documentService.requestReload();
                this.hxpNotificationService.showSuccess('DOCUMENT_VERSION.SNACKBAR.RESTORE_SUCCESS');
            },
            error: () => this.hxpNotificationService.showError('DOCUMENT_VERSION.SNACKBAR.RESTORE_ERROR'),
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionRestoreActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionRestoreActionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionRestoreActionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ManageColumnDialogComponent {
    constructor() {
        this.availableColumns = [];
        this.selectedColumns = [];
        this.canReset = false;
        this.canUpdate = false;
        this.canAdd = false;
        this.searchTerm = '';
        this.initialDefaultColumns = [];
        this.initialSelectedColumns = [];
        this.initialCustomColumns = [];
        this.allColumns = [];
        this.searchTerms = new Subject();
        this.destroyRef = inject(DestroyRef);
        this.manageColumnDialogData = inject(MAT_DIALOG_DATA);
        this.dialogRef = inject(MatDialogRef);
        this.columnConfigService = inject(ColumnConfigService);
        this.identityUserService = inject(IDENTITY_USER_SERVICE_TOKEN);
        this.identityUser$ = of(this.identityUserService.getCurrentUserInfo());
        this.columnConfigService
            .getCustomColumns()
            .pipe(takeUntilDestroyed())
            .subscribe((customColumns) => {
            this.initialCustomColumns = customColumns;
        });
    }
    ngOnInit() {
        this.identityUser$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((userInfo) => {
            this.userInfo = userInfo;
            this.initializeColumns();
        });
        this.searchTerms.pipe(debounceTime(300), takeUntilDestroyed(this.destroyRef)).subscribe(() => {
            this.applySearch();
        });
    }
    selectColumn(column) {
        this.selectedColumns.push(column);
        this.availableColumns = this.availableColumns.filter((c) => c.key !== column.key);
        this.checkForChanges();
    }
    deselectColumn(column) {
        this.availableColumns.push(column);
        this.selectedColumns = this.selectedColumns.filter((c) => c.key !== column.key);
        this.checkForChanges();
    }
    totalSelectableColumns() {
        return this.initialDefaultColumns.length;
    }
    onSearchChange() {
        this.searchTerms.next(this.searchTerm);
    }
    applyChanges() {
        this.columnConfigService.setCurrentSelectedColumnsForCurrentUser(this.userInfo, this.selectedColumns);
        this.closeDialog();
    }
    clearSearch() {
        this.searchTerm = '';
        this.onSearchChange();
    }
    drop(event) {
        moveItemInArray(this.selectedColumns, event.previousIndex, event.currentIndex);
        this.checkForChanges();
    }
    resetToDefault() {
        this.selectedColumns = this.initialDefaultColumns;
        this.availableColumns = [...this.initialCustomColumns];
        this.searchTerm = '';
        this.checkForChanges();
    }
    hasSelectionChanged() {
        return JSON.stringify(this.selectedColumns) !== JSON.stringify(this.initialSelectedColumns);
    }
    hasDefaultChanged() {
        return JSON.stringify(this.selectedColumns) !== JSON.stringify(this.initialDefaultColumns);
    }
    addColumnEnabled() {
        return this.selectedColumns.length !== this.totalSelectableColumns();
    }
    initializeColumns() {
        this.selectedColumns = this.columnConfigService.getSelectedColumnsForCurrentUser(this.userInfo);
        this.initialDefaultColumns = this.columnConfigService.getDefaultColumns();
        this.allColumns = [...this.initialDefaultColumns, ...this.initialCustomColumns];
        this.availableColumns = this.allColumns.filter((column) => !this.selectedColumns.some((selected) => selected.key === column.key));
        this.initialSelectedColumns = [...this.selectedColumns];
        this.checkForChanges();
    }
    applySearch() {
        if (this.searchTerm) {
            const searchLower = this.searchTerm.toLowerCase();
            this.availableColumns = this.allColumns.filter((column) => column.title.toLowerCase().includes(searchLower) && !this.selectedColumns.some((selected) => selected.key === column.key));
        }
        else {
            this.availableColumns = this.allColumns.filter((column) => !this.selectedColumns.some((selected) => selected.key === column.key));
        }
    }
    checkForChanges() {
        this.canReset = this.hasDefaultChanged();
        this.canUpdate = this.hasSelectionChanged();
        this.canAdd = this.addColumnEnabled();
    }
    closeDialog() {
        this.dialogRef.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageColumnDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: ManageColumnDialogComponent, isStandalone: true, selector: "hxp-manage-column-dialog", ngImport: i0, template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <h1 mat-dialog-title>{{ 'SEARCH.MANAGE_COLUMN.DIALOG.TITLE' | translate }}</h1>\n    <div\n        mat-dialog-content\n        class=\"hxp-fixed-dialog-content-height\"\n    >\n        <div class=\"hxp-manage-columns-container\">\n            <div class=\"hxp-manage-columns-available-columns\">\n                <p>\n                    {{ 'SEARCH.MANAGE_COLUMN.DIALOG.AVAILABLE_COLUMN' | translate }}\n                    ({{ 'SEARCH.MANAGE_COLUMN.DIALOG.AVAILABLE' | translate: { count: availableColumns.length } }})\n                </p>\n                <div class=\"hxp-manage-columns-box-list\">\n                    <div class=\"hxp-manage-columns-search-container\">\n                        <mat-form-field class=\"hxp-manage-columns-search-container-form-field\">\n                            <textarea\n                                matInput\n                                [(ngModel)]=\"searchTerm\"\n                                (keyup)=\"onSearchChange()\"\n                                cdkTextareaAutosize\n                                cdkAutosizeMinRows=\"1\"\n                                cdkAutosizeMaxRows=\"3\"\n                                placeholder=\"{{ 'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.INPUT.PLACEHOLDER' | translate }}\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.INPUT.ARIA_LABEL' | translate\"\n                            ></textarea>\n                            <button\n                                mat-icon-button\n                                matSuffix\n                                *ngIf=\"searchTerm\"\n                                (click)=\"clearSearch()\"\n                                class=\"hxp-manage-columns-search-clear\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.CLEAR.ARIA_LABEL' | translate\"\n                            >\n                                <mat-icon\n                                    aria-hidden=\"true\"\n                                    svgIcon=\"x_large\"\n                                />\n                            </button>\n                            <button\n                                mat-icon-button\n                                matSuffix\n                                class=\"hxp-manage-columns-search-button\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.BUTTON.ARIA_LABEL' | translate\"\n                            >\n                                <mat-icon\n                                    aria-hidden=\"true\"\n                                    svgIcon=\"search\"\n                                />\n                            </button>\n                        </mat-form-field>\n                    </div>\n                    <div\n                        class=\"hxp-manage-columns-column-item\"\n                        *ngFor=\"let column of availableColumns\"\n                    >\n                        <div>{{ column.title | translate }}</div>\n                        <button\n                            mat-icon-button\n                            [disabled]=\"!canAdd\"\n                            (click)=\"selectColumn(column)\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.ADD_COLUMN' | translate\"\n                        >\n                            <mat-icon\n                                aria-hidden=\"true\"\n                                svgIcon=\"circle_add\"\n                            />\n                        </button>\n                    </div>\n                </div>\n            </div>\n            <div class=\"hxp-manage-columns-selected-columns\">\n                <p>\n                    {{ 'SEARCH.MANAGE_COLUMN.DIALOG.SELECTED_COLUMN' | translate: { count: selectedColumns.length } }}\n                    <span>{{\n                        'SEARCH.MANAGE_COLUMN.DIALOG.COLUMN_COUNT' | translate: { selected: selectedColumns.length, total: totalSelectableColumns() }\n                    }}</span>\n                </p>\n                <div\n                    class=\"hxp-manage-columns-box-list hxp-manage-columns-drag-columns\"\n                    cdkDropList\n                    (cdkDropListDropped)=\"drop($event)\"\n                >\n                    <div\n                        class=\"hxp-manage-columns-column-item\"\n                        *ngFor=\"let column of selectedColumns\"\n                        cdkDrag\n                    >\n                        <div>\n                            <button\n                                mat-icon-button\n                                cdkDragHandle\n                                class=\"hxp-manage-columns-drag-handel\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.DRAG_COLUMN' | translate\"\n                            >\n                                <mat-icon\n                                    aria-hidden=\"true\"\n                                    svgIcon=\"drag_and_drop_handle\"\n                                />\n                            </button>\n                            {{ column.title | translate }}\n                        </div>\n                        <button\n                            mat-icon-button\n                            *ngIf=\"column.removable\"\n                            (click)=\"deselectColumn(column)\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.REMOVE_COLUMN' | translate\"\n                        >\n                            <mat-icon\n                                aria-hidden=\"true\"\n                                svgIcon=\"circle_minus\"\n                            />\n                        </button>\n\n                        <!-- Custom drag preview -->\n                        <div\n                            *cdkDragPreview\n                            class=\"hxp-manage-columns-column-item\"\n                        >\n                            <div class=\"hxp-drag-preview\">\n                                <button\n                                    mat-icon-button\n                                    class=\"hxp-manage-columns-drag-handel\"\n                                >\n                                    <mat-icon\n                                        aria-hidden=\"true\"\n                                        svgIcon=\"drag_and_drop_handle\"\n                                    />\n                                </button>\n                                <span class=\"hxp-drag-preview-label\">{{ column.title | translate }}</span>\n                                <button\n                                    mat-icon-button\n                                    *ngIf=\"column.removable\"\n                                >\n                                    <mat-icon\n                                        aria-hidden=\"true\"\n                                        svgIcon=\"circle_minus\"\n                                    />\n                                </button>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div\n        mat-dialog-actions\n        class=\"hxp-manage-column-dialog-action\"\n    >\n        <button\n            mat-button\n            class=\"hxp-manage-column-reset-button\"\n            [disabled]=\"!canReset\"\n            (click)=\"resetToDefault()\"\n        >\n            {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.RESET' | translate }}\n        </button>\n        <div>\n            <button\n                mat-button\n                class=\"hxp-manage-column-close-button\"\n                mat-dialog-close\n            >\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.CANCEL' | translate }}\n            </button>\n            <button\n                mat-flat-button\n                class=\"hxp-update-table-btn\"\n                [disabled]=\"!canUpdate\"\n                (click)=\"applyChanges()\"\n            >\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.UPDATE_TABLE' | translate }}\n            </button>\n        </div>\n    </div>\n</div>\n", styles: [".hxp-dialog-fixed-size-wrapper{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.dialog-title{display:flex;justify-content:space-between;align-items:center}.dialog-title h1{flex:1;padding-left:0}.hxp-manage-column-dialog-action{display:flex;justify-content:space-between}.hxp-manage-columns-container{display:flex;justify-content:space-between;height:100%}.hxp-manage-columns-container .hxp-manage-columns-available-columns,.hxp-manage-columns-container .hxp-manage-columns-selected-columns{flex:1;display:flex;flex-direction:column}.hxp-manage-columns-container .hxp-manage-columns-available-columns{margin-right:10px}.hxp-manage-columns-container .hxp-manage-columns-box-list{display:flex;flex-direction:column;border:1px solid var(--mat-sys-outline);border-radius:5px;padding:12px;height:100%;overflow-y:auto;overflow-x:hidden}.hxp-manage-columns-container .hxp-manage-columns-search-container{display:flex}.hxp-manage-columns-container .hxp-manage-columns-search-container .hxp-manage-columns-search-clear{right:5px}.hxp-manage-columns-container .hxp-manage-columns-search-container .hxp-manage-columns-search-container-form-field{flex:1}.hxp-manage-columns-container .hxp-manage-columns-column-item{display:flex;justify-content:space-between;padding:5px 0;align-items:center}.hxp-manage-columns-container .hxp-manage-columns-column-item div{display:flex;text-overflow:ellipsis;word-break:break-all;overflow:hidden;padding-right:10px;align-items:center}.hxp-manage-columns-container .hxp-manage-columns-drag-columns .hxp-manage-columns-drag-handel{cursor:move}.hxp-drag-preview{display:flex;align-items:center;width:100%;min-width:210px;padding:5px 0}.hxp-drag-preview .hxp-drag-preview-label{flex:1}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i6$1.CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i8.CdkDropList, selector: "[cdkDropList], cdk-drop-list", inputs: ["cdkDropListConnectedTo", "cdkDropListData", "cdkDropListOrientation", "id", "cdkDropListLockAxis", "cdkDropListDisabled", "cdkDropListSortingDisabled", "cdkDropListEnterPredicate", "cdkDropListSortPredicate", "cdkDropListAutoScrollDisabled", "cdkDropListAutoScrollStep", "cdkDropListElementContainer"], outputs: ["cdkDropListDropped", "cdkDropListEntered", "cdkDropListExited", "cdkDropListSorted"], exportAs: ["cdkDropList"] }, { kind: "directive", type: i8.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i8.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: i8.CdkDragPreview, selector: "ng-template[cdkDragPreview]", inputs: ["data", "matchSize"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageColumnDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-manage-column-dialog', imports: [
                        NgIf,
                        NgFor,
                        MatDialogModule,
                        MatIconModule,
                        MatButtonModule,
                        MatFormFieldModule,
                        MatTooltipModule,
                        MatInputModule,
                        FormsModule,
                        DragDropModule,
                        TranslatePipe,
                    ], template: "<div class=\"hxp-dialog-fixed-size-wrapper\">\n    <h1 mat-dialog-title>{{ 'SEARCH.MANAGE_COLUMN.DIALOG.TITLE' | translate }}</h1>\n    <div\n        mat-dialog-content\n        class=\"hxp-fixed-dialog-content-height\"\n    >\n        <div class=\"hxp-manage-columns-container\">\n            <div class=\"hxp-manage-columns-available-columns\">\n                <p>\n                    {{ 'SEARCH.MANAGE_COLUMN.DIALOG.AVAILABLE_COLUMN' | translate }}\n                    ({{ 'SEARCH.MANAGE_COLUMN.DIALOG.AVAILABLE' | translate: { count: availableColumns.length } }})\n                </p>\n                <div class=\"hxp-manage-columns-box-list\">\n                    <div class=\"hxp-manage-columns-search-container\">\n                        <mat-form-field class=\"hxp-manage-columns-search-container-form-field\">\n                            <textarea\n                                matInput\n                                [(ngModel)]=\"searchTerm\"\n                                (keyup)=\"onSearchChange()\"\n                                cdkTextareaAutosize\n                                cdkAutosizeMinRows=\"1\"\n                                cdkAutosizeMaxRows=\"3\"\n                                placeholder=\"{{ 'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.INPUT.PLACEHOLDER' | translate }}\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.INPUT.ARIA_LABEL' | translate\"\n                            ></textarea>\n                            <button\n                                mat-icon-button\n                                matSuffix\n                                *ngIf=\"searchTerm\"\n                                (click)=\"clearSearch()\"\n                                class=\"hxp-manage-columns-search-clear\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.CLEAR.ARIA_LABEL' | translate\"\n                            >\n                                <mat-icon\n                                    aria-hidden=\"true\"\n                                    svgIcon=\"x_large\"\n                                />\n                            </button>\n                            <button\n                                mat-icon-button\n                                matSuffix\n                                class=\"hxp-manage-columns-search-button\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.SEARCH_COLUMN.BUTTON.ARIA_LABEL' | translate\"\n                            >\n                                <mat-icon\n                                    aria-hidden=\"true\"\n                                    svgIcon=\"search\"\n                                />\n                            </button>\n                        </mat-form-field>\n                    </div>\n                    <div\n                        class=\"hxp-manage-columns-column-item\"\n                        *ngFor=\"let column of availableColumns\"\n                    >\n                        <div>{{ column.title | translate }}</div>\n                        <button\n                            mat-icon-button\n                            [disabled]=\"!canAdd\"\n                            (click)=\"selectColumn(column)\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.ADD_COLUMN' | translate\"\n                        >\n                            <mat-icon\n                                aria-hidden=\"true\"\n                                svgIcon=\"circle_add\"\n                            />\n                        </button>\n                    </div>\n                </div>\n            </div>\n            <div class=\"hxp-manage-columns-selected-columns\">\n                <p>\n                    {{ 'SEARCH.MANAGE_COLUMN.DIALOG.SELECTED_COLUMN' | translate: { count: selectedColumns.length } }}\n                    <span>{{\n                        'SEARCH.MANAGE_COLUMN.DIALOG.COLUMN_COUNT' | translate: { selected: selectedColumns.length, total: totalSelectableColumns() }\n                    }}</span>\n                </p>\n                <div\n                    class=\"hxp-manage-columns-box-list hxp-manage-columns-drag-columns\"\n                    cdkDropList\n                    (cdkDropListDropped)=\"drop($event)\"\n                >\n                    <div\n                        class=\"hxp-manage-columns-column-item\"\n                        *ngFor=\"let column of selectedColumns\"\n                        cdkDrag\n                    >\n                        <div>\n                            <button\n                                mat-icon-button\n                                cdkDragHandle\n                                class=\"hxp-manage-columns-drag-handel\"\n                                [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.DRAG_COLUMN' | translate\"\n                            >\n                                <mat-icon\n                                    aria-hidden=\"true\"\n                                    svgIcon=\"drag_and_drop_handle\"\n                                />\n                            </button>\n                            {{ column.title | translate }}\n                        </div>\n                        <button\n                            mat-icon-button\n                            *ngIf=\"column.removable\"\n                            (click)=\"deselectColumn(column)\"\n                            [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.DIALOG.REMOVE_COLUMN' | translate\"\n                        >\n                            <mat-icon\n                                aria-hidden=\"true\"\n                                svgIcon=\"circle_minus\"\n                            />\n                        </button>\n\n                        <!-- Custom drag preview -->\n                        <div\n                            *cdkDragPreview\n                            class=\"hxp-manage-columns-column-item\"\n                        >\n                            <div class=\"hxp-drag-preview\">\n                                <button\n                                    mat-icon-button\n                                    class=\"hxp-manage-columns-drag-handel\"\n                                >\n                                    <mat-icon\n                                        aria-hidden=\"true\"\n                                        svgIcon=\"drag_and_drop_handle\"\n                                    />\n                                </button>\n                                <span class=\"hxp-drag-preview-label\">{{ column.title | translate }}</span>\n                                <button\n                                    mat-icon-button\n                                    *ngIf=\"column.removable\"\n                                >\n                                    <mat-icon\n                                        aria-hidden=\"true\"\n                                        svgIcon=\"circle_minus\"\n                                    />\n                                </button>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div>\n    <div\n        mat-dialog-actions\n        class=\"hxp-manage-column-dialog-action\"\n    >\n        <button\n            mat-button\n            class=\"hxp-manage-column-reset-button\"\n            [disabled]=\"!canReset\"\n            (click)=\"resetToDefault()\"\n        >\n            {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.RESET' | translate }}\n        </button>\n        <div>\n            <button\n                mat-button\n                class=\"hxp-manage-column-close-button\"\n                mat-dialog-close\n            >\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.CANCEL' | translate }}\n            </button>\n            <button\n                mat-flat-button\n                class=\"hxp-update-table-btn\"\n                [disabled]=\"!canUpdate\"\n                (click)=\"applyChanges()\"\n            >\n                {{ 'SEARCH.MANAGE_COLUMN.DIALOG.BUTTON.UPDATE_TABLE' | translate }}\n            </button>\n        </div>\n    </div>\n</div>\n", styles: [".hxp-dialog-fixed-size-wrapper{display:flex;flex-direction:column;overflow:hidden;flex:1 1 auto}.dialog-title{display:flex;justify-content:space-between;align-items:center}.dialog-title h1{flex:1;padding-left:0}.hxp-manage-column-dialog-action{display:flex;justify-content:space-between}.hxp-manage-columns-container{display:flex;justify-content:space-between;height:100%}.hxp-manage-columns-container .hxp-manage-columns-available-columns,.hxp-manage-columns-container .hxp-manage-columns-selected-columns{flex:1;display:flex;flex-direction:column}.hxp-manage-columns-container .hxp-manage-columns-available-columns{margin-right:10px}.hxp-manage-columns-container .hxp-manage-columns-box-list{display:flex;flex-direction:column;border:1px solid var(--mat-sys-outline);border-radius:5px;padding:12px;height:100%;overflow-y:auto;overflow-x:hidden}.hxp-manage-columns-container .hxp-manage-columns-search-container{display:flex}.hxp-manage-columns-container .hxp-manage-columns-search-container .hxp-manage-columns-search-clear{right:5px}.hxp-manage-columns-container .hxp-manage-columns-search-container .hxp-manage-columns-search-container-form-field{flex:1}.hxp-manage-columns-container .hxp-manage-columns-column-item{display:flex;justify-content:space-between;padding:5px 0;align-items:center}.hxp-manage-columns-container .hxp-manage-columns-column-item div{display:flex;text-overflow:ellipsis;word-break:break-all;overflow:hidden;padding-right:10px;align-items:center}.hxp-manage-columns-container .hxp-manage-columns-drag-columns .hxp-manage-columns-drag-handel{cursor:move}.hxp-drag-preview{display:flex;align-items:center;width:100%;min-width:210px;padding:5px 0}.hxp-drag-preview .hxp-drag-preview-label{flex:1}\n"] }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ManageColumnActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.dialog = inject(MatDialog);
    }
    isAvailable(context) {
        return /search/i.test(context.refererURL || '');
    }
    execute(context) {
        this.dialog.open(ManageColumnDialogComponent, {
            width: DialogConfig.medium.width,
            height: DialogConfig.medium.height,
            minWidth: DialogConfig.medium.width,
            minHeight: DialogConfig.medium.height,
            data: context,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageColumnActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageColumnActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageColumnActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const CONTEXT_MENU_ACTIONS_PROVIDERS = [
    {
        provide: HXP_DOCUMENT_PERMISSIONS_ACTION_SERVICE,
        useClass: PermissionsButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_DELETE_ACTION_SERVICE,
        useClass: DeleteButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE,
        useClass: SingleItemDownloadButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_SHARE_ACTION_SERVICE,
        useClass: ContentShareButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_INFO_ACTION_SERVICE,
        useClass: ContentPropertyViewerActionService,
    },
    {
        provide: HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE,
        useClass: VersionDeleteButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE,
        useClass: VersionEditButtonActionService,
    },
    {
        provide: HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE,
        useClass: VersionRestoreActionService,
    },
    {
        provide: HXP_MANAGE_COLUMN_ACTION_SERVICE,
        useClass: ManageColumnActionService,
    },
];

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component presents document breadcrumb.
 * To use the `HxpDocumentListComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpDocumentListComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         HxpDocumentListComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-document-list [isLoading]="isLoading" [documents]="documents" [schema]="schema">
 * </hxp-document-list>
 */
class HxpDocumentListComponent {
    constructor() {
        /**
         * The list of documents to be displayed.
         * @type {Document[]}
         * @default []
         *
         */
        this.documents = [];
        /**
         * Indicates whether the document list is currently loading.
         * When set to `true`, a loading indicator may be displayed.
         * Defaults to `false`.
         * @type {boolean}
         * @default false
         */
        this.isLoading = false;
        /**
         * Indicates whether it is possible to select more than one document.
         * @type {boolean}
         * @default true
         */
        this.multiselect = true;
        /**
         * Indicates whether the context menu actions are enabled.
         * @type {boolean}
         * @default true
         */
        this.contextMenuActions = true;
        /**
         * Event emitter that notifies the list of selected documents whenever it changes.
         *
         * @event selectedDocuments
         */
        this.selectedDocuments = new EventEmitter();
        /**
         * Emit the Document associated with the clicked row, when the row is clicked.
         *
         * @event rowClicked
         */
        this.rowClicked = new EventEmitter();
        /**
         * Event emitter that notifies when sorting the Document List.
         * The emitted value is a string in the form of `<column name> <direction>`
         *
         * @event sortingClicked
         */
        this.sortingClicked = new EventEmitter();
        /**
         * Event emitter that notifies when columns are resized.
         * The event payload is an array of `DataColumn` objects with updated width.
         *
         * @event columnsResized
         */
        this.columnsResized = new EventEmitter();
        this.evaluatedSchema = [];
        this.documentCache = inject(DocumentCacheService);
        this.contextMenuActionsService = inject(ContextMenuActionsService);
        this.contextMenuOverlayService = inject(ContextMenuOverlayService);
    }
    /**
     * Property to access the underlying Alfresco `DataTableComponent` instance.
     * https://www.alfresco.com/abn/adf/docs/core/components/datatable.component/
     */
    get table() {
        return this.documentListElement;
    }
    ngOnChanges() {
        this.updateDocumentList();
    }
    /**
     * Resets the selection of the document list.
     */
    resetSelection() {
        if (this.documentListElement) {
            this.documentListElement.resetSelection();
            if (this.documents && this.documentListElement.data) {
                this.documentListElement.onSelectAllClick({
                    checked: false,
                });
            }
        }
        this.selectedDocuments.emit([]);
    }
    /**
     * Resets the sorting of the document list.
     */
    resetSorting() {
        if (this.documentListElement) {
            this.documentListElement.sorting = [];
        }
    }
    onShowContextMenu(event) {
        event.preventDefault();
        this.contextMenuLocation = { x: event.clientX, y: event.clientY };
        const allRows = this.documentListElement.data.getRows();
        this.documentListElement.onSelectAllClick({
            checked: false,
        });
        for (const row of allRows) {
            if (row.isContextMenuSource) {
                this.selectedDocuments.emit([row['obj']]);
                this.documentListElement.selectRow(row, true);
            }
        }
    }
    handleRowClicked(event) {
        this.rowClicked.emit(event.value['obj']);
    }
    handleSortingChanged(event) {
        const sortingEvent = event;
        if (!sortingEvent.detail) {
            return;
        }
        const { key, direction } = sortingEvent.detail;
        if (key && direction) {
            this.sortingClicked.emit([`${key} ${direction}`]);
        }
    }
    setSelectedRows(event) {
        const selectionEvent = event;
        if (Array.isArray(selectionEvent?.detail?.selection)) {
            const selection = selectionEvent.detail.selection.map((row) => row['obj']);
            this.selectedDocuments.emit(selection);
        }
    }
    onColumnsWidthChange(columns) {
        this.columnsResized.emit(columns);
    }
    onShowRowContextMenu(event) {
        if (!this.contextMenuActions) {
            return;
        }
        const assignActions = (doc) => {
            event.value.actions = this.getContextActions(event.value.row, doc);
        };
        if (this.parentDocument) {
            assignActions(this.parentDocument);
            return;
        }
        const parentId = event.value.row['obj'].sys_parentId;
        this.refreshCachedDocument(parentId)?.subscribe({
            next: (doc) => {
                if (this.contextMenuLocation) {
                    this.contextMenuOverlayService.open({
                        source: new MouseEvent('contextmenu', {
                            clientX: this.contextMenuLocation.x,
                            clientY: this.contextMenuLocation.y,
                        }),
                        data: this.getContextActions(event.value.row, doc),
                    });
                    this.contextMenuLocation = undefined;
                }
            },
            error: (error) => {
                console.error(error);
            },
        });
    }
    updateDocumentList() {
        if (!this.documents) {
            this.documents = [];
        }
        if (this.documents.length > 0) {
            if (Array.isArray(this.schema)) {
                this.evaluatedSchema = [...this.schema];
            }
            else {
                this.configureSchema();
            }
            this.fetchCommonParentDocument(this.documents);
        }
    }
    fetchCommonParentDocument(docs) {
        const parentIds = docs.map((doc) => doc.sys_parentId);
        if (parentIds[0] && parentIds.every((parentId) => parentId === parentIds[0])) {
            this.refreshCachedDocument(parentIds[0]).subscribe({
                next: (doc) => {
                    this.parentDocument = doc;
                },
                error: (error) => {
                    console.error(error);
                },
            });
        }
        else {
            this.parentDocument = undefined;
        }
    }
    refreshCachedDocument(sysId) {
        this.documentCache.invalidate(sysId);
        return this.documentCache.getDocument(sysId).pipe(catchError((error) => {
            /**
             * if there is an error here, we need to swallow it, otherwise the interface will hang.
             *
             * onShowRowContextMenu is called constantly which means that if we don't swallow it, we'd be
             * throwing an exception at every call.
             */
            /*
             * Some users don't have permissions to see the root document, so we return a mock root document to pass for the context actions to work
             */
            if (sysId === ROOT_DOCUMENT.sys_id && isPermissionError(error)) {
                return of(ROOT_DOCUMENT);
            }
            if (!isPermissionError(error)) {
                console.error(error);
            }
            return of(undefined);
        }), shareReplay(1));
    }
    configureSchema() {
        if (this.documentListElement) {
            const inputSchema = this.inputColumnList?.columns.toArray() || [];
            const projectedSchema = this.projectedColumnList?.columns.toArray() || [];
            this.evaluatedSchema = [...inputSchema, ...projectedSchema];
        }
    }
    getContextActions(rowData, parentDocument) {
        return this.contextMenuActionsService.getContextActions(rowData['obj'], parentDocument);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpDocumentListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: HxpDocumentListComponent, isStandalone: true, selector: "hxp-document-list", inputs: { documents: "documents", isLoading: "isLoading", multiselect: "multiselect", contextMenuActions: "contextMenuActions", inputColumnList: "inputColumnList", schema: "schema" }, outputs: { selectedDocuments: "selectedDocuments", rowClicked: "rowClicked", sortingClicked: "sortingClicked", columnsResized: "columnsResized" }, host: { listeners: { "contextmenu": "onShowContextMenu($event)" } }, providers: [
            provideTranslations('adf-enterprise-adf-hx-content-services-ui', 'assets/adf-enterprise-adf-hx-content-services-ui'),
            provideTranslations('process-services-cloud-extension-process-form', 'assets/process-services-cloud-extension-process-form'),
            provideTranslations('content-services-extension-content-browser-feature-shell', 'assets/content-services-extension-content-browser'),
            ...CONTEXT_MENU_ACTIONS_PROVIDERS,
        ], queries: [{ propertyName: "projectedColumnList", first: true, predicate: DataColumnListComponent, descendants: true }], viewQueries: [{ propertyName: "documentListElement", first: true, predicate: ["documentList"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-document-list-container\">\n    <ng-content />\n    <adf-datatable\n        #documentList\n        [loading]=\"isLoading\"\n        [isResizingEnabled]=\"true\"\n        [rows]=\"documents\"\n        [stickyHeader]=\"true\"\n        [multiselect]=\"multiselect\"\n        selectionMode=\"multiple\"\n        (rowClick)=\"handleRowClicked($event)\"\n        (sorting-changed)=\"handleSortingChanged($event)\"\n        (row-select)=\"setSelectedRows($event)\"\n        (row-unselect)=\"setSelectedRows($event)\"\n        [contextMenu]=\"contextMenuActions\"\n        (showRowContextMenu)=\"onShowRowContextMenu($event)\"\n        (columnsWidthChanged)=\"onColumnsWidthChange($event)\"\n        [columns]=\"evaluatedSchema\"\n    >\n        <data-columns />\n        <loading-content-template>\n            <ng-template>\n                <mat-progress-spinner mode=\"indeterminate\" />\n            </ng-template>\n        </loading-content-template>\n        <no-content-template>\n            <ng-template>\n                @if (!isLoading) {\n                    <adf-empty-content\n                        icon=\"folder_open\"\n                        title=\"DOCUMENT_LIST.NO_CONTENT.TITLE\"\n                        subtitle=\"DOCUMENT_LIST.NO_CONTENT.SUBTITLE\"\n                    />\n                }\n            </ng-template>\n        </no-content-template>\n    </adf-datatable>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%}.hxp-document-list-container{flex:1;height:calc(100% - 65px)}adf-datatable{overflow:hidden}::ng-deep .adf-ellipsis-cell .adf-cell-value{display:block!important;min-height:auto!important;text-overflow:ellipsis;overflow:clip visible}::ng-deep .adf-ellipsis-cell .adf-cell-value .adf-datatable-content-cell{position:relative!important}::ng-deep .adf-ellipsis-cell .adf-cell-value>div,::ng-deep .adf-ellipsis-cell .adf-cell-value>span{text-overflow:ellipsis;overflow:hidden;white-space:nowrap}::ng-deep .adf-ellipsis-cell .adf-cell-value>span{display:block;max-width:fit-content}::ng-deep .adf-datatable-list .adf-datatable-cell--text{max-width:320px!important}::ng-deep .adf-datatable-checkbox label{display:none}\n"], dependencies: [{ kind: "component", type: DataColumnListComponent, selector: "data-columns" }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i3$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "directive", type: NoContentTemplateDirective, selector: "adf-no-content-template, no-content-template" }, { kind: "component", type: EmptyContentComponent, selector: "adf-empty-content", inputs: ["icon", "title", "subtitle"] }, { kind: "component", type: DataTableComponent, selector: "adf-datatable", inputs: ["data", "rows", "sorting", "columns", "selectionMode", "multiselect", "mainTableAction", "actions", "showMainDatatableActions", "showProvidedActions", "actionsPosition", "actionsVisibleOnHover", "fallbackThumbnail", "contextMenu", "rowStyle", "rowStyleClass", "showHeader", "stickyHeader", "loading", "noPermission", "rowMenuCacheEnabled", "resolverFn", "allowFiltering", "isResizingEnabled", "blurOnResize", "displayCheckboxesOnHover", "enableDragRows"], outputs: ["rowClick", "rowDblClick", "showRowContextMenu", "showRowActionsMenu", "executeRowAction", "columnOrderChanged", "columnsWidthChanged", "selectedItemsCountChanged", "dragDropped"] }, { kind: "directive", type: LoadingContentTemplateDirective, selector: "adf-loading-content-template, loading-content-template" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpDocumentListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-list', imports: [
                        DataColumnListComponent,
                        MatProgressSpinnerModule,
                        NoContentTemplateDirective,
                        EmptyContentComponent,
                        DataTableComponent,
                        LoadingContentTemplateDirective,
                    ], providers: [
                        provideTranslations('adf-enterprise-adf-hx-content-services-ui', 'assets/adf-enterprise-adf-hx-content-services-ui'),
                        provideTranslations('process-services-cloud-extension-process-form', 'assets/process-services-cloud-extension-process-form'),
                        provideTranslations('content-services-extension-content-browser-feature-shell', 'assets/content-services-extension-content-browser'),
                        ...CONTEXT_MENU_ACTIONS_PROVIDERS,
                    ], template: "<div class=\"hxp-document-list-container\">\n    <ng-content />\n    <adf-datatable\n        #documentList\n        [loading]=\"isLoading\"\n        [isResizingEnabled]=\"true\"\n        [rows]=\"documents\"\n        [stickyHeader]=\"true\"\n        [multiselect]=\"multiselect\"\n        selectionMode=\"multiple\"\n        (rowClick)=\"handleRowClicked($event)\"\n        (sorting-changed)=\"handleSortingChanged($event)\"\n        (row-select)=\"setSelectedRows($event)\"\n        (row-unselect)=\"setSelectedRows($event)\"\n        [contextMenu]=\"contextMenuActions\"\n        (showRowContextMenu)=\"onShowRowContextMenu($event)\"\n        (columnsWidthChanged)=\"onColumnsWidthChange($event)\"\n        [columns]=\"evaluatedSchema\"\n    >\n        <data-columns />\n        <loading-content-template>\n            <ng-template>\n                <mat-progress-spinner mode=\"indeterminate\" />\n            </ng-template>\n        </loading-content-template>\n        <no-content-template>\n            <ng-template>\n                @if (!isLoading) {\n                    <adf-empty-content\n                        icon=\"folder_open\"\n                        title=\"DOCUMENT_LIST.NO_CONTENT.TITLE\"\n                        subtitle=\"DOCUMENT_LIST.NO_CONTENT.SUBTITLE\"\n                    />\n                }\n            </ng-template>\n        </no-content-template>\n    </adf-datatable>\n</div>\n", styles: [":host{display:flex;flex-direction:column;height:100%}.hxp-document-list-container{flex:1;height:calc(100% - 65px)}adf-datatable{overflow:hidden}::ng-deep .adf-ellipsis-cell .adf-cell-value{display:block!important;min-height:auto!important;text-overflow:ellipsis;overflow:clip visible}::ng-deep .adf-ellipsis-cell .adf-cell-value .adf-datatable-content-cell{position:relative!important}::ng-deep .adf-ellipsis-cell .adf-cell-value>div,::ng-deep .adf-ellipsis-cell .adf-cell-value>span{text-overflow:ellipsis;overflow:hidden;white-space:nowrap}::ng-deep .adf-ellipsis-cell .adf-cell-value>span{display:block;max-width:fit-content}::ng-deep .adf-datatable-list .adf-datatable-cell--text{max-width:320px!important}::ng-deep .adf-datatable-checkbox label{display:none}\n"] }]
        }], propDecorators: { documents: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], multiselect: [{
                type: Input
            }], contextMenuActions: [{
                type: Input
            }], inputColumnList: [{
                type: Input
            }], schema: [{
                type: Input
            }], selectedDocuments: [{
                type: Output
            }], rowClicked: [{
                type: Output
            }], sortingClicked: [{
                type: Output
            }], columnsResized: [{
                type: Output
            }], documentListElement: [{
                type: ViewChild,
                args: ['documentList']
            }], projectedColumnList: [{
                type: ContentChild,
                args: [DataColumnListComponent]
            }], onShowContextMenu: [{
                type: HostListener,
                args: ['contextmenu', ['$event']]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component that display the content type icon of a given `Document`.
 *
 * To use the `ContentTypeIconComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { ContentTypeIconComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentTypeIconComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *   <hxp-document-type-icon [document]="document" [isExpanded]="isExpanded"></hxp-document-type-icon>
 */
class ContentTypeIconComponent {
    constructor() {
        /**
         * Toggles between expanded and collapsed for folder type documents only.
         * If the document is not a folder, this property is ignored.
         * @type {boolean}
         * @default false
         */
        this.isExpanded = false;
        this.documentIconType = DefaultIcon.UNKNOWN;
        this.featuresService = inject(FeaturesServiceToken);
        this.isDocumentLayoutFeatureFlagOn = toSignal(this.featuresService.isOn$(ADF_HX_CONTENT_SERVICES_INTERNAL.CIC_WORKSPACE_DOCUMENT_LAYOUT_TOGGLE));
    }
    /**
     * The mime type of the `Document`.
     * @type {string}
     * @readonly
     */
    get mimeType() {
        return this.documentIconType;
    }
    ngOnChanges() {
        this.checkDocumentIconType();
    }
    checkDocumentIconType() {
        this.documentIconType = DefaultIcon.UNKNOWN;
        if (!this.document) {
            return;
        }
        this.getDocumentIcon();
    }
    getDocumentIcon() {
        if (!this.document) {
            return;
        }
        if (this.isDocumentLayoutFeatureFlagOn()) {
            if (hasBlob(this.document)) {
                this.documentIconType = this.document['sysfile_blob'].mimeType;
            }
            else if (isFolder(this.document)) {
                this.documentIconType = this.getFolderIcon(this.isExpanded);
            }
        }
        else {
            if (isFolder(this.document)) {
                this.documentIconType = this.getFolderIcon(this.isExpanded);
            }
            else if (hasBlob(this.document)) {
                this.documentIconType = this.document['sysfile_blob'].mimeType;
            }
        }
    }
    getFolderIcon(isExpanded) {
        return isExpanded ? DefaultIcon.OPEN_FOLDER : DefaultIcon.FOLDER;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentTypeIconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: ContentTypeIconComponent, isStandalone: true, selector: "hxp-document-type-icon", inputs: { document: "document", isExpanded: "isExpanded" }, usesOnChanges: true, ngImport: i0, template: "<hxp-mime-type-icon [mimeType]=\"documentIconType\" />\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: MimeTypeIconComponent, selector: "hxp-mime-type-icon", inputs: ["mimeType"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentTypeIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-type-icon', imports: [CommonModule, MimeTypeIconComponent], template: "<hxp-mime-type-icon [mimeType]=\"documentIconType\" />\n" }]
        }], propDecorators: { document: [{
                type: Input
            }], isExpanded: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const EditPropertiesStatus$1 = {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
    INFO: 'INFO',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const editPropertiesNotificationMessages$1 = {
    [EditPropertiesStatus$1.SUCCESS]: 'DOCUMENT.PROPERTIES.EDIT.SUCCESS',
    [EditPropertiesStatus$1.ERROR]: 'DOCUMENT.PROPERTIES.EDIT.ERROR',
    [EditPropertiesStatus$1.INFO]: 'DOCUMENT.PROPERTIES.EDIT.INFO',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component presents document properties viewer content.
 *
 * To use the `PropertiesViewerContentComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { PropertiesViewerContentComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         PropertiesViewerContentComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-properties-viewer-content
 *    [document]="document"
 *    [properties]="defaultProperties"
 *    [editable]="editable"
 *    [expanded]="expanded"
 *    [copyToClipboardAction]="copyToClipboardAction"
 *    [displayDefaultProperties]="displayDefaultProperties"
 *    [displayEmpty]="displayEmpty"
 *    [multi]="multi"
 *    [useChipsForMultiValueProperty]="useChipsForMultiValueProperty">
 * </hxp-properties-viewer-content>
 */
class PropertiesViewerContentComponent {
    constructor(
    /**
     * An attribute representing a text to display in the header. Can be a key to translate.
     */
    // eslint-disable-next-line @angular-eslint/prefer-inject
    headerText = 'CORE.METADATA.BASIC.HEADER') {
        this.headerText = headerText;
        this.destroyRef = inject(DestroyRef);
        this.documentService = inject(DOCUMENT_SERVICE);
        this.cardViewUpdateService = inject(CardViewUpdateService);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.documentPropertiesService = inject(DOCUMENT_PROPERTIES_SERVICE);
        /**
         * The properties to display in the card view.
         * @type {CardViewItem[]}
         * @default []
         *
         * ```ts
         * export interface CardViewItem {
         *      label: string;
         *      value: any;
         *      key: string;
         *      default?: any;
         *      type: string;
         *      displayValue: any;
         *      editable?: boolean;
         *      icon?: string;
         * }
         * ```
         *
         */
        this.properties = [];
        /**
         * Toggles whether or not to enable copy to clipboard action.
         * @type {boolean}
         * @default true
         */
        this.copyToClipboardAction = true;
        /**
         * Toggles whether the metadata properties should be shown.
         * @type {boolean}
         * @default true
         */
        this.displayDefaultProperties = true;
        /**
         * Toggles whether to display empty values in the card view.
         * @type {boolean}
         * @default false
         */
        this.displayEmpty = false;
        /**
         * Toggles whether the edit button should be shown
         * @type {boolean}
         * @default false
         */
        this.editable = false;
        /**
         * Expand or collapse the panel.
         * @type {boolean}
         * @default false
         */
        this.expanded = false;
        /**
         * The multi parameter of the underlying material expansion panel, set to true to allow multi accordion to be expanded at the same time.
         * @type {boolean}
         * @default false
         */
        this.multi = false;
        /**
         * Toggles whether or not to enable chips for multivalued properties.
         * @type {boolean}
         * @default true
         */
        this.useChipsForMultiValueProperty = true;
        this.propertyUpdateRequest = new EventEmitter();
        this.editMode = false;
        this.workingCopy = true;
        this.isEditableRecord = false;
        this.cardValueValidationMap = {};
        this.documentPropertiesToUpdate = {};
        this.requiredProperties = this.documentPropertiesService.getRequiredProperties();
        this.cardViewUpdateService.itemUpdated$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(this.respondToCardUpdate.bind(this));
    }
    ngOnChanges() {
        if (this.document) {
            this.workingCopy = !isVersion(this.document);
            this.isEditableRecord = !BLOCK_EDIT_STATUSES.includes(getRetentionStatus(this.document));
        }
    }
    onSaveProperties() {
        if (!this.document?.sys_id) {
            return;
        }
        this.documentService
            .updateDocument(this.document.sys_id, this.documentPropertiesToUpdate)
            .pipe(take$1(1))
            .subscribe({
            next: (document) => {
                this.document = document;
                this.editMode = false;
                this.documentPropertiesToUpdate = {};
                this.hxpNotificationService.showSuccess(editPropertiesNotificationMessages$1[EditPropertiesStatus$1.SUCCESS]);
            },
            error: () => {
                this.hxpNotificationService.showError(editPropertiesNotificationMessages$1[EditPropertiesStatus$1.ERROR]);
            },
        });
    }
    toggleEditMode() {
        this.editMode = !this.editMode;
        this.documentPropertiesToUpdate = {};
        if (!this.editMode) {
            this.propertyUpdateRequest.emit(true);
        }
    }
    hasBeenModified() {
        return Object.keys(this.documentPropertiesToUpdate).length > 0;
    }
    allCardValuesAreValid() {
        return Object.keys(this.documentPropertiesToUpdate).every((changedKey) => this.cardValueValidationMap[changedKey]);
    }
    respondToCardUpdate(updateNotification) {
        const changedKey = Object.keys(updateNotification.changed)[0];
        const changedValue = updateNotification.changed[changedKey];
        const fieldType = this.documentPropertiesService.propertyType(changedKey);
        this.cardValueValidationMap[changedKey] = this.validateCardValue(changedKey, changedValue, fieldType);
        if (!this.cardValueValidationMap[changedKey]) {
            return;
        }
        const updatedValue = this.isComplexProperty(changedValue, fieldType)
            ? this.getUpdatedComplexProperty(changedKey, changedValue)
            : updateNotification.changed;
        this.documentPropertiesToUpdate = {
            ...this.documentPropertiesToUpdate,
            ...updatedValue,
        };
    }
    getUpdatedComplexProperty(changedKey, changedValue) {
        const existingDataInDocument = this.document?.[changedKey] || {};
        const existingUpdateData = this.documentPropertiesToUpdate[changedKey] || {};
        return {
            [changedKey]: {
                ...existingDataInDocument,
                ...existingUpdateData,
                ...changedValue,
            },
        };
    }
    validateCardValue(changedKey, changedValue, fieldType) {
        let invalidCardValue = false;
        if (fieldType === FieldType.Blob || fieldType === FieldType.Complex) {
            const nestedPropertyName = Object.keys(changedValue)[0];
            if (this.isEmptyProperty(changedValue[`${nestedPropertyName}`])) {
                invalidCardValue = this.handleEmptyProperty(`${changedKey}.${nestedPropertyName || ''}`);
            }
        }
        else if (this.isEmptyProperty(changedValue)) {
            invalidCardValue = this.handleEmptyProperty(changedKey);
        }
        return !invalidCardValue;
    }
    isComplexProperty(changedValue, fieldType) {
        return fieldType === FieldType.Complex || (fieldType !== FieldType.Date && typeof changedValue === 'object' && !Array.isArray(changedValue));
    }
    isEmptyProperty(changedValue) {
        return !changedValue;
    }
    handleEmptyProperty(propertyName) {
        if (this.requiredProperties.includes(propertyName)) {
            this.hxpNotificationService.showInfo(editPropertiesNotificationMessages$1[EditPropertiesStatus$1.INFO]);
            return true;
        }
        return false;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PropertiesViewerContentComponent, deps: [{ token: 'headerText', attribute: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: PropertiesViewerContentComponent, isStandalone: true, selector: "hxp-properties-viewer-content", inputs: { document: "document", properties: "properties", copyToClipboardAction: "copyToClipboardAction", displayDefaultProperties: "displayDefaultProperties", displayEmpty: "displayEmpty", editable: "editable", expanded: "expanded", multi: "multi", useChipsForMultiValueProperty: "useChipsForMultiValueProperty" }, outputs: { propertyUpdateRequest: "propertyUpdateRequest" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-metadata-properties\">\n    <mat-accordion\n        displayMode=\"flat\"\n        [multi]=\"multi\"\n    >\n        <mat-expansion-panel\n            *ngIf=\"displayDefaultProperties\"\n            [expanded]=\"expanded\"\n        >\n            <mat-expansion-panel-header>\n                <mat-panel-title class=\"hxp-metadata-properties-title mat-subtitle-1\">\n                    {{ headerText | translate }}\n                </mat-panel-title>\n            </mat-expansion-panel-header>\n            <adf-card-view\n                [properties]=\"properties\"\n                [editable]=\"editMode\"\n                [displayEmpty]=\"displayEmpty\"\n                [copyToClipboardAction]=\"copyToClipboardAction\"\n                [useChipsForMultiValueProperty]=\"useChipsForMultiValueProperty\"\n                [multiValueSeparator]=\"', '\"\n            />\n\n            @if (workingCopy && editable && isEditableRecord) {\n                <div class=\"hxp-property-edit-actions\">\n                    @if (!editMode) {\n                        <button\n                            mat-flat-button\n                            class=\"hxp-property-edit-button\"\n                            (click)=\"toggleEditMode()\"\n                        >\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.EDIT' | translate }}\n                        </button>\n                    } @else {\n                        <button\n                            mat-button\n                            data-automation-id=\"hxp-document-properties-edit-cancel-button\"\n                            (click)=\"toggleEditMode()\"\n                        >\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.CANCEL' | translate }}\n                        </button>\n                        <button\n                            class=\"hxp-save-properties-button\"\n                            mat-flat-button\n                            [disabled]=\"!(hasBeenModified() && allCardValuesAreValid())\"\n                            (click)=\"onSaveProperties()\"\n                        >\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.SAVE' | translate }}\n                        </button>\n                    }\n                </div>\n            }\n        </mat-expansion-panel>\n    </mat-accordion>\n</div>\n", styles: [".hxp-metadata-properties-title{margin-bottom:0}.hxp-metadata-properties .hxp-property-edit-actions{padding-top:40px;display:flex;justify-content:flex-end;gap:8px}\n"], dependencies: [{ kind: "ngmodule", type: MatExpansionModule }, { kind: "directive", type: i1$5.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i1$5.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i1$5.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i1$5.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: CardViewComponent, selector: "adf-card-view", inputs: ["properties", "editable", "displayEmpty", "displayNoneOption", "displayClearAction", "copyToClipboardAction", "useChipsForMultiValueProperty", "multiValueSeparator"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PropertiesViewerContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-properties-viewer-content', imports: [MatExpansionModule, NgIf, CardViewComponent, MatButtonModule, TranslatePipe], template: "<div class=\"hxp-metadata-properties\">\n    <mat-accordion\n        displayMode=\"flat\"\n        [multi]=\"multi\"\n    >\n        <mat-expansion-panel\n            *ngIf=\"displayDefaultProperties\"\n            [expanded]=\"expanded\"\n        >\n            <mat-expansion-panel-header>\n                <mat-panel-title class=\"hxp-metadata-properties-title mat-subtitle-1\">\n                    {{ headerText | translate }}\n                </mat-panel-title>\n            </mat-expansion-panel-header>\n            <adf-card-view\n                [properties]=\"properties\"\n                [editable]=\"editMode\"\n                [displayEmpty]=\"displayEmpty\"\n                [copyToClipboardAction]=\"copyToClipboardAction\"\n                [useChipsForMultiValueProperty]=\"useChipsForMultiValueProperty\"\n                [multiValueSeparator]=\"', '\"\n            />\n\n            @if (workingCopy && editable && isEditableRecord) {\n                <div class=\"hxp-property-edit-actions\">\n                    @if (!editMode) {\n                        <button\n                            mat-flat-button\n                            class=\"hxp-property-edit-button\"\n                            (click)=\"toggleEditMode()\"\n                        >\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.EDIT' | translate }}\n                        </button>\n                    } @else {\n                        <button\n                            mat-button\n                            data-automation-id=\"hxp-document-properties-edit-cancel-button\"\n                            (click)=\"toggleEditMode()\"\n                        >\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.CANCEL' | translate }}\n                        </button>\n                        <button\n                            class=\"hxp-save-properties-button\"\n                            mat-flat-button\n                            [disabled]=\"!(hasBeenModified() && allCardValuesAreValid())\"\n                            (click)=\"onSaveProperties()\"\n                        >\n                            {{ 'DOCUMENT.PROPERTIES_EDIT.SAVE' | translate }}\n                        </button>\n                    }\n                </div>\n            }\n        </mat-expansion-panel>\n    </mat-accordion>\n</div>\n", styles: [".hxp-metadata-properties-title{margin-bottom:0}.hxp-metadata-properties .hxp-property-edit-actions{padding-top:40px;display:flex;justify-content:flex-end;gap:8px}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Attribute,
                    args: ['headerText']
                }] }], propDecorators: { document: [{
                type: Input
            }], properties: [{
                type: Input
            }], copyToClipboardAction: [{
                type: Input
            }], displayDefaultProperties: [{
                type: Input
            }], displayEmpty: [{
                type: Input
            }], editable: [{
                type: Input
            }], expanded: [{
                type: Input
            }], multi: [{
                type: Input
            }], useChipsForMultiValueProperty: [{
                type: Input
            }], propertyUpdateRequest: [{
                type: Output
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * This component is responsible for managing the permissions in the form of a panel.
 * The rest of the application is still accessible.
 *
 * It includes functionalities to add, edit, and display permissions to `User`s and `Group`s.
 *
 * Available permissions are `Read`, `Write` and `Everything`.
 *
 * Permissions are inherited from the parent `Document`.
 * It's possible to only upgrade a inherited permission.
 *
 * To use the `PermissionsManagementPanelComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { PermissionsManagementPanelComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         PermissionsManagementPanelComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-permissions-management-panel></hxp-permissions-management-panel>
 */
class PermissionsManagementPanelComponent extends DismissPermission {
    constructor() {
        super(...arguments);
        this.permissionsPanelRequestService = inject(PermissionsPanelRequestService);
        this.dialog = inject(MatDialog);
    }
    cancel(isEdited) {
        if (!isEdited) {
            return this.close();
        }
        this.dialog.open(CancelPermissionDialogComponent, {
            width: DialogConfig.small.width,
            data: {
                dialogTitle: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.TITLE',
                dialogDescription: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.DESCRIPTION',
                dialogRejectButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.REJECT',
                dialogConfirmButton: 'PERMISSIONS_MANAGEMENT_ACTION.ASK_TO_CANCEL_DIALOG.CONFIRM',
            },
        });
    }
    close() {
        this.permissionsPanelRequestService.requestClosePanel();
    }
    restore() {
        const restoreDialogRef = this.dialog.open(RestorePermissionDialogComponent, {
            width: DialogConfig.small.width,
        });
        restoreDialogRef.afterClosed().subscribe((result) => {
            if (result?.restore) {
                this.container.restorePermissions(result.option);
            }
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementPanelComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PermissionsManagementPanelComponent, isStandalone: true, selector: "hxp-permissions-management-panel", inputs: { document: "document", parentDocument: "parentDocument" }, providers: [PermissionsManagementStateService], viewQueries: [{ propertyName: "container", first: true, predicate: PermissionManagementContainerComponent, descendants: true }], usesInheritance: true, ngImport: i0, template: "<div class=\"hxp-permissions-management-panel-container\">\n    <div class=\"hxp-permission-container\">\n        <hxp-permission-management-container\n            [document]=\"document\"\n            [parentDocument]=\"parentDocument\"\n            (cancelEvent)=\"cancel($event)\"\n            (closeEvent)=\"close()\"\n            (restoreEvent)=\"restore()\"\n        >\n            <ng-template\n                #title\n                let-title\n            >\n                <hxp-permissions-document-title [title]=\"title || ''\" />\n            </ng-template>\n        </hxp-permission-management-container>\n    </div>\n</div>\n", styles: [".hxp-permissions-management-panel-container{display:flex;padding:16px;overflow:auto;height:calc(100% - 32px)}hxp-permission-management-container{display:flex;flex-direction:column;flex:1}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatTabsModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: PermissionsDocumentTitleComponent, selector: "hxp-permissions-document-title", inputs: ["title"] }, { kind: "ngmodule", type: MatSnackBarModule }, { kind: "component", type: PermissionManagementContainerComponent, selector: "hxp-permission-management-container", inputs: ["document", "parentDocument"], outputs: ["cancelEvent", "closeEvent", "restoreEvent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementPanelComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-permissions-management-panel', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTabsModule,
                        MatIconModule,
                        MatDividerModule,
                        PermissionsDocumentTitleComponent,
                        MatSnackBarModule,
                        PermissionManagementContainerComponent,
                    ], providers: [PermissionsManagementStateService], template: "<div class=\"hxp-permissions-management-panel-container\">\n    <div class=\"hxp-permission-container\">\n        <hxp-permission-management-container\n            [document]=\"document\"\n            [parentDocument]=\"parentDocument\"\n            (cancelEvent)=\"cancel($event)\"\n            (closeEvent)=\"close()\"\n            (restoreEvent)=\"restore()\"\n        >\n            <ng-template\n                #title\n                let-title\n            >\n                <hxp-permissions-document-title [title]=\"title || ''\" />\n            </ng-template>\n        </hxp-permission-management-container>\n    </div>\n</div>\n", styles: [".hxp-permissions-management-panel-container{display:flex;padding:16px;overflow:auto;height:calc(100% - 32px)}hxp-permission-management-container{display:flex;flex-direction:column;flex:1}\n"] }]
        }], propDecorators: { document: [{
                type: Input
            }], parentDocument: [{
                type: Input
            }], container: [{
                type: ViewChild,
                args: [PermissionManagementContainerComponent]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Pipe that transforms a Document object into a URL string using the DocumentRouterService.
 *
 * @example
 * * Using the pipe in a component:
 * ```typescript
 * const document: Document = { id: '123', name: 'example.docx' };
 * const options: DocumentRouterOptions = { absolute: true };
 * const url: string = documentRouterPipe.transform(document, options);
 * ```
 * Using the pipe in a template:
 * ```html
 * <a [href]="document | urlFor: { absolute: true }">Document Details</a>
 * ```
 */
class DocumentRouterPipe {
    constructor() {
        this.documentRouterService = inject(DocumentRouterService);
    }
    transform(document, options = { absolute: false }) {
        return this.documentRouterService.urlFor(document, options);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentRouterPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.20", ngImport: i0, type: DocumentRouterPipe, isStandalone: true, name: "urlFor" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentRouterPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'urlFor',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component presents document breadcrumb.
 * To use the `HxpUiBreadcrumbComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpUiBreadcrumbComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         HxpUiBreadcrumbComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-ui-breadcrumb [documents]="documents"></hxp-ui-breadcrumb>
 */
class HxpUiBreadcrumbComponent {
    constructor() {
        /**
         * List of `Document` object the breadcrumb is rendered from.
         * @type {Document}
         */
        this.documents = [];
        /**
         * If true, breadcrumb elements are grouped together and displayed as ellipsis, except for the first and last entry.
         * @default false
         * @type {boolean}
         */
        this.compact = false;
    }
    documentTrackBy(_index, document) {
        return document?.sys_id;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpUiBreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: HxpUiBreadcrumbComponent, isStandalone: true, selector: "hxp-ui-breadcrumb", inputs: { documents: "documents", compact: "compact" }, ngImport: i0, template: "<adf-breadcrumb\n    [compact]=\"compact\"\n    data-testid=\"breadcrumb\"\n>\n    <adf-breadcrumb-item *ngFor=\"let doc of documents; last as isLast; trackBy: documentTrackBy\">\n        <a\n            class=\"hxp-breadcrumb-item\"\n            *ngIf=\"!!doc; else notNavigable\"\n            [routerLink]=\"!isLast ? (doc | urlFor) : undefined\"\n            [attr.aria-current]=\"isLast ? 'location' : undefined\"\n        >\n            {{ doc | breadcrumbLabel: 'DOCUMENT_BREADCRUMB.ROOT' }}\n        </a>\n        <ng-template #notNavigable>\n            <span class=\"hxp-not-navigable-folder\"> ... </span>\n        </ng-template>\n    </adf-breadcrumb-item>\n</adf-breadcrumb>\n", styles: [".hxp-breadcrumb-item{font:var(--mat-sys-body-medium)}.hxp-not-navigable-folder{font-weight:600;color:var(--mat-sys-secondary)}\n"], dependencies: [{ kind: "component", type: BreadcrumbComponent, selector: "adf-breadcrumb", inputs: ["compact"], outputs: ["compactChange"] }, { kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "component", type: BreadcrumbItemComponent, selector: "adf-breadcrumb-item" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "pipe", type: DocumentRouterPipe, name: "urlFor" }, { kind: "pipe", type: BreadcrumbLabelPipe, name: "breadcrumbLabel" }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpUiBreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-ui-breadcrumb', encapsulation: ViewEncapsulation.None, imports: [BreadcrumbComponent, NgFor, BreadcrumbItemComponent, NgIf, RouterLink, DocumentRouterPipe, BreadcrumbLabelPipe], template: "<adf-breadcrumb\n    [compact]=\"compact\"\n    data-testid=\"breadcrumb\"\n>\n    <adf-breadcrumb-item *ngFor=\"let doc of documents; last as isLast; trackBy: documentTrackBy\">\n        <a\n            class=\"hxp-breadcrumb-item\"\n            *ngIf=\"!!doc; else notNavigable\"\n            [routerLink]=\"!isLast ? (doc | urlFor) : undefined\"\n            [attr.aria-current]=\"isLast ? 'location' : undefined\"\n        >\n            {{ doc | breadcrumbLabel: 'DOCUMENT_BREADCRUMB.ROOT' }}\n        </a>\n        <ng-template #notNavigable>\n            <span class=\"hxp-not-navigable-folder\"> ... </span>\n        </ng-template>\n    </adf-breadcrumb-item>\n</adf-breadcrumb>\n", styles: [".hxp-breadcrumb-item{font:var(--mat-sys-body-medium)}.hxp-not-navigable-folder{font-weight:600;color:var(--mat-sys-secondary)}\n"] }]
        }], propDecorators: { documents: [{
                type: Input
            }], compact: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component that displays a series of clickable links that represent the path to a given `Document`.
 * To use the `HxpBreadcrumbComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpBreadcrumbComponent } from '@alfresco/adf-hx-content-services/icons';
 * @NgModule({
 *     imports: [
 *         HxpBreadcrumbComponent
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-breadcrumb [document]="document"></hxp-breadcrumb>
 *
 */
class HxpBreadcrumbComponent {
    constructor() {
        /**
         * The `Document` object for which the breadcrumb is displayed.
         * The breadcrumb will be built based on the ancestors of the given `Document`.
         */
        this.document = ROOT_DOCUMENT;
        /**
         * If true, breadcrumb elements are grouped together and displayed as ellipsis, except for the first and last entry.
         */
        this.compact = false;
        this.breadcrumbElements = [];
        this.documentService = inject(DocumentService);
    }
    ngOnInit() {
        this._buildBreadcrumb(this.document);
    }
    ngOnChanges(changes) {
        if (changes['document']) {
            this._buildBreadcrumb(this.document);
        }
    }
    _buildBreadcrumb(document) {
        if (!document) {
            this.breadcrumbElements = [];
            return;
        }
        this.documentService
            .getAncestors(document?.sys_id ?? '')
            .pipe(catchError(() => of([{ ...ROOT_DOCUMENT }])), map$1((ancestors) => (isVersion(document) ? ancestors.filter((ancestor) => ancestor.sys_id !== document.sys_parentId) : ancestors)))
            .subscribe({
            next: (ancestors) => {
                this.breadcrumbElements = ancestors;
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpBreadcrumbComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: HxpBreadcrumbComponent, isStandalone: true, selector: "hxp-breadcrumb", inputs: { document: "document", compact: "compact" }, usesOnChanges: true, ngImport: i0, template: "<hxp-ui-breadcrumb\n    [compact]=\"compact\"\n    [documents]=\"breadcrumbElements\"\n/>\n", dependencies: [{ kind: "component", type: HxpUiBreadcrumbComponent, selector: "hxp-ui-breadcrumb", inputs: ["documents", "compact"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpBreadcrumbComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-breadcrumb', encapsulation: ViewEncapsulation.None, imports: [HxpUiBreadcrumbComponent], template: "<hxp-ui-breadcrumb\n    [compact]=\"compact\"\n    [documents]=\"breadcrumbElements\"\n/>\n" }]
        }], propDecorators: { document: [{
                type: Input
            }], compact: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const EditPropertiesStatus = {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
    INFO: 'INFO',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const editPropertiesNotificationMessages = {
    [EditPropertiesStatus.SUCCESS]: 'DOCUMENT.PROPERTIES.EDIT.SUCCESS',
    [EditPropertiesStatus.ERROR]: 'DOCUMENT.PROPERTIES.EDIT.ERROR',
    [EditPropertiesStatus.INFO]: 'DOCUMENT.PROPERTIES.EDIT.INFO',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component presents document properties viewer container.
 *
 * To use the `MetadataSidebarContentComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { MetadataSidebarContentComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         MetadataSidebarContentComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-metadata-sidebar-content
 *    [document]="document"
 *    [editable]="editable"
 *    [copyToClipboardAction]="copyToClipboardAction"
 *    [displayEmpty]="displayEmpty"
 *    [useChipsForMultiValueProperty]="useChipsForMultiValueProperty">
 * </hxp-metadata-sidebar-content>
 */
class MetadataSidebarContentComponent {
    constructor() {
        /**
         * The document to display the properties for.
         * @type {Document}
         * @required
         */
        this.document = input();
        /**
         * The properties to display in the card view.
         * @type {CardViewItem[]}
         * @default []
         *
         * ```ts
         * export interface CardViewItem {
         *      label: string;
         *      value: any;
         *      key: string;
         *      default?: any;
         *      type: string;
         *      displayValue: any;
         *      editable?: boolean;
         *      icon?: string;
         * }
         * ```
         *
         */
        this.properties = input([]);
        this.propertiesGroups = input([]);
        /**
         * Toggles whether or not to enable copy to clipboard action.
         * @type {boolean}
         * @default true
         */
        this.copyToClipboardAction = input(true);
        /**
         * Toggles whether to display empty values in the card view.
         * @type {boolean}
         * @default false
         */
        this.displayEmpty = input(true);
        /**
         * Toggles whether the edit button should be shown
         * @type {boolean}
         * @default false
         */
        this.editable = input(false);
        /**
         * Toggles whether or not to enable chips for multivalued properties.
         * @type {boolean}
         * @default true
         */
        this.useChipsForMultiValueProperty = input(true);
        /**
         * Toggles whether to display properties in a collapsible accordion.
         * When true, properties are shown in an expandable accordion with the first property's label as the header.
         * When false, properties are displayed directly without accordion wrapping.
         * @type {boolean}
         * @default false
         */
        this.collapsible = input(false);
        this.propertyUpdateRequest = output();
        /**
         * Array of invalid field IDs that should trigger accordion expansion.
         * When set, accordions containing these fields will automatically expand.
         * @type {string[]}
         * @default []
         */
        this.invalidFieldIds = input([]);
        this.expansionPanels = viewChildren(MatExpansionPanel);
        this.expandedStates = signal([]);
        this.groupedProperties = computed(() => {
            const props = this.properties();
            const groups = this.propertiesGroups();
            return groups.map((group, index) => ({
                ...group,
                properties: this.getPropertiesForGroup(props, group.fields),
                expanded: index === 0,
            }));
        });
        this.allExpanded = computed(() => {
            const states = this.expandedStates();
            return states.length > 0 && states.every(Boolean);
        });
        this.multiValueSeparator = ', ';
        // Effect to expand accordions containing invalid fields
        effect(() => {
            const invalidIds = this.invalidFieldIds();
            if (invalidIds.length > 0) {
                this.expandAccordionsWithInvalidFields(invalidIds);
            }
        });
    }
    getPropertiesForGroup(properties, fields) {
        const keys = Object.keys(fields);
        return properties.filter((property) => keys.includes(property.key.split('.')[0]));
    }
    onPanelExpandedChange() {
        const panels = this.expansionPanels();
        this.expandedStates.set(panels.map((panel) => panel.expanded));
    }
    toggleAllAccordions() {
        const expandable = !this.allExpanded();
        const panels = this.expansionPanels();
        for (const panel of panels) {
            if (expandable) {
                panel.open();
            }
            else {
                panel.close();
            }
        }
        this.expandedStates.set(panels.map(() => expandable));
    }
    expandAccordionsWithInvalidFields(invalidIds) {
        const props = this.properties();
        const groups = this.propertiesGroups();
        const panels = this.expansionPanels();
        for (const [index, group] of groups.entries()) {
            if (!panels[index]) {
                continue;
            }
            const groupProperties = this.getPropertiesForGroup(props, group.fields);
            const hasInvalidField = groupProperties.some((prop) => invalidIds.includes(prop.key));
            if (hasInvalidField) {
                panels[index].open();
            }
        }
        this.expandedStates.set(panels.map((panel) => panel.expanded));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: MetadataSidebarContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: MetadataSidebarContentComponent, isStandalone: true, selector: "hxp-metadata-sidebar-content", inputs: { document: { classPropertyName: "document", publicName: "document", isSignal: true, isRequired: false, transformFunction: null }, properties: { classPropertyName: "properties", publicName: "properties", isSignal: true, isRequired: false, transformFunction: null }, propertiesGroups: { classPropertyName: "propertiesGroups", publicName: "propertiesGroups", isSignal: true, isRequired: false, transformFunction: null }, copyToClipboardAction: { classPropertyName: "copyToClipboardAction", publicName: "copyToClipboardAction", isSignal: true, isRequired: false, transformFunction: null }, displayEmpty: { classPropertyName: "displayEmpty", publicName: "displayEmpty", isSignal: true, isRequired: false, transformFunction: null }, editable: { classPropertyName: "editable", publicName: "editable", isSignal: true, isRequired: false, transformFunction: null }, useChipsForMultiValueProperty: { classPropertyName: "useChipsForMultiValueProperty", publicName: "useChipsForMultiValueProperty", isSignal: true, isRequired: false, transformFunction: null }, collapsible: { classPropertyName: "collapsible", publicName: "collapsible", isSignal: true, isRequired: false, transformFunction: null }, invalidFieldIds: { classPropertyName: "invalidFieldIds", publicName: "invalidFieldIds", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { propertyUpdateRequest: "propertyUpdateRequest" }, viewQueries: [{ propertyName: "expansionPanels", predicate: MatExpansionPanel, descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"hxp-metadata-properties\">\n    @if (properties() && properties().length > 0) {\n        @if (collapsible()) {\n            <div class=\"hxp-metadata-properties-accordion-controls\">\n                <button\n                    mat-button\n                    (click)=\"toggleAllAccordions()\"\n                    class=\"hxp-accordion-controls-button\"\n                    data-automation-id=\"metadata-accordion-toggle-all\"\n                >\n                    {{\n                        (allExpanded() ? 'DOCUMENT.METADATA.PROPERTIES.ACCORDION.COLLAPSE_ALL' : 'DOCUMENT.METADATA.PROPERTIES.ACCORDION.EXPAND_ALL')\n                            | translate\n                    }}\n                </button>\n            </div>\n            @for (group of groupedProperties(); track group.schema) {\n                <mat-accordion displayMode=\"flat\">\n                    <mat-expansion-panel\n                        class=\"hxp-panel-dropdown mat-elevation-z0\"\n                        [expanded]=\"group.expanded\"\n                        (expandedChange)=\"onPanelExpandedChange()\"\n                    >\n                        <mat-expansion-panel-header>\n                            <mat-panel-title>{{ group.schema | translate }}</mat-panel-title>\n                        </mat-expansion-panel-header>\n                        <div class=\"hxp-metadata-properties-accordion-content\">\n                            <adf-card-view\n                                [properties]=\"group.properties\"\n                                [editable]=\"editable()\"\n                                [displayEmpty]=\"displayEmpty()\"\n                                [copyToClipboardAction]=\"copyToClipboardAction()\"\n                                [useChipsForMultiValueProperty]=\"useChipsForMultiValueProperty()\"\n                                [multiValueSeparator]=\"multiValueSeparator\"\n                            />\n                        </div>\n                    </mat-expansion-panel>\n                </mat-accordion>\n            }\n        } @else {\n            <adf-card-view\n                [properties]=\"properties()\"\n                [editable]=\"editable()\"\n                [displayEmpty]=\"displayEmpty()\"\n                [copyToClipboardAction]=\"copyToClipboardAction()\"\n                [useChipsForMultiValueProperty]=\"useChipsForMultiValueProperty()\"\n                [multiValueSeparator]=\"multiValueSeparator\"\n            />\n        }\n    }\n</div>\n", styles: [":host{--mdc-outlined-text-field-disabled-input-text-color: var(--mat-sys-on-surface);--adf-metadata-property-panel-label-color: var(--mat-sys-on-surface)}.hxp-metadata-properties{display:flex;flex-direction:column}.hxp-metadata-properties-title{margin-bottom:16px;font-size:var(--mat-sys-headline-small)}.hxp-metadata-properties-accordion-content{margin-top:12px}.hxp-metadata-properties-accordion-controls{display:flex;justify-content:flex-end;padding-top:8px}\n"], dependencies: [{ kind: "ngmodule", type: MatExpansionModule }, { kind: "directive", type: i1$5.MatAccordion, selector: "mat-accordion", inputs: ["hideToggle", "displayMode", "togglePosition"], exportAs: ["matAccordion"] }, { kind: "component", type: i1$5.MatExpansionPanel, selector: "mat-expansion-panel", inputs: ["hideToggle", "togglePosition"], outputs: ["afterExpand", "afterCollapse"], exportAs: ["matExpansionPanel"] }, { kind: "component", type: i1$5.MatExpansionPanelHeader, selector: "mat-expansion-panel-header", inputs: ["expandedHeight", "collapsedHeight", "tabIndex"] }, { kind: "directive", type: i1$5.MatExpansionPanelTitle, selector: "mat-panel-title" }, { kind: "component", type: CardViewComponent, selector: "adf-card-view", inputs: ["properties", "editable", "displayEmpty", "displayNoneOption", "displayClearAction", "copyToClipboardAction", "useChipsForMultiValueProperty", "multiValueSeparator"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: MetadataSidebarContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-metadata-sidebar-content', changeDetection: ChangeDetectionStrategy.OnPush, imports: [MatExpansionModule, CardViewComponent, MatButtonModule, TranslatePipe], template: "<div class=\"hxp-metadata-properties\">\n    @if (properties() && properties().length > 0) {\n        @if (collapsible()) {\n            <div class=\"hxp-metadata-properties-accordion-controls\">\n                <button\n                    mat-button\n                    (click)=\"toggleAllAccordions()\"\n                    class=\"hxp-accordion-controls-button\"\n                    data-automation-id=\"metadata-accordion-toggle-all\"\n                >\n                    {{\n                        (allExpanded() ? 'DOCUMENT.METADATA.PROPERTIES.ACCORDION.COLLAPSE_ALL' : 'DOCUMENT.METADATA.PROPERTIES.ACCORDION.EXPAND_ALL')\n                            | translate\n                    }}\n                </button>\n            </div>\n            @for (group of groupedProperties(); track group.schema) {\n                <mat-accordion displayMode=\"flat\">\n                    <mat-expansion-panel\n                        class=\"hxp-panel-dropdown mat-elevation-z0\"\n                        [expanded]=\"group.expanded\"\n                        (expandedChange)=\"onPanelExpandedChange()\"\n                    >\n                        <mat-expansion-panel-header>\n                            <mat-panel-title>{{ group.schema | translate }}</mat-panel-title>\n                        </mat-expansion-panel-header>\n                        <div class=\"hxp-metadata-properties-accordion-content\">\n                            <adf-card-view\n                                [properties]=\"group.properties\"\n                                [editable]=\"editable()\"\n                                [displayEmpty]=\"displayEmpty()\"\n                                [copyToClipboardAction]=\"copyToClipboardAction()\"\n                                [useChipsForMultiValueProperty]=\"useChipsForMultiValueProperty()\"\n                                [multiValueSeparator]=\"multiValueSeparator\"\n                            />\n                        </div>\n                    </mat-expansion-panel>\n                </mat-accordion>\n            }\n        } @else {\n            <adf-card-view\n                [properties]=\"properties()\"\n                [editable]=\"editable()\"\n                [displayEmpty]=\"displayEmpty()\"\n                [copyToClipboardAction]=\"copyToClipboardAction()\"\n                [useChipsForMultiValueProperty]=\"useChipsForMultiValueProperty()\"\n                [multiValueSeparator]=\"multiValueSeparator\"\n            />\n        }\n    }\n</div>\n", styles: [":host{--mdc-outlined-text-field-disabled-input-text-color: var(--mat-sys-on-surface);--adf-metadata-property-panel-label-color: var(--mat-sys-on-surface)}.hxp-metadata-properties{display:flex;flex-direction:column}.hxp-metadata-properties-title{margin-bottom:16px;font-size:var(--mat-sys-headline-small)}.hxp-metadata-properties-accordion-content{margin-top:12px}.hxp-metadata-properties-accordion-controls{display:flex;justify-content:flex-end;padding-top:8px}\n"] }]
        }], ctorParameters: () => [] });

class MetadataSidebarService {
    constructor() {
        this.EDITABLE_DEFAULT_PROPERTIES = ['sys_primaryType', 'sys_title', 'sysfile_blob.filename'];
        this.NON_EDITABLE_DEFAULT_PROPERTIES = [
            'sys_created',
            'sys_modified',
            'sys_creator',
            'sys_lastContributor',
            'sys_contributors',
            'sys_path',
            'sysfile_blob.length',
            'sysfile_blob.mimeType',
        ];
        this.documentPropertiesService = inject(DOCUMENT_PROPERTIES_SERVICE);
    }
    getEditableSystemPropertiesFromDocument(document) {
        if (!document) {
            return of([]);
        }
        return this.documentPropertiesService
            .getDefaultPropertiesFromDocument(document)
            .pipe(map((properties) => this.filterAndSortProperties(properties, this.EDITABLE_DEFAULT_PROPERTIES)));
    }
    getNonEditableSystemPropertiesFromDocument(document) {
        if (!document) {
            return of([]);
        }
        return this.documentPropertiesService
            .getDefaultPropertiesFromDocument(document)
            .pipe(map((properties) => this.filterAndSortProperties(properties, this.NON_EDITABLE_DEFAULT_PROPERTIES)));
    }
    getCustomProperties(document) {
        if (!document) {
            return of([]);
        }
        return this.documentPropertiesService.getPropertiesFromDocument(document, {
            exclude: {
                schemas: ['sysfile_blob', 'sys_', 'sysver_', 'sysgov_'],
            },
        });
    }
    filterAndSortProperties(properties, keys) {
        return properties.filter((property) => keys.includes(property.key)).sort((a, b) => keys.indexOf(a.key) - keys.indexOf(b.key));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: MetadataSidebarService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: MetadataSidebarService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: MetadataSidebarService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class HxpCancelMetadataSidebarEditDialogComponent {
    constructor() {
        this.discardChanges = output();
        this.saveChanges = output();
        this.dialogRef = inject((MatDialogRef));
    }
    onDiscardChanges() {
        this.dialogRef.close();
        this.discardChanges.emit();
    }
    onSaveAndExit() {
        this.dialogRef.close();
        this.saveChanges.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpCancelMetadataSidebarEditDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: HxpCancelMetadataSidebarEditDialogComponent, isStandalone: true, selector: "hxp-cancel-metadata-sidebar-edit-dialog", outputs: { discardChanges: "discardChanges", saveChanges: "saveChanges" }, ngImport: i0, template: "<div class=\"hxp-cancel-edit-dialog\">\n    <h1 mat-dialog-title>{{ 'DOCUMENT.METADATA.CANCEL_DIALOG.TITLE' | translate }}</h1>\n    <div mat-dialog-content>\n        <p>{{ 'DOCUMENT.METADATA.CANCEL_DIALOG.DESCRIPTION_LINE1' | translate }}</p>\n        <p>{{ 'DOCUMENT.METADATA.CANCEL_DIALOG.DESCRIPTION_LINE2' | translate }}</p>\n    </div>\n    <div\n        mat-dialog-actions\n        align=\"end\"\n    >\n        <button\n            mat-button\n            data-automation-id=\"continue-editing-button\"\n            mat-dialog-close\n        >\n            {{ 'DOCUMENT.METADATA.CANCEL_DIALOG.CONTINUE_EDITING' | translate }}\n        </button>\n        <button\n            mat-button\n            data-automation-id=\"discard-button\"\n            (click)=\"onDiscardChanges()\"\n        >\n            {{ 'DOCUMENT.METADATA.CANCEL_DIALOG.DISCARD' | translate }}\n        </button>\n        <button\n            mat-flat-button\n            cdkFocusInitial\n            data-automation-id=\"save-and-exit-button\"\n            (click)=\"onSaveAndExit()\"\n        >\n            {{ 'DOCUMENT.METADATA.CANCEL_DIALOG.SAVE_AND_EXIT' | translate }}\n        </button>\n    </div>\n</div>\n", dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogTitle, selector: "[mat-dialog-title], [matDialogTitle]", inputs: ["id"], exportAs: ["matDialogTitle"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpCancelMetadataSidebarEditDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-cancel-metadata-sidebar-edit-dialog', imports: [CommonModule, MatDialogModule, MatButtonModule, TranslatePipe], template: "<div class=\"hxp-cancel-edit-dialog\">\n    <h1 mat-dialog-title>{{ 'DOCUMENT.METADATA.CANCEL_DIALOG.TITLE' | translate }}</h1>\n    <div mat-dialog-content>\n        <p>{{ 'DOCUMENT.METADATA.CANCEL_DIALOG.DESCRIPTION_LINE1' | translate }}</p>\n        <p>{{ 'DOCUMENT.METADATA.CANCEL_DIALOG.DESCRIPTION_LINE2' | translate }}</p>\n    </div>\n    <div\n        mat-dialog-actions\n        align=\"end\"\n    >\n        <button\n            mat-button\n            data-automation-id=\"continue-editing-button\"\n            mat-dialog-close\n        >\n            {{ 'DOCUMENT.METADATA.CANCEL_DIALOG.CONTINUE_EDITING' | translate }}\n        </button>\n        <button\n            mat-button\n            data-automation-id=\"discard-button\"\n            (click)=\"onDiscardChanges()\"\n        >\n            {{ 'DOCUMENT.METADATA.CANCEL_DIALOG.DISCARD' | translate }}\n        </button>\n        <button\n            mat-flat-button\n            cdkFocusInitial\n            data-automation-id=\"save-and-exit-button\"\n            (click)=\"onSaveAndExit()\"\n        >\n            {{ 'DOCUMENT.METADATA.CANCEL_DIALOG.SAVE_AND_EXIT' | translate }}\n        </button>\n    </div>\n</div>\n" }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class HxpMetadataSidebarAdditionalInfoComponent {
    constructor() {
        this.nonEditableSystemProperties = input([]);
        this.pathContent = viewChild('pathContent');
        this.pathProperty = computed(() => this.nonEditableSystemProperties().find((p) => p.label?.toLowerCase() === 'path'));
        this.isClamped = true;
        this.isOverflowing = false;
        this.hasOverflowed = false;
        this.checkOverflow$ = new Subject();
        this.clipboard = inject(Clipboard);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.checkOverflow$.pipe(takeUntilDestroyed()).subscribe(() => {
            this.checkOverflow();
        });
        afterNextRender(() => {
            const pathContentElement = this.pathContent();
            if (pathContentElement) {
                const resizeObserver = new ResizeObserver(() => {
                    this.checkOverflow$.next();
                });
                resizeObserver.observe(pathContentElement.nativeElement);
            }
        });
    }
    toggleClamp() {
        this.isClamped = !this.isClamped;
    }
    onCopyPath() {
        const pathProperty = this.pathProperty();
        if (pathProperty?.displayValue) {
            const copied = this.clipboard.copy(pathProperty.displayValue);
            if (copied) {
                this.hxpNotificationService.showSuccess('DOCUMENT.METADATA.COPY_PATH.SUCCESS');
            }
        }
    }
    checkOverflow() {
        // To avoid multiple calculations once overflow is detected
        if (this.hasOverflowed) {
            return;
        }
        const pathContentElement = this.pathContent();
        if (pathContentElement) {
            const element = pathContentElement.nativeElement;
            this.isOverflowing = element.scrollHeight > element.clientHeight;
            if (this.isOverflowing) {
                this.hasOverflowed = true;
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpMetadataSidebarAdditionalInfoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: HxpMetadataSidebarAdditionalInfoComponent, isStandalone: true, selector: "hxp-metadata-sidebar-additional-info", inputs: { nonEditableSystemProperties: { classPropertyName: "nonEditableSystemProperties", publicName: "nonEditableSystemProperties", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "pathContent", first: true, predicate: ["pathContent"], descendants: true, isSignal: true }], ngImport: i0, template: "<dl class=\"hxp-metadata-panel-additional-info\">\n    @for (property of nonEditableSystemProperties(); track property.key) {\n        @if (property.label.toLowerCase() === 'path') {\n            <div class=\"hxp-metadata-panel-additional-info-property-path\">\n                <dt class=\"hxp-metadata-panel-additional-info-property-label mat-body-small\">{{ property.label }}</dt>\n                <dd class=\"hxp-metadata-panel-additional-info-property-container\">\n                    <span\n                        #pathContent\n                        class=\"hxp-metadata-panel-additional-info-property-value\"\n                        [attr.data-automation-id]=\"'hxp-metadata-additional-info-value-' + property.key\"\n                        [class.hxp-metadata-panel-additional-info-property-value_clamp]=\"isClamped\"\n                    >\n                        {{ property.displayValue }}\n                    </span>\n                    @if (hasOverflowed) {\n                        <button\n                            mat-icon-button\n                            (click)=\"toggleClamp()\"\n                            [attr.aria-label]=\"\n                                (isClamped ? 'DOCUMENT.METADATA.TOGGLE_PATH.EXPAND' : 'DOCUMENT.METADATA.TOGGLE_PATH.COLLAPSE') | translate\n                            \"\n                            [attr.aria-expanded]=\"!isClamped\"\n                            matTooltip=\"{{\n                                (isClamped ? 'DOCUMENT.METADATA.TOGGLE_PATH.EXPAND' : 'DOCUMENT.METADATA.TOGGLE_PATH.COLLAPSE') | translate\n                            }}\"\n                            class=\"hxp-metadata-panel-additional-info-property-path-expand-button\"\n                        >\n                            <mat-icon [svgIcon]=\"isClamped ? 'chevron_down' : 'chevron_up'\" />\n                        </button>\n                    }\n                    <button\n                        mat-icon-button\n                        (click)=\"onCopyPath()\"\n                        [attr.aria-label]=\"'DOCUMENT.METADATA.COPY_PATH.TOOLTIP' | translate\"\n                        matTooltip=\"{{ 'DOCUMENT.METADATA.COPY_PATH.TOOLTIP' | translate }}\"\n                        class=\"hxp-metadata-panel-additional-info-property-path-copy-button\"\n                    >\n                        <mat-icon\n                            class=\"hxp-metadata-panel-additional-info-property-path-copy-button-icon\"\n                            svgIcon=\"copy\"\n                        />\n                    </button>\n                </dd>\n            </div>\n        } @else {\n            <div class=\"hxp-metadata-panel-additional-info-property\">\n                <dt class=\"hxp-metadata-panel-additional-info-property-label mat-body-small\">{{ property.label }}</dt>\n                <dd\n                    class=\"hxp-metadata-panel-additional-info-property-value\"\n                    [attr.data-automation-id]=\"'hxp-metadata-additional-info-value-' + property.key\"\n                >\n                    {{ property.displayValue }}\n                </dd>\n            </div>\n        }\n    }\n</dl>\n", styles: [".hxp-metadata-panel-additional-info{margin:24px 0}.hxp-metadata-panel-additional-info-property{display:flex;flex-direction:column;margin-bottom:24px}.hxp-metadata-panel-additional-info-property-value{margin-inline-start:unset;overflow-wrap:anywhere}.hxp-metadata-panel-additional-info-property-value_clamp{display:-webkit-box;line-clamp:2;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;flex:1}.hxp-metadata-panel-additional-info-property-container{display:flex;margin-inline-start:unset}.hxp-metadata-panel-additional-info-property-path{display:flex;flex-direction:column}.hxp-metadata-panel-additional-info-property-path-expand-button,.hxp-metadata-panel-additional-info-property-path-copy-button{transform:translate(-4px,-8px)}.hxp-metadata-panel-additional-info-property-path-copy-button-icon{font-size:var(--mat-sys-body-medium)}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpMetadataSidebarAdditionalInfoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-metadata-sidebar-additional-info', imports: [MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "<dl class=\"hxp-metadata-panel-additional-info\">\n    @for (property of nonEditableSystemProperties(); track property.key) {\n        @if (property.label.toLowerCase() === 'path') {\n            <div class=\"hxp-metadata-panel-additional-info-property-path\">\n                <dt class=\"hxp-metadata-panel-additional-info-property-label mat-body-small\">{{ property.label }}</dt>\n                <dd class=\"hxp-metadata-panel-additional-info-property-container\">\n                    <span\n                        #pathContent\n                        class=\"hxp-metadata-panel-additional-info-property-value\"\n                        [attr.data-automation-id]=\"'hxp-metadata-additional-info-value-' + property.key\"\n                        [class.hxp-metadata-panel-additional-info-property-value_clamp]=\"isClamped\"\n                    >\n                        {{ property.displayValue }}\n                    </span>\n                    @if (hasOverflowed) {\n                        <button\n                            mat-icon-button\n                            (click)=\"toggleClamp()\"\n                            [attr.aria-label]=\"\n                                (isClamped ? 'DOCUMENT.METADATA.TOGGLE_PATH.EXPAND' : 'DOCUMENT.METADATA.TOGGLE_PATH.COLLAPSE') | translate\n                            \"\n                            [attr.aria-expanded]=\"!isClamped\"\n                            matTooltip=\"{{\n                                (isClamped ? 'DOCUMENT.METADATA.TOGGLE_PATH.EXPAND' : 'DOCUMENT.METADATA.TOGGLE_PATH.COLLAPSE') | translate\n                            }}\"\n                            class=\"hxp-metadata-panel-additional-info-property-path-expand-button\"\n                        >\n                            <mat-icon [svgIcon]=\"isClamped ? 'chevron_down' : 'chevron_up'\" />\n                        </button>\n                    }\n                    <button\n                        mat-icon-button\n                        (click)=\"onCopyPath()\"\n                        [attr.aria-label]=\"'DOCUMENT.METADATA.COPY_PATH.TOOLTIP' | translate\"\n                        matTooltip=\"{{ 'DOCUMENT.METADATA.COPY_PATH.TOOLTIP' | translate }}\"\n                        class=\"hxp-metadata-panel-additional-info-property-path-copy-button\"\n                    >\n                        <mat-icon\n                            class=\"hxp-metadata-panel-additional-info-property-path-copy-button-icon\"\n                            svgIcon=\"copy\"\n                        />\n                    </button>\n                </dd>\n            </div>\n        } @else {\n            <div class=\"hxp-metadata-panel-additional-info-property\">\n                <dt class=\"hxp-metadata-panel-additional-info-property-label mat-body-small\">{{ property.label }}</dt>\n                <dd\n                    class=\"hxp-metadata-panel-additional-info-property-value\"\n                    [attr.data-automation-id]=\"'hxp-metadata-additional-info-value-' + property.key\"\n                >\n                    {{ property.displayValue }}\n                </dd>\n            </div>\n        }\n    }\n</dl>\n", styles: [".hxp-metadata-panel-additional-info{margin:24px 0}.hxp-metadata-panel-additional-info-property{display:flex;flex-direction:column;margin-bottom:24px}.hxp-metadata-panel-additional-info-property-value{margin-inline-start:unset;overflow-wrap:anywhere}.hxp-metadata-panel-additional-info-property-value_clamp{display:-webkit-box;line-clamp:2;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;flex:1}.hxp-metadata-panel-additional-info-property-container{display:flex;margin-inline-start:unset}.hxp-metadata-panel-additional-info-property-path{display:flex;flex-direction:column}.hxp-metadata-panel-additional-info-property-path-expand-button,.hxp-metadata-panel-additional-info-property-path-copy-button{transform:translate(-4px,-8px)}.hxp-metadata-panel-additional-info-property-path-copy-button-icon{font-size:var(--mat-sys-body-medium)}\n"] }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class HxpMetadataCacheService {
    constructor() {
        this.globalCache = new Map();
    }
    /**
     * Retrieves a cached value by its key if it has been updated.
     * If the value exists in the cache, it returns the value.
     * If the key does not exist in the cache, it returns the provided fallback value (if any) and stores it in the cache.
     * @param key The key to look up in the cache.
     * @param fallbackValue The value to return and store if the key is not found.
     * @returns The cached value or the fallback value.
     */
    getCachedValue(key, fallbackValue) {
        let value = fallbackValue;
        if (this.globalCache.has(key)) {
            const cachedItem = this.globalCache.get(key);
            value = cachedItem?.updated ? cachedItem.value : cachedItem?.originalValue ?? fallbackValue;
        }
        else if (fallbackValue !== undefined) {
            if (this.isComplexValue(fallbackValue)) {
                throw new Error('Caching of complex objects is only supported using dot notation keys. Eg: "schema.propertyName"');
            }
            this.globalCache.set(key, { value: fallbackValue, updated: false, originalValue: fallbackValue });
        }
        return value;
    }
    getAllCachedValues() {
        const allValues = {};
        for (const [fieldName, cachedItem] of this.globalCache.entries()) {
            allValues[fieldName] = cachedItem.value;
        }
        return allValues;
    }
    updateCache(keyValuePairs) {
        this.updateGlobalCache(keyValuePairs);
    }
    invalidateCache() {
        this.globalCache.clear();
    }
    getUpdatedValues() {
        const cachedValues = {};
        for (const [fieldName, cachedItem] of this.globalCache.entries()) {
            const keys = fieldName.split('.');
            if (cachedItem.updated && !this.isSameValue(cachedItem)) {
                this.setValueToObject(cachedValues, keys, cachedItem.value);
            }
        }
        return cachedValues;
    }
    getUpdatedValuesForSchemas(schema) {
        const cachedValues = {};
        for (const [fieldName, cachedItem] of this.globalCache.entries()) {
            const keys = fieldName.split('.');
            if (cachedItem.updated && schema.includes(keys[0]) && !this.isSameValue(cachedItem)) {
                this.setValueToObject(cachedValues, keys, cachedItem.value);
            }
        }
        return cachedValues;
    }
    setValueToObject(obj, keys, value) {
        const key = keys.shift();
        if (key) {
            if (keys.length > 0) {
                if (!obj[key]) {
                    obj[key] = {};
                }
                this.setValueToObject(obj[key], keys, value);
            }
            else {
                obj[key] = value;
            }
        }
    }
    updateGlobalCache(obj, parentKey) {
        const keys = Object.keys(obj);
        for (const key of keys) {
            if (this.isComplexValue(obj[key])) {
                this.updateGlobalCache(obj[key], parentKey ? `${parentKey}.${key}` : key);
            }
            else {
                const fullKey = parentKey ? `${parentKey}.${key}` : key;
                const existingEntry = this.globalCache.get(fullKey);
                this.globalCache.set(fullKey, { value: obj[key], updated: true, originalValue: existingEntry?.originalValue });
            }
        }
    }
    isComplexValue(value) {
        return typeof value === 'object' && value !== null && !(value instanceof Date) && !Array.isArray(value);
    }
    /**
     * Verify that CachedItem originalValue and value properties represent the same value.
     * @param originalValue It is initialised with a value coming from the backend,
     * which might be a number, a string, a string representing a Date in ISO format or an Array.
     * Objects (complex properties) are stored as nested key-value pairs in the cache using dot notation.
     * @param value The value coming from the UI might be a string, a Date object or an Array.
     * @returns true if both values are the same, false otherwise.
     */
    isSameValue({ originalValue, value }) {
        if (originalValue === value) {
            return true;
        }
        if (Number.isFinite(+originalValue)) {
            return originalValue === Number(value);
        }
        if (value instanceof Date) {
            return this.isSameDate(originalValue, value);
        }
        if (Array.isArray(originalValue) && value !== null) {
            return this.isSameArray(originalValue, value);
        }
        return false;
    }
    isSameDate(originalValue, value) {
        try {
            if (!(originalValue instanceof Date)) {
                originalValue = new Date(originalValue);
            }
            return originalValue.getTime() === value.getTime();
        }
        catch {
            return false;
        }
    }
    isSameArray(originalValue, value) {
        if (originalValue.length !== value.length) {
            return false;
        }
        return originalValue.every((item, index) => this.isSameValue({ originalValue: item, value: value[index] }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpMetadataCacheService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpMetadataCacheService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpMetadataCacheService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * This directive is used to detect clicks outside the element.
 *
 * Example:
 * <div (hxpOutsideClick)="close()"></div>
 *
 */
class HxpOutsideClickDirective {
    constructor() {
        this.ngZone = inject(NgZone);
        this.elementRef = inject(ElementRef);
        this.overlayContainer = inject(OverlayContainer);
        this.documentClick$ = this.getClickOutsideSubject();
        this.destroyRef$ = inject(DestroyRef);
        this.hxpOutsideClick = output();
    }
    ngOnInit() {
        this.documentClick$
            .pipe(takeUntilDestroyed(this.destroyRef$), filter$1((event) => !this.elementRef.nativeElement.contains(event.target) && !this.isInsideOverlay(event.target)))
            .subscribe((event) => {
            this.ngZone.run(() => this.hxpOutsideClick.emit(event));
        });
    }
    getClickOutsideSubject() {
        const click$ = new Subject();
        const document = inject(DOCUMENT);
        this.ngZone.runOutsideAngular(() => {
            fromEvent(document, 'mousedown').pipe(takeUntilDestroyed(this.destroyRef$)).subscribe(click$);
        });
        return click$;
    }
    isInsideOverlay(target) {
        return this.overlayContainer.getContainerElement().contains(target);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpOutsideClickDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.20", type: HxpOutsideClickDirective, isStandalone: true, selector: "[hxpOutsideClick]", outputs: { hxpOutsideClick: "hxpOutsideClick" }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpOutsideClickDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[hxpOutsideClick]',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Sidebar component to display and edit a Document properties.
 *
 * To use the `HxpMetadataSidebarComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpMetadataSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         HxpMetadataSidebarComponent
 *         ...
 *     ],
 *    [...]
 * })
 *
 * export class AppModule {}
 *
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-metadata-sidebar [editable]="false" [document]="document" (closePropertySidebar)="onClose()">
 */
class HxpMetadataSidebarComponent {
    constructor() {
        this.destroyRef = inject(DestroyRef);
        this.envInjector = inject(EnvironmentInjector);
        this.metadataSidebarService = inject(MetadataSidebarService);
        /**
         * Input property to enable or disable edit mode availability
         * @type {boolean}
         * @default true
         */
        this.editable = true;
        /**
         * Emits an event when the sidebar is closed
         */
        this.closePropertySidebar = new EventEmitter();
        this.propertyLoading = false;
        this.workingCopy = true;
        this.isEditableRecord = false;
        this.editMode = false;
        this.hasPendingChanges = false;
        this.isUpdateInProgress = false;
        this.propertiesGroups = [];
        this.cardValueValidationMap = {};
        this.documentPropertiesToUpdate = {};
        this.dialogRef = null;
        this.editableNonNullableProperties = [];
        this.contentTypeSchemas = [];
        this.requiredCustomFieldLabel = [];
        this.isContentTypeChanged = false;
        // Signal to communicate invalid fields to child component for accordion expansion
        this.invalidFieldIds = signal([]);
        this.documentService = inject(DocumentService);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.cardViewUpdateService = inject(CardViewUpdateService);
        this.dialog = inject(MatDialog);
        this.translateService = inject(TranslateService);
        this.cacheService = inject(HxpMetadataCacheService);
        this.documentPropertiesService = inject(DOCUMENT_PROPERTIES_SERVICE);
        this.subscribeToDocumentUpdates();
        this.requiredProperties = this.documentPropertiesService.getRequiredProperties();
        const itemUpdated$ = this.cardViewUpdateService.itemUpdated$.pipe(shareReplay());
        itemUpdated$.pipe(takeUntilDestroyed()).subscribe(this.respondToCardUpdate.bind(this));
        itemUpdated$
            .pipe(map((updateNotification) => {
            const changedKey = Object.keys(updateNotification.changed)[0];
            const changedValue = updateNotification.changed[changedKey];
            return { changedKey, changedValue };
        }), filter(({ changedKey }) => changedKey === 'sys_primaryType'), takeUntilDestroyed())
            // eslint-disable-next-line rxjs/no-nested-subscribe
            .subscribe(({ changedValue }) => this.updateContentType(changedValue));
        this.destroyRef.onDestroy(() => {
            this.cacheService.invalidateCache();
        });
        const keyUp$ = fromEvent(document, 'keyup');
        keyUp$
            .pipe(filter((e) => e.key === 'Escape'), takeUntilDestroyed())
            .subscribe((event) => {
            event.stopImmediatePropagation();
            event.preventDefault();
            // eslint-disable-next-line rxjs/no-nested-subscribe
            this.onSidebarKeyUp();
        });
    }
    ngOnChanges(changes) {
        if (!this.document) {
            return;
        }
        if (changes['document'] && this.hasDocumentChanged(changes['document'].previousValue, changes['document'].currentValue)) {
            this.cacheService.invalidateCache();
            this.hasPendingChanges = false;
            this.documentPropertiesToUpdate = {};
        }
        this.loadDocumentProperties(this.document.sys_id ?? '');
        this.workingCopy = !isVersion(this.document);
    }
    hasDocumentChanged(previous, current) {
        return previous?.sys_id !== current?.sys_id;
    }
    initializeRequiredFieldsState() {
        if (!this.allEditableProperties$) {
            return;
        }
        this.allEditableProperties$.pipe(take$1(1)).subscribe((properties) => {
            this.buildRequiredPropertiesLists(properties);
            this.markRequiredFieldsInDom(properties);
            this.handleContentTypeChangeValidation();
        });
    }
    buildRequiredPropertiesLists(properties) {
        this.editableNonNullableProperties = [];
        this.requiredCustomFieldLabel = [];
        for (const property of properties) {
            if (this.requiredProperties.includes(property.key)) {
                continue;
            }
            const isRequired = this.documentPropertiesService.isRequired(property.key);
            if (property.editable && isRequired) {
                this.editableNonNullableProperties.push(property.key);
                if (!this.requiredCustomFieldLabel.includes(property.label)) {
                    this.requiredCustomFieldLabel.push(property.label);
                }
            }
        }
    }
    markRequiredFieldsInDom(properties) {
        for (const property of properties) {
            const isSystemRequired = this.requiredProperties.includes(property.key);
            const isCustomRequired = this.editableNonNullableProperties.includes(property.key);
            if (isSystemRequired || isCustomRequired) {
                this.markHtmlElementAsRequiredField(property);
            }
        }
    }
    handleContentTypeChangeValidation() {
        if (!this.isContentTypeChanged) {
            return;
        }
        this.updateInvalidFields();
        if (this.requiredCustomFieldLabel.length > 0 && !this.allRequiredPropertiesAreSet()) {
            this.displayToastForRequiredFields();
        }
        this.isContentTypeChanged = false;
    }
    markHtmlElementAsRequiredField(property) {
        runInInjectionContext(this.envInjector, () => {
            afterNextRender(() => {
                const element = document.querySelector(`[data-automation-id="header-${property.key}"] .adf-property-label`);
                element?.classList.add('hxp-required-field');
            });
        });
    }
    onEscKeyUp(event) {
        event.stopImmediatePropagation();
        event.preventDefault();
        this.onSidebarKeyUp();
    }
    onCancel() {
        if (!this.hasPendingChanges) {
            return this.exitEditMode();
        }
        this.openCancelDialog();
    }
    handlePropertyUpdate(propertyUpdated) {
        if (propertyUpdated) {
            this.fetchAllEditableProperties();
        }
    }
    onClose() {
        if (!this.hasPendingChanges) {
            this.closePropertySidebar.emit();
            return this.exitEditMode();
        }
        else if (!this.dialogRef) {
            this.openCancelDialog();
        }
    }
    onOutsideClick() {
        if (!this.editMode || !this.hasPendingChanges) {
            return;
        }
        this.onClose();
    }
    onTabChange(event) {
        if (event.index === 0) {
            this.initializeRequiredFieldsState();
        }
    }
    openCancelDialog() {
        this.dialogRef = this.dialog.open(HxpCancelMetadataSidebarEditDialogComponent, {
            width: DialogConfig.small.width,
            disableClose: true,
            hasBackdrop: true,
        });
        this.dialogRef.componentInstance.discardChanges.subscribe(() => {
            this.exitEditMode();
        });
        this.dialogRef.componentInstance.saveChanges.subscribe(() => {
            this.onSaveProperties();
        });
        this.dialogRef.afterClosed().subscribe(() => {
            this.dialogRef = null;
        });
        this.dialogRef
            .backdropClick()
            .pipe(takeUntil(this.dialogRef.afterClosed()))
            .subscribe(() => {
            if (this.dialogRef) {
                this.dialogRef.close();
            }
        });
    }
    exitEditMode() {
        this.cacheService.invalidateCache();
        if (this.contentTypeHasChanged()) {
            this.loadDocumentProperties(this.document?.sys_id ?? '');
        }
        else {
            this.fetchNonEditableProperties();
            this.fetchAllEditableProperties();
        }
        this.documentPropertiesToUpdate = {};
        this.cardValueValidationMap = {};
        this.editMode = false;
        this.hasPendingChanges = false;
        this.invalidFieldIds.set([]); // Reset invalid fields when exiting edit mode
    }
    contentTypeHasChanged() {
        return !!this.documentPropertiesToUpdate['sys_primaryType'];
    }
    subscribeToDocumentUpdates() {
        this.documentService.documentUpdated$
            .pipe(filter(({ document }) => !!document && document.sys_id === this.document?.sys_id), takeUntilDestroyed(this.destroyRef))
            .subscribe({
            next: ({ document }) => {
                if (document) {
                    this.selectedDocument = document;
                    // eslint-disable-next-line rxjs/no-nested-subscribe
                    this.fetchDocumentProperties();
                }
            },
            error: (error) => console.error(error),
        });
    }
    loadDocumentProperties(documentId) {
        if (!documentId) {
            return;
        }
        this.propertyLoading = true;
        this.documentService
            .getDocumentById(documentId)
            .pipe(take$1(1), finalize(() => (this.propertyLoading = false)))
            .subscribe({
            next: (doc) => {
                this.selectedDocument = doc;
                // eslint-disable-next-line rxjs/no-nested-subscribe
                this.fetchDocumentProperties();
            },
            error: ({ error }) => {
                console.error(error);
            },
        });
    }
    fetchDocumentProperties() {
        if (!this.selectedDocument) {
            return;
        }
        this.fetchCustomSchemaFields(this.selectedDocument.sys_primaryType);
        this.fetchNonEditableProperties();
        this.fetchAllEditableProperties();
    }
    fetchCustomSchemaFields(contentType) {
        this.documentPropertiesService
            .extractSchemas(contentType, { includeCustomProperties: true })
            .pipe(take$1(1))
            .subscribe({
            next: (schemaFields) => {
                const customSchemaTree = Array.isArray(schemaFields) ? schemaFields : [];
                this.propertiesGroups = customSchemaTree;
                this.initializeDocumentWithSchema(this.flatSchemaTree(customSchemaTree));
            },
            error: (error) => console.error(error),
        });
    }
    flatSchemaTree(schemaTree) {
        let schemaFieldsFlat = {};
        for (const schemaFields of schemaTree) {
            schemaFieldsFlat = { ...schemaFieldsFlat, ...schemaFields.fields };
        }
        return schemaFieldsFlat;
    }
    initializeDocumentWithSchema(schemaFields, currentDoc = this.selectedDocument) {
        const newSchemaKeys = Object.keys(schemaFields) || [];
        for (const fieldName of this.contentTypeSchemas) {
            if (!newSchemaKeys.includes(fieldName)) {
                delete currentDoc[fieldName];
                delete this.documentPropertiesToUpdate[fieldName];
            }
        }
        this.contentTypeSchemas = newSchemaKeys;
        if (this.contentTypeHasChanged()) {
            this.documentPropertiesToUpdate = {
                ...this.documentPropertiesToUpdate,
                ...this.cacheService.getUpdatedValuesForSchemas(newSchemaKeys),
            };
        }
        this.addSchemaFieldsToDocument(schemaFields, currentDoc);
    }
    addSchemaFieldsToDocument(schemaFields, currentDoc) {
        const newSchemaKeys = Object.keys(schemaFields) || [];
        for (const fieldName of newSchemaKeys) {
            if (!currentDoc[fieldName]) {
                currentDoc[fieldName] = typeof schemaFields[fieldName] === 'object' ? {} : '';
            }
            if (typeof schemaFields[fieldName] === 'object') {
                this.addSchemaFieldsToDocument(schemaFields[fieldName], currentDoc[fieldName]);
            }
        }
    }
    fetchNonEditableProperties() {
        this.nonEditableSystemProperties$ = this.metadataSidebarService.getNonEditableSystemPropertiesFromDocument(this.selectedDocument).pipe(map((properties) => {
            // To ensure sys_path is always the last property displayed
            const pathProperties = properties.filter((p) => p.label?.toLowerCase() === 'path');
            const otherProperties = properties.filter((p) => p.label?.toLowerCase() !== 'path');
            return [...otherProperties, ...pathProperties];
        }));
    }
    fetchAllEditableProperties() {
        this.fetchEditableProperties();
        this.fetchCustomProperties();
        this.updateAllEditableProperties();
        this.initializeRequiredFieldsState();
    }
    fetchEditableProperties() {
        this.editableSystemProperties$ = this.metadataSidebarService
            .getEditableSystemPropertiesFromDocument(this.selectedDocument)
            .pipe(map((properties) => this.mapCachedProperties(properties)));
    }
    fetchCustomProperties() {
        this.customProperties$ = this.metadataSidebarService
            .getCustomProperties(this.selectedDocument)
            .pipe(map((properties) => this.mapCachedProperties(properties)));
    }
    mapCachedProperties(properties) {
        return properties.map((property) => {
            const value = this.cacheService.getCachedValue(property.key, property.value);
            property.value = value;
            return property;
        });
    }
    updateAllEditableProperties() {
        if (this.editableSystemProperties$ && this.customProperties$) {
            this.allEditableProperties$ = combineLatest([this.editableSystemProperties$, this.customProperties$]).pipe(map(([editableProperties, customProperties]) => [...editableProperties, ...customProperties]));
        }
    }
    respondToCardUpdate(updateNotification) {
        const changedKey = Object.keys(updateNotification.changed)[0];
        const changedValue = updateNotification.changed[changedKey];
        // We cast updateNotification because 'target' is not a standard property of the interface.
        // It references the specific UI component instance that triggered the update.
        // 'isValidValue' captures whether that component's internal validation failed.
        const isValidValue = updateNotification.target?.isValidValue;
        const fieldType = this.documentPropertiesService.propertyType(changedKey);
        const updatedValue = this.isComplexProperty(changedValue, fieldType)
            ? this.getUpdatedComplexProperty(changedKey, changedValue)
            : updateNotification.changed;
        this.cacheService.updateCache(updatedValue);
        const actualChanges = this.cacheService.getUpdatedValues();
        this.hasPendingChanges = Object.keys(actualChanges).length > 0;
        this.documentPropertiesToUpdate = {
            ...this.documentPropertiesToUpdate,
            ...updatedValue,
        };
        this.cardValueValidationMap[changedKey] =
            isValidValue === false
                ? { isValid: false, errorType: 'INVALID_VALUE' }
                : { isValid: this.validateCardValue(changedKey, changedValue, fieldType) };
    }
    updateInvalidFields() {
        const invalidIds = [];
        // First pass: Check for invalid values in documentPropertiesToUpdate
        if (Object.keys(this.cardValueValidationMap).length > 0) {
            for (const key of Object.keys(this.documentPropertiesToUpdate)) {
                const validation = this.cardValueValidationMap[key];
                if (validation && !validation.isValid) {
                    invalidIds.push(key);
                }
            }
        }
        // Second pass: Check for missing/empty required properties
        const values = this.cacheService.getAllCachedValues();
        for (const property of this.editableNonNullableProperties) {
            const value = values[property];
            const isMissingOrEmpty = value === null || value === undefined || String(value).trim().length === 0;
            if (isMissingOrEmpty && // Only override if not already marked as INVALID_VALUE
                !invalidIds.includes(property)) {
                invalidIds.push(property);
            }
        }
        this.invalidFieldIds.set(invalidIds);
    }
    validateCardValue(changedKey, changedValue, fieldType) {
        let invalidCardValue = false;
        if (fieldType === FieldType.Blob || fieldType === FieldType.Complex) {
            const nestedPropertyName = Object.keys(changedValue)[0];
            if (this.isEmptyProperty(changedValue[`${nestedPropertyName}`], changedKey, fieldType)) {
                invalidCardValue = this.isPropertyRequired(`${changedKey}.${nestedPropertyName || ''}`);
            }
        }
        else if (this.isEmptyProperty(changedValue, changedKey, fieldType)) {
            invalidCardValue = this.isPropertyRequired(changedKey);
        }
        return !invalidCardValue;
    }
    isComplexProperty(changedValue, fieldType) {
        return fieldType === FieldType.Complex || (fieldType !== FieldType.Date && typeof changedValue === 'object' && !Array.isArray(changedValue));
    }
    isEmptyProperty(changedValue, changedKey, fieldType) {
        if (changedValue == null) {
            return true;
        }
        if (typeof changedValue === 'string' && changedValue.trim().length === 0) {
            return true;
        }
        if (fieldType === FieldType.Integer || fieldType === FieldType.Float) {
            const element = document.querySelector(`[data-automation-id="card-textitem-value-${changedKey}"]`);
            if (element) {
                const inputValue = element.value;
                if (inputValue === '' || inputValue === null || inputValue === undefined) {
                    return true;
                }
            }
        }
        return !changedValue;
    }
    isPropertyRequired(propertyName) {
        if (this.requiredProperties.includes(propertyName) || this.editableNonNullableProperties.includes(propertyName)) {
            return true;
        }
        return false;
    }
    getUpdatedComplexProperty(changedKey, changedValue) {
        const existingDataInDocument = this.selectedDocument?.[changedKey] || {};
        const existingUpdateData = this.documentPropertiesToUpdate[changedKey] || {};
        return {
            [changedKey]: {
                ...existingDataInDocument,
                ...existingUpdateData,
                ...changedValue,
            },
        };
    }
    enableEditMode() {
        this.editMode = true;
        this.isUpdateInProgress = false;
        this.documentPropertiesToUpdate = {};
        this.invalidFieldIds.set([]);
        this.cardValueValidationMap = {};
        this.initializeRequiredFieldsState();
    }
    hasBeenModified() {
        const schemaValues = Object.keys(this.cacheService.getUpdatedValues());
        return schemaValues.length > 0;
    }
    allCardValuesAreValid() {
        return this.invalidFieldIds().length === 0;
    }
    allRequiredPropertiesAreSet() {
        if (Object.values(this.cardValueValidationMap).some((state) => !state.isValid)) {
            return false;
        }
        const values = this.cacheService.getAllCachedValues();
        return this.editableNonNullableProperties.every((property) => values[property] !== null && values[property] !== undefined && values[property].toString().trim().length > 0);
    }
    onSaveProperties() {
        this.updateInvalidFields();
        if (!this.document?.sys_id) {
            return;
        }
        if (!this.allCardValuesAreValid()) {
            const invalidIds = this.invalidFieldIds();
            const hasInvalidValueErrors = invalidIds.some((key) => this.cardValueValidationMap[key]?.errorType === 'INVALID_VALUE');
            if (hasInvalidValueErrors) {
                this.hxpNotificationService.showError(this.translateService.instant('DOCUMENT.METADATA.VALIDATION.INVALID_VALUE'));
                return;
            }
            const violationsCount = invalidIds.length;
            if (violationsCount > 1) {
                this.hxpNotificationService.showError(this.translateService.instant('DOCUMENT.METADATA.VALIDATION.REQUIRED_MULTIPLE'));
            }
            else if (violationsCount === 1) {
                // Look up the label of the first empty required field from allEditableProperties$
                const firstViolationKey = invalidIds[0];
                this.allEditableProperties$.pipe(take$1(1)).subscribe((properties) => {
                    const violatedProperty = properties.find((prop) => prop.key === firstViolationKey);
                    const propertyLabel = violatedProperty?.label;
                    if (propertyLabel) {
                        this.hxpNotificationService.showError(this.translateService.instant('DOCUMENT.METADATA.VALIDATION.REQUIRED', {
                            propertyLabel,
                        }));
                    }
                    else {
                        this.hxpNotificationService.showError(this.translateService.instant('DOCUMENT.METADATA.VALIDATION.INVALID_VALUE'));
                    }
                });
            }
            return;
        }
        this.isUpdateInProgress = true;
        this.documentService
            .updateDocument(this.document.sys_id, this.documentPropertiesToUpdate)
            .pipe(take$1(1), finalize(() => {
            this.isUpdateInProgress = false;
        }))
            .subscribe({
            next: (document) => {
                this.document = document;
                this.documentPropertiesToUpdate = {};
                this.hasPendingChanges = false;
                this.editMode = false;
                this.cardValueValidationMap = {};
                this.invalidFieldIds.set([]); // Reset invalid fields after successful save
                this.cacheService.invalidateCache();
                this.hxpNotificationService.showSuccess(editPropertiesNotificationMessages[EditPropertiesStatus.SUCCESS]);
            },
            error: () => {
                this.hxpNotificationService.showError(editPropertiesNotificationMessages[EditPropertiesStatus.ERROR]);
            },
        });
    }
    updateContentType(changedValue) {
        this.fetchCustomSchemaFields(changedValue);
        this.fetchCustomProperties();
        this.updateAllEditableProperties();
        this.isContentTypeChanged = true;
        this.updateInvalidFields();
    }
    displayToastForRequiredFields() {
        const msg = this.requiredCustomFieldLabel.length > 1
            ? this.translateService.instant('DOCUMENT.METADATA.VALIDATION.REQUIRED_MULTIPLE')
            : this.translateService.instant('DOCUMENT.METADATA.VALIDATION.REQUIRED', { propertyLabel: this.requiredCustomFieldLabel[0] });
        this.hxpNotificationService.showError(msg);
    }
    onSidebarKeyUp() {
        if (this.hasPendingChanges) {
            if (this.dialogRef) {
                this.dialogRef.close();
            }
            else {
                this.openCancelDialog();
            }
        }
        else if (this.editMode) {
            this.exitEditMode();
        }
        else if (!this.dialogRef) {
            this.closePropertySidebar.emit();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpMetadataSidebarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: HxpMetadataSidebarComponent, isStandalone: true, selector: "hxp-metadata-sidebar", inputs: { document: "document", editable: "editable" }, outputs: { closePropertySidebar: "closePropertySidebar" }, host: { listeners: { "keyup.esc": "onEscKeyUp($event)" } }, providers: [HxpMetadataCacheService], usesOnChanges: true, ngImport: i0, template: "<adf-info-drawer-layout\n    class=\"hxp-metadata-panel\"\n    (hxpOutsideClick)=\"onOutsideClick()\"\n>\n    <div\n        info-drawer-content\n        class=\"hxp-metadata-info-drawer-content\"\n    >\n        <div\n            class=\"hxp-metadata-panel-header\"\n            data-automation-id=\"hxp-metadata-sidebar-title\"\n        >\n            <div class=\"hxp-metadata-panel-header_title mat-headline-medium\">{{ selectedDocument?.sys_title }}</div>\n            <button\n                mat-icon-button\n                tabindex=\"0\"\n                attr.aria-label=\"{{ 'DOCUMENT.PROPERTIES.RIGHT_SIDEBAR.CLOSE' | translate }}\"\n                (click)=\"onClose()\"\n                class=\"hxp-metadata-sidebar-close-button\"\n                data-automation-id=\"hxp-metadata-sidebar-close-button\"\n            >\n                <mat-icon svgIcon=\"x_large\" />\n            </button>\n        </div>\n\n        <div class=\"hxp-metadata-panel-wrapper\">\n            @if (propertyLoading) {\n                <div class=\"hxp-metadata-panel-spinner-container\">\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"30\"\n                    />\n                </div>\n            } @else {\n                <!--\n                The tab structure uses nested conditionals for each tab rather than dynamically adding/removing tabs.\n                This is necessary because Angular Material's tab group doesn't handle dynamic insertion at index 0 correctly.\n                -->\n                @if (editableSystemProperties$ | async; as editableSystemProperties) {\n                    <hxp-metadata-sidebar-content\n                        [useChipsForMultiValueProperty]=\"false\"\n                        [properties]=\"editableSystemProperties\"\n                        id=\"properties-viewer-content\"\n                        [editable]=\"editMode\"\n                        [document]=\"selectedDocument\"\n                        (propertyUpdateRequest)=\"handlePropertyUpdate($event)\"\n                    />\n                }\n                <mat-tab-group\n                    animationDuration=\"0\"\n                    mat-stretch-tabs=\"false\"\n                    (selectedTabChange)=\"onTabChange($event)\"\n                >\n                    @let customProperties = customProperties$ | async;\n                    @let nonEditableSystemProperties = nonEditableSystemProperties$ | async;\n                    @if (customProperties && customProperties.length > 0) {\n                        <mat-tab>\n                            <ng-template mat-tab-label>\n                                <span data-automation-id=\"hxp-metadata-sidebar-properties-tab\">\n                                    {{ 'DOCUMENT.METADATA.TABS.PROPERTIES' | translate }}\n                                </span>\n                            </ng-template>\n                            <hxp-metadata-sidebar-content\n                                [useChipsForMultiValueProperty]=\"true\"\n                                [properties]=\"customProperties\"\n                                [propertiesGroups]=\"propertiesGroups\"\n                                [editable]=\"editMode\"\n                                [document]=\"selectedDocument\"\n                                (propertyUpdateRequest)=\"handlePropertyUpdate($event)\"\n                                [collapsible]=\"true\"\n                                [invalidFieldIds]=\"invalidFieldIds()\"\n                            />\n                        </mat-tab>\n                        @if (nonEditableSystemProperties && nonEditableSystemProperties.length > 0) {\n                            <mat-tab>\n                                <ng-template mat-tab-label>\n                                    <span data-automation-id=\"hxp-metadata-sidebar-additional-info-tab\">\n                                        {{ 'DOCUMENT.METADATA.TABS.ADDITIONAL_INFORMATION' | translate }}\n                                    </span>\n                                </ng-template>\n                                <hxp-metadata-sidebar-additional-info [nonEditableSystemProperties]=\"nonEditableSystemProperties\" />\n                            </mat-tab>\n                        }\n                    } @else if (nonEditableSystemProperties && nonEditableSystemProperties.length > 0) {\n                        <mat-tab>\n                            <ng-template mat-tab-label>\n                                <span data-automation-id=\"hxp-metadata-sidebar-additional-info-tab\">\n                                    {{ 'DOCUMENT.METADATA.TABS.ADDITIONAL_INFORMATION' | translate }}\n                                </span>\n                            </ng-template>\n                            <hxp-metadata-sidebar-additional-info [nonEditableSystemProperties]=\"nonEditableSystemProperties\" />\n                        </mat-tab>\n                    }\n                </mat-tab-group>\n            }\n        </div>\n\n        @if (workingCopy && editable) {\n            <div class=\"hxp-property-edit-actions\">\n                @if (!editMode && !isUpdateInProgress) {\n                    <button\n                        mat-flat-button\n                        [disabled]=\"propertyLoading\"\n                        data-automation-id=\"hxp-metadata-sidebar-edit-button\"\n                        (click)=\"enableEditMode()\"\n                    >\n                        {{ 'DOCUMENT.PROPERTIES_EDIT.EDIT' | translate }}\n                    </button>\n                } @else if (editMode || isUpdateInProgress) {\n                    <button\n                        mat-button\n                        data-automation-id=\"hxp-metadata-sidebar-cancel-button\"\n                        (click)=\"onCancel()\"\n                        [disabled]=\"isUpdateInProgress\"\n                    >\n                        {{ 'DOCUMENT.PROPERTIES_EDIT.CANCEL' | translate }}\n                    </button>\n                    <button\n                        mat-flat-button\n                        data-automation-id=\"hxp-metadata-sidebar-save-button\"\n                        [disabled]=\"isUpdateInProgress || !hasBeenModified()\"\n                        (click)=\"onSaveProperties()\"\n                    >\n                        {{ 'DOCUMENT.PROPERTIES_EDIT.UPDATE' | translate }}\n                    </button>\n                }\n            </div>\n        }\n    </div>\n</adf-info-drawer-layout>\n", styles: [".hxp-metadata-panel-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}.hxp-metadata-panel-header_title{display:inline-block;text-overflow:ellipsis;overflow:hidden;margin-bottom:0!important}.hxp-metadata-panel-spinner-container{display:flex;justify-content:center;align-items:center;height:100%}adf-info-drawer-layout.hxp-metadata-panel{width:420px;height:calc(100% - 32px);padding:16px;background-color:var(--mat-sys-surface)}adf-info-drawer-layout.hxp-metadata-panel .adf-info-drawer-layout-content{padding:0;height:100%}adf-info-drawer-layout.hxp-metadata-panel .adf-info-drawer-layout-header{display:none}.adf-property-container adf-card-view-selectitem .adf-property-value{margin-top:0;padding-top:0}.adf-viewer-sidebars .adf-viewer__sidebar{width:auto}.hxp-metadata-info-drawer-content{height:100%;flex-direction:column;display:flex!important}.hxp-metadata-panel-wrapper{overflow-y:scroll;padding-top:16px;flex:1}.hxp-property-edit-actions{padding-top:16px;border-top:1px solid var(--mat-sys-outline-variant);display:flex;justify-content:flex-end;gap:8px}.mdc-text-field:not(.mdc-text-field--focused,.mdc-text-field--invalid) .adf-property-label{color:var(--mat-sys-on-surface)!important}.hxp-required-field:after{content:\" *\"}\n"], dependencies: [{ kind: "component", type: InfoDrawerLayoutComponent, selector: "adf-info-drawer-layout", inputs: ["showHeader"] }, { kind: "directive", type: InfoDrawerContentDirective, selector: "[adf-info-drawer-content], [info-drawer-content]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "directive", type: i3$4.MatTabLabel, selector: "[mat-tab-label], [matTabLabel]" }, { kind: "component", type: i3$4.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i3$4.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i3$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "component", type: MetadataSidebarContentComponent, selector: "hxp-metadata-sidebar-content", inputs: ["document", "properties", "propertiesGroups", "copyToClipboardAction", "displayEmpty", "editable", "useChipsForMultiValueProperty", "collapsible", "invalidFieldIds"], outputs: ["propertyUpdateRequest"] }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "component", type: HxpMetadataSidebarAdditionalInfoComponent, selector: "hxp-metadata-sidebar-additional-info", inputs: ["nonEditableSystemProperties"] }, { kind: "directive", type: HxpOutsideClickDirective, selector: "[hxpOutsideClick]", outputs: ["hxpOutsideClick"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpMetadataSidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-metadata-sidebar', encapsulation: ViewEncapsulation.None, imports: [
                        InfoDrawerLayoutComponent,
                        InfoDrawerContentDirective,
                        MatButtonModule,
                        MatIconModule,
                        MatTabsModule,
                        MatProgressSpinnerModule,
                        MatTooltipModule,
                        MetadataSidebarContentComponent,
                        AsyncPipe,
                        TranslatePipe,
                        HxpMetadataSidebarAdditionalInfoComponent,
                        HxpOutsideClickDirective,
                    ], providers: [HxpMetadataCacheService], template: "<adf-info-drawer-layout\n    class=\"hxp-metadata-panel\"\n    (hxpOutsideClick)=\"onOutsideClick()\"\n>\n    <div\n        info-drawer-content\n        class=\"hxp-metadata-info-drawer-content\"\n    >\n        <div\n            class=\"hxp-metadata-panel-header\"\n            data-automation-id=\"hxp-metadata-sidebar-title\"\n        >\n            <div class=\"hxp-metadata-panel-header_title mat-headline-medium\">{{ selectedDocument?.sys_title }}</div>\n            <button\n                mat-icon-button\n                tabindex=\"0\"\n                attr.aria-label=\"{{ 'DOCUMENT.PROPERTIES.RIGHT_SIDEBAR.CLOSE' | translate }}\"\n                (click)=\"onClose()\"\n                class=\"hxp-metadata-sidebar-close-button\"\n                data-automation-id=\"hxp-metadata-sidebar-close-button\"\n            >\n                <mat-icon svgIcon=\"x_large\" />\n            </button>\n        </div>\n\n        <div class=\"hxp-metadata-panel-wrapper\">\n            @if (propertyLoading) {\n                <div class=\"hxp-metadata-panel-spinner-container\">\n                    <mat-progress-spinner\n                        mode=\"indeterminate\"\n                        diameter=\"30\"\n                    />\n                </div>\n            } @else {\n                <!--\n                The tab structure uses nested conditionals for each tab rather than dynamically adding/removing tabs.\n                This is necessary because Angular Material's tab group doesn't handle dynamic insertion at index 0 correctly.\n                -->\n                @if (editableSystemProperties$ | async; as editableSystemProperties) {\n                    <hxp-metadata-sidebar-content\n                        [useChipsForMultiValueProperty]=\"false\"\n                        [properties]=\"editableSystemProperties\"\n                        id=\"properties-viewer-content\"\n                        [editable]=\"editMode\"\n                        [document]=\"selectedDocument\"\n                        (propertyUpdateRequest)=\"handlePropertyUpdate($event)\"\n                    />\n                }\n                <mat-tab-group\n                    animationDuration=\"0\"\n                    mat-stretch-tabs=\"false\"\n                    (selectedTabChange)=\"onTabChange($event)\"\n                >\n                    @let customProperties = customProperties$ | async;\n                    @let nonEditableSystemProperties = nonEditableSystemProperties$ | async;\n                    @if (customProperties && customProperties.length > 0) {\n                        <mat-tab>\n                            <ng-template mat-tab-label>\n                                <span data-automation-id=\"hxp-metadata-sidebar-properties-tab\">\n                                    {{ 'DOCUMENT.METADATA.TABS.PROPERTIES' | translate }}\n                                </span>\n                            </ng-template>\n                            <hxp-metadata-sidebar-content\n                                [useChipsForMultiValueProperty]=\"true\"\n                                [properties]=\"customProperties\"\n                                [propertiesGroups]=\"propertiesGroups\"\n                                [editable]=\"editMode\"\n                                [document]=\"selectedDocument\"\n                                (propertyUpdateRequest)=\"handlePropertyUpdate($event)\"\n                                [collapsible]=\"true\"\n                                [invalidFieldIds]=\"invalidFieldIds()\"\n                            />\n                        </mat-tab>\n                        @if (nonEditableSystemProperties && nonEditableSystemProperties.length > 0) {\n                            <mat-tab>\n                                <ng-template mat-tab-label>\n                                    <span data-automation-id=\"hxp-metadata-sidebar-additional-info-tab\">\n                                        {{ 'DOCUMENT.METADATA.TABS.ADDITIONAL_INFORMATION' | translate }}\n                                    </span>\n                                </ng-template>\n                                <hxp-metadata-sidebar-additional-info [nonEditableSystemProperties]=\"nonEditableSystemProperties\" />\n                            </mat-tab>\n                        }\n                    } @else if (nonEditableSystemProperties && nonEditableSystemProperties.length > 0) {\n                        <mat-tab>\n                            <ng-template mat-tab-label>\n                                <span data-automation-id=\"hxp-metadata-sidebar-additional-info-tab\">\n                                    {{ 'DOCUMENT.METADATA.TABS.ADDITIONAL_INFORMATION' | translate }}\n                                </span>\n                            </ng-template>\n                            <hxp-metadata-sidebar-additional-info [nonEditableSystemProperties]=\"nonEditableSystemProperties\" />\n                        </mat-tab>\n                    }\n                </mat-tab-group>\n            }\n        </div>\n\n        @if (workingCopy && editable) {\n            <div class=\"hxp-property-edit-actions\">\n                @if (!editMode && !isUpdateInProgress) {\n                    <button\n                        mat-flat-button\n                        [disabled]=\"propertyLoading\"\n                        data-automation-id=\"hxp-metadata-sidebar-edit-button\"\n                        (click)=\"enableEditMode()\"\n                    >\n                        {{ 'DOCUMENT.PROPERTIES_EDIT.EDIT' | translate }}\n                    </button>\n                } @else if (editMode || isUpdateInProgress) {\n                    <button\n                        mat-button\n                        data-automation-id=\"hxp-metadata-sidebar-cancel-button\"\n                        (click)=\"onCancel()\"\n                        [disabled]=\"isUpdateInProgress\"\n                    >\n                        {{ 'DOCUMENT.PROPERTIES_EDIT.CANCEL' | translate }}\n                    </button>\n                    <button\n                        mat-flat-button\n                        data-automation-id=\"hxp-metadata-sidebar-save-button\"\n                        [disabled]=\"isUpdateInProgress || !hasBeenModified()\"\n                        (click)=\"onSaveProperties()\"\n                    >\n                        {{ 'DOCUMENT.PROPERTIES_EDIT.UPDATE' | translate }}\n                    </button>\n                }\n            </div>\n        }\n    </div>\n</adf-info-drawer-layout>\n", styles: [".hxp-metadata-panel-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}.hxp-metadata-panel-header_title{display:inline-block;text-overflow:ellipsis;overflow:hidden;margin-bottom:0!important}.hxp-metadata-panel-spinner-container{display:flex;justify-content:center;align-items:center;height:100%}adf-info-drawer-layout.hxp-metadata-panel{width:420px;height:calc(100% - 32px);padding:16px;background-color:var(--mat-sys-surface)}adf-info-drawer-layout.hxp-metadata-panel .adf-info-drawer-layout-content{padding:0;height:100%}adf-info-drawer-layout.hxp-metadata-panel .adf-info-drawer-layout-header{display:none}.adf-property-container adf-card-view-selectitem .adf-property-value{margin-top:0;padding-top:0}.adf-viewer-sidebars .adf-viewer__sidebar{width:auto}.hxp-metadata-info-drawer-content{height:100%;flex-direction:column;display:flex!important}.hxp-metadata-panel-wrapper{overflow-y:scroll;padding-top:16px;flex:1}.hxp-property-edit-actions{padding-top:16px;border-top:1px solid var(--mat-sys-outline-variant);display:flex;justify-content:flex-end;gap:8px}.mdc-text-field:not(.mdc-text-field--focused,.mdc-text-field--invalid) .adf-property-label{color:var(--mat-sys-on-surface)!important}.hxp-required-field:after{content:\" *\"}\n"] }]
        }], ctorParameters: () => [], propDecorators: { document: [{
                type: Input
            }], editable: [{
                type: Input
            }], closePropertySidebar: [{
                type: Output
            }], onEscKeyUp: [{
                type: HostListener,
                args: ['keyup.esc', ['$event']]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentMoreMenuItemComponent {
    constructor() {
        this.actionContext = { documents: [] };
        this.dynamicComponent = viewChild(DynamicExtensionComponent);
    }
    get isAvailable() {
        return this.dynamicComponent()?.componentRef?.instance?.isAvailable === true;
    }
    ngOnInit() {
        this.appComponent = this.item?.component ?? '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentMoreMenuItemComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.20", type: DocumentMoreMenuItemComponent, isStandalone: true, selector: "hxp-document-more-menu-item", inputs: { item: "item", actionContext: "actionContext" }, viewQueries: [{ propertyName: "dynamicComponent", first: true, predicate: DynamicExtensionComponent, descendants: true, isSignal: true }], ngImport: i0, template: "<ng-container [ngSwitch]=\"item?.type\">\n    <ng-container *ngSwitchCase=\"'custom'\">\n        <adf-dynamic-component\n            [id]=\"appComponent\"\n            [data]=\"actionContext\"\n        />\n    </ng-container>\n</ng-container>\n", dependencies: [{ kind: "directive", type: NgSwitch, selector: "[ngSwitch]", inputs: ["ngSwitch"] }, { kind: "directive", type: NgSwitchCase, selector: "[ngSwitchCase]", inputs: ["ngSwitchCase"] }, { kind: "component", type: DynamicExtensionComponent, selector: "adf-dynamic-component", inputs: ["id", "data"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentMoreMenuItemComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-more-menu-item', imports: [NgSwitch, NgSwitchCase, DynamicExtensionComponent], template: "<ng-container [ngSwitch]=\"item?.type\">\n    <ng-container *ngSwitchCase=\"'custom'\">\n        <adf-dynamic-component\n            [id]=\"appComponent\"\n            [data]=\"actionContext\"\n        />\n    </ng-container>\n</ng-container>\n" }]
        }], propDecorators: { item: [{
                type: Input
            }], actionContext: [{
                type: Input
            }] } });

/**
 * Component that display a menu on click, built on top of Alfresco Extensions API (https://www.alfresco.com/abn/adf/docs/extensions/components/dynamic.component/).
 *
 * To use the `DocumentMoreActionComponent`, first create a module to register your custom components using Alfresco `ExtensionService`:
 *
 * ```ts
 * import { NgModule } from '@angular/core';
 * import { ExtensionService } from '@alfresco/adf-extensions';
 *
 * @NgModule({})
 * export class ExtensionsRegisterModule {
 *     constructor(private readonly extensions: ExtensionService) {
 *         this.extensions.setComponents({
 *             'action.one': ActionOneButtonComponent,
 *             'action.two': ActionTwoButtonComponent,
 *         });
 *     }
 * }
 * ```
 * The components should provide a `data` Input property to receive the `ActionContext` object.
 * Example:
 *
 * ```ts
 * import { Component, Input } from '@angular/core';
 * import { ActionContext } from '@alfresco/adf-hx-content-services/services';
 *
 * @Component({
 *   template: '<button (click)="sayHello()">{{ data.documents[0].sys_title }}</button>',
 * })
 * class ActionTwoButtonComponent {
 *    @Input() data: ActionContext;
 *
 *    sayHello() {
 *        console.log(`Hello world! Here is ${data?.documents[0]?.sys_title}, nice to meet you!`);
 *    }
 * }
 * ```
 *
 * Then import your customized `ExtensionsRegisterModule` and the `DocumentMoreActionComponent` component in your module
 *
 * ```ts
 * import { DocumentMoreActionComponent } from '@alfresco/adf-hx-content-services/ui';
 * import { ExtensionsRegisterModule } from './extensions-register.module';
 *
 * @NgModule({
 *     imports: [
 *         ExtensionsRegisterModule,
 *         DocumentMoreActionComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-document-more-action [menuItems]="menuItems" [actionContext]="actionContext"></hxp-document-more-action>
 *
 */
class DocumentMoreActionComponent {
    constructor() {
        this.availabilityStatus = output();
        this.menuItemChildren = viewChildren('menuItem');
        this.isAvailable = signal(false);
        /**
         * Input property which specifies an `ActionContext` object
         * An `ActionContext` object must provide a list of documents.
         * The object is passed as `data` input property to the registered components.
         * @type {ActionContext}
         *
         * @example
         * interface ActionContext {
         *     documents: Document[];
         *     parentDocument?: Document;
         *     shouldRedirect?: boolean;
         *     refererURL?: string;
         *     showPanel?: 'property' | 'version';
         * }
         *
         */
        this.actionContext = { documents: [] };
        afterRenderEffect(() => {
            const items = this.menuItemChildren();
            const hasAvailableItems = items.some(item => item?.isAvailable);
            this.isAvailable.set(hasAvailableItems);
            this.availabilityStatus.emit(hasAvailableItems);
        });
    }
    childTrackBy(_index, child) {
        return child.id;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentMoreActionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: DocumentMoreActionComponent, isStandalone: true, selector: "hxp-document-more-action", inputs: { menuItems: "menuItems", actionContext: "actionContext" }, outputs: { availabilityStatus: "availabilityStatus" }, viewQueries: [{ propertyName: "menuItemChildren", predicate: ["menuItem"], descendants: true, isSignal: true }], ngImport: i0, template: "@if (actionContext.documents.length === 1) {\n    <div class=\"hxp-more-action-button\">\n        @if (menuItems) {\n            @if (isAvailable()) {\n                <button\n                    mat-icon-button\n                    [matMenuTriggerFor]=\"menu\"\n                    [attr.aria-label]=\"menuItems.title\"\n                >\n                    <mat-icon [svgIcon]=\"menuItems.icon ?? ''\" />\n                </button>\n            }\n            <mat-menu\n                #menu=\"matMenu\"\n                xPosition=\"before\"\n            >\n                <div data-automation-id=\"hxp-document-more-menu-panel\">\n                    @for (action of menuItems.children; track childTrackBy($index, action)) {\n                        <hxp-document-more-menu-item\n                            #menuItem\n                            [actionContext]=\"actionContext\"\n                            [item]=\"action\"\n                        />\n                    }\n                </div>\n            </mat-menu>\n        }\n    </div>\n}\n", dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i4.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i4.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: DocumentMoreMenuItemComponent, selector: "hxp-document-more-menu-item", inputs: ["item", "actionContext"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentMoreActionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-document-more-action', imports: [MatButtonModule, MatMenuModule, MatIconModule, DocumentMoreMenuItemComponent], template: "@if (actionContext.documents.length === 1) {\n    <div class=\"hxp-more-action-button\">\n        @if (menuItems) {\n            @if (isAvailable()) {\n                <button\n                    mat-icon-button\n                    [matMenuTriggerFor]=\"menu\"\n                    [attr.aria-label]=\"menuItems.title\"\n                >\n                    <mat-icon [svgIcon]=\"menuItems.icon ?? ''\" />\n                </button>\n            }\n            <mat-menu\n                #menu=\"matMenu\"\n                xPosition=\"before\"\n            >\n                <div data-automation-id=\"hxp-document-more-menu-panel\">\n                    @for (action of menuItems.children; track childTrackBy($index, action)) {\n                        <hxp-document-more-menu-item\n                            #menuItem\n                            [actionContext]=\"actionContext\"\n                            [item]=\"action\"\n                        />\n                    }\n                </div>\n            </mat-menu>\n        }\n    </div>\n}\n" }]
        }], ctorParameters: () => [], propDecorators: { menuItems: [{
                type: Input
            }], actionContext: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component that display the content of a Document.
 *
 * To use the `HxpUiDocumentViewerComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { HxpUiDocumentViewerComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         HxpUiDocumentViewerComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 *  <hxp-ui-document-viewer
 *      [document]="document"
 *      [showRightSidebar]="showRightSidebar"
 *      [fullScreen]="fullScreen"
 *      (closeViewer)="onClose()">
 *          <ng-template #toolbar>
 *              <div>Your optional custom toolbar</div>
 *          </ng-template>
 *          <ng-template #sidebar>
 *              <div>Your optional custom sidebar</div>
 *          </ng-template>
 *  </hxp-ui-document-viewer>
 */
class HxpUiDocumentViewerComponent {
    constructor() {
        this.blobDownloadService = inject(BlobDownloadService);
        this.renditionsService = inject(RenditionsService);
        this.viewUtilService = inject(ViewUtilService);
        this.sidebarService = inject(SidebarService);
        this.destroyRef = inject(DestroyRef);
        /**
         * A boolean input property that determines whether the right sidebar is displayed.
         * When set to `true`, the right sidebar will be shown. When set to `false`, the right sidebar will be hidden.
         * @type {boolean}
         * @default false
         */
        this.showRightSidebar = false;
        /**
         * A boolean input property that trigger the browser native full-screen mode.
         * The default value is `false`. To trigger the full-screen mode, set the property to `true`.
         * Setting it back to `false` will not exit the full-screen mode,
         * you have to manually set it to `false` when the `closeViewer` event is emitted
         *
         * @type {boolean}
         * @default false
         */
        this.fullScreen = false;
        /**
         * Event emitter that notifies when the document has been closed.
         *
         * @event closeViewer
         */
        this.closeViewer = new EventEmitter();
        this.toolbarTemplateRef = null;
        this.sidebarTemplateRef = null;
        this.isRenditionLoading = false;
    }
    ngOnChanges(changes) {
        if (changes['document']) {
            this.fetchBlob();
        }
        if (this.viewer) {
            if (changes['showRightSidebar']) {
                this.viewer.showRightSidebar = this.showRightSidebar;
            }
            if (changes['fullScreen']) {
                this.manageFullScreenMode(this.fullScreen);
            }
        }
    }
    // this HostListener is needed to prevent the ADF card viewer to manage the ESC key
    // when the metadata sidebar is opened, which has its own ESC key handling
    onEscKeyDown(event) {
        if (this.sidebarService.panel() === 'property') {
            event.stopImmediatePropagation();
            event.preventDefault();
        }
    }
    onClose() {
        this.closeViewer.emit();
    }
    manageFullScreenMode(shouldEnterFullScreen) {
        if (shouldEnterFullScreen) {
            try {
                this.viewer.enterFullScreen();
            }
            catch {
                console.warn('Unable to enter full-screen mode');
            }
        }
    }
    fetchBlob() {
        if (this.document) {
            const documentMimeType = this.document['sysfile_blob']?.['mimeType'];
            const isMimeTypeSupported = this.viewUtilService.getViewerTypeByMimeType(documentMimeType) !== 'unknown';
            if (isMimeTypeSupported) {
                this.blobFile$ = this.blobDownloadService.downloadBlob(this.document.sys_id).pipe(catchError(() => of(new Blob())));
            }
            else {
                this.isRenditionLoading = true;
                this.renditionsService
                    .listRenditions(this.document.sys_id)
                    .pipe(switchMap((renditions = []) => iif(() => renditions.length === 0, this.requestRendition(this.document), this.getRendition(this.document))))
                    .subscribe({
                    next: (rendition) => {
                        if (hasRenditionBlob(rendition)) {
                            this.blobFile$ = this.blobDownloadService.downloadBlob(rendition.sys_id, 'sysrendition_blob');
                            this.isRenditionLoading = false;
                        }
                        else if (!this.isRenditionLoading || rendition['sysrendition_status'] === RenditionStatus.FAILED) {
                            this.blobFile$ = of(new Blob());
                        }
                    },
                    error: () => {
                        this.blobFile$ = of(new Blob());
                        this.isRenditionLoading = false;
                    },
                });
            }
        }
    }
    requestRendition(document) {
        return defer(() => this.renditionsService.requestRenditionCreation(document.sys_id, DEFAULT_RENDITION_ID).pipe(switchMap((rendition) => this.renditionsService.getRendition(rendition['sysrendition_sourceDoc'], DEFAULT_RENDITION_ID)), pollWhile(1000, (rendition) => rendition['sysrendition_sourceDoc'] === RenditionStatus.PENDING), finalize(() => (this.isRenditionLoading = false)), takeUntilDestroyed(this.destroyRef)));
    }
    getRendition(document) {
        return defer(() => this.renditionsService.getRendition(document.sys_id, DEFAULT_RENDITION_ID)).pipe(pollWhile(1000, (rendition) => rendition['sysrendition_status'] === RenditionStatus.PENDING), finalize(() => (this.isRenditionLoading = false)), takeUntilDestroyed(this.destroyRef));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpUiDocumentViewerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: HxpUiDocumentViewerComponent, isStandalone: true, selector: "hxp-ui-document-viewer", inputs: { document: "document", showRightSidebar: "showRightSidebar", fullScreen: "fullScreen" }, outputs: { closeViewer: "closeViewer" }, host: { listeners: { "document:keydown.esc": "onEscKeyDown($event)" } }, queries: [{ propertyName: "toolbarTemplateRef", first: true, predicate: ["toolbar"], descendants: true }, { propertyName: "sidebarTemplateRef", first: true, predicate: ["sidebar"], descendants: true }], viewQueries: [{ propertyName: "viewer", first: true, predicate: ["viewer"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<adf-viewer\n    id=\"hxp-viewer\"\n    #viewer\n    *ngIf=\"document\"\n    [allowFullScreen]=\"true\"\n    [allowRightSidebar]=\"!!sidebarTemplateRef\"\n    [canNavigateBefore]=\"false\"\n    [canNavigateNext]=\"false\"\n    [showViewer]=\"true\"\n    [overlayMode]=\"true\"\n    [blobFile]=\"(blobFile$ | async)!\"\n    (showViewerChange)=\"onClose()\"\n>\n    <adf-viewer-toolbar class=\"hxp-document-viewer-toolbar\">\n        <ng-container *ngTemplateOutlet=\"toolbarTemplateRef || toolbar\" />\n    </adf-viewer-toolbar>\n    <adf-viewer-sidebar *ngIf=\"sidebarTemplateRef\">\n        <ng-container *ngTemplateOutlet=\"sidebarTemplateRef\" />\n    </adf-viewer-sidebar>\n</adf-viewer>\n<ng-template #toolbar />\n", styles: ["#hxp-viewer .adf-viewer-sidebar{min-width:436px;display:block;height:100%}#hxp-viewer .adf-viewer-sidebars .adf-viewer__sidebar:has(hxp-permissions-management-panel){width:450px}\n"], dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: ViewerComponent, selector: "adf-viewer", inputs: ["urlFile", "blobFile", "showViewer", "allowGoBack", "allowFullScreen", "showToolbar", "overlayMode", "allowNavigate", "canNavigateBefore", "canNavigateNext", "allowLeftSidebar", "allowRightSidebar", "showRightSidebar", "showLeftSidebar", "sidebarRightTemplate", "sidebarLeftTemplate", "readOnly", "allowedEditActions", "tracks", "mimeType", "sidebarRightTemplateContext", "sidebarLeftTemplateContext", "closeButtonPosition", "hideInfoButton", "viewerExtensions", "nodeId", "nodeMimeType", "customError", "showToolbarDividers", "title", "fileName"], outputs: ["downloadFile", "navigateBefore", "navigateNext", "showViewerChange", "submitFile"] }, { kind: "component", type: ViewerToolbarComponent, selector: "adf-viewer-toolbar" }, { kind: "component", type: ViewerSidebarComponent, selector: "adf-viewer-sidebar" }, { kind: "pipe", type: AsyncPipe, name: "async" }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: MatDialogModule }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpUiDocumentViewerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-ui-document-viewer', encapsulation: ViewEncapsulation.None, imports: [NgIf, ViewerComponent, ViewerToolbarComponent, ViewerSidebarComponent, AsyncPipe, NgTemplateOutlet, MatDialogModule], template: "<adf-viewer\n    id=\"hxp-viewer\"\n    #viewer\n    *ngIf=\"document\"\n    [allowFullScreen]=\"true\"\n    [allowRightSidebar]=\"!!sidebarTemplateRef\"\n    [canNavigateBefore]=\"false\"\n    [canNavigateNext]=\"false\"\n    [showViewer]=\"true\"\n    [overlayMode]=\"true\"\n    [blobFile]=\"(blobFile$ | async)!\"\n    (showViewerChange)=\"onClose()\"\n>\n    <adf-viewer-toolbar class=\"hxp-document-viewer-toolbar\">\n        <ng-container *ngTemplateOutlet=\"toolbarTemplateRef || toolbar\" />\n    </adf-viewer-toolbar>\n    <adf-viewer-sidebar *ngIf=\"sidebarTemplateRef\">\n        <ng-container *ngTemplateOutlet=\"sidebarTemplateRef\" />\n    </adf-viewer-sidebar>\n</adf-viewer>\n<ng-template #toolbar />\n", styles: ["#hxp-viewer .adf-viewer-sidebar{min-width:436px;display:block;height:100%}#hxp-viewer .adf-viewer-sidebars .adf-viewer__sidebar:has(hxp-permissions-management-panel){width:450px}\n"] }]
        }], propDecorators: { document: [{
                type: Input
            }], showRightSidebar: [{
                type: Input
            }], fullScreen: [{
                type: Input
            }], closeViewer: [{
                type: Output
            }], viewer: [{
                type: ViewChild,
                args: ['viewer']
            }], toolbarTemplateRef: [{
                type: ContentChild,
                args: ['toolbar', { static: false }]
            }], sidebarTemplateRef: [{
                type: ContentChild,
                args: ['sidebar', { static: false }]
            }], onEscKeyDown: [{
                type: HostListener,
                args: ['document:keydown.esc', ['$event']]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component representing a skeleton to display during content loading.
 *
 * To use the `TableSkeletonLoaderComponent`, you need first to import the component in your module
 *
 * ```ts
 * import { TableSkeletonLoaderComponent } from '@alfresco/adf-hx-content-services/ui';
 * @NgModule({
 *     imports: [
 *         TableSkeletonLoaderComponent,
 *         ...
 *     ],
 *    [...]
 * })
 * export class AppModule {}
 * ```
 *
 * Then use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-table-skeleton-loader></hxp-table-skeleton-loader>
 */
class TableSkeletonLoaderComponent {
    constructor() {
        /**
         * Indicates the number of rows to display in the skeleton table.
         * @type {number}
         * @default 5
         */
        this.skeletonRows = TableSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    /**
     * Default value of skeleton tree rows to display.
     * @readonly
     * @type {number}
     */
    static { this.DEFAULT_SKELETON_ROWS = 5; }
    ngOnChanges() {
        if (!this.skeletonRows && this.skeletonRows !== 0) {
            this.skeletonRows = TableSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        }
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    skeletonRowTrackBy(index) {
        return index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: TableSkeletonLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: TableSkeletonLoaderComponent, isStandalone: true, selector: "hxp-table-skeleton-loader", inputs: { skeletonRows: "skeletonRows" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-skeleton-table-wrapper\">\n    <table class=\"hxp-skeleton-table\">\n        <thead>\n            <tr>\n                <th class=\"hxp-skeleton-checkbox-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-checkbox\"></div></th>\n                <th class=\"hxp-skeleton-icon-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-70\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-70\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-100\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-80\"></div></th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n                <td class=\"hxp-skeleton-checkbox-cell\">\n                    <div class=\"hxp-skeleton-box hxp-skeleton-checkbox\">\n                        <input\n                            type=\"checkbox\"\n                            disabled\n                        />\n                    </div>\n                </td>\n                <td class=\"hxp-skeleton-icon-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-50\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-small\"></div></td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n", styles: [".hxp-skeleton-table-wrapper{padding-bottom:50%}.hxp-skeleton-table{width:100%;border-collapse:collapse;table-layout:fixed}thead th,tbody td{padding:20px;text-align:start}thead th{border-bottom:2px solid var(--mat-sys-surface-container-highest);padding-top:15px;padding-bottom:15px}.hxp-skeleton-box{background-color:var(--mat-sys-surface-container-highest);border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-checkbox{width:20px;height:20px;background:transparent}.hxp-skeleton-icon{width:20px;height:20px}.hxp-skeleton-header-70{width:70%;height:16px}.hxp-skeleton-header-80{width:80%;height:16px}.hxp-skeleton-header-100,.hxp-skeleton-text-100{width:100%;height:16px}.hxp-skeleton-text-50{width:50%;height:16px}.hxp-skeleton-small{width:50px;height:16px}.hxp-skeleton-checkbox-cell,.hxp-skeleton-icon-cell{width:2%;padding:8px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"], dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: TableSkeletonLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-table-skeleton-loader', imports: [NgFor], template: "<div class=\"hxp-skeleton-table-wrapper\">\n    <table class=\"hxp-skeleton-table\">\n        <thead>\n            <tr>\n                <th class=\"hxp-skeleton-checkbox-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-checkbox\"></div></th>\n                <th class=\"hxp-skeleton-icon-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-70\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-70\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-100\"></div></th>\n                <th><div class=\"hxp-skeleton-box hxp-skeleton-header-80\"></div></th>\n            </tr>\n        </thead>\n        <tbody>\n            <tr *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\">\n                <td class=\"hxp-skeleton-checkbox-cell\">\n                    <div class=\"hxp-skeleton-box hxp-skeleton-checkbox\">\n                        <input\n                            type=\"checkbox\"\n                            disabled\n                        />\n                    </div>\n                </td>\n                <td class=\"hxp-skeleton-icon-cell\"><div class=\"hxp-skeleton-box hxp-skeleton-icon\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-50\"></div></td>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-small\"></div></td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n", styles: [".hxp-skeleton-table-wrapper{padding-bottom:50%}.hxp-skeleton-table{width:100%;border-collapse:collapse;table-layout:fixed}thead th,tbody td{padding:20px;text-align:start}thead th{border-bottom:2px solid var(--mat-sys-surface-container-highest);padding-top:15px;padding-bottom:15px}.hxp-skeleton-box{background-color:var(--mat-sys-surface-container-highest);border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-checkbox{width:20px;height:20px;background:transparent}.hxp-skeleton-icon{width:20px;height:20px}.hxp-skeleton-header-70{width:70%;height:16px}.hxp-skeleton-header-80{width:80%;height:16px}.hxp-skeleton-header-100,.hxp-skeleton-text-100{width:100%;height:16px}.hxp-skeleton-text-50{width:50%;height:16px}.hxp-skeleton-small{width:50px;height:16px}.hxp-skeleton-checkbox-cell,.hxp-skeleton-icon-cell{width:2%;padding:8px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"] }]
        }], propDecorators: { skeletonRows: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionContextMenuActionsService {
    constructor() {
        this.documentSingleItemDownloadHandler = inject(HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE);
        this.documentShareHandler = inject(HXP_DOCUMENT_SHARE_ACTION_SERVICE);
        this.documentVersionRestoreHandler = inject(HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE);
        this.documentVersionEditHandler = inject(HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE);
        this.documentVersionDeleteHandler = inject(HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE);
    }
    getVersionContextActions(data, parentDocument) {
        const context = {
            documents: [data],
            parentDocument,
        };
        const actions = [
            {
                data,
                model: {
                    key: 'download',
                    icon: 'download',
                    title: 'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE',
                    visible: this.documentSingleItemDownloadHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentSingleItemDownloadHandler, context),
            },
            {
                data,
                model: {
                    key: 'share',
                    icon: 'share',
                    title: 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE',
                    visible: this.documentShareHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentShareHandler, context),
            },
        ];
        if (this.documentVersionRestoreHandler) {
            actions.push({
                data,
                model: {
                    key: 'restore-version',
                    icon: 'clock',
                    title: 'RESTORE_VERSION.TOOLBAR.BUTTONS.RESTORE.TITLE',
                    visible: this.documentVersionRestoreHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentVersionRestoreHandler, context),
            });
        }
        if (this.documentVersionEditHandler) {
            actions.push({
                data,
                model: {
                    key: 'edit-version',
                    icon: 'pencil',
                    title: 'MANAGE_VERSIONS.DIALOG.MORE_MENU.EDIT',
                    visible: this.documentVersionEditHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentVersionEditHandler, context),
            });
        }
        if (this.documentVersionDeleteHandler) {
            actions.push({
                data,
                model: {
                    key: 'delete-version',
                    icon: 'trash',
                    title: 'MANAGE_VERSIONS.DIALOG.MORE_MENU.DELETE',
                    visible: this.documentVersionDeleteHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentVersionDeleteHandler, context),
            });
        }
        return actions;
    }
    toContextAction(documentActionService, context) {
        const subject = new Subject();
        subject.subscribe({
            next: () => {
                documentActionService.execute(context);
            },
        });
        return subject;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionContextMenuActionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionContextMenuActionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionContextMenuActionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PanelSkeletonLoaderComponent {
    constructor() {
        /**
         * Indicates the number of rows to display in the skeleton panel.
         * @type {number}
         * @default 10
         */
        this.skeletonRows = PanelSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    /**
     * Default value of skeleton panel rows to display.
     * @readonly
     * @type {number}
     */
    static { this.DEFAULT_SKELETON_ROWS = 10; }
    ngOnChanges() {
        if (!this.skeletonRows && this.skeletonRows !== 0) {
            this.skeletonRows = PanelSkeletonLoaderComponent.DEFAULT_SKELETON_ROWS;
        }
        this.skeletonRowArray = Array.from({ length: this.skeletonRows });
    }
    skeletonRowTrackBy(index) {
        return index;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PanelSkeletonLoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: PanelSkeletonLoaderComponent, isStandalone: true, selector: "hxp-panel-skeleton-loader", inputs: { skeletonRows: "skeletonRows" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-skeleton-table-container\">\n    <table\n        class=\"hxp-skeleton-table\"\n        aria-hidden=\"true\"\n        *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\"\n    >\n        <tbody>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-50\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-25\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-25\"></div></td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n", styles: [".hxp-skeleton-table-container{width:100%}.hxp-skeleton-table{border-collapse:collapse;table-layout:fixed;margin-bottom:20px;width:100%}tbody td{padding:5px 15px;text-align:left}.hxp-skeleton-box{background-color:var(--mat-sys-surface-container-highest);border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-text-25{width:25%;height:15px}.hxp-skeleton-text-50{width:50%;height:15px}.hxp-skeleton-text-100{width:100%;height:15px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"], dependencies: [{ kind: "directive", type: NgFor, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PanelSkeletonLoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-panel-skeleton-loader', imports: [NgFor], template: "<div class=\"hxp-skeleton-table-container\">\n    <table\n        class=\"hxp-skeleton-table\"\n        aria-hidden=\"true\"\n        *ngFor=\"let i of skeletonRowArray; trackBy: skeletonRowTrackBy\"\n    >\n        <tbody>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-50\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-25\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-100\"></div></td>\n            </tr>\n            <tr>\n                <td><div class=\"hxp-skeleton-box hxp-skeleton-text-25\"></div></td>\n            </tr>\n        </tbody>\n    </table>\n</div>\n", styles: [".hxp-skeleton-table-container{width:100%}.hxp-skeleton-table{border-collapse:collapse;table-layout:fixed;margin-bottom:20px;width:100%}tbody td{padding:5px 15px;text-align:left}.hxp-skeleton-box{background-color:var(--mat-sys-surface-container-highest);border-radius:4px;animation:pulse 1.5s infinite ease-in-out}.hxp-skeleton-text-25{width:25%;height:15px}.hxp-skeleton-text-50{width:50%;height:15px}.hxp-skeleton-text-100{width:100%;height:15px}@keyframes pulse{0%{opacity:1}50%{opacity:.5}to{opacity:1}}\n"] }]
        }], propDecorators: { skeletonRows: [{
                type: Input
            }] } });

class ManageVersionsSidebarComponent {
    constructor() {
        /**
         * Emits an event when the sidebar is closed
         */
        this.closeVersionsSidebar = new EventEmitter();
        this.documentVersions = [];
        this.isLoading = false;
        this.workingCopy = undefined;
        this.selectedDocument = undefined;
        this.contextActionMenuTemplateRef = null;
        this.contextMenuPosition = { x: '0px', y: '0px' };
        this.contextActions = [];
        this.documentRouterService = inject(DocumentRouterService);
        this.documentVersionsService = inject(DocumentVersionsService);
        this.versionContextMenuActionsService = inject(VersionContextMenuActionsService);
    }
    ngOnInit() {
        merge(this.documentVersionsService.versionDeleted$, this.documentVersionsService.versionUpdated$).subscribe(() => {
            // eslint-disable-next-line rxjs/no-nested-subscribe
            this.loadVersions();
        });
    }
    ngOnChanges() {
        if (this.document) {
            this.selectedDocument = this.document;
            this.loadVersions();
        }
    }
    redirectToVersion(document) {
        if (document) {
            this.selectedDocument = document;
            this.documentRouterService.navigateTo(document);
        }
    }
    onClose() {
        this.closeVersionsSidebar.emit();
    }
    onContextMenu(event, version) {
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuPosition = { x: `${event.clientX}px`, y: `${event.clientY}px` };
        const targetHtmlElement = event.target;
        if (targetHtmlElement.tagName !== 'BUTTON' && targetHtmlElement.tagName !== 'MAT-ICON') {
            const node = targetHtmlElement.closest('.hxp-version-item');
            const trigger = node?.querySelector('.hxp-menu-trigger');
            this.contextActions = this.getContextActions(version);
            if (this.contextActions.some((action) => action.model.visible)) {
                trigger?.dispatchEvent(new MouseEvent('click'));
            }
        }
        else {
            this.contextActions = this.getContextActions(version);
            if (this.contextActions.some((action) => action.model.visible)) {
                this.hiddenTrigger?.openMenu();
            }
        }
    }
    getContextActions(version) {
        return this.versionContextMenuActionsService.getVersionContextActions(version, this.workingCopy);
    }
    loadVersions() {
        if (!this.selectedDocument) {
            return;
        }
        this.isLoading = true;
        this.documentVersionsService
            .getCurrentDocument(this.selectedDocument)
            .pipe(take(1), switchMap$1((currentDoc) => {
            this.workingCopy = currentDoc;
            return this.documentVersionsService
                .getVersions(currentDoc)
                .pipe(map$1((versions) => [currentDoc, ...versions]));
        }), finalize$1(() => (this.isLoading = false)))
            .subscribe({
            next: (mergedVersions) => {
                this.documentVersions = mergedVersions;
            },
            error: (err) => {
                console.error(err);
            },
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageVersionsSidebarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: ManageVersionsSidebarComponent, isStandalone: true, selector: "hxp-manage-versions-sidebar", inputs: { document: "document" }, outputs: { closeVersionsSidebar: "closeVersionsSidebar" }, queries: [{ propertyName: "contextActionMenuTemplateRef", first: true, predicate: ["contextActionMenu"], descendants: true }], viewQueries: [{ propertyName: "menuTrigger", first: true, predicate: ["trigger"], descendants: true }, { propertyName: "hiddenTrigger", first: true, predicate: ["hiddenTrigger"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<adf-info-drawer-layout>\n    <div info-drawer-content>\n        <div class=\"hxp-manage-versions-sidebar-header\">\n            <h5>{{ 'MANAGE_VERSIONS.DIALOG.TITLE' | translate }}</h5>\n            <button\n                mat-icon-button\n                class=\"hxp-manage-versions-sidebar-close-btn\"\n                attr.aria-label=\"{{ 'MANAGE_VERSIONS.DIALOG.CLOSE' | translate }}\"\n                (click)=\"onClose()\"\n            >\n                <mat-icon svgIcon=\"x_large\" />\n            </button>\n        </div>\n        @if (isLoading) {\n            <hxp-panel-skeleton-loader\n                [skeletonRows]=\"10\"\n                class=\"hxp-version-panel-skeleton-loader\"\n            />\n        } @else {\n            <div class=\"hxp-version-list\">\n                @for (version of documentVersions; track version) {\n                    <button\n                        type=\"button\"\n                        class=\"hxp-version-item\"\n                        [class.hxp-current-version]=\"!version.sysver_isVersion\"\n                        [class.active]=\"document?.sys_id === version.sys_id\"\n                        (click)=\"redirectToVersion(version)\"\n                        (contextmenu)=\"onContextMenu($event, version)\"\n                    >\n                        @if (!version.sysver_isVersion) {\n                            <div class=\"hxp-version-header\">\n                                <span\n                                    class=\"hxp-version-title mat-title-medium\"\n                                    matTooltip=\"{{ version?.sys_modified | date: 'medium' }}\"\n                                >\n                                    {{ version?.sys_modified | date: 'medium' }}\n                                </span>\n                                <div class=\"hxp-context-btn\">\n                                    <button\n                                        mat-icon-button\n                                        data-automation-id=\"hxp-current-version-context-menu-button\"\n                                        [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                                        (click)=\"onContextMenu($event, version)\"\n                                    >\n                                        <mat-icon svgIcon=\"more_vert\" />\n                                    </button>\n                                </div>\n                            </div>\n                            <div\n                                class=\"hxp-version-description mat-title-medium\"\n                                matTooltip=\"{{ version.sysver_description }}\"\n                            >\n                                {{ 'MANAGE_VERSIONS.DIALOG.CURRENT_VERSION' | translate }}\n                            </div>\n                            <div class=\"hxp-version-meta mat-body-small\">\n                                <span>\n                                    {{ 'MANAGE_VERSIONS.DIALOG.CREATOR' | translate }}\n                                    {{ version.sys_creator | hxpUserResolverPipe }}\n                                </span>\n                                <span class=\"hxp-version-date\">\n                                    {{ version?.sys_created | date: 'medium' }}\n                                </span>\n                            </div>\n                        } @else {\n                            <div class=\"hxp-version-header\">\n                                <span\n                                    class=\"hxp-version-title mat-title-medium\"\n                                    matTooltip=\"{{ version?.sysver_title || (version?.sysver_created || version?.sys_modified | date: 'medium') }}\"\n                                >\n                                    {{ version?.sysver_title || (version?.sysver_created || version?.sys_modified | date: 'medium') }}\n                                </span>\n                                <div class=\"hxp-context-btn\">\n                                    <button\n                                        mat-icon-button\n                                        data-automation-id=\"hxp-version-context-menu-button\"\n                                        [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                                        (click)=\"onContextMenu($event, version)\"\n                                    >\n                                        <mat-icon svgIcon=\"more_vert\" />\n                                    </button>\n                                </div>\n                            </div>\n                            @if (version.sysver_description) {\n                                <div\n                                    class=\"hxp-version-description\"\n                                    matTooltip=\"{{ version.sysver_description }}\"\n                                >\n                                    {{ version.sysver_description }}\n                                </div>\n                            }\n                            <div class=\"hxp-version-meta mat-body-small\">\n                                <span>\n                                    {{ 'MANAGE_VERSIONS.DIALOG.CREATOR' | translate }}\n                                    {{ version.sysver_creator | hxpUserResolverPipe }}\n                                </span>\n                                <span class=\"hxp-version-date\">\n                                    {{ version?.sysver_created | date: 'medium' }}\n                                </span>\n                            </div>\n                        }\n                        <div class=\"hxp-version-footer mat-body-small\">\n                            <span>\n                                {{\n                                    version.sysver_expires\n                                        ? (('MANAGE_VERSIONS.DIALOG.EXPIRES' | translate) + version.sysver_expires | date: 'medium')\n                                        : ('MANAGE_VERSIONS.DIALOG.NEVER_EXPIRES' | translate)\n                                }}\n                            </span>\n                        </div>\n                        <div\n                            #hiddenTrigger=\"matMenuTrigger\"\n                            class=\"hxp-menu-trigger\"\n                            [style.left]=\"contextMenuPosition.x\"\n                            [style.top]=\"contextMenuPosition.y\"\n                            [matMenuTriggerFor]=\"contextMenu\"\n                            [matMenuTriggerData]=\"{ actions: contextActions }\"\n                        ></div>\n                    </button>\n                }\n            </div>\n        }\n    </div>\n    <mat-menu\n        #contextMenu=\"matMenu\"\n        class=\"hxp-context-menu\"\n    >\n        <ng-container *ngTemplateOutlet=\"contextActionMenuTemplateRef; context: { $implicit: contextActions }\" />\n    </mat-menu>\n</adf-info-drawer-layout>\n", styles: ["adf-info-drawer-layout .hxp-version-panel-skeleton-loader{display:inline-block;width:370px}adf-info-drawer-layout .adf-info-drawer-layout-content{position:relative}adf-info-drawer-layout .adf-info-drawer-layout-header{display:none}adf-info-drawer-layout .hxp-manage-versions-sidebar-header{display:flex;justify-content:space-between;align-items:center;padding:24px 16px}adf-info-drawer-layout .hxp-version-list{display:flex;flex-direction:column;flex:1;overflow-y:auto;padding:12px;height:100vh}adf-info-drawer-layout .hxp-version-list .hxp-version-item{padding:0 24px;margin-bottom:8px;text-align:left;cursor:pointer;border:0;background-color:var(--mat-sys-on-surface-container)}adf-info-drawer-layout .hxp-version-list .hxp-version-item:hover,adf-info-drawer-layout .hxp-version-list .hxp-version-item.active{background-color:var(--mat-sys-surface-container)}adf-info-drawer-layout .hxp-version-list .hxp-version-item.hxp-current-version .hxp-version-description{color:var(--mat-sys-primary)}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header{display:flex;justify-content:space-between;align-items:center}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header .hxp-context-btn{position:relative;right:-24px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-description{padding-bottom:12px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-title,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-description{max-width:320px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-meta,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-footer{padding-bottom:12px;color:var(--mat-sys-on-surface)}adf-info-drawer-layout .hxp-menu-trigger{visibility:hidden;position:fixed}.adf-viewer-sidebars .adf-viewer__sidebar{width:auto}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "pipe", type: UserResolverPipe, name: "hxpUserResolverPipe" }, { kind: "pipe", type: DatePipe, name: "date" }, { kind: "component", type: InfoDrawerLayoutComponent, selector: "adf-info-drawer-layout", inputs: ["showHeader"] }, { kind: "directive", type: InfoDrawerContentDirective, selector: "[adf-info-drawer-content], [info-drawer-content]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "component", type: PanelSkeletonLoaderComponent, selector: "hxp-panel-skeleton-loader", inputs: ["skeletonRows"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i4.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "directive", type: i4.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }], encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageVersionsSidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-manage-versions-sidebar', encapsulation: ViewEncapsulation.None, imports: [
                        NgTemplateOutlet,
                        TranslatePipe,
                        UserResolverPipe,
                        DatePipe,
                        InfoDrawerLayoutComponent,
                        InfoDrawerContentDirective,
                        MatButtonModule,
                        MatIconModule,
                        PanelSkeletonLoaderComponent,
                        MatMenuModule,
                        MatTooltipModule,
                    ], template: "<adf-info-drawer-layout>\n    <div info-drawer-content>\n        <div class=\"hxp-manage-versions-sidebar-header\">\n            <h5>{{ 'MANAGE_VERSIONS.DIALOG.TITLE' | translate }}</h5>\n            <button\n                mat-icon-button\n                class=\"hxp-manage-versions-sidebar-close-btn\"\n                attr.aria-label=\"{{ 'MANAGE_VERSIONS.DIALOG.CLOSE' | translate }}\"\n                (click)=\"onClose()\"\n            >\n                <mat-icon svgIcon=\"x_large\" />\n            </button>\n        </div>\n        @if (isLoading) {\n            <hxp-panel-skeleton-loader\n                [skeletonRows]=\"10\"\n                class=\"hxp-version-panel-skeleton-loader\"\n            />\n        } @else {\n            <div class=\"hxp-version-list\">\n                @for (version of documentVersions; track version) {\n                    <button\n                        type=\"button\"\n                        class=\"hxp-version-item\"\n                        [class.hxp-current-version]=\"!version.sysver_isVersion\"\n                        [class.active]=\"document?.sys_id === version.sys_id\"\n                        (click)=\"redirectToVersion(version)\"\n                        (contextmenu)=\"onContextMenu($event, version)\"\n                    >\n                        @if (!version.sysver_isVersion) {\n                            <div class=\"hxp-version-header\">\n                                <span\n                                    class=\"hxp-version-title mat-title-medium\"\n                                    matTooltip=\"{{ version?.sys_modified | date: 'medium' }}\"\n                                >\n                                    {{ version?.sys_modified | date: 'medium' }}\n                                </span>\n                                <div class=\"hxp-context-btn\">\n                                    <button\n                                        mat-icon-button\n                                        data-automation-id=\"hxp-current-version-context-menu-button\"\n                                        [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                                        (click)=\"onContextMenu($event, version)\"\n                                    >\n                                        <mat-icon svgIcon=\"more_vert\" />\n                                    </button>\n                                </div>\n                            </div>\n                            <div\n                                class=\"hxp-version-description mat-title-medium\"\n                                matTooltip=\"{{ version.sysver_description }}\"\n                            >\n                                {{ 'MANAGE_VERSIONS.DIALOG.CURRENT_VERSION' | translate }}\n                            </div>\n                            <div class=\"hxp-version-meta mat-body-small\">\n                                <span>\n                                    {{ 'MANAGE_VERSIONS.DIALOG.CREATOR' | translate }}\n                                    {{ version.sys_creator | hxpUserResolverPipe }}\n                                </span>\n                                <span class=\"hxp-version-date\">\n                                    {{ version?.sys_created | date: 'medium' }}\n                                </span>\n                            </div>\n                        } @else {\n                            <div class=\"hxp-version-header\">\n                                <span\n                                    class=\"hxp-version-title mat-title-medium\"\n                                    matTooltip=\"{{ version?.sysver_title || (version?.sysver_created || version?.sys_modified | date: 'medium') }}\"\n                                >\n                                    {{ version?.sysver_title || (version?.sysver_created || version?.sys_modified | date: 'medium') }}\n                                </span>\n                                <div class=\"hxp-context-btn\">\n                                    <button\n                                        mat-icon-button\n                                        data-automation-id=\"hxp-version-context-menu-button\"\n                                        [attr.aria-label]=\"'DOCUMENT_TREE.CONTEXT_MENU.TRIGGER_ARIA_LABEL' | translate\"\n                                        (click)=\"onContextMenu($event, version)\"\n                                    >\n                                        <mat-icon svgIcon=\"more_vert\" />\n                                    </button>\n                                </div>\n                            </div>\n                            @if (version.sysver_description) {\n                                <div\n                                    class=\"hxp-version-description\"\n                                    matTooltip=\"{{ version.sysver_description }}\"\n                                >\n                                    {{ version.sysver_description }}\n                                </div>\n                            }\n                            <div class=\"hxp-version-meta mat-body-small\">\n                                <span>\n                                    {{ 'MANAGE_VERSIONS.DIALOG.CREATOR' | translate }}\n                                    {{ version.sysver_creator | hxpUserResolverPipe }}\n                                </span>\n                                <span class=\"hxp-version-date\">\n                                    {{ version?.sysver_created | date: 'medium' }}\n                                </span>\n                            </div>\n                        }\n                        <div class=\"hxp-version-footer mat-body-small\">\n                            <span>\n                                {{\n                                    version.sysver_expires\n                                        ? (('MANAGE_VERSIONS.DIALOG.EXPIRES' | translate) + version.sysver_expires | date: 'medium')\n                                        : ('MANAGE_VERSIONS.DIALOG.NEVER_EXPIRES' | translate)\n                                }}\n                            </span>\n                        </div>\n                        <div\n                            #hiddenTrigger=\"matMenuTrigger\"\n                            class=\"hxp-menu-trigger\"\n                            [style.left]=\"contextMenuPosition.x\"\n                            [style.top]=\"contextMenuPosition.y\"\n                            [matMenuTriggerFor]=\"contextMenu\"\n                            [matMenuTriggerData]=\"{ actions: contextActions }\"\n                        ></div>\n                    </button>\n                }\n            </div>\n        }\n    </div>\n    <mat-menu\n        #contextMenu=\"matMenu\"\n        class=\"hxp-context-menu\"\n    >\n        <ng-container *ngTemplateOutlet=\"contextActionMenuTemplateRef; context: { $implicit: contextActions }\" />\n    </mat-menu>\n</adf-info-drawer-layout>\n", styles: ["adf-info-drawer-layout .hxp-version-panel-skeleton-loader{display:inline-block;width:370px}adf-info-drawer-layout .adf-info-drawer-layout-content{position:relative}adf-info-drawer-layout .adf-info-drawer-layout-header{display:none}adf-info-drawer-layout .hxp-manage-versions-sidebar-header{display:flex;justify-content:space-between;align-items:center;padding:24px 16px}adf-info-drawer-layout .hxp-version-list{display:flex;flex-direction:column;flex:1;overflow-y:auto;padding:12px;height:100vh}adf-info-drawer-layout .hxp-version-list .hxp-version-item{padding:0 24px;margin-bottom:8px;text-align:left;cursor:pointer;border:0;background-color:var(--mat-sys-on-surface-container)}adf-info-drawer-layout .hxp-version-list .hxp-version-item:hover,adf-info-drawer-layout .hxp-version-list .hxp-version-item.active{background-color:var(--mat-sys-surface-container)}adf-info-drawer-layout .hxp-version-list .hxp-version-item.hxp-current-version .hxp-version-description{color:var(--mat-sys-primary)}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header{display:flex;justify-content:space-between;align-items:center}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header .hxp-context-btn{position:relative;right:-24px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-header,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-description{padding-bottom:12px}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-title,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-description{max-width:320px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-meta,adf-info-drawer-layout .hxp-version-list .hxp-version-item .hxp-version-footer{padding-bottom:12px;color:var(--mat-sys-on-surface)}adf-info-drawer-layout .hxp-menu-trigger{visibility:hidden;position:fixed}.adf-viewer-sidebars .adf-viewer__sidebar{width:auto}\n"] }]
        }], propDecorators: { document: [{
                type: Input
            }], closeVersionsSidebar: [{
                type: Output
            }], contextActionMenuTemplateRef: [{
                type: ContentChild,
                args: ['contextActionMenu', { static: false }]
            }], menuTrigger: [{
                type: ViewChild,
                args: ['trigger', { static: false }]
            }], hiddenTrigger: [{
                type: ViewChild,
                args: ['hiddenTrigger', { static: false }]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component icon button that delete a `Document` file. Success or error action result status is notified to the user.
 *
 * To display the component:
 * - the `actionContext` input property must provide a list of `Document` to delete in the `documents` array;
 * - current logged in user must have `DELETE` permission on every `Document` in the list;
 * - current logged in user must have `DELETE_CHILD` permission on the parent `Document`.
 *
 * To use the `ContentDeleteButtonComponent`, import the component in your module
 *
 * ```ts
 * import { ContentDeleteButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentDeleteButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-content-delete [actionContext]="actionContext"></hxp-content-delete>
 *
 */
class ContentDeleteButtonComponent {
    constructor() {
        this.isAvailable = false;
        this.deleteButtonActionService = inject(HXP_DOCUMENT_DELETE_ACTION_SERVICE);
        this.documentCache = inject(DocumentCacheService);
    }
    ngOnChanges() {
        if (!this.actionContext.parentDocument && this.actionContext.documents.length > 0 && this.actionContext.documents[0].sys_parentId) {
            this.documentCache.getDocument(this.actionContext.documents[0].sys_parentId).subscribe({
                next: (doc) => {
                    this.actionContext.parentDocument = doc;
                    this.isAvailable = this.deleteButtonActionService.isAvailable(this.actionContext);
                },
                error: (error) => {
                    this.actionContext.parentDocument = undefined;
                    this.isAvailable = false;
                    if (!isPermissionError(error)) {
                        console.error(error);
                    }
                },
            });
        }
        else {
            this.isAvailable = this.deleteButtonActionService.isAvailable(this.actionContext);
        }
    }
    onDelete() {
        this.deleteButtonActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentDeleteButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: ContentDeleteButtonComponent, isStandalone: true, selector: "hxp-content-delete", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "<button\n    *ngIf=\"isAvailable\"\n    mat-icon-button\n    [attr.aria-label]=\"'APP.TOOLBAR.BUTTONS.DELETE.ARIA-LABEL' | translate\"\n    title=\"{{ 'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE' | translate }}\"\n    [matTooltip]=\"'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE' | translate\"\n    (click)=\"onDelete()\"\n>\n    <mat-icon svgIcon=\"trash\" />\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentDeleteButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-content-delete', imports: [NgIf, MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "<button\n    *ngIf=\"isAvailable\"\n    mat-icon-button\n    [attr.aria-label]=\"'APP.TOOLBAR.BUTTONS.DELETE.ARIA-LABEL' | translate\"\n    title=\"{{ 'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE' | translate }}\"\n    [matTooltip]=\"'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE' | translate\"\n    (click)=\"onDelete()\"\n>\n    <mat-icon svgIcon=\"trash\" />\n</button>\n" }]
        }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component icon button that downloads a `Document` file. Success or error action result status is notified to the user.
 *
 * To display the component:
 * - the `actionContext` input property must provide only one `Document` in the `documents` array;
 * - the `Document` must have a valid blob to download;
 * - the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `SingleItemDownloadButtonComponent`, import the component in your module
 *
 * ```ts
 * import { SingleItemDownloadButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         SingleItemDownloadButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-single-item-download [actionContext]="actionContext"></hxp-single-item-download>
 *
 */
class SingleItemDownloadButtonComponent {
    constructor() {
        /**
         * Input property which specifies an `ActionContext` object
         * The `ActionContext` object should provide an array containing only one `Document`.
         * @type {ActionContext}
         *
         * @example
         * interface ActionContext {
         *     documents: Document[];
         * }
         *
         */
        this.actionContext = { documents: [] };
        this.isAvailable = false;
        this.singleItemDownloadButtonActionService = inject(HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE);
    }
    ngOnChanges() {
        this.isAvailable = this.singleItemDownloadButtonActionService.isAvailable(this.actionContext);
    }
    onDownload() {
        this.singleItemDownloadButtonActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemDownloadButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: SingleItemDownloadButtonComponent, isStandalone: true, selector: "hxp-single-item-download", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "<button\n    *ngIf=\"isAvailable\"\n    id=\"document-viewer-single-download-button\"\n    mat-icon-button\n    [attr.aria-label]=\"'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.ARIA-LABEL' | translate\"\n    title=\"{{ 'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE' | translate }}\"\n    [matTooltip]=\"'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE' | translate\"\n    (click)=\"onDownload()\"\n>\n    <mat-icon svgIcon=\"download\" />\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemDownloadButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-single-item-download', imports: [NgIf, MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "<button\n    *ngIf=\"isAvailable\"\n    id=\"document-viewer-single-download-button\"\n    mat-icon-button\n    [attr.aria-label]=\"'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.ARIA-LABEL' | translate\"\n    title=\"{{ 'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE' | translate }}\"\n    [matTooltip]=\"'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE' | translate\"\n    (click)=\"onDownload()\"\n>\n    <mat-icon svgIcon=\"download\" />\n</button>\n" }]
        }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component icon button that shows a dialog to share a `Document` url.
 *
 * To display the component, the `actionContext` input property must provide only one `Document` in the `documents` array,
 * and the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `ContentShareButtonComponent`, import the component in your module
 *
 * ```ts
 * import { ContentShareButtonComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentShareButtonComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Use it in your Angular template as shown in the example below:
 *
 * @example
 * <hxp-single-file-share [actionContext]="actionContext"></hxp-single-file-share>
 *
 */
class ContentShareButtonComponent {
    constructor() {
        /**
         * Input property which specifies an `ActionContext` object
         * The `ActionContext` object should provide an array containing only one `Document`.
         * @type {ActionContext}
         *
         * @example
         * interface ActionContext {
         *     documents: Document[];
         * }
         *
         */
        this.actionContext = { documents: [] };
        this.isAvailable = false;
        this.contentShareButtonActionService = inject(HXP_DOCUMENT_SHARE_ACTION_SERVICE);
    }
    ngOnChanges() {
        this.isAvailable = this.contentShareButtonActionService.isAvailable(this.actionContext);
    }
    onShare() {
        this.contentShareButtonActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: ContentShareButtonComponent, isStandalone: true, selector: "hxp-single-file-share", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "@if (isAvailable) {\n    <button\n        mat-icon-button\n        class=\"hxp-content-share-button\"\n        [attr.aria-label]=\"'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.ARIA-LABEL' | translate\"\n        title=\"{{ 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE' | translate }}\"\n        matTooltip=\"{{ 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE' | translate }}\"\n        (click)=\"onShare()\"\n    >\n        <mat-icon svgIcon=\"share\" />\n    </button>\n}\n", dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-single-file-share', imports: [MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "@if (isAvailable) {\n    <button\n        mat-icon-button\n        class=\"hxp-content-share-button\"\n        [attr.aria-label]=\"'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.ARIA-LABEL' | translate\"\n        title=\"{{ 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE' | translate }}\"\n        matTooltip=\"{{ 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE' | translate }}\"\n        (click)=\"onShare()\"\n    >\n        <mat-icon svgIcon=\"share\" />\n    </button>\n}\n" }]
        }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * Component icon button that triggers an event to display the Document Properties Sidebar.
 *
 * To display the component, the `actionContext` input property must provide only one `Document` in the `documents` array,
 * and the current logged in user must have `READ` permission on the `Document`.
 *
 * To use the `ContentPropertiesViewerButtonComponent`, import the component in your module along with `HxpMetadataSidebarComponent`.
 *
 * ```ts
 * import { ContentPropertiesViewerButtonComponent, HxpMetadataSidebarComponent } from '@alfresco/adf-hx-content-services/ui';
 *
 * @NgModule({
 *     imports: [
 *         ContentPropertiesViewerButtonComponent,
 *         HxpMetadataSidebarComponent,
 *         ...
 *     ],
 * })
 * export class AppModule {}
 * ```
 *
 * Inject the `ContentPropertyViewerActionService` in your component as shown in the example below.
 * Subscribe to `showPropertyPanel$` service stream to update the `ActionContext` object with the new value.
 *
 * ```ts
 * import { ActionContext, ContentPropertyViewerActionService, HXP_DOCUMENT_INFO_ACTION_SERVICE } from '@alfresco/adf-hx-content-services/services';
 * import { Subject } from 'rxjs';
 * import { takeUntil } from 'rxjs/operators';
 *
 * @Component({
 *   template: '
 *       <hxp-content-properties-viewer-button [actionContext]="actionContext"></hxp-content-properties-viewer-button>
 *       <hxp-metadata-sidebar
 *           *ngIf="actionContext?.showPanel === 'property'"
 *           [document]="actionContext?.documents[0]"
 *           (closePropertySidebar)="closePropertiesSidebar()"
 *           >
 *        </hxp-metadata-sidebar>
 * ',
 * })
 * export class YourComponent implements OnDestroy {
 *
 *     actionContext: ActionContext = { documents: [] };
 *
 *     private destroyed$: Subject<void> = new Subject<void>();
 *     private readonly contentPropertyViewerActionService = inject<ContentPropertyViewerActionService>(HXP_DOCUMENT_INFO_ACTION_SERVICE);
 *
 *     constructor() {
 *         this.subscribeToShowPropertyPanelStatus();
 *     }
 *
 *     ngOnDestroy() {
 *         this.destroyed$.next();
 *         this.destroyed$.complete();
 *     }
 *
 *     [...]
 *
 *     closePropertiesSidebar(): void {
 *         this.actionContext = { ...this.actionContext, showPanel: undefined };
 *         this.contentPropertyViewerActionService.execute(this.actionContext);
 *     }
 *
 *     private subscribeToShowPropertyPanelStatus(): void {
 *         this.contentPropertyViewerActionService.showPropertyPanel$
 *             .pipe(takeUntil(this.destroyed$))
 *             .subscribe({
 *                  next: (showPropertyPanel) => {
 *                      this.actionContext = { ...this.actionContext, showPanel : showPropertyPanel ? 'property' : undefined };
 *                  },
 *                  error: (error) => console.error(error)
 *         });
 *     }
 * }
 * ```
 *
 */
class ContentPropertiesViewerButtonComponent {
    constructor() {
        /**
         * Input property which specifies an `ActionContext` object
         * The `ActionContext` object should provide an array containing only one `Document`.
         *
         * Optionally the object can provide the `showPanel` to forcefully trigger an event to display or hidden the Properties Viewer.
         * @type {ActionContext}
         *
         * @example
         * interface ActionContext {
         *     documents: Document[];
         *     showPanel?: 'property' | 'version';
         * }
         *
         */
        this.actionContext = { documents: [] };
        this.isAvailable = false;
        this.contentPropertyViewerActionService = inject(HXP_DOCUMENT_INFO_ACTION_SERVICE);
    }
    ngOnChanges() {
        this.isAvailable = this.contentPropertyViewerActionService.isAvailable(this.actionContext);
    }
    showInfo() {
        this.contentPropertyViewerActionService.execute();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentPropertiesViewerButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: ContentPropertiesViewerButtonComponent, isStandalone: true, selector: "hxp-content-properties-viewer-button", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "<button\n    id=\"document-properties-viewer-button\"\n    mat-icon-button\n    data-automation-id=\"document-properties-viewer-button\"\n    [attr.aria-label]=\"'ADF_VIEWER.ACTIONS.INFO' | translate\"\n    title=\"{{ 'ADF_VIEWER.ACTIONS.INFO' | translate }}\"\n    [matTooltip]=\"'ADF_VIEWER.ACTIONS.INFO' | translate\"\n    *ngIf=\"isAvailable\"\n    (click)=\"showInfo()\"\n>\n    <mat-icon svgIcon=\"info\" />\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentPropertiesViewerButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-content-properties-viewer-button', imports: [NgIf, MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "<button\n    id=\"document-properties-viewer-button\"\n    mat-icon-button\n    data-automation-id=\"document-properties-viewer-button\"\n    [attr.aria-label]=\"'ADF_VIEWER.ACTIONS.INFO' | translate\"\n    title=\"{{ 'ADF_VIEWER.ACTIONS.INFO' | translate }}\"\n    [matTooltip]=\"'ADF_VIEWER.ACTIONS.INFO' | translate\"\n    *ngIf=\"isAvailable\"\n    (click)=\"showInfo()\"\n>\n    <mat-icon svgIcon=\"info\" />\n</button>\n" }]
        }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ManageColumnButtonComponent {
    constructor() {
        this.actionContext = { documents: [] };
        this.isAvailable = false;
        this.manageColumnActionService = inject(HXP_MANAGE_COLUMN_ACTION_SERVICE);
    }
    ngOnChanges() {
        this.isAvailable = this.manageColumnActionService.isAvailable(this.actionContext);
    }
    onCopy() {
        this.manageColumnActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageColumnButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: ManageColumnButtonComponent, isStandalone: true, selector: "hxp-manage-column-button", inputs: { actionContext: "actionContext", isAvailable: "isAvailable" }, usesOnChanges: true, ngImport: i0, template: "<button\n    *ngIf=\"isAvailable\"\n    [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.BUTTON.TOOLTIP' | translate\"\n    mat-icon-button\n    [matTooltip]=\"'SEARCH.MANAGE_COLUMN.BUTTON.TOOLTIP' | translate\"\n    (click)=\"onCopy()\"\n    class=\"hxp-manage-column-button mat-button-base\"\n>\n    <mat-icon aria-hidden=\"true\" svgIcon=\"settings\" />\n</button>\n", dependencies: [{ kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageColumnButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-manage-column-button', imports: [NgIf, MatIconModule, MatButtonModule, MatTooltipModule, TranslatePipe], template: "<button\n    *ngIf=\"isAvailable\"\n    [attr.aria-label]=\"'SEARCH.MANAGE_COLUMN.BUTTON.TOOLTIP' | translate\"\n    mat-icon-button\n    [matTooltip]=\"'SEARCH.MANAGE_COLUMN.BUTTON.TOOLTIP' | translate\"\n    (click)=\"onCopy()\"\n    class=\"hxp-manage-column-button mat-button-base\"\n>\n    <mat-icon aria-hidden=\"true\" svgIcon=\"settings\" />\n</button>\n" }]
        }], propDecorators: { actionContext: [{
                type: Input
            }], isAvailable: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionDeleteButtonComponent {
    constructor() {
        this.isAvailable = false;
        this.versionDeleteActionService = inject(HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE);
    }
    ngOnChanges() {
        this.isAvailable = this.versionDeleteActionService.isAvailable(this.actionContext);
    }
    onDelete() {
        this.versionDeleteActionService.execute(this.actionContext);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionDeleteButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: VersionDeleteButtonComponent, isStandalone: true, selector: "hxp-version-delete-button", inputs: { actionContext: "actionContext" }, usesOnChanges: true, ngImport: i0, template: "@if (isAvailable) {\n    <button\n        mat-icon-button\n        [attr.aria-label]=\"'MANAGE_VERSIONS.DELETE_BUTTON.ARIA_LABEL' | translate\"\n        title=\"{{ 'MANAGE_VERSIONS.DELETE_BUTTON.TITLE' | translate }}\"\n        [matTooltip]=\"'MANAGE_VERSIONS.DELETE_BUTTON.TITLE' | translate\"\n    >\n        <mat-icon svgIcon=\"trash\" />\n    </button>\n}\n", dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionDeleteButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-version-delete-button', imports: [MatButtonModule, MatTooltipModule, MatIconModule, TranslatePipe], template: "@if (isAvailable) {\n    <button\n        mat-icon-button\n        [attr.aria-label]=\"'MANAGE_VERSIONS.DELETE_BUTTON.ARIA_LABEL' | translate\"\n        title=\"{{ 'MANAGE_VERSIONS.DELETE_BUTTON.TITLE' | translate }}\"\n        [matTooltip]=\"'MANAGE_VERSIONS.DELETE_BUTTON.TITLE' | translate\"\n    >\n        <mat-icon svgIcon=\"trash\" />\n    </button>\n}\n" }]
        }], propDecorators: { actionContext: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class VersionRestoreComponent {
    constructor() {
        this.isAvailable = false;
        this.data = { documents: [] };
        this.versionRestoreService = inject(VersionRestoreActionService);
    }
    ngOnChanges() {
        this.isAvailable = this.versionRestoreService.isAvailable(this.data);
    }
    restoreVersion() {
        this.versionRestoreService.execute(this.data);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionRestoreComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: VersionRestoreComponent, isStandalone: true, selector: "hxp-version-restore", inputs: { isAvailable: "isAvailable", data: "data" }, usesOnChanges: true, ngImport: i0, template: "@if (isAvailable) {\n    <button\n        mat-menu-item\n        class=\"hxp-restore-version-button\"\n        (click)=\"restoreVersion()\"\n        aria-labelledby=\"hxp-restore-version-button-label\"\n    >\n        <mat-icon svgIcon=\"clock\" />\n        <span id=\"hxp-restore-version-button-label\">{{ 'DOCUMENT_RESTORE_VERSION.LABEL' | translate }}</span>\n    </button>\n}\n", dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i4.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: VersionRestoreComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-version-restore', imports: [MatButtonModule, MatMenuModule, MatIconModule, TranslatePipe], template: "@if (isAvailable) {\n    <button\n        mat-menu-item\n        class=\"hxp-restore-version-button\"\n        (click)=\"restoreVersion()\"\n        aria-labelledby=\"hxp-restore-version-button-label\"\n    >\n        <mat-icon svgIcon=\"clock\" />\n        <span id=\"hxp-restore-version-button-label\">{{ 'DOCUMENT_RESTORE_VERSION.LABEL' | translate }}</span>\n    </button>\n}\n" }]
        }], propDecorators: { isAvailable: [{
                type: Input
            }], data: [{
                type: Input
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FormatDocumentPathDirective {
    constructor() {
        this.originalText = null;
        this.el = inject(ElementRef);
        this.renderer = inject(Renderer2);
    }
    ngOnChanges(changes) {
        if (changes['columnWidths']) {
            this.truncatePath();
        }
    }
    ngAfterViewInit() {
        this.originalText = this.el.nativeElement.textContent;
        this.truncatePath();
    }
    truncatePath() {
        if (!this.originalText) {
            return;
        }
        const element = this.el.nativeElement;
        const parentElement = element.parentNode;
        this.renderer.setProperty(element, 'innerText', this.originalText);
        const parentWidth = parentElement.offsetWidth;
        const textWidth = element.offsetWidth;
        const parts = this.originalText.split('/');
        if (textWidth > parentWidth && parts.length > 2) {
            this.renderer.setProperty(element, 'innerText', `${parts[0]}/.../${parts.at(-1)}`);
        }
        else {
            this.renderer.setProperty(element, 'innerText', this.originalText);
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FormatDocumentPathDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.20", type: FormatDocumentPathDirective, isStandalone: true, selector: "[hxpFormatDocumentPath]", inputs: { columnWidths: ["hxpFormatDocumentPath", "columnWidths"] }, usesOnChanges: true, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FormatDocumentPathDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[hxpFormatDocumentPath]',
                }]
        }], propDecorators: { columnWidths: [{
                type: Input,
                args: ['hxpFormatDocumentPath']
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFilterInputComponent {
    constructor() {
        this.applyOnEnter = false;
        // eslint-disable-next-line @angular-eslint/no-output-native
        this.search = new EventEmitter();
        this.clear = new EventEmitter();
        this.prefixClick = new EventEmitter();
        this.searchTerm = '';
        this.matIconRegistry = inject(MatIconRegistry);
        this.domSanitizer = inject(DomSanitizer);
        const icons = {
            search_glass: 'assets/search-icons/Search.svg',
        };
        for (const [iconName, iconPath] of Object.entries(icons)) {
            this.matIconRegistry.addSvgIcon(iconName, this.domSanitizer.bypassSecurityTrustResourceUrl(iconPath));
        }
    }
    applyFilter(event) {
        if (!this.applyOnEnter) {
            this.emitSearch();
        }
        else if (event.key === 'Enter') {
            this.emitSearch();
        }
    }
    emitSearch() {
        this.search.emit(this.searchTerm);
    }
    clearInput() {
        this.searchTerm = '';
        this.clear.emit();
    }
    onPrefixClick() {
        this.prefixClick.emit();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: SearchFilterInputComponent, isStandalone: true, selector: "hxp-search-filter-input", inputs: { applyOnEnter: "applyOnEnter", inputAriaLabel: "inputAriaLabel", placeholder: "placeholder", clearAriaLabel: "clearAriaLabel", prefixIcon: "prefixIcon", prefixAriaLabel: "prefixAriaLabel" }, outputs: { search: "search", clear: "clear", prefixClick: "prefixClick" }, ngImport: i0, template: "<mat-form-field\n    class=\"hxp-search-filter-input\"\n    appearance=\"outline\"\n>\n    <div\n        *ngIf=\"prefixIcon\"\n        matPrefix\n        class=\"hxp-search-filter-input-prefix\"\n    >\n        <button\n            mat-icon-button\n            type=\"button\"\n            [attr.aria-label]=\"prefixAriaLabel\"\n            (click)=\"onPrefixClick()\"\n        >\n            <mat-icon\n                aria-hidden=\"true\"\n                [svgIcon]=\"prefixIcon\"\n            />\n        </button>\n        <mat-divider\n            vertical\n            class=\"hxp-search-filter-input-divider\"\n        />\n    </div>\n    <input\n        matInput\n        type=\"text\"\n        [attr.aria-label]=\"inputAriaLabel\"\n        [placeholder]=\"placeholder ?? ''\"\n        [(ngModel)]=\"searchTerm\"\n        (keyup)=\"applyFilter($event)\"\n    />\n    <div\n        matSuffix\n        class=\"hxp-search-filter-input-suffix\"\n    >\n        <button\n            *ngIf=\"searchTerm\"\n            mat-icon-button\n            class=\"hxp-search-filter-input-clear\"\n            [attr.aria-label]=\"clearAriaLabel\"\n            (click)=\"clearInput()\"\n        >\n            <mat-icon\n                class=\"hxp-search-filter-input-clear-icon\"\n                svgIcon=\"x_large\"\n            />\n        </button>\n        <mat-divider\n            vertical\n            class=\"hxp-search-filter-input-divider\"\n        />\n        <div class=\"hxp-search-filter-input-search\">\n            <div\n                *ngIf=\"applyOnEnter\"\n                class=\"hxp-search-filter-search-button\"\n            >\n                <button\n                    mat-icon-button\n                    type=\"button\"\n                    [attr.aria-label]=\"'SEARCH.FILTERS.SEARCH'\"\n                    (click)=\"emitSearch()\"\n                >\n                    <mat-icon\n                        svgIcon=\"search\"\n                        class=\"hxp-search-filter-input-search-icon\"\n                    />\n                </button>\n            </div>\n            @if (!applyOnEnter) {\n                <mat-icon\n                    svgIcon=\"search\"\n                    class=\"hxp-search-filter-input-search-icon\"\n                />\n            }\n        </div>\n    </div>\n</mat-form-field>\n", styles: [".hxp-search-filter-input{width:100%}.hxp-search-filter-input-prefix,.hxp-search-filter-input-suffix{display:flex;align-items:center}.hxp-search-filter-input-divider{height:54px}.hxp-search-filter-input-clear{display:flex;text-align:center}.hxp-search-filter-input-search{min-width:48px;position:relative;display:flex;justify-content:center;align-items:center}.hxp-search-filter-input-search button{display:flex;justify-content:center;align-items:center}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i4$2.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$1.MatPrefix, selector: "[matPrefix], [matIconPrefix], [matTextPrefix]", inputs: ["matTextPrefix"] }, { kind: "directive", type: i4$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: SatIconModule }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-filter-input', imports: [CommonModule, FormsModule, MatIconModule, MatDividerModule, MatFormFieldModule, MatInputModule, MatButtonModule, SatIconModule], template: "<mat-form-field\n    class=\"hxp-search-filter-input\"\n    appearance=\"outline\"\n>\n    <div\n        *ngIf=\"prefixIcon\"\n        matPrefix\n        class=\"hxp-search-filter-input-prefix\"\n    >\n        <button\n            mat-icon-button\n            type=\"button\"\n            [attr.aria-label]=\"prefixAriaLabel\"\n            (click)=\"onPrefixClick()\"\n        >\n            <mat-icon\n                aria-hidden=\"true\"\n                [svgIcon]=\"prefixIcon\"\n            />\n        </button>\n        <mat-divider\n            vertical\n            class=\"hxp-search-filter-input-divider\"\n        />\n    </div>\n    <input\n        matInput\n        type=\"text\"\n        [attr.aria-label]=\"inputAriaLabel\"\n        [placeholder]=\"placeholder ?? ''\"\n        [(ngModel)]=\"searchTerm\"\n        (keyup)=\"applyFilter($event)\"\n    />\n    <div\n        matSuffix\n        class=\"hxp-search-filter-input-suffix\"\n    >\n        <button\n            *ngIf=\"searchTerm\"\n            mat-icon-button\n            class=\"hxp-search-filter-input-clear\"\n            [attr.aria-label]=\"clearAriaLabel\"\n            (click)=\"clearInput()\"\n        >\n            <mat-icon\n                class=\"hxp-search-filter-input-clear-icon\"\n                svgIcon=\"x_large\"\n            />\n        </button>\n        <mat-divider\n            vertical\n            class=\"hxp-search-filter-input-divider\"\n        />\n        <div class=\"hxp-search-filter-input-search\">\n            <div\n                *ngIf=\"applyOnEnter\"\n                class=\"hxp-search-filter-search-button\"\n            >\n                <button\n                    mat-icon-button\n                    type=\"button\"\n                    [attr.aria-label]=\"'SEARCH.FILTERS.SEARCH'\"\n                    (click)=\"emitSearch()\"\n                >\n                    <mat-icon\n                        svgIcon=\"search\"\n                        class=\"hxp-search-filter-input-search-icon\"\n                    />\n                </button>\n            </div>\n            @if (!applyOnEnter) {\n                <mat-icon\n                    svgIcon=\"search\"\n                    class=\"hxp-search-filter-input-search-icon\"\n                />\n            }\n        </div>\n    </div>\n</mat-form-field>\n", styles: [".hxp-search-filter-input{width:100%}.hxp-search-filter-input-prefix,.hxp-search-filter-input-suffix{display:flex;align-items:center}.hxp-search-filter-input-divider{height:54px}.hxp-search-filter-input-clear{display:flex;text-align:center}.hxp-search-filter-input-search{min-width:48px;position:relative;display:flex;justify-content:center;align-items:center}.hxp-search-filter-input-search button{display:flex;justify-content:center;align-items:center}\n"] }]
        }], ctorParameters: () => [], propDecorators: { applyOnEnter: [{
                type: Input
            }], inputAriaLabel: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], clearAriaLabel: [{
                type: Input
            }], prefixIcon: [{
                type: Input
            }], prefixAriaLabel: [{
                type: Input
            }], search: [{
                type: Output
            }], clear: [{
                type: Output
            }], prefixClick: [{
                type: Output
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchNoResultsComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchNoResultsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: SearchNoResultsComponent, isStandalone: true, selector: "hxp-search-no-results", ngImport: i0, template: "<div class=\"hxp-search-no-results adf-full-width adf-datatable-list adf-datatable--empty\">\n    <adf-custom-empty-content-template>\n        <adf-empty-content\n            icon=\"null\"\n            title=\"SEARCH.NO_RESULTS.TITLE\"\n            subtitle=\"SEARCH.NO_RESULTS.SUBTITLE\"\n            class=\"hxp-search-empty-content\"\n        />\n    </adf-custom-empty-content-template>\n</div>\n", styles: [".hxp-search-no-results{display:flex;flex-direction:column;flex:1;height:100%;justify-content:center}\n"], dependencies: [{ kind: "component", type: EmptyContentComponent, selector: "adf-empty-content", inputs: ["icon", "title", "subtitle"] }, { kind: "directive", type: CustomEmptyContentTemplateDirective, selector: "adf-custom-empty-content-template, empty-folder-content" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchNoResultsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-no-results', imports: [EmptyContentComponent, CustomEmptyContentTemplateDirective], template: "<div class=\"hxp-search-no-results adf-full-width adf-datatable-list adf-datatable--empty\">\n    <adf-custom-empty-content-template>\n        <adf-empty-content\n            icon=\"null\"\n            title=\"SEARCH.NO_RESULTS.TITLE\"\n            subtitle=\"SEARCH.NO_RESULTS.SUBTITLE\"\n            class=\"hxp-search-empty-content\"\n        />\n    </adf-custom-empty-content-template>\n</div>\n", styles: [".hxp-search-no-results{display:flex;flex-direction:column;flex:1;height:100%;justify-content:center}\n"] }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CreatedDateSearchFilterService {
    toHXQL(data) {
        const valuesArray = data?.values;
        if (!valuesArray || valuesArray?.length === 0) {
            return '';
        }
        const createdDateValue = valuesArray[0];
        switch (createdDateValue.date) {
            case 'LAST_7_DAYS': {
                return this.formatLastPeriodToHXQL({ days: 7 });
            }
            case 'LAST_30_DAYS': {
                return this.formatLastPeriodToHXQL({ days: 30 });
            }
            case 'LAST_6_MONTHS': {
                return this.formatLastPeriodToHXQL({ months: 6 });
            }
            case 'LAST_YEAR': {
                return this.formatLastPeriodToHXQL({ years: 1 });
            }
            default: {
                const { afterDate, beforeDate } = createdDateValue;
                if (afterDate && beforeDate) {
                    const afterDateValue = this.formatCreatedDateToHXQL('after', startOfDay(afterDate));
                    const beforeDateValue = this.formatCreatedDateToHXQL('before', startOfDay(beforeDate));
                    return `${afterDateValue} AND ${beforeDateValue}`;
                }
                else if (afterDate && !beforeDate) {
                    return this.formatCreatedDateToHXQL('after', startOfDay(afterDate));
                }
                else if (!afterDate && beforeDate) {
                    return this.formatCreatedDateToHXQL('before', startOfDay(beforeDate));
                }
            }
        }
        return '';
    }
    formatCreatedDateToHXQL(type, date) {
        const formattedDate = formatISO(date, { representation: 'complete' });
        return type === 'before' ? `sys_created <= DATE '${formattedDate}'` : `sys_created >= DATE '${formattedDate}'`;
    }
    formatLastPeriodToHXQL(options) {
        const today = startOfToday();
        return this.formatCreatedDateToHXQL('after', sub(today, options));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CreatedDateSearchFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CreatedDateSearchFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CreatedDateSearchFilterService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CreatedDateSearchFilterValue {
    constructor() {
        this.label = '';
    }
}
class CreatedDateSearchFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        // only single selection is supported for this data type
        const val = this.values[0];
        const dataVal = data.values[0];
        return (val.date === dataVal.date &&
            val.beforeDate?.toISOString() === dataVal.beforeDate?.toISOString() &&
            val.afterDate?.toISOString() === dataVal.afterDate?.toISOString());
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class BaseSearchFilterDirective {
    constructor() {
        this.filterCleared = new EventEmitter();
        this.filterApplied = new EventEmitter();
        this.searchFilterValueService = inject(SearchFilterValueService);
        this.destroyRef = inject(DestroyRef);
        this.translateService = inject(TranslateService);
        this.filterForm = new FormGroup(this.getFormControls());
        this.initialFormValue = { ...this.filterForm.value };
        this.oldFormValue = { ...this.filterForm.value };
    }
    clearFilter() {
        this.clearChanges();
        this.filterCleared.emit();
        this.searchFilterValueService.filterReset$.next(this);
        this.clearForm();
    }
    applyFilter() {
        this.applyChanges();
        this.filterApplied.emit(this.value);
        this.searchFilterValueService.filterApplied$.next({
            filter: this,
            value: this.value,
        });
    }
    applyChanges() {
        this.value = this.selectedValue;
        this.oldFormValue = { ...this.filterForm.value };
    }
    clearChanges() {
        this.selectedValue = undefined;
        this.value = undefined;
        this.clearForm();
    }
    /**
     * A change is pending if the currently selected value is different from the value already applied.
     */
    hasPendingChanges() {
        return this.oldFormValue !== this.filterForm.value || this.value !== this.selectedValue;
    }
    /**
     * Discards pending changes by resetting the selected value to the applied value.
     */
    discardPendingChanges() {
        this.selectedValue = this.value;
        this.filterForm.setValue({ ...this.oldFormValue });
    }
    /**
     * Populates whatever properties the filter needs with the provided data and updates the filter container.
     */
    populateWith(data) {
        this.setData(data);
        if (this.searchFilterContainer) {
            this.searchFilterContainer.selectedValue = this.selectedValue;
            this.searchFilterContainer.applyChanges();
        }
        this.applyFilter();
    }
    clearForm() {
        this.filterForm.reset({ ...this.initialFormValue });
        this.oldFormValue = { ...this.initialFormValue };
    }
    /**
     * Called when the overlay is closed.
     * Discards any pending changes, because neither clear and filter actions were applied.
     */
    overlayClosed() {
        this.discardPendingChanges();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: BaseSearchFilterDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.20", type: BaseSearchFilterDirective, isStandalone: true, inputs: { selectedValue: "selectedValue" }, outputs: { filterCleared: "filterCleared", filterApplied: "filterApplied" }, viewQueries: [{ propertyName: "searchFilterContainer", first: true, predicate: ["searchFilter"], descendants: true }], ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: BaseSearchFilterDirective, decorators: [{
            type: Directive
        }], ctorParameters: () => [], propDecorators: { selectedValue: [{
                type: Input
            }], filterCleared: [{
                type: Output
            }], filterApplied: [{
                type: Output
            }], searchFilterContainer: [{
                type: ViewChild,
                args: ['searchFilter']
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFilterContainerComponent {
    constructor() {
        this.name = '';
        this.filterForm = new FormGroup({});
        /**
         * Event emitted when the filter overlay is closed without any explicit action (e.g. clear or apply filter)
         */
        this.overlayClosed = new EventEmitter();
        this.filterCleared = new EventEmitter();
        this.filterApplied = new EventEmitter();
        this.selectionLabel = '';
        this.hiddenValuesCount = 0;
        this.isFilterOverlayOpened = false;
        this.overlayPosition = [
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'top',
            },
        ];
        this.destroyRef = inject(DestroyRef);
        this.overlay = inject(Overlay);
        this.viewContainerRef = inject(ViewContainerRef);
    }
    ngAfterViewInit() {
        this.templatePortal = new TemplatePortal(this.template, this.viewContainerRef);
    }
    ngOnChanges(changes) {
        const { selectedValue } = changes;
        if (!selectedValue) {
            return;
        }
        const currentValue = selectedValue.currentValue;
        if (this.data === currentValue || (this.data === undefined && currentValue === undefined) || this.data?.isEquivalentTo(currentValue)) {
            this.filterForm.markAsPristine();
        }
        else {
            this.filterForm.markAsDirty();
        }
    }
    applyChanges() {
        this.data = this.selectedValue;
        this.filterForm.markAsPristine();
        this.computeLabelVisibility();
    }
    clearChanges() {
        this.selectedValue = undefined;
        this.data = undefined;
        this.filterForm.markAsPristine();
        this.computeLabelVisibility();
    }
    clearFilter(event) {
        event.stopPropagation();
        event.preventDefault();
        this.clearChanges();
        this.filterCleared.emit();
        this.closeOverlay();
    }
    applyFilter(event) {
        event.stopPropagation();
        event.preventDefault();
        this.applyChanges();
        this.filterApplied.emit(this.data);
        this.closeOverlay();
    }
    computeLabelVisibility() {
        if ((this.selectedValue?.values || []).length > 0 && this.data?.values) {
            this.selectionLabel = this.data.values[0].label;
            this.hiddenValuesCount = this.data.values.length - 1;
        }
        else {
            this.selectionLabel = '';
            this.hiddenValuesCount = 0;
        }
    }
    hasPendingChanges() {
        return this.data !== this.selectedValue;
    }
    discardPendingChanges() {
        this.selectedValue = this.data;
    }
    openFilterOverlay() {
        const positionStrategy = this.chip
            ? this.overlay.position().flexibleConnectedTo(this.chip._elementRef.nativeElement).withPositions(this.overlayPosition)
            : undefined;
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            backdropClass: 'cdk-overlay-transparent-backdrop',
            positionStrategy,
        });
        this.overlayRef = this.overlay.create(overlayConfig);
        this.overlayRef.attach(this.templatePortal);
        this.isFilterOverlayOpened = true;
        this.overlayRef
            .backdropClick()
            .pipe(takeUntilDestroyed(this.destroyRef), finalize(() => this.closeOverlay()))
            .subscribe({
            next: () => {
                if (this.hasPendingChanges()) {
                    this.discardPendingChanges();
                }
                this.overlayClosed.emit();
                this.closeOverlay();
            },
        });
    }
    closeOverlay() {
        this.isFilterOverlayOpened = false;
        if (this.overlayRef && this.overlayRef.hasAttached()) {
            this.overlayRef.detach();
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterContainerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: SearchFilterContainerComponent, isStandalone: true, selector: "hxp-search-filter-container", inputs: { name: "name", filterForm: "filterForm", selectedValue: "selectedValue" }, outputs: { overlayClosed: "overlayClosed", filterCleared: "filterCleared", filterApplied: "filterApplied" }, viewQueries: [{ propertyName: "template", first: true, predicate: ["template"], descendants: true }, { propertyName: "chip", first: true, predicate: ["chip"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"hxp-search-filter\">\n    <mat-chip-set>\n        <mat-chip\n            #chip\n            (click)=\"openFilterOverlay()\"\n            class=\"hxp-search-filter-chip\"\n            [class.hxp-search-filter-chip_active]=\"data\"\n            [class.hxp-search-filter-chip_opened]=\"isFilterOverlayOpened\"\n            [matTooltip]=\"selectionLabel | translate\"\n        >\n            <div class=\"hxp-search-filter-chip-label-container\">\n                <div\n                    class=\"hxp-search-filter-chip-label\"\n                    #chipLabel\n                >\n                    <span>{{ name + (selectionLabel ? ': ' + (selectionLabel | translate) : '') }}</span>\n                </div>\n                <div\n                    *ngIf=\"hiddenValuesCount > 0\"\n                    aria-hidden=\"true\"\n                    class=\"hxp-search-filter-chip-badge\"\n                >\n                    +{{ hiddenValuesCount }}\n                </div>\n                <mat-icon\n                    class=\"hxp-search-filter-chip-icon\"\n                    [svgIcon]=\"isFilterOverlayOpened ? 'chevron_up' : 'chevron_down'\"\n                />\n            </div>\n        </mat-chip>\n    </mat-chip-set>\n    <ng-template #template>\n        <div class=\"hxp-search-filter-overlay\">\n            <form\n                [formGroup]=\"filterForm\"\n                (ngSubmit)=\"applyFilter($event)\"\n                (reset)=\"clearFilter($event)\"\n                (keydown.enter)=\"$event.preventDefault()\"\n            >\n                <ng-content />\n\n                <div class=\"hxp-search-filter-overlay-actions\">\n                    <button\n                        class=\"hxp-search-filter-overlay-actions-clear\"\n                        mat-button\n                        type=\"reset\"\n                        [disabled]=\"(!data || data.values?.length === 0) && filterForm.pristine\"\n                    >\n                        {{ 'SEARCH.FILTERS.ACTIONS.CLEAR_ALL' | translate }}\n                    </button>\n                    <button\n                        class=\"hxp-search-filter-overlay-actions-apply\"\n                        mat-flat-button\n                        type=\"submit\"\n                        [disabled]=\"filterForm.pristine || filterForm.invalid\"\n                    >\n                        {{ 'SEARCH.FILTERS.ACTIONS.APPLY' | translate }}\n                    </button>\n                </div>\n            </form>\n        </div>\n    </ng-template>\n</div>\n", styles: [".hxp-search-filter .hxp-search-filter-chip{max-width:320px}.hxp-search-filter .hxp-search-filter-chip-label-container{display:flex;align-items:center;color:var(--mat-sys-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:100%;max-width:290px}.hxp-search-filter .hxp-search-filter-chip-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:255px}.hxp-search-filter .hxp-search-filter-chip-badge{color:var(--mat-sys-surface);background-color:var(--mat-sys-primary);border-radius:100px;width:24px;height:24px;min-width:24px;display:inline-flex;align-items:center;justify-content:center;margin:0 5px}.hxp-search-filter .hxp-search-filter-chip_active{--mdc-chip-outline-width: 2px;--mdc-chip-outline-color: var(--mat-sys-primary);background:var(--mat-sys-primary-container)}.hxp-search-filter .hxp-search-filter-chip_opened{background:var(--mat-sys-primary-container)}.hxp-search-filter-overlay{box-shadow:0 3px 3px -2px #0003,0 3px 4px #00000024,0 1px 8px #0000001f;background-color:var(--mat-sys-surface);border-radius:8px;width:100%}.hxp-search-filter-overlay-actions{display:flex;flex-direction:row;justify-content:space-between;padding:16px 24px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i2$3.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "component", type: i2$3.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: OverlayModule }, { kind: "ngmodule", type: PortalModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i3$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i3$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterContainerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-filter-container', imports: [
                        CommonModule,
                        MatButtonModule,
                        MatChipsModule,
                        MatIconModule,
                        MatTooltipModule,
                        OverlayModule,
                        PortalModule,
                        ReactiveFormsModule,
                        TranslatePipe,
                    ], template: "<div class=\"hxp-search-filter\">\n    <mat-chip-set>\n        <mat-chip\n            #chip\n            (click)=\"openFilterOverlay()\"\n            class=\"hxp-search-filter-chip\"\n            [class.hxp-search-filter-chip_active]=\"data\"\n            [class.hxp-search-filter-chip_opened]=\"isFilterOverlayOpened\"\n            [matTooltip]=\"selectionLabel | translate\"\n        >\n            <div class=\"hxp-search-filter-chip-label-container\">\n                <div\n                    class=\"hxp-search-filter-chip-label\"\n                    #chipLabel\n                >\n                    <span>{{ name + (selectionLabel ? ': ' + (selectionLabel | translate) : '') }}</span>\n                </div>\n                <div\n                    *ngIf=\"hiddenValuesCount > 0\"\n                    aria-hidden=\"true\"\n                    class=\"hxp-search-filter-chip-badge\"\n                >\n                    +{{ hiddenValuesCount }}\n                </div>\n                <mat-icon\n                    class=\"hxp-search-filter-chip-icon\"\n                    [svgIcon]=\"isFilterOverlayOpened ? 'chevron_up' : 'chevron_down'\"\n                />\n            </div>\n        </mat-chip>\n    </mat-chip-set>\n    <ng-template #template>\n        <div class=\"hxp-search-filter-overlay\">\n            <form\n                [formGroup]=\"filterForm\"\n                (ngSubmit)=\"applyFilter($event)\"\n                (reset)=\"clearFilter($event)\"\n                (keydown.enter)=\"$event.preventDefault()\"\n            >\n                <ng-content />\n\n                <div class=\"hxp-search-filter-overlay-actions\">\n                    <button\n                        class=\"hxp-search-filter-overlay-actions-clear\"\n                        mat-button\n                        type=\"reset\"\n                        [disabled]=\"(!data || data.values?.length === 0) && filterForm.pristine\"\n                    >\n                        {{ 'SEARCH.FILTERS.ACTIONS.CLEAR_ALL' | translate }}\n                    </button>\n                    <button\n                        class=\"hxp-search-filter-overlay-actions-apply\"\n                        mat-flat-button\n                        type=\"submit\"\n                        [disabled]=\"filterForm.pristine || filterForm.invalid\"\n                    >\n                        {{ 'SEARCH.FILTERS.ACTIONS.APPLY' | translate }}\n                    </button>\n                </div>\n            </form>\n        </div>\n    </ng-template>\n</div>\n", styles: [".hxp-search-filter .hxp-search-filter-chip{max-width:320px}.hxp-search-filter .hxp-search-filter-chip-label-container{display:flex;align-items:center;color:var(--mat-sys-primary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;width:100%;max-width:290px}.hxp-search-filter .hxp-search-filter-chip-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:255px}.hxp-search-filter .hxp-search-filter-chip-badge{color:var(--mat-sys-surface);background-color:var(--mat-sys-primary);border-radius:100px;width:24px;height:24px;min-width:24px;display:inline-flex;align-items:center;justify-content:center;margin:0 5px}.hxp-search-filter .hxp-search-filter-chip_active{--mdc-chip-outline-width: 2px;--mdc-chip-outline-color: var(--mat-sys-primary);background:var(--mat-sys-primary-container)}.hxp-search-filter .hxp-search-filter-chip_opened{background:var(--mat-sys-primary-container)}.hxp-search-filter-overlay{box-shadow:0 3px 3px -2px #0003,0 3px 4px #00000024,0 1px 8px #0000001f;background-color:var(--mat-sys-surface);border-radius:8px;width:100%}.hxp-search-filter-overlay-actions{display:flex;flex-direction:row;justify-content:space-between;padding:16px 24px}\n"] }]
        }], propDecorators: { name: [{
                type: Input
            }], filterForm: [{
                type: Input
            }], selectedValue: [{
                type: Input
            }], overlayClosed: [{
                type: Output
            }], filterCleared: [{
                type: Output
            }], filterApplied: [{
                type: Output
            }], template: [{
                type: ViewChild,
                args: ['template']
            }], chip: [{
                type: ViewChild,
                args: ['chip']
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CreatedDateSearchFiltersComponent extends BaseSearchFilterDirective {
    constructor() {
        super();
        this.defaultCreatedDateOptions = [
            {
                label: 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.LAST_7_DAYS',
                date: 'LAST_7_DAYS',
            },
            {
                label: 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.LAST_30_DAYS',
                date: 'LAST_30_DAYS',
            },
            {
                label: 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.LAST_6_MONTHS',
                date: 'LAST_6_MONTHS',
            },
            {
                label: 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.LAST_YEAR',
                date: 'LAST_YEAR',
            },
        ];
        this.beforeDateInputSubject = new Subject();
        this.afterDateInputSubject = new Subject();
        this.datePipe = inject(DatePipe);
        this.createdDateSearchFilterService = inject(CreatedDateSearchFilterService);
        this.matIconRegistry = inject(MatIconRegistry);
        this.domSanitizer = inject(DomSanitizer);
        this.afterDateFilter = (d) => {
            const beforeDate = this.filterForm.value.beforeDate;
            return !beforeDate || !d || isBefore(d, beforeDate);
        };
        this.beforeDateFilter = (d) => {
            const afterDate = this.filterForm.value.afterDate;
            return !afterDate || !d || isAfter(d, afterDate);
        };
        const icons = {
            search_calendar: 'assets/search-icons/Calendar_search.svg',
        };
        for (const [iconName, iconPath] of Object.entries(icons)) {
            this.matIconRegistry.addSvgIcon(iconName, this.domSanitizer.bypassSecurityTrustResourceUrl(iconPath));
        }
    }
    get id() {
        return 'CreatedDateSearchFiltersComponent';
    }
    ngOnInit() {
        this.beforeDateInputSubject.pipe(debounceTime(500), takeUntilDestroyed(this.destroyRef)).subscribe(() => {
            this.filterForm.get('beforeDate')?.updateValueAndValidity({ onlySelf: true, emitEvent: false });
        });
        this.afterDateInputSubject.pipe(debounceTime(500), takeUntilDestroyed(this.destroyRef)).subscribe(() => {
            this.filterForm.get('afterDate')?.updateValueAndValidity({ onlySelf: true, emitEvent: false });
        });
    }
    toHXQL(data) {
        return this.createdDateSearchFilterService.toHXQL(data);
    }
    setData(data) {
        try {
            for (const value of data?.values || []) {
                const beforeDate = value.beforeDate ? new Date(value.beforeDate) : null;
                const afterDate = value.afterDate ? new Date(value.afterDate) : null;
                if (afterDate || beforeDate) {
                    this.filterForm.patchValue({
                        isCustomDate: true,
                        afterDate,
                        beforeDate,
                    });
                    this.updateCustomDateSelectedValue();
                }
                else if (value['date']) {
                    this.createdDateValueChanged(value);
                }
            }
        }
        catch (error) {
            console.error('Error while setting data for Created Date filter', error);
        }
    }
    getFormControls() {
        return {
            defaultOption: new FormControl(null),
            isCustomDate: new FormControl(false),
            afterDate: new FormControl(null, [this.dateFormatValidator('afterDateInput'), this.afterDateValidator()]),
            beforeDate: new FormControl(null, [this.dateFormatValidator('beforeDateInput'), this.beforeDateValidator()]),
        };
    }
    dateFormatValidator(dateInputTypeLocator) {
        return () => {
            const value = this[dateInputTypeLocator]?.nativeElement.value || '';
            const parsedDate = parse(value, 'MM/dd/yyyy', new Date());
            if (value && !isValid(parsedDate)) {
                return { invalidDateFormat: true };
            }
            return null;
        };
    }
    afterDateValidator() {
        return (control) => {
            const afterDate = control.value;
            const beforeDate = this.filterForm?.get('beforeDate')?.value;
            if (isAfter(afterDate, beforeDate)) {
                return { afterDateTooLate: true };
            }
            return null;
        };
    }
    beforeDateValidator() {
        return (control) => {
            const beforeDate = control.value;
            const afterDate = this.filterForm?.get('afterDate')?.value;
            if (isBefore(beforeDate, afterDate)) {
                return { beforeDateTooEarly: true };
            }
            return null;
        };
    }
    enableCustomDate(e) {
        e.preventDefault();
        this.selectionList?.deselectAll();
        this.selectedValue = this.value;
        this.filterForm.patchValue({
            defaultOption: null,
            isCustomDate: true,
        });
    }
    createdDateValueChanged(data) {
        this.selectedValue = new CreatedDateSearchFilterData([data]);
        this.filterForm.patchValue({
            defaultOption: this.selectedValue,
            isCustomDate: false,
            afterDate: null,
            beforeDate: null,
        });
    }
    afterDateChanged(event) {
        this.filterForm.patchValue({
            afterDate: event.value,
        });
        this.updateCustomDateSelectedValue();
    }
    beforeDateChanged(event) {
        this.filterForm.patchValue({
            beforeDate: event.value,
        });
        this.updateCustomDateSelectedValue();
    }
    clearAfterDate(event) {
        event.stopPropagation();
        event.preventDefault();
        if (this.afterDateInput) {
            this.afterDateInput.nativeElement.value = '';
            this.filterForm.patchValue({
                afterDate: null,
            });
            this.updateCustomDateSelectedValue();
        }
    }
    clearBeforeDate(event) {
        event.stopPropagation();
        event.preventDefault();
        if (this.beforeDateInput) {
            this.beforeDateInput.nativeElement.value = '';
            this.filterForm.patchValue({
                beforeDate: null,
            });
            this.updateCustomDateSelectedValue();
        }
    }
    validateInput(event) {
        const pattern = /[0-9+\-/]/;
        const inputChar = String.fromCharCode(event.charCode);
        if (!pattern.test(inputChar)) {
            event.preventDefault();
        }
    }
    updateCustomDateSelectedValue() {
        let label = '';
        const { afterDate, beforeDate } = this.filterForm.value;
        if (afterDate && beforeDate) {
            label = this.translateService.instant('SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.SINCE_TO_DATE', {
                afterDate: this.datePipe.transform(afterDate, 'mediumDate'),
                beforeDate: this.datePipe.transform(beforeDate, 'mediumDate'),
            });
        }
        else if (afterDate && !beforeDate) {
            label = this.translateService.instant('SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.SINCE_TO_TODAY', {
                date: this.datePipe.transform(afterDate, 'mediumDate'),
            });
        }
        else if (!afterDate && beforeDate) {
            label = this.translateService.instant('SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.UNTIL_DATE', {
                date: this.datePipe.transform(beforeDate, 'mediumDate'),
            });
        }
        this.selectedValue = label
            ? new CreatedDateSearchFilterData([
                {
                    label,
                    afterDate,
                    beforeDate,
                },
            ])
            : this.value;
    }
    discardPendingChanges() {
        super.discardPendingChanges();
        this.selectionList?.deselectAll();
    }
    clearChanges() {
        super.clearChanges();
        this.selectionList?.deselectAll();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CreatedDateSearchFiltersComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: CreatedDateSearchFiltersComponent, isStandalone: true, selector: "hxp-search-created-date-filter", providers: [CreatedDateSearchFilterService], viewQueries: [{ propertyName: "afterDateInput", first: true, predicate: ["afterDateInput"], descendants: true }, { propertyName: "beforeDateInput", first: true, predicate: ["beforeDateInput"], descendants: true }, { propertyName: "selectionList", first: true, predicate: MatSelectionList, descendants: true }], usesInheritance: true, ngImport: i0, template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.CREATED_DATE.LABEL' | translate\"\n    [filterForm]=\"filterForm\"\n    [selectedValue]=\"selectedValue\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n>\n    <div class=\"hxp-created-date-filter-container\">\n        <mat-selection-list\n            id=\"hxp-created-data-filter-default-options-list\"\n            multiple=\"false\"\n            hideSingleSelectionIndicator\n            [attr.aria-label]=\"'SEARCH.FILTERS.CREATED_DATE.ARIA-LABEL.DEFAULT_OPTIONS_LIST' | translate\"\n        >\n            <mat-list-option\n                *ngFor=\"let option of defaultCreatedDateOptions\"\n                id=\"{{ option.date }}\"\n                [class.hxp-created-date-filter-option_active]=\"filterForm.value.defaultOption?.values?.[0]?.date === option.date\"\n                class=\"hxp-created-date-filter-option\"\n                (click)=\"createdDateValueChanged(option)\"\n                [value]=\"option.label\"\n                [attr.aria-label]=\"option.label | translate\"\n            >\n                <div class=\"hxp-created-date-filter-option-container\">\n                    <span class=\"hxp-created-date-filter-option-label\">{{ option.label | translate }}</span>\n                    @if (filterForm.value.defaultOption?.values?.[0]?.date === option.date) {\n                        <mat-icon svgIcon=\"check\" />\n                    }\n                </div>\n            </mat-list-option>\n        </mat-selection-list>\n\n        <mat-divider class=\"hxp-created-date-divider\" />\n\n        <button\n            class=\"hxp-created-date-filter-custom-date-button\"\n            *ngIf=\"!filterForm.value.isCustomDate; else customDateRange\"\n            mat-menu-item\n            (click)=\"enableCustomDate($event)\"\n        >\n            <mat-icon\n                aria-hidden=\"true\"\n                svgIcon=\"plus_large\"\n            />\n            <span class=\"mat-body-1\">{{ 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.LABEL' | translate }}</span>\n        </button>\n\n        <ng-template #customDateRange>\n            <div class=\"hxp-custom-created-date\">\n                <mat-form-field [class.hxp-custom-created-date_active]=\"afterPicker.opened\">\n                    <mat-label\n                        id=\"hxp-after-created-date-picker-label\"\n                        for=\"hxp-after-created-date-picker-input\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.AFTER' | translate }}\n                    </mat-label>\n                    <input\n                        #afterDateInput\n                        id=\"hxp-after-created-date-picker-input\"\n                        aria-labelledby=\"hxp-after-created-date-picker-label\"\n                        placeholder=\"MM/DD/YYYY\"\n                        matInput\n                        [(ngModel)]=\"filterForm.value.afterDate\"\n                        (click)=\"afterPicker.open()\"\n                        [matDatepicker]=\"afterPicker\"\n                        [matDatepickerFilter]=\"afterDateFilter\"\n                        (dateChange)=\"afterDateChanged($event)\"\n                        (keypress)=\"validateInput($event)\"\n                        (input)=\"afterDateInputSubject.next()\"\n                    />\n                    <mat-error\n                        *ngIf=\"filterForm.get('afterDate')?.errors?.['afterDateTooLate']\"\n                        class=\"hxp-custom-created-date-error mat-caption\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.ERRORS.AFTER_DATE_TOO_LATE' | translate }}\n                    </mat-error>\n                    <mat-error\n                        *ngIf=\"filterForm.get('afterDate')?.errors?.['invalidDateFormat']\"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.ERRORS.INVALID_DATE_FORMAT' | translate }}\n                    </mat-error>\n\n                    <div\n                        class=\"hxp-created-date-picker-suffix\"\n                        matSuffix\n                    >\n                        <button\n                            *ngIf=\"afterDateInput.value\"\n                            mat-icon-button\n                            [attr.aria-label]=\"'SEARCH.FILTERS.CREATED_DATE.BUTTON.CLEAR.ARIA_LABEL.AFTER' | translate\"\n                            (click)=\"clearAfterDate($event)\"\n                        >\n                            <mat-icon svgIcon=\"x_large\" />\n                        </button>\n\n                        <mat-datepicker-toggle\n                            [for]=\"afterPicker\"\n                            data-automation-id=\"hxp-after-created-date-toggle\"\n                        >\n                            <mat-icon\n                                class=\"hxp-custom-data-calendar-icon\"\n                                matDatepickerToggleIcon\n                                svgIcon=\"calendar\"\n                            />\n                        </mat-datepicker-toggle>\n                    </div>\n                    <mat-datepicker #afterPicker />\n                </mat-form-field>\n            </div>\n\n            <div class=\"hxp-custom-created-date\">\n                <mat-form-field [class.hxp-custom-created-date_active]=\"beforePicker.opened\">\n                    <mat-label\n                        id=\"hxp-before-created-date-picker-label\"\n                        for=\"hxp-before-created-date-picker-input\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.BEFORE' | translate }}\n                    </mat-label>\n                    <input\n                        #beforeDateInput\n                        id=\"hxp-before-created-date-picker-input\"\n                        aria-labelledby=\"hxp-before-created-date-picker-label\"\n                        placeholder=\"MM/DD/YYYY\"\n                        matInput\n                        [(ngModel)]=\"filterForm.value.beforeDate\"\n                        (click)=\"beforePicker.open()\"\n                        [matDatepicker]=\"beforePicker\"\n                        [matDatepickerFilter]=\"beforeDateFilter\"\n                        (dateChange)=\"beforeDateChanged($event)\"\n                        (keypress)=\"validateInput($event)\"\n                        (input)=\"beforeDateInputSubject.next()\"\n                    />\n                    <mat-error\n                        *ngIf=\"filterForm.get('beforeDate')?.errors?.['beforeDateTooEarly']\"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.ERRORS.BEFORE_DATE_TOO_EARLY' | translate }}\n                    </mat-error>\n                    <mat-error\n                        *ngIf=\"filterForm.get('beforeDate')?.errors?.['invalidDateFormat']\"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.ERRORS.INVALID_DATE_FORMAT' | translate }}\n                    </mat-error>\n\n                    <div\n                        class=\"hxp-created-date-picker-suffix\"\n                        matSuffix\n                    >\n                        <button\n                            *ngIf=\"beforeDateInput.value\"\n                            mat-icon-button\n                            [attr.aria-label]=\"'SEARCH.FILTERS.CREATED_DATE.BUTTON.CLEAR.ARIA_LABEL.BEFORE' | translate\"\n                            (click)=\"clearBeforeDate($event)\"\n                        >\n                            <mat-icon svgIcon=\"x_large\" />\n                        </button>\n\n                        <mat-datepicker-toggle\n                            [for]=\"beforePicker\"\n                            data-automation-id=\"hxp-before-created-date-toggle\"\n                        >\n                            <mat-icon\n                                class=\"hxp-custom-data-calendar-icon\"\n                                matDatepickerToggleIcon\n                                svgIcon=\"calendar\"\n                            />\n                        </mat-datepicker-toggle>\n                        <mat-datepicker #beforePicker />\n                    </div>\n                </mat-form-field>\n            </div>\n        </ng-template>\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-created-date-filter-container{width:300px;display:flex;flex-direction:column}.hxp-created-date-filter-container .hxp-created-date-filter-option_active{background-color:var(--mat-sys-secondary-container)}.hxp-created-date-filter-container .hxp-created-date-filter-option-container{display:flex;align-items:center}.hxp-created-date-filter-container .hxp-created-date-filter-option-label{flex:1}.hxp-created-date-filter-container .hxp-created-date-divider{margin:10px}.hxp-created-date-filter-container .hxp-created-date-filter-custom-date-button{font:inherit}.hxp-created-date-filter-container .hxp-custom-created-date{display:flex;flex-direction:column;margin:0 15px 15px}.hxp-created-date-filter-container .hxp-custom-created-date-error{margin:0 -15px}.hxp-created-date-filter-container .hxp-custom-created-date .hxp-created-date-picker-suffix{display:flex}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$4.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3$2.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i4$2.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: MatDatepickerModule }, { kind: "component", type: i5$1.MatDatepicker, selector: "mat-datepicker", exportAs: ["matDatepicker"] }, { kind: "directive", type: i5$1.MatDatepickerInput, selector: "input[matDatepicker]", inputs: ["matDatepicker", "min", "max", "matDatepickerFilter"], exportAs: ["matDatepickerInput"] }, { kind: "component", type: i5$1.MatDatepickerToggle, selector: "mat-datepicker-toggle", inputs: ["for", "tabIndex", "aria-label", "disabled", "disableRipple"], exportAs: ["matDatepickerToggle"] }, { kind: "directive", type: i5$1.MatDatepickerToggleIcon, selector: "[matDatepickerToggleIcon]" }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$1.MatLabel, selector: "mat-label" }, { kind: "directive", type: i4$1.MatError, selector: "mat-error, [matError]", inputs: ["id"] }, { kind: "directive", type: i4$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "ngmodule", type: MatListModule }, { kind: "component", type: i9.MatSelectionList, selector: "mat-selection-list", inputs: ["color", "compareWith", "multiple", "hideSingleSelectionIndicator", "disabled"], outputs: ["selectionChange"], exportAs: ["matSelectionList"] }, { kind: "component", type: i9.MatListOption, selector: "mat-list-option", inputs: ["togglePosition", "checkboxPosition", "color", "value", "selected"], outputs: ["selectedChange"], exportAs: ["matListOption"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i4.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: SearchFilterContainerComponent, selector: "hxp-search-filter-container", inputs: ["name", "filterForm", "selectedValue"], outputs: ["overlayClosed", "filterCleared", "filterApplied"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CreatedDateSearchFiltersComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-created-date-filter', imports: [
                        CommonModule,
                        FormsModule,
                        MatButtonModule,
                        MatDividerModule,
                        MatDatepickerModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatListModule,
                        MatMenuModule,
                        ReactiveFormsModule,
                        SearchFilterContainerComponent,
                        TranslatePipe,
                    ], providers: [CreatedDateSearchFilterService], template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.CREATED_DATE.LABEL' | translate\"\n    [filterForm]=\"filterForm\"\n    [selectedValue]=\"selectedValue\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n>\n    <div class=\"hxp-created-date-filter-container\">\n        <mat-selection-list\n            id=\"hxp-created-data-filter-default-options-list\"\n            multiple=\"false\"\n            hideSingleSelectionIndicator\n            [attr.aria-label]=\"'SEARCH.FILTERS.CREATED_DATE.ARIA-LABEL.DEFAULT_OPTIONS_LIST' | translate\"\n        >\n            <mat-list-option\n                *ngFor=\"let option of defaultCreatedDateOptions\"\n                id=\"{{ option.date }}\"\n                [class.hxp-created-date-filter-option_active]=\"filterForm.value.defaultOption?.values?.[0]?.date === option.date\"\n                class=\"hxp-created-date-filter-option\"\n                (click)=\"createdDateValueChanged(option)\"\n                [value]=\"option.label\"\n                [attr.aria-label]=\"option.label | translate\"\n            >\n                <div class=\"hxp-created-date-filter-option-container\">\n                    <span class=\"hxp-created-date-filter-option-label\">{{ option.label | translate }}</span>\n                    @if (filterForm.value.defaultOption?.values?.[0]?.date === option.date) {\n                        <mat-icon svgIcon=\"check\" />\n                    }\n                </div>\n            </mat-list-option>\n        </mat-selection-list>\n\n        <mat-divider class=\"hxp-created-date-divider\" />\n\n        <button\n            class=\"hxp-created-date-filter-custom-date-button\"\n            *ngIf=\"!filterForm.value.isCustomDate; else customDateRange\"\n            mat-menu-item\n            (click)=\"enableCustomDate($event)\"\n        >\n            <mat-icon\n                aria-hidden=\"true\"\n                svgIcon=\"plus_large\"\n            />\n            <span class=\"mat-body-1\">{{ 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.LABEL' | translate }}</span>\n        </button>\n\n        <ng-template #customDateRange>\n            <div class=\"hxp-custom-created-date\">\n                <mat-form-field [class.hxp-custom-created-date_active]=\"afterPicker.opened\">\n                    <mat-label\n                        id=\"hxp-after-created-date-picker-label\"\n                        for=\"hxp-after-created-date-picker-input\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.AFTER' | translate }}\n                    </mat-label>\n                    <input\n                        #afterDateInput\n                        id=\"hxp-after-created-date-picker-input\"\n                        aria-labelledby=\"hxp-after-created-date-picker-label\"\n                        placeholder=\"MM/DD/YYYY\"\n                        matInput\n                        [(ngModel)]=\"filterForm.value.afterDate\"\n                        (click)=\"afterPicker.open()\"\n                        [matDatepicker]=\"afterPicker\"\n                        [matDatepickerFilter]=\"afterDateFilter\"\n                        (dateChange)=\"afterDateChanged($event)\"\n                        (keypress)=\"validateInput($event)\"\n                        (input)=\"afterDateInputSubject.next()\"\n                    />\n                    <mat-error\n                        *ngIf=\"filterForm.get('afterDate')?.errors?.['afterDateTooLate']\"\n                        class=\"hxp-custom-created-date-error mat-caption\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.ERRORS.AFTER_DATE_TOO_LATE' | translate }}\n                    </mat-error>\n                    <mat-error\n                        *ngIf=\"filterForm.get('afterDate')?.errors?.['invalidDateFormat']\"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.ERRORS.INVALID_DATE_FORMAT' | translate }}\n                    </mat-error>\n\n                    <div\n                        class=\"hxp-created-date-picker-suffix\"\n                        matSuffix\n                    >\n                        <button\n                            *ngIf=\"afterDateInput.value\"\n                            mat-icon-button\n                            [attr.aria-label]=\"'SEARCH.FILTERS.CREATED_DATE.BUTTON.CLEAR.ARIA_LABEL.AFTER' | translate\"\n                            (click)=\"clearAfterDate($event)\"\n                        >\n                            <mat-icon svgIcon=\"x_large\" />\n                        </button>\n\n                        <mat-datepicker-toggle\n                            [for]=\"afterPicker\"\n                            data-automation-id=\"hxp-after-created-date-toggle\"\n                        >\n                            <mat-icon\n                                class=\"hxp-custom-data-calendar-icon\"\n                                matDatepickerToggleIcon\n                                svgIcon=\"calendar\"\n                            />\n                        </mat-datepicker-toggle>\n                    </div>\n                    <mat-datepicker #afterPicker />\n                </mat-form-field>\n            </div>\n\n            <div class=\"hxp-custom-created-date\">\n                <mat-form-field [class.hxp-custom-created-date_active]=\"beforePicker.opened\">\n                    <mat-label\n                        id=\"hxp-before-created-date-picker-label\"\n                        for=\"hxp-before-created-date-picker-input\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.OPTIONS.CUSTOM_DATE.VALUES.BEFORE' | translate }}\n                    </mat-label>\n                    <input\n                        #beforeDateInput\n                        id=\"hxp-before-created-date-picker-input\"\n                        aria-labelledby=\"hxp-before-created-date-picker-label\"\n                        placeholder=\"MM/DD/YYYY\"\n                        matInput\n                        [(ngModel)]=\"filterForm.value.beforeDate\"\n                        (click)=\"beforePicker.open()\"\n                        [matDatepicker]=\"beforePicker\"\n                        [matDatepickerFilter]=\"beforeDateFilter\"\n                        (dateChange)=\"beforeDateChanged($event)\"\n                        (keypress)=\"validateInput($event)\"\n                        (input)=\"beforeDateInputSubject.next()\"\n                    />\n                    <mat-error\n                        *ngIf=\"filterForm.get('beforeDate')?.errors?.['beforeDateTooEarly']\"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.ERRORS.BEFORE_DATE_TOO_EARLY' | translate }}\n                    </mat-error>\n                    <mat-error\n                        *ngIf=\"filterForm.get('beforeDate')?.errors?.['invalidDateFormat']\"\n                        class=\"hxp-custom-created-date-error\"\n                    >\n                        {{ 'SEARCH.FILTERS.CREATED_DATE.ERRORS.INVALID_DATE_FORMAT' | translate }}\n                    </mat-error>\n\n                    <div\n                        class=\"hxp-created-date-picker-suffix\"\n                        matSuffix\n                    >\n                        <button\n                            *ngIf=\"beforeDateInput.value\"\n                            mat-icon-button\n                            [attr.aria-label]=\"'SEARCH.FILTERS.CREATED_DATE.BUTTON.CLEAR.ARIA_LABEL.BEFORE' | translate\"\n                            (click)=\"clearBeforeDate($event)\"\n                        >\n                            <mat-icon svgIcon=\"x_large\" />\n                        </button>\n\n                        <mat-datepicker-toggle\n                            [for]=\"beforePicker\"\n                            data-automation-id=\"hxp-before-created-date-toggle\"\n                        >\n                            <mat-icon\n                                class=\"hxp-custom-data-calendar-icon\"\n                                matDatepickerToggleIcon\n                                svgIcon=\"calendar\"\n                            />\n                        </mat-datepicker-toggle>\n                        <mat-datepicker #beforePicker />\n                    </div>\n                </mat-form-field>\n            </div>\n        </ng-template>\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-created-date-filter-container{width:300px;display:flex;flex-direction:column}.hxp-created-date-filter-container .hxp-created-date-filter-option_active{background-color:var(--mat-sys-secondary-container)}.hxp-created-date-filter-container .hxp-created-date-filter-option-container{display:flex;align-items:center}.hxp-created-date-filter-container .hxp-created-date-filter-option-label{flex:1}.hxp-created-date-filter-container .hxp-created-date-divider{margin:10px}.hxp-created-date-filter-container .hxp-created-date-filter-custom-date-button{font:inherit}.hxp-created-date-filter-container .hxp-custom-created-date{display:flex;flex-direction:column;margin:0 15px 15px}.hxp-created-date-filter-container .hxp-custom-created-date-error{margin:0 -15px}.hxp-created-date-filter-container .hxp-custom-created-date .hxp-created-date-picker-suffix{display:flex}\n"] }]
        }], ctorParameters: () => [], propDecorators: { afterDateInput: [{
                type: ViewChild,
                args: ['afterDateInput']
            }], beforeDateInput: [{
                type: ViewChild,
                args: ['beforeDateInput']
            }], selectionList: [{
                type: ViewChild,
                args: [MatSelectionList]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentCategorySearchFilterService {
    toHXQL(data) {
        return data?.values?.length > 0 ? `sys_primaryType IN (${data.values.map((i) => `'${i.value}'`).join(',')})` : '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentCategorySearchFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentCategorySearchFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentCategorySearchFilterService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentCategorySearchFilterValue {
    constructor() {
        this.label = '';
        this.value = '';
    }
}
const compareFn$2 = (a, b) => a.value.localeCompare(b.value);
class DocumentCategorySearchFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        const sortedValues = this.values.sort(compareFn$2);
        const sortedDataValues = data.values.sort(compareFn$2);
        for (const [i, sortedValue] of sortedValues.entries()) {
            if (sortedValue.value !== sortedDataValues[i].value) {
                return false;
            }
        }
        return true;
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentCategorySearchFiltersComponent extends BaseSearchFilterDirective {
    constructor() {
        super();
        this.allowedSysCategories = ['SysFolder', 'SysFile'];
        this.isLoading = false;
        this.categories = [];
        this.filteredCategories = [];
        this.searchTerm = '';
        this.selection = new SelectionModel(true, []);
        this.documentModelService = inject(DocumentModelService);
        this.documentCategorySearchFilterService = inject(DocumentCategorySearchFilterService);
        this.changeDetector = inject(ChangeDetectorRef);
        this.matIconRegistry = inject(MatIconRegistry);
        this.domSanitizer = inject(DomSanitizer);
        const icons = {
            search_clear: 'assets/search-icons/Clear.svg',
        };
        for (const [iconName, iconPath] of Object.entries(icons)) {
            this.matIconRegistry.addSvgIcon(iconName, this.domSanitizer.bypassSecurityTrustResourceUrl(iconPath));
        }
    }
    get id() {
        return 'DocumentCategorySearchFiltersComponent';
    }
    ngOnInit() {
        this.isLoading = true;
        this.documentModelService
            .getModel()
            .pipe(takeUntilDestroyed(this.destroyRef), finalize(() => (this.isLoading = false)))
            .subscribe({
            next: (model) => {
                this.categories = model
                    .getSubtypes('')
                    .filter((category) => (category.startsWith('Sys') ? this.allowedSysCategories.includes(category) : category));
                this.filteredCategories = this.categories;
            },
        });
    }
    toHXQL(data) {
        return this.documentCategorySearchFilterService.toHXQL(data);
    }
    clearFilter() {
        super.clearFilter();
        this.searchFilterComponent?.clearInput();
        this.selection.clear();
    }
    applyFilter() {
        if (this.selection.selected.length === 0) {
            return this.clearFilter();
        }
        super.applyFilter();
    }
    overlayClosed() {
        this.selection.clear();
        if (this.oldFormValue.selectedCategories.length > 0) {
            for (const category of this.oldFormValue.selectedCategories) {
                this.selection.select(category);
            }
        }
        this.discardPendingChanges();
    }
    getFormControls() {
        return {
            selectedCategories: new FormControl([]),
        };
    }
    setData(data) {
        try {
            if (data?.values) {
                for (const category of data?.values || []) {
                    this.selection.select(category.value);
                }
            }
            this.setSelectedValue();
        }
        catch (error) {
            console.error('Error while setting data for Content Type filter', error);
        }
    }
    filteredSearch(searchTerm) {
        this.searchTerm = searchTerm;
        this.filteredCategories = this.categories.filter((entry) => entry.toLowerCase().includes(searchTerm));
    }
    onSelectionListChange(event) {
        this.onSelectionChange(event?.options[0]?.value);
    }
    onDeselect(category) {
        this.onSelectionChange(category);
    }
    onSelectionChange(category) {
        this.selection.toggle(category);
        this.setSelectedValue();
    }
    setSelectedValue() {
        this.filterForm.patchValue({
            selectedCategories: this.selection.selected,
        });
        if (this.selection.selected.length === 0) {
            this.selectedValue = undefined;
            return;
        }
        const selectedValues = this.selection.selected.length === 0
            ? undefined
            : this.selection.selected.map((sel) => ({
                label: sel,
                value: sel,
            }));
        this.selectedValue = new DocumentCategorySearchFilterData(selectedValues);
    }
    isChecked(category) {
        return this.selection.isSelected(category);
    }
    clearInput() {
        this.searchTerm = '';
        this.filteredCategories = this.categories;
        this.changeDetector.detectChanges();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentCategorySearchFiltersComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: DocumentCategorySearchFiltersComponent, isStandalone: true, selector: "hxp-search-document-category-filter", providers: [DocumentCategorySearchFilterService], viewQueries: [{ propertyName: "searchFilterComponent", first: true, predicate: SearchFilterInputComponent, descendants: true }], usesInheritance: true, ngImport: i0, template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.LABEL' | translate\"\n    [selectedValue]=\"selectedValue\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n    [filterForm]=\"filterForm\"\n>\n    <div class=\"hxp-document-category-filter-container\">\n        <hxp-search-filter-input\n            [inputAriaLabel]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.LABEL' | translate\"\n            [placeholder]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.PLACEHOLDER' | translate\"\n            [clearAriaLabel]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.CLEAR_INPUT' | translate\"\n            (search)=\"filteredSearch($event)\"\n            (clear)=\"clearInput()\"\n        />\n\n        <div class=\"hxp-document-category-filter-summary\">\n            <mat-chip-set\n                class=\"hxp-document-category-filter-summary-list\"\n                tabindex=\"0\"\n            >\n                <span class=\"hxp-document-category-filter-summary-list-prefix\">\n                    {{ 'SEARCH.FILTERS.DOCUMENT_CATEGORY.SELECTED' | translate: { selected: selection.selected.length }\n                    }}<span\n                        *ngIf=\"selection.selected.length > 0\"\n                        class=\"hxp-document-category-filter-summary-list-colon\"\n                        >:</span\n                    >\n                </span>\n                <mat-chip\n                    *ngFor=\"let selectedCategory of selection.selected\"\n                    class=\"hxp-document-category-filter-summary-list-item\"\n                    [attr.aria-label]=\"selectedCategory\"\n                >\n                    <span class=\"hxp-document-category-filter-summary-list-item__label\">{{ selectedCategory }}</span>\n                    <button\n                        matChipRemove\n                        [attr.aria-label]=\"('SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.REMOVE' | translate) + ' ' + selectedCategory\"\n                        (click)=\"onDeselect(selectedCategory)\"\n                    >\n                        <mat-icon\n                            class=\"hxp-document-category-filter-summary-list-remove-item-icon\"\n                            svgIcon=\"x_large\"\n                        />\n                    </button>\n                </mat-chip>\n            </mat-chip-set>\n        </div>\n\n        <div\n            *ngIf=\"isLoading\"\n            class=\"hxp-document-category-filter-spinner-container\"\n        >\n            <mat-progress-spinner mode=\"indeterminate\" />\n        </div>\n\n        <ng-container *ngIf=\"!isLoading\">\n            <mat-selection-list\n                #documentCategories\n                class=\"hxp-document-category-filter-list\"\n                (selectionChange)=\"onSelectionListChange($event)\"\n                *ngIf=\"filteredCategories.length; else noResults\"\n                [attr.aria-label]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.DOCUMENT_CATEGORIES_LIST' | translate\"\n            >\n                <mat-list-option\n                    *ngFor=\"let category of filteredCategories\"\n                    [value]=\"category\"\n                    class=\"hxp-document-category-filter-list-option\"\n                    checkboxPosition=\"before\"\n                    [selected]=\"isChecked(category)\"\n                    [attr.aria-label]=\"category\"\n                >\n                    <span>{{ category }}</span>\n                </mat-list-option>\n            </mat-selection-list>\n\n            <ng-template #noResults>\n                <div class=\"hxp-document-category-filter-no-results\">\n                    <h2>\n                        {{ 'SEARCH.FILTERS.DOCUMENT_CATEGORY.NO_SEARCH_RESULTS.TITLE' | translate }}\n                    </h2>\n                    <p>\n                        {{ 'SEARCH.FILTERS.DOCUMENT_CATEGORY.NO_SEARCH_RESULTS.MESSAGE' | translate }}\n                    </p>\n                </div>\n            </ng-template>\n        </ng-container>\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-document-category-filter-container{width:300px;height:468px;display:flex;flex-direction:column;padding:24px}.hxp-document-category-filter-list{max-height:360px;overflow-y:scroll}.hxp-document-category-filter-summary{padding:22px 0 8px}.hxp-document-category-filter-summary-list{width:100%;max-height:110px;overflow-y:auto}.hxp-document-category-filter-summary-list-prefix{margin-left:8px;display:flex;align-items:center}.hxp-document-category-filter-summary-list-colon{display:flex;align-items:center}.hxp-document-category-filter-summary-list-item{min-height:auto;height:18px;background-color:var(--mat-sys-primary-container);padding-top:3px;padding-bottom:3px}.hxp-document-category-filter-summary-list-item button{margin:0}.hxp-document-category-filter-summary-list-item__label{color:var(--mat-sys-primary)}.hxp-document-category-filter-summary-list-remove-item-icon{--mdc-icon-size: 12px;color:var(--mat-sys-primary);opacity:1;display:flex}.hxp-document-category-filter-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center}.hxp-document-category-filter-no-results h2,.hxp-document-category-filter-no-results p{margin:0}.hxp-document-category-filter-spinner-container{display:flex;justify-content:center;align-items:center;height:100%;width:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$4.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i2$3.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "directive", type: i2$3.MatChipRemove, selector: "[matChipRemove]" }, { kind: "component", type: i2$3.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: MatListModule }, { kind: "component", type: i9.MatSelectionList, selector: "mat-selection-list", inputs: ["color", "compareWith", "multiple", "hideSingleSelectionIndicator", "disabled"], outputs: ["selectionChange"], exportAs: ["matSelectionList"] }, { kind: "component", type: i9.MatListOption, selector: "mat-list-option", inputs: ["togglePosition", "checkboxPosition", "color", "value", "selected"], outputs: ["selectedChange"], exportAs: ["matListOption"] }, { kind: "ngmodule", type: MatProgressSpinnerModule }, { kind: "component", type: i3$1.MatProgressSpinner, selector: "mat-progress-spinner, mat-spinner", inputs: ["color", "mode", "value", "diameter", "strokeWidth"], exportAs: ["matProgressSpinner"] }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "component", type: SearchFilterContainerComponent, selector: "hxp-search-filter-container", inputs: ["name", "filterForm", "selectedValue"], outputs: ["overlayClosed", "filterCleared", "filterApplied"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "component", type: SearchFilterInputComponent, selector: "hxp-search-filter-input", inputs: ["applyOnEnter", "inputAriaLabel", "placeholder", "clearAriaLabel", "prefixIcon", "prefixAriaLabel"], outputs: ["search", "clear", "prefixClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentCategorySearchFiltersComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-document-category-filter', imports: [
                        CommonModule,
                        FormsModule,
                        MatButtonModule,
                        MatChipsModule,
                        MatDividerModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatListModule,
                        MatProgressSpinnerModule,
                        ReactiveFormsModule,
                        SearchFilterContainerComponent,
                        TranslatePipe,
                        SearchFilterInputComponent,
                    ], providers: [DocumentCategorySearchFilterService], template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.LABEL' | translate\"\n    [selectedValue]=\"selectedValue\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n    [filterForm]=\"filterForm\"\n>\n    <div class=\"hxp-document-category-filter-container\">\n        <hxp-search-filter-input\n            [inputAriaLabel]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.LABEL' | translate\"\n            [placeholder]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.PLACEHOLDER' | translate\"\n            [clearAriaLabel]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.CLEAR_INPUT' | translate\"\n            (search)=\"filteredSearch($event)\"\n            (clear)=\"clearInput()\"\n        />\n\n        <div class=\"hxp-document-category-filter-summary\">\n            <mat-chip-set\n                class=\"hxp-document-category-filter-summary-list\"\n                tabindex=\"0\"\n            >\n                <span class=\"hxp-document-category-filter-summary-list-prefix\">\n                    {{ 'SEARCH.FILTERS.DOCUMENT_CATEGORY.SELECTED' | translate: { selected: selection.selected.length }\n                    }}<span\n                        *ngIf=\"selection.selected.length > 0\"\n                        class=\"hxp-document-category-filter-summary-list-colon\"\n                        >:</span\n                    >\n                </span>\n                <mat-chip\n                    *ngFor=\"let selectedCategory of selection.selected\"\n                    class=\"hxp-document-category-filter-summary-list-item\"\n                    [attr.aria-label]=\"selectedCategory\"\n                >\n                    <span class=\"hxp-document-category-filter-summary-list-item__label\">{{ selectedCategory }}</span>\n                    <button\n                        matChipRemove\n                        [attr.aria-label]=\"('SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.REMOVE' | translate) + ' ' + selectedCategory\"\n                        (click)=\"onDeselect(selectedCategory)\"\n                    >\n                        <mat-icon\n                            class=\"hxp-document-category-filter-summary-list-remove-item-icon\"\n                            svgIcon=\"x_large\"\n                        />\n                    </button>\n                </mat-chip>\n            </mat-chip-set>\n        </div>\n\n        <div\n            *ngIf=\"isLoading\"\n            class=\"hxp-document-category-filter-spinner-container\"\n        >\n            <mat-progress-spinner mode=\"indeterminate\" />\n        </div>\n\n        <ng-container *ngIf=\"!isLoading\">\n            <mat-selection-list\n                #documentCategories\n                class=\"hxp-document-category-filter-list\"\n                (selectionChange)=\"onSelectionListChange($event)\"\n                *ngIf=\"filteredCategories.length; else noResults\"\n                [attr.aria-label]=\"'SEARCH.FILTERS.DOCUMENT_CATEGORY.ARIA-LABEL.DOCUMENT_CATEGORIES_LIST' | translate\"\n            >\n                <mat-list-option\n                    *ngFor=\"let category of filteredCategories\"\n                    [value]=\"category\"\n                    class=\"hxp-document-category-filter-list-option\"\n                    checkboxPosition=\"before\"\n                    [selected]=\"isChecked(category)\"\n                    [attr.aria-label]=\"category\"\n                >\n                    <span>{{ category }}</span>\n                </mat-list-option>\n            </mat-selection-list>\n\n            <ng-template #noResults>\n                <div class=\"hxp-document-category-filter-no-results\">\n                    <h2>\n                        {{ 'SEARCH.FILTERS.DOCUMENT_CATEGORY.NO_SEARCH_RESULTS.TITLE' | translate }}\n                    </h2>\n                    <p>\n                        {{ 'SEARCH.FILTERS.DOCUMENT_CATEGORY.NO_SEARCH_RESULTS.MESSAGE' | translate }}\n                    </p>\n                </div>\n            </ng-template>\n        </ng-container>\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-document-category-filter-container{width:300px;height:468px;display:flex;flex-direction:column;padding:24px}.hxp-document-category-filter-list{max-height:360px;overflow-y:scroll}.hxp-document-category-filter-summary{padding:22px 0 8px}.hxp-document-category-filter-summary-list{width:100%;max-height:110px;overflow-y:auto}.hxp-document-category-filter-summary-list-prefix{margin-left:8px;display:flex;align-items:center}.hxp-document-category-filter-summary-list-colon{display:flex;align-items:center}.hxp-document-category-filter-summary-list-item{min-height:auto;height:18px;background-color:var(--mat-sys-primary-container);padding-top:3px;padding-bottom:3px}.hxp-document-category-filter-summary-list-item button{margin:0}.hxp-document-category-filter-summary-list-item__label{color:var(--mat-sys-primary)}.hxp-document-category-filter-summary-list-remove-item-icon{--mdc-icon-size: 12px;color:var(--mat-sys-primary);opacity:1;display:flex}.hxp-document-category-filter-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center}.hxp-document-category-filter-no-results h2,.hxp-document-category-filter-no-results p{margin:0}.hxp-document-category-filter-spinner-container{display:flex;justify-content:center;align-items:center;height:100%;width:100%}\n"] }]
        }], ctorParameters: () => [], propDecorators: { searchFilterComponent: [{
                type: ViewChild,
                args: [SearchFilterInputComponent]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeSearchFilterService {
    toHXQL(data) {
        if (!data?.values?.length) {
            return '';
        }
        const mimeTypes = data.values.flatMap((fileType) => fileType.value);
        return `sysfile_blob/mimeType IN (${mimeTypes.map((type) => `'${type}'`).join(', ')})`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileTypeSearchFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileTypeSearchFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileTypeSearchFilterService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeSearchFilterValue {
    constructor() {
        this.label = '';
        this.value = [];
        this.fileTypeId = '';
    }
}
const compareFn$1 = (a, b) => a.fileTypeId.localeCompare(b.fileTypeId);
class FileTypeSearchFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        const sortedValues = this.values.sort(compareFn$1);
        const sortedDataValues = data.values.sort(compareFn$1);
        return sortedValues.every((sortedValue, index) => sortedValue.value === sortedDataValues[index].value);
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeNode {
    constructor() {
        this.id = '';
        this.label = '';
        this.formats = [];
    }
}
class FileTypeFlatNode {
    constructor() {
        this.id = '';
        this.label = '';
        this.mimeTypeIcon = '';
    }
}
const TREE_DATA = [
    {
        id: 'documents',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.LABEL',
        formats: [
            {
                id: 'documents/portable-document-format',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.PORTABLE_DOCUMENT_FORMAT',
                extensions: ['pdf'],
                mimeTypes: ['application/pdf'],
                mimeTypeIcon: 'application/pdf',
            },
            {
                id: 'documents/presentation',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.PRESENTATION',
                extensions: ['ppt', 'pptx'],
                mimeTypes: ['application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation'],
                mimeTypeIcon: 'application/vnd.ms-powerpoint',
            },
            {
                id: 'documents/spreadsheet',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.SPREADSHEET',
                extensions: ['xls', 'xlsx'],
                mimeTypes: ['application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
                mimeTypeIcon: 'application/vnd.ms-excel',
            },
            {
                id: 'documents/text-document',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.TEXT_DOCUMENT',
                extensions: ['doc', 'docx'],
                mimeTypes: ['application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
                mimeTypeIcon: 'application/msword',
            },
            {
                id: 'documents/text-file',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.DOCUMENTS.FORMATS.TEXT_FILE',
                extensions: ['txt'],
                mimeTypes: ['text/plain'],
                mimeTypeIcon: 'text/plain',
            },
        ],
    },
    {
        id: 'images',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.LABEL',
        formats: [
            {
                id: 'images/uncompressed-image-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.FORMATS.UNCOMPRESSED_IMAGE_FORMATS',
                extensions: ['bmp', 'raw'],
                mimeTypes: ['image/bmp', 'image/x-panasonic-raw'],
                mimeTypeIcon: 'image/bmp',
            },
            {
                id: 'images/compressed-image-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.FORMATS.COMPRESSED_IMAGE_FORMATS',
                extensions: ['png', 'jpg', 'jpeg', 'gif', 'tiff', 'tif', 'webp'],
                mimeTypes: ['image/png', 'image/jpeg', 'image/jpg', 'image/gif', 'image/tiff', 'image/webp'],
                mimeTypeIcon: 'image/png',
            },
            {
                id: 'images/vector-image-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.FORMATS.VECTOR_IMAGE_FORMATS',
                extensions: ['eps', 'svg'],
                mimeTypes: ['image/svg+xml', 'application/postscript'],
                mimeTypeIcon: 'image/svg+xml',
            },
            {
                id: 'images/software-files',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.IMAGES.FORMATS.SOFTWARE_FILES',
                extensions: ['ai', 'eps', 'psd', 'tga'],
                mimeTypes: [
                    'image/vnd.adobe.photoshop',
                    'application/postscript',
                    'application/illustrator',
                    'application/pdf',
                    'application/vsn.adobe.illustrator',
                    'image/x-tga',
                    'image/x-targa',
                    'image/targa',
                ],
                mimeTypeIcon: 'image/vnd.adobe.photoshop',
            },
        ],
    },
    {
        id: 'video',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.VIDEO.LABEL',
        formats: [
            {
                id: 'video/uncompressed-video-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.VIDEO.FORMATS.UNCOMPRESSED_VIDEO_FORMATS',
                extensions: ['avi', 'mov', 'raw'],
                mimeTypes: ['video/x-msvideo', 'video/quicktime', 'image/x-panasonic-raw'],
                mimeTypeIcon: 'video/x-msvideo',
            },
            {
                id: 'video/compressed-video-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.VIDEO.FORMATS.COMPRESSED_VIDEO_FORMATS',
                extensions: ['mp4', 'avi', 'mov', 'webm', 'flv'],
                mimeTypes: ['video/mp4', 'video/x-msvideo', 'video/quicktime', 'video/webm', 'video/x-flv'],
                mimeTypeIcon: 'video/mp4',
            },
            {
                id: 'video/software-files',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.VIDEO.FORMATS.SOFTWARE_FILES',
                extensions: ['mov', 'mp4', '3gp'],
                mimeTypes: ['video/quicktime', 'video/mp4', 'video/3gpp'],
                mimeTypeIcon: 'video/quicktime',
            },
        ],
    },
    {
        id: 'audio',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.AUDIO.LABEL',
        formats: [
            {
                id: 'audio/uncompressed-audio-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.AUDIO.FORMATS.UNCOMPRESSED_AUDIO_FORMATS',
                extensions: ['wav', 'aiff', 'au', 'raw'],
                mimeTypes: ['audio/vnd.wav', 'audio/wav', 'audio/aiff', 'audio/basic', 'image/x-panasonic-raw'],
                mimeTypeIcon: 'audio/wav',
            },
            {
                id: 'audio/compressed-audio-formats',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.AUDIO.FORMATS.COMPRESSED_AUDIO_FORMATS',
                extensions: ['flac', 'wma', 'm4a', 'mp3', 'aac'],
                mimeTypes: ['audio/flac', 'audio/x-ms-wma', 'audio/m4a', 'audio/mp4', 'audio/mpeg', 'audio/aac'],
                mimeTypeIcon: 'audio/mp3',
            },
        ],
    },
    {
        id: 'other',
        label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.OTHER.LABEL',
        formats: [
            {
                id: 'other/archive-files',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.OTHER.FORMATS.ARCHIVE_FILES',
                extensions: ['7z', 'zip'],
                mimeTypes: ['application/x-7z-compressed', 'application/zip', 'application/zip-compressed', 'application/x-zip-compressed'],
                mimeTypeIcon: 'application/zip',
            },
            {
                id: 'other/font-files',
                label: 'SEARCH.FILTERS.FILE_TYPE.CATEGORIES.OTHER.FORMATS.FONT_FILES',
                extensions: ['otf', 'ttf'],
                mimeTypes: ['font/otf', 'application/x-font-otf', 'application/x-font-ttf'],
                mimeTypeIcon: 'font/otf',
            },
        ],
    },
];

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ArrayToStringPipe {
    transform(value = [], prefix = '.', separator = ',') {
        if (!Array.isArray(value) || value.length === 0) {
            return '';
        }
        return value.map((val) => `${prefix}${val}`).join(`${separator} `);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ArrayToStringPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.20", ngImport: i0, type: ArrayToStringPipe, isStandalone: true, name: "arrayToString" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ArrayToStringPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'arrayToString',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeSearchFilterTreeComponent {
    constructor() {
        this.flatNodeMap = new Map();
        this.nestedNodeMap = new Map();
        this.selectedParent = null;
        this.fileTypeSelection = new SelectionModel(true, [], true, (node1, node2) => node1.id === node2.id);
        this.selectedFileTypes = new EventEmitter();
        this.getLevel = (node) => node.level || 0;
        this.isExpandable = (node) => node.expandable || false;
        this.getChildren = (node) => node.formats || [];
        this.hasChild = (_, _nodeData) => _nodeData.expandable;
        this.hasNoContent = (_, _nodeData) => _nodeData.label === '';
        /**
         * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
         */
        this.transformer = (node, level) => {
            const existingNode = this.nestedNodeMap.get(node);
            const flatNode = existingNode && existingNode.label === node.label ? existingNode : new FileTypeFlatNode();
            flatNode.id = node.id;
            flatNode.label = node.label;
            flatNode.level = level;
            flatNode.expandable = !!node.formats?.length;
            if (!flatNode.expandable) {
                flatNode.mimeTypes = node['mimeTypes'];
                flatNode.extensions = node['extensions'];
                flatNode.mimeTypeIcon = node['mimeTypeIcon'];
            }
            this.flatNodeMap.set(flatNode, node);
            this.nestedNodeMap.set(node, flatNode);
            return flatNode;
        };
        this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
        this.treeControl = new FlatTreeControl(this.getLevel, this.isExpandable);
        this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
        this.dataSource.data = TREE_DATA;
    }
    ngOnChanges() {
        this.filterTree(this.filteredFileType);
    }
    fileTypeSelectionToggleById(nodeId) {
        const treeNode = this.treeControl.dataNodes.find((n) => n.id === nodeId);
        const node = this.flatNodeMap.get(treeNode);
        if (node) {
            this.fileTypeSelectionToggle(this.nestedNodeMap.get(node));
        }
    }
    fileTypeSelectionToggle(node) {
        this.fileTypeSelection.toggle(node);
        const descendants = this.treeControl.getDescendants(node);
        if (this.fileTypeSelection.isSelected(node)) {
            this.fileTypeSelection.select(...descendants);
        }
        else {
            this.fileTypeSelection.deselect(...descendants);
        }
        // Force update for the parent
        for (const child of descendants) {
            this.fileTypeSelection.isSelected(child);
        }
        this.checkAllParentsSelection(node);
        this.selectedFileTypes.emit(this.fileTypeSelection.selected);
        // keep the selected nodes expanded
        this.expandSelectedNodes();
    }
    clearSelection() {
        this.fileTypeSelection.clear();
        this.treeControl.collapseAll();
    }
    onNodeExpand(event) {
        event.preventDefault();
        event.stopPropagation();
    }
    descendantsAllSelected(node) {
        const descendants = this.treeControl.getDescendants(node);
        const descAllSelected = descendants.length > 0 &&
            descendants.every((child) => {
                return this.fileTypeSelection.isSelected(child);
            });
        return descAllSelected;
    }
    descendantsPartiallySelected(node) {
        const descendants = this.treeControl.getDescendants(node);
        const result = descendants.some((child) => this.fileTypeSelection.isSelected(child));
        return result && !this.descendantsAllSelected(node);
    }
    leafItemSelectionToggle(node) {
        this.fileTypeSelectionToggle(node);
        this.checkAllParentsSelection(node);
    }
    checkAllParentsSelection(node) {
        let parent = this.getParentNode(node);
        while (parent) {
            this.checkRootNodeSelection(parent);
            parent = this.getParentNode(parent);
        }
    }
    checkRootNodeSelection(node) {
        const nodeSelected = this.fileTypeSelection.isSelected(node);
        const descendants = this.treeControl.getDescendants(node);
        const descAllSelected = descendants.length > 0 &&
            descendants.every((child) => {
                return this.fileTypeSelection.isSelected(child);
            });
        if (nodeSelected && !descAllSelected) {
            this.fileTypeSelection.deselect(node);
        }
        else if (!nodeSelected && descAllSelected) {
            this.fileTypeSelection.select(node);
        }
    }
    getParentNode(node) {
        const currentLevel = this.getLevel(node);
        if (currentLevel < 1) {
            return null;
        }
        const startIndex = this.treeControl.dataNodes.indexOf(node) - 1;
        for (let i = startIndex; i >= 0; i--) {
            const currentNode = this.treeControl.dataNodes[i];
            if (this.getLevel(currentNode) < currentLevel) {
                return currentNode;
            }
        }
        return null;
    }
    filterTree(filterText) {
        this.dataSource.data = this.filterRecursive(filterText, TREE_DATA, 'label');
        if (filterText) {
            this.treeControl.expandAll();
        }
        else {
            // confirm if parent nodes are selected or not, because in case of filter we need to recheck the parent selection
            [...this.flatNodeMap.keys()].forEach((node) => this.checkAllParentsSelection(node));
            this.expandSelectedNodes();
        }
    }
    filterRecursive(filterText, data, property) {
        if (!filterText) {
            return data;
        }
        const copy = (o) => {
            return Object.assign({}, o);
        };
        filterText = filterText.toLowerCase();
        const filteredData = data.map(copy).filter(function x(y) {
            if (y[property].toLowerCase().includes(filterText)) {
                return true;
            }
            if (y?.formats) {
                return (y.formats = y.formats.map(copy).filter(x)).length;
            }
            if (y?.extensions) {
                return y.extensions.some((ext) => ext.includes(filterText));
            }
        });
        return filteredData;
    }
    /**
     * Expands all selected nodes to make inner nodes visible.
     */
    expandSelectedNodes() {
        for (const node of this.treeControl.dataNodes) {
            if (this.descendantsPartiallySelected(node) || this.descendantsAllSelected(node)) {
                this.treeControl.expand(node);
                let parent = this.getParentNode(node);
                while (parent) {
                    this.treeControl.expand(parent);
                    parent = this.getParentNode(parent);
                }
            }
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileTypeSearchFilterTreeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: FileTypeSearchFilterTreeComponent, isStandalone: true, selector: "hxp-file-type-search-filter-tree", inputs: { filteredFileType: "filteredFileType" }, outputs: { selectedFileTypes: "selectedFileTypes" }, usesOnChanges: true, ngImport: i0, template: "<mat-tree\n    *ngIf=\"dataSource?.data?.length; else noResults\"\n    [dataSource]=\"dataSource\"\n    [treeControl]=\"treeControl\"\n    class=\"hxp-file-type-tree\"\n>\n    <mat-tree-node\n        *matTreeNodeDef=\"let node\"\n        matTreeNodeToggle\n        matTreeNodePadding\n    >\n        <button\n            mat-icon-button\n            disabled\n            aria-hidden=\"true\"\n        ></button>\n        <mat-checkbox\n            [checked]=\"fileTypeSelection.isSelected(node)\"\n            (change)=\"leafItemSelectionToggle(node)\"\n        >\n            <div class=\"hxp-mime-type-row\">\n                <hxp-mime-type-icon\n                    [mimeType]=\"node?.mimeTypeIcon\"\n                    aria-hidden=\"true\"\n                />\n                <div class=\"hxp-mime-type-description\">\n                    <span class=\"hxp-mime-type-description-title\">{{ node.label | translate }}</span>\n                    <span class=\"hxp-mime-type-description-extensions\">{{ node.extensions | arrayToString }}</span>\n                </div>\n            </div>\n        </mat-checkbox>\n    </mat-tree-node>\n\n    <mat-tree-node\n        *matTreeNodeDef=\"let node; when: hasChild\"\n        matTreeNodePadding\n    >\n        <button\n            mat-icon-button\n            matTreeNodeToggle\n            [attr.aria-label]=\"'Toggle ' + node.label\"\n            (click)=\"onNodeExpand($event)\"\n        >\n            <mat-icon\n                class=\"mat-icon-rtl-mirror\"\n                [svgIcon]=\"treeControl.isExpanded(node) ? 'chevron_down' : 'chevron_right'\"\n            />\n        </button>\n        <mat-checkbox\n            [checked]=\"descendantsAllSelected(node)\"\n            [indeterminate]=\"descendantsPartiallySelected(node)\"\n            (change)=\"fileTypeSelectionToggle(node)\"\n        >\n            <span class=\"hxp-mime-type-parent-label hxp-label-bold\">{{ node.label | translate }}</span>\n        </mat-checkbox>\n    </mat-tree-node>\n</mat-tree>\n\n<ng-template #noResults>\n    <div class=\"hxp-file-type-no-results\">\n        <h2>\n            {{ 'SEARCH.FILTERS.FILE_TYPE.NO_SEARCH_RESULTS.TITLE' | translate }}\n        </h2>\n        <p>\n            {{ 'SEARCH.FILTERS.FILE_TYPE.NO_SEARCH_RESULTS.MESSAGE' | translate }}\n        </p>\n    </div>\n</ng-template>\n", styles: [":host{display:block;height:100%}.hxp-mime-type-row{display:flex;flex-direction:row;align-items:center;gap:8px}.hxp-mime-type-description{display:flex;flex-direction:column}.hxp-mime-type-description-extensions{color:var(--mat-sys-secondary)}.hxp-file-type-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center}.hxp-file-type-no-results h2,.hxp-file-type-no-results p{margin:0}\n"], dependencies: [{ kind: "pipe", type: ArrayToStringPipe, name: "arrayToString" }, { kind: "directive", type: NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i2.MatCheckbox, selector: "mat-checkbox", inputs: ["aria-label", "aria-labelledby", "aria-describedby", "aria-expanded", "aria-controls", "aria-owns", "id", "required", "labelPosition", "name", "value", "disableRipple", "tabIndex", "color", "disabledInteractive", "checked", "disabled", "indeterminate"], outputs: ["change", "indeterminateChange"], exportAs: ["matCheckbox"] }, { kind: "ngmodule", type: MatTreeModule }, { kind: "directive", type: i6.MatTreeNodeDef, selector: "[matTreeNodeDef]", inputs: ["matTreeNodeDefWhen", "matTreeNode"] }, { kind: "directive", type: i6.MatTreeNodePadding, selector: "[matTreeNodePadding]", inputs: ["matTreeNodePadding", "matTreeNodePaddingIndent"] }, { kind: "directive", type: i6.MatTreeNodeToggle, selector: "[matTreeNodeToggle]", inputs: ["matTreeNodeToggleRecursive"] }, { kind: "component", type: i6.MatTree, selector: "mat-tree", exportAs: ["matTree"] }, { kind: "directive", type: i6.MatTreeNode, selector: "mat-tree-node", inputs: ["tabIndex", "disabled"], outputs: ["activation", "expandedChange"], exportAs: ["matTreeNode"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "component", type: MimeTypeIconComponent, selector: "hxp-mime-type-icon", inputs: ["mimeType"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileTypeSearchFilterTreeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-file-type-search-filter-tree', imports: [ArrayToStringPipe, NgIf, MatCheckboxModule, MatTreeModule, MatIconModule, MatButtonModule, MimeTypeIconComponent, TranslatePipe], template: "<mat-tree\n    *ngIf=\"dataSource?.data?.length; else noResults\"\n    [dataSource]=\"dataSource\"\n    [treeControl]=\"treeControl\"\n    class=\"hxp-file-type-tree\"\n>\n    <mat-tree-node\n        *matTreeNodeDef=\"let node\"\n        matTreeNodeToggle\n        matTreeNodePadding\n    >\n        <button\n            mat-icon-button\n            disabled\n            aria-hidden=\"true\"\n        ></button>\n        <mat-checkbox\n            [checked]=\"fileTypeSelection.isSelected(node)\"\n            (change)=\"leafItemSelectionToggle(node)\"\n        >\n            <div class=\"hxp-mime-type-row\">\n                <hxp-mime-type-icon\n                    [mimeType]=\"node?.mimeTypeIcon\"\n                    aria-hidden=\"true\"\n                />\n                <div class=\"hxp-mime-type-description\">\n                    <span class=\"hxp-mime-type-description-title\">{{ node.label | translate }}</span>\n                    <span class=\"hxp-mime-type-description-extensions\">{{ node.extensions | arrayToString }}</span>\n                </div>\n            </div>\n        </mat-checkbox>\n    </mat-tree-node>\n\n    <mat-tree-node\n        *matTreeNodeDef=\"let node; when: hasChild\"\n        matTreeNodePadding\n    >\n        <button\n            mat-icon-button\n            matTreeNodeToggle\n            [attr.aria-label]=\"'Toggle ' + node.label\"\n            (click)=\"onNodeExpand($event)\"\n        >\n            <mat-icon\n                class=\"mat-icon-rtl-mirror\"\n                [svgIcon]=\"treeControl.isExpanded(node) ? 'chevron_down' : 'chevron_right'\"\n            />\n        </button>\n        <mat-checkbox\n            [checked]=\"descendantsAllSelected(node)\"\n            [indeterminate]=\"descendantsPartiallySelected(node)\"\n            (change)=\"fileTypeSelectionToggle(node)\"\n        >\n            <span class=\"hxp-mime-type-parent-label hxp-label-bold\">{{ node.label | translate }}</span>\n        </mat-checkbox>\n    </mat-tree-node>\n</mat-tree>\n\n<ng-template #noResults>\n    <div class=\"hxp-file-type-no-results\">\n        <h2>\n            {{ 'SEARCH.FILTERS.FILE_TYPE.NO_SEARCH_RESULTS.TITLE' | translate }}\n        </h2>\n        <p>\n            {{ 'SEARCH.FILTERS.FILE_TYPE.NO_SEARCH_RESULTS.MESSAGE' | translate }}\n        </p>\n    </div>\n</ng-template>\n", styles: [":host{display:block;height:100%}.hxp-mime-type-row{display:flex;flex-direction:row;align-items:center;gap:8px}.hxp-mime-type-description{display:flex;flex-direction:column}.hxp-mime-type-description-extensions{color:var(--mat-sys-secondary)}.hxp-file-type-no-results{width:100%;height:100%;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center}.hxp-file-type-no-results h2,.hxp-file-type-no-results p{margin:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { filteredFileType: [{
                type: Input
            }], selectedFileTypes: [{
                type: Output
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileTypeSearchFilterComponent extends BaseSearchFilterDirective {
    constructor() {
        super(...arguments);
        this.searchTerm = '';
        this.selection = new SelectionModel(true, [], true, (fileType1, fileType2) => fileType1.id === fileType2.id);
        this.fileTypeSearchFilterService = inject(FileTypeSearchFilterService);
        this.arrayToStringPipe = inject(ArrayToStringPipe);
    }
    get id() {
        return 'FileTypeSearchFilterComponent';
    }
    toHXQL(data) {
        return this.fileTypeSearchFilterService.toHXQL(data);
    }
    setData(data) {
        try {
            if (data?.values) {
                for (const value of data?.values || []) {
                    if (value.fileTypeId) {
                        this.toggleNodeSelectionFromId(value.fileTypeId);
                    }
                }
            }
            this.setSelectedValue();
        }
        catch (error) {
            console.error('Error while setting data for File Type Search Filter', error);
        }
    }
    applyFilter() {
        if (this.selection.selected.length === 0) {
            return this.clearFilter();
        }
        super.applyFilter();
    }
    clearFilter() {
        super.clearFilter();
        this.selection.clear();
        this.searchFilterInputComponent.clearInput();
        this.fileTypeSearchFilterTreeComponent.clearSelection();
    }
    overlayClosed() {
        this.selection.clear();
        this.fileTypeSearchFilterTreeComponent.clearSelection();
        this.oldFormValue?.['selectedFileTypes']?.forEach((item) => {
            this.fileTypeSearchFilterTreeComponent.fileTypeSelectionToggle(item);
            this.selection.select(item);
        });
        this.discardPendingChanges();
    }
    filteredSearch(searchTerm) {
        this.searchTerm = searchTerm;
    }
    getFormControls() {
        return {
            selectedFileTypes: new FormControl([]),
        };
    }
    onSelectedFileType(selectedFileTypes) {
        this.selection.clear();
        for (const selectedFileType of selectedFileTypes) {
            if (selectedFileType?.level !== 0) {
                this.selection.select(selectedFileType);
            }
        }
        this.setSelectedValue();
        this.filterForm.markAsDirty();
    }
    toggleSelection(fileTypeNode) {
        this.selection.toggle(fileTypeNode);
        this.fileTypeSearchFilterTreeComponent.fileTypeSelectionToggle(fileTypeNode);
        this.setSelectedValue();
    }
    clearSearchInput() {
        this.searchTerm = '';
    }
    toggleNodeSelectionFromId(fileTypeId) {
        this.fileTypeSearchFilterTreeComponent.fileTypeSelectionToggleById(fileTypeId);
    }
    setSelectedValue() {
        this.filterForm.patchValue({
            selectedFileTypes: [...this.selection.selected],
        });
        if (this.selection.selected.length === 0) {
            this.selectedValue = undefined;
            return;
        }
        const selectedValues = this.selection.selected.map((sel) => ({
            label: `${this.translateService.instant(sel.label)} (${this.arrayToStringPipe.transform(sel.extensions || [])})`,
            value: sel.mimeTypes || [],
            fileTypeId: sel.id,
        }));
        this.selectedValue = new FileTypeSearchFilterData(selectedValues);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileTypeSearchFilterComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.20", type: FileTypeSearchFilterComponent, isStandalone: true, selector: "hxp-file-type-search-filter", providers: [ArrayToStringPipe, FileTypeSearchFilterService], viewQueries: [{ propertyName: "searchFilterInputComponent", first: true, predicate: SearchFilterInputComponent, descendants: true }, { propertyName: "fileTypeSearchFilterTreeComponent", first: true, predicate: FileTypeSearchFilterTreeComponent, descendants: true }], usesInheritance: true, ngImport: i0, template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.FILE_TYPE.LABEL' | translate\"\n    [selectedValue]=\"selectedValue\"\n    [filterForm]=\"filterForm\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n>\n    <div class=\"hxp-file-type-search-filter-container\">\n        <hxp-search-filter-input\n            [inputAriaLabel]=\"'SEARCH.FILTERS.FILE_TYPE.LABEL' | translate\"\n            [placeholder]=\"'SEARCH.FILTERS.FILE_TYPE.PLACEHOLDER' | translate\"\n            [clearAriaLabel]=\"'SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.CLEAR_INPUT' | translate\"\n            (search)=\"filteredSearch($event)\"\n            (clear)=\"clearSearchInput()\"\n        />\n        <div class=\"hxp-file-type-search-filter-summary\">\n            <mat-chip-set\n                ariaLabel=\"\n                        'SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.SELECTED_FILTERS'\n                            | translate\n                    \"\n                class=\"hxp-file-type-search-filter-summary-list\"\n            >\n                <span class=\"hxp-file-type-search-filter-summary-list-prefix\">\n                    {{ 'SEARCH.FILTERS.FILE_TYPE.SELECTED' | translate: { selected: selection.selected.length } }}\n                </span>\n                <span\n                    *ngIf=\"selection.selected.length > 0\"\n                    class=\"hxp-file-type-search-filter-summary-list-colon\"\n                    >:</span\n                >\n                <mat-chip\n                    *ngFor=\"let selectedFileType of selection.selected\"\n                    class=\"hxp-file-type-search-filter-summary-list-item\"\n                    [attr.aria-label]=\"selectedFileType\"\n                    [matTooltip]=\"selectedFileType.extensions | arrayToString\"\n                >\n                    <span class=\"hxp-file-type-search-filter-summary-list-item__label\">\n                        {{ (selectedFileType.label | translate) + ' (' + (selectedFileType.extensions | arrayToString) + ')' }}\n                    </span>\n                    <button\n                        matChipRemove\n                        [attr.aria-label]=\"('SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.REMOVE' | translate) + ' ' + selectedFileType\"\n                        (click)=\"toggleSelection(selectedFileType)\"\n                    >\n                        <mat-icon\n                            class=\"hxp-file-type-search-filter-summary-list-remove-item-icon\"\n                            svgIcon=\"x_large\"\n                        />\n                    </button>\n                </mat-chip>\n            </mat-chip-set>\n        </div>\n\n        <hxp-file-type-search-filter-tree\n            (selectedFileTypes)=\"onSelectedFileType($event)\"\n            [filteredFileType]=\"searchTerm\"\n        />\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-file-type-search-filter-container{height:468px;width:370px;display:flex;flex-direction:column;padding:24px}.hxp-file-type-search-filter-summary{padding:22px 0 20px}.hxp-file-type-search-filter-summary-list{width:100%;max-height:110px;overflow-y:scroll}.hxp-file-type-search-filter-summary-list-prefix{margin-left:8px;display:flex;align-items:center}.hxp-file-type-search-filter-summary-list-colon{display:flex;align-items:center}.hxp-file-type-search-filter-summary-list-item{min-height:auto;height:18px;background-color:var(--mat-sys-primary-container);padding-top:3px;padding-bottom:3px}.hxp-file-type-search-filter-summary-list-item button{margin:0}.hxp-file-type-search-filter-summary-list-item__label{color:var(--mat-sys-primary)}.hxp-file-type-search-filter-summary-list-remove-item-icon{--mdc-icon-size: 12px;color:var(--mat-sys-primary);opacity:1;display:flex}.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mdc-evolution-chip__cell--primary,.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mdc-evolution-chip__action--primary,.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mat-mdc-chip-action-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}hxp-file-type-search-filter-tree{overflow-y:scroll}\n"], dependencies: [{ kind: "pipe", type: ArrayToStringPipe, name: "arrayToString" }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$4.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1$4.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: FileTypeSearchFilterTreeComponent, selector: "hxp-file-type-search-filter-tree", inputs: ["filteredFileType"], outputs: ["selectedFileTypes"] }, { kind: "ngmodule", type: FormsModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatChipsModule }, { kind: "component", type: i2$3.MatChip, selector: "mat-basic-chip, [mat-basic-chip], mat-chip, [mat-chip]", inputs: ["role", "id", "aria-label", "aria-description", "value", "color", "removable", "highlighted", "disableRipple", "disabled"], outputs: ["removed", "destroyed"], exportAs: ["matChip"] }, { kind: "directive", type: i2$3.MatChipRemove, selector: "[matChipRemove]" }, { kind: "component", type: i2$3.MatChipSet, selector: "mat-chip-set", inputs: ["disabled", "role", "tabIndex"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i2$2.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: SearchFilterContainerComponent, selector: "hxp-search-filter-container", inputs: ["name", "filterForm", "selectedValue"], outputs: ["overlayClosed", "filterCleared", "filterApplied"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }, { kind: "component", type: SearchFilterInputComponent, selector: "hxp-search-filter-input", inputs: ["applyOnEnter", "inputAriaLabel", "placeholder", "clearAriaLabel", "prefixIcon", "prefixAriaLabel"], outputs: ["search", "clear", "prefixClick"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileTypeSearchFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-file-type-search-filter', imports: [
                        ArrayToStringPipe,
                        CommonModule,
                        FileTypeSearchFilterTreeComponent,
                        FormsModule,
                        MatButtonModule,
                        MatChipsModule,
                        MatDividerModule,
                        MatFormFieldModule,
                        MatIconModule,
                        MatInputModule,
                        MatTooltipModule,
                        SearchFilterContainerComponent,
                        TranslatePipe,
                        SearchFilterInputComponent,
                    ], providers: [ArrayToStringPipe, FileTypeSearchFilterService], template: "<hxp-search-filter-container\n    #searchFilter\n    [name]=\"'SEARCH.FILTERS.FILE_TYPE.LABEL' | translate\"\n    [selectedValue]=\"selectedValue\"\n    [filterForm]=\"filterForm\"\n    (filterApplied)=\"applyFilter()\"\n    (filterCleared)=\"clearFilter()\"\n    (overlayClosed)=\"overlayClosed()\"\n>\n    <div class=\"hxp-file-type-search-filter-container\">\n        <hxp-search-filter-input\n            [inputAriaLabel]=\"'SEARCH.FILTERS.FILE_TYPE.LABEL' | translate\"\n            [placeholder]=\"'SEARCH.FILTERS.FILE_TYPE.PLACEHOLDER' | translate\"\n            [clearAriaLabel]=\"'SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.CLEAR_INPUT' | translate\"\n            (search)=\"filteredSearch($event)\"\n            (clear)=\"clearSearchInput()\"\n        />\n        <div class=\"hxp-file-type-search-filter-summary\">\n            <mat-chip-set\n                ariaLabel=\"\n                        'SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.SELECTED_FILTERS'\n                            | translate\n                    \"\n                class=\"hxp-file-type-search-filter-summary-list\"\n            >\n                <span class=\"hxp-file-type-search-filter-summary-list-prefix\">\n                    {{ 'SEARCH.FILTERS.FILE_TYPE.SELECTED' | translate: { selected: selection.selected.length } }}\n                </span>\n                <span\n                    *ngIf=\"selection.selected.length > 0\"\n                    class=\"hxp-file-type-search-filter-summary-list-colon\"\n                    >:</span\n                >\n                <mat-chip\n                    *ngFor=\"let selectedFileType of selection.selected\"\n                    class=\"hxp-file-type-search-filter-summary-list-item\"\n                    [attr.aria-label]=\"selectedFileType\"\n                    [matTooltip]=\"selectedFileType.extensions | arrayToString\"\n                >\n                    <span class=\"hxp-file-type-search-filter-summary-list-item__label\">\n                        {{ (selectedFileType.label | translate) + ' (' + (selectedFileType.extensions | arrayToString) + ')' }}\n                    </span>\n                    <button\n                        matChipRemove\n                        [attr.aria-label]=\"('SEARCH.FILTERS.FILE_TYPE.ARIA-LABEL.REMOVE' | translate) + ' ' + selectedFileType\"\n                        (click)=\"toggleSelection(selectedFileType)\"\n                    >\n                        <mat-icon\n                            class=\"hxp-file-type-search-filter-summary-list-remove-item-icon\"\n                            svgIcon=\"x_large\"\n                        />\n                    </button>\n                </mat-chip>\n            </mat-chip-set>\n        </div>\n\n        <hxp-file-type-search-filter-tree\n            (selectedFileTypes)=\"onSelectedFileType($event)\"\n            [filteredFileType]=\"searchTerm\"\n        />\n    </div>\n</hxp-search-filter-container>\n", styles: [".hxp-file-type-search-filter-container{height:468px;width:370px;display:flex;flex-direction:column;padding:24px}.hxp-file-type-search-filter-summary{padding:22px 0 20px}.hxp-file-type-search-filter-summary-list{width:100%;max-height:110px;overflow-y:scroll}.hxp-file-type-search-filter-summary-list-prefix{margin-left:8px;display:flex;align-items:center}.hxp-file-type-search-filter-summary-list-colon{display:flex;align-items:center}.hxp-file-type-search-filter-summary-list-item{min-height:auto;height:18px;background-color:var(--mat-sys-primary-container);padding-top:3px;padding-bottom:3px}.hxp-file-type-search-filter-summary-list-item button{margin:0}.hxp-file-type-search-filter-summary-list-item__label{color:var(--mat-sys-primary)}.hxp-file-type-search-filter-summary-list-remove-item-icon{--mdc-icon-size: 12px;color:var(--mat-sys-primary);opacity:1;display:flex}.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mdc-evolution-chip__cell--primary,.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mdc-evolution-chip__action--primary,.hxp-file-type-search-filter-summary-list ::ng-deep .mat-mdc-standard-chip .mat-mdc-chip-action-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%}hxp-file-type-search-filter-tree{overflow-y:scroll}\n"] }]
        }], propDecorators: { searchFilterInputComponent: [{
                type: ViewChild,
                args: [SearchFilterInputComponent]
            }], fileTypeSearchFilterTreeComponent: [{
                type: ViewChild,
                args: [FileTypeSearchFilterTreeComponent]
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchTermFilterValue {
    constructor() {
        this.label = '';
        this.term = '';
        this.type = SearchType.BASIC;
    }
}
const compareFn = (a, b) => a.term.localeCompare(b.term) && a.type.localeCompare(b.type);
class SearchTermFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        const sortedValues = this.values.sort(compareFn);
        const sortedDataValues = data.values.sort(compareFn);
        for (const [i, sortedValue] of sortedValues.entries()) {
            if (sortedValue.term !== sortedDataValues[i].term && sortedValue.type !== sortedDataValues[i].type) {
                return false;
            }
        }
        return true;
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchTermFilterService {
    toHXQL(data) {
        return data?.values?.length > 0 ? `sys_fulltext = '${data.values[0].term}*'` : '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchTermFilterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchTermFilterService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchTermFilterService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchTermFilterComponent extends BaseSearchFilterDirective {
    constructor() {
        super(...arguments);
        this.searchType = SearchType.BASIC;
        this.searchTerm = '';
        this.searchTermChanged = new EventEmitter();
        this.SearchTypeEnum = SearchType;
        this.errorStateMatcher = new ShowOnDirtyErrorStateMatcher();
        this.searchTermFilterService = inject(SearchTermFilterService);
    }
    ngOnChanges() {
        this.filterForm.get('type')?.setValue(this.searchType);
        this.filterForm.get('query')?.setValue(this.searchTerm);
    }
    get id() {
        return 'SearchTermFilterComponent';
    }
    toHXQL(data) {
        return this.searchTermFilterService.toHXQL(data);
    }
    onInput() {
        this.selectedValue = new SearchTermFilterData([
            {
                label: 'Search term',
                term: this.filterForm.get('query')?.value,
                type: this.filterForm.get('type')?.value,
            },
        ]);
        this.applyChanges();
        this.emitSearchTermChanged();
    }
    onClear() {
        this.filterForm.get('query')?.setValue('');
        this.clearFilter();
        this.emitSearchTermChanged();
    }
    onSearch(event) {
        // Stops textarea from adding a newline on 'enter' button
        if (event) {
            event.preventDefault();
        }
        if (this.filterForm.invalid) {
            return;
        }
        this.applyFilter();
    }
    getFormControls() {
        return {
            type: new FormControl(SearchType.BASIC, {
                nonNullable: true,
            }),
            query: new FormControl('', {
                validators: Validators.required,
            }),
        };
    }
    setData(data) {
        if (!data?.values?.length) {
            return;
        }
        try {
            this.filterForm.setValue({
                type: data.values[0].type ?? SearchType.BASIC,
                query: data.values[0].term ?? '',
            });
            if (data.values[0].term) {
                this.selectedValue = data;
            }
        }
        catch (error) {
            console.error('Error while setting data for Search Term filter', error);
        }
    }
    emitSearchTermChanged() {
        this.searchTermChanged.emit(this.filterForm.get('query')?.value.trim());
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchTermFilterComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.20", type: SearchTermFilterComponent, isStandalone: true, selector: "hxp-search-term-filter", inputs: { searchType: "searchType", searchTerm: "searchTerm" }, outputs: { searchTermChanged: "searchTermChanged" }, providers: [SearchTermFilterService], usesInheritance: true, usesOnChanges: true, ngImport: i0, template: "<form\n    class=\"hxp-search-input\"\n    role=\"search\"\n    [formGroup]=\"filterForm\"\n    (submit)=\"onSearch()\"\n>\n    <div class=\"hxp-search-text\">\n        <mat-form-field\n            appearance=\"outline\"\n            subscriptSizing=\"dynamic\"\n            class=\"hxp-new-search-input\"\n        >\n            <textarea\n                matInput\n                #searchInput\n                type=\"search\"\n                formControlName=\"query\"\n                cdkTextareaAutosize\n                cdkAutosizeMinRows=\"1\"\n                cdkAutosizeMaxRows=\"3\"\n                placeholder=\"{{ 'SEARCH.INPUT.PLACEHOLDER' | translate }}\"\n                [attr.aria-label]=\"'SEARCH.INPUT.ARIA_LABEL' | translate\"\n                [errorStateMatcher]=\"errorStateMatcher\"\n                (input)=\"onInput()\"\n                (keydown.enter)=\"onSearch($event)\"\n            ></textarea>\n\n            @if (searchInput?.value?.length && filterForm.get('query')?.value) {\n                <div\n                    matSuffix\n                    class=\"hxp-search-text-suffix-container\"\n                >\n                    <button\n                        mat-icon-button\n                        class=\"hxp-clear\"\n                        [attr.aria-label]=\"'SEARCH.INPUT.CLEAR_INPUT' | translate\"\n                        (click)=\"onClear()\"\n                    >\n                        <mat-icon\n                            aria-hidden=\"true\"\n                            svgIcon=\"x_large\"\n                        />\n                    </button>\n                </div>\n            }\n        </mat-form-field>\n    </div>\n</form>\n", styles: [".hxp-search-input .hxp-search-text{display:flex;justify-content:space-between;flex-grow:1}.hxp-search-input .hxp-search-text .hxp-new-search-input{flex:1}.hxp-search-input textarea{width:100%;resize:none}.hxp-search-text-suffix-container{align-items:center;border-left:1px solid var(--mat-sys-outline);display:flex;height:56px;justify-content:center;width:56px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatFormFieldModule }, { kind: "component", type: i4$1.MatFormField, selector: "mat-form-field", inputs: ["hideRequiredMarker", "color", "floatLabel", "appearance", "subscriptSizing", "hintLabel"], exportAs: ["matFormField"] }, { kind: "directive", type: i4$1.MatSuffix, selector: "[matSuffix], [matIconSuffix], [matTextSuffix]", inputs: ["matTextSuffix"] }, { kind: "ngmodule", type: MatInputModule }, { kind: "directive", type: i5.MatInput, selector: "input[matInput], textarea[matInput], select[matNativeControl],      input[matNativeControl], textarea[matNativeControl]", inputs: ["disabled", "id", "placeholder", "name", "required", "type", "errorStateMatcher", "aria-describedby", "value", "readonly", "disabledInteractive"], exportAs: ["matInput"] }, { kind: "directive", type: i6$1.CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }, { kind: "ngmodule", type: MatSelectModule }, { kind: "ngmodule", type: ReactiveFormsModule }, { kind: "directive", type: i3$2.ɵNgNoValidate, selector: "form:not([ngNoForm]):not([ngNativeValidate])" }, { kind: "directive", type: i3$2.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3$2.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3$2.NgControlStatusGroup, selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],form:not([ngNoForm]),[ngForm]" }, { kind: "directive", type: i3$2.FormGroupDirective, selector: "[formGroup]", inputs: ["formGroup"], outputs: ["ngSubmit"], exportAs: ["ngForm"] }, { kind: "directive", type: i3$2.FormControlName, selector: "[formControlName]", inputs: ["formControlName", "disabled", "ngModel"], outputs: ["ngModelChange"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchTermFilterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'hxp-search-term-filter', imports: [CommonModule, MatButtonModule, MatIconModule, MatFormFieldModule, MatInputModule, MatSelectModule, ReactiveFormsModule, TranslatePipe], providers: [SearchTermFilterService], template: "<form\n    class=\"hxp-search-input\"\n    role=\"search\"\n    [formGroup]=\"filterForm\"\n    (submit)=\"onSearch()\"\n>\n    <div class=\"hxp-search-text\">\n        <mat-form-field\n            appearance=\"outline\"\n            subscriptSizing=\"dynamic\"\n            class=\"hxp-new-search-input\"\n        >\n            <textarea\n                matInput\n                #searchInput\n                type=\"search\"\n                formControlName=\"query\"\n                cdkTextareaAutosize\n                cdkAutosizeMinRows=\"1\"\n                cdkAutosizeMaxRows=\"3\"\n                placeholder=\"{{ 'SEARCH.INPUT.PLACEHOLDER' | translate }}\"\n                [attr.aria-label]=\"'SEARCH.INPUT.ARIA_LABEL' | translate\"\n                [errorStateMatcher]=\"errorStateMatcher\"\n                (input)=\"onInput()\"\n                (keydown.enter)=\"onSearch($event)\"\n            ></textarea>\n\n            @if (searchInput?.value?.length && filterForm.get('query')?.value) {\n                <div\n                    matSuffix\n                    class=\"hxp-search-text-suffix-container\"\n                >\n                    <button\n                        mat-icon-button\n                        class=\"hxp-clear\"\n                        [attr.aria-label]=\"'SEARCH.INPUT.CLEAR_INPUT' | translate\"\n                        (click)=\"onClear()\"\n                    >\n                        <mat-icon\n                            aria-hidden=\"true\"\n                            svgIcon=\"x_large\"\n                        />\n                    </button>\n                </div>\n            }\n        </mat-form-field>\n    </div>\n</form>\n", styles: [".hxp-search-input .hxp-search-text{display:flex;justify-content:space-between;flex-grow:1}.hxp-search-input .hxp-search-text .hxp-new-search-input{flex:1}.hxp-search-input textarea{width:100%;resize:none}.hxp-search-text-suffix-container{align-items:center;border-left:1px solid var(--mat-sys-outline);display:flex;height:56px;justify-content:center;width:56px}\n"] }]
        }], propDecorators: { searchType: [{
                type: Input
            }], searchTerm: [{
                type: Input
            }], searchTermChanged: [{
                type: Output
            }] } });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFilterHarness extends ComponentHarness {
    constructor() {
        super(...arguments);
        this.getLabel = this.locatorForOptional('.hxp-search-filter-chip-label');
        this.getExpandIcon = this.locatorForOptional(MatIconHarness.with({ selector: '.hxp-search-filter-chip-icon' }));
        this.getBadge = this.locatorForOptional('.hxp-search-filter-chip-badge');
        this.getApplyButton = this.documentRootLocatorFactory().locatorForOptional(MatButtonHarness.with({ selector: '.hxp-search-filter-overlay-actions-apply' }));
        this.getClearButton = this.documentRootLocatorFactory().locatorForOptional(MatButtonHarness.with({ selector: '.hxp-search-filter-overlay-actions-clear' }));
        this.getOverlayBackdrop = this.documentRootLocatorFactory().locatorForOptional('.cdk-overlay-backdrop');
        this.getChip = this.locatorForOptional('.hxp-search-filter-chip');
        this.getOverlayContainer = this.documentRootLocatorFactory().locatorForOptional('.hxp-search-filter-overlay');
    }
    static { this.hostSelector = '.hxp-search-filter'; }
    async isOpen() {
        return !!(await this.getOverlayContainer());
    }
    async open() {
        const chip = await this.getChip();
        return chip ? chip.click() : undefined;
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BaseSearchFilterDirective, CONTEXT_MENU_ACTIONS_PROVIDERS, ContentDeleteButtonComponent, ContentPropertiesViewerButtonComponent, ContentPropertyViewerActionService, ContentShareButtonActionService, ContentShareButtonComponent, ContentShareDialogComponent, ContentTypeIconComponent, CreatedDateSearchFiltersComponent, DIALOG_MIN_WIDTH, DeleteButtonActionService, DialogConfig, DocumentCategorySearchFiltersComponent, DocumentMoreActionComponent, FileTypeSearchFilterComponent, FileTypeSearchFilterTreeComponent, FormatDocumentPathDirective, HxpBreadcrumbComponent, HxpDocumentListComponent, HxpDocumentTreeComponent, HxpMetadataSidebarComponent, HxpUiBreadcrumbComponent, HxpUiDocumentViewerComponent, ManageColumnButtonComponent, ManageVersionsSidebarComponent, PermissionsButtonActionService, PermissionsManagementDialogComponent, PermissionsManagementPanelComponent, PropertiesViewerContentComponent, SearchFilterContainerComponent, SearchFilterHarness, SearchFilterInputComponent, SearchNoResultsComponent, SearchTermFilterComponent, SearchTermFilterData, SearchTermFilterValue, SingleItemDownloadButtonActionService, SingleItemDownloadButtonComponent, TableSkeletonLoaderComponent, TreeSkeletonLoaderComponent, VersionDeleteButtonComponent, VersionRestoreComponent };
//# sourceMappingURL=alfresco-adf-hx-content-services-ui.mjs.map
