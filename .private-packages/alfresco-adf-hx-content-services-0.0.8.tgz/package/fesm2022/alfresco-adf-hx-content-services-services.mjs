import { AsyncPipe, Location, DOCUMENT, DatePipe } from '@angular/common';
import { CardViewBaseItemModel, DecimalNumberPipe, LocalizedDatePipe, FileSizePipe, CardViewTextItemModel, CardViewSelectItemModel, CardViewIntItemModel, CardViewFloatItemModel, CardViewDateItemModel, CardViewBoolItemModel, provideTranslations, NotificationService, DownloadService, TimeAgoPipe, TranslationService, StorageService, UserPreferencesService, UserPreferenceValues } from '@alfresco/adf-core';
import * as i0 from '@angular/core';
import { inject, Injectable, Pipe, InjectionToken, makeEnvironmentProviders, signal } from '@angular/core';
import { from, of, combineLatest, map as map$1, Subject, BehaviorSubject, timer, merge, concat } from 'rxjs';
import { map, shareReplay, switchMap, catchError, tap, filter, take, scan, takeWhile, last, toArray, takeUntil, distinctUntilChanged, debounceTime, finalize, delay } from 'rxjs/operators';
import { USER_API_TOKEN, COPY_API_TOKEN, MOVE_API_TOKEN, CHECKIN_API_TOKEN, VERSION_API_TOKEN, DEFAULT_REPOSITORY_ID, DOCUMENT_API_TOKEN, QUERY_API_TOKEN, ROOT_DOCUMENT, FieldType, MODEL_API_TOKEN, ADF_HX_CONTENT_SERVICES_API_PROVIDERS, RENDITIONS_API_TOKEN, DOWNLOAD_API_TOKEN, GROUP_API_TOKEN } from '@alfresco/adf-hx-content-services/api';
import { TranslateService } from '@ngx-translate/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { FeaturesServiceToken } from '@alfresco/adf-core/feature-flags';
import { ADF_HX_CONTENT_SERVICES_INTERNAL } from '@alfresco/adf-hx-content-services/features';
import { toSignal, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ExtensionService } from '@alfresco/adf-extensions';
import { FlatTreeControl } from '@angular/cdk/tree';

class UserService {
    constructor() {
        this.cache = new Map();
        this.userApi = inject(USER_API_TOKEN);
    }
    resolveUser(id) {
        if (this.cache.has(id)) {
            return this.cache.get(id);
        }
        const user$ = from(this.userApi.getUserById(id)).pipe(map((res) => {
            return res.data;
        }), shareReplay(1));
        this.cache.set(id, user$);
        return user$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: UserService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: UserService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: UserService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class UserResolverService {
    constructor() {
        this.userService = inject(UserService);
    }
    // Note: since some user related fields are already resolved, we need to support them here.
    parse(userData) {
        if (!userData || userData.length === 0) {
            return of('');
        }
        const users$ = userData.map((data) => (typeof data === 'string' ? this.resolveUser(data) : this.getFullName(data)));
        return combineLatest(users$).pipe(map((userNames) => userNames.join(',')));
    }
    resolveUser(id) {
        return this.userService.resolveUser(id).pipe(switchMap((user) => this.getFullName(user)));
    }
    getFullName(user) {
        return of(`${user.firstName} ${user.lastName}`);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: UserResolverService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: UserResolverService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: UserResolverService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
/**
 * A pipe that resolves the user data into a string representation of user names.
 * The user data can be a string representing a User id, a User object, an array of User ids or User objects, or undefined.
 *
 * @remarks
 * Developers using this pipe need to configure/provide the `userApiProvider` provider somewhere.
 *
 * @param userData - The user data to transform. It can be a string representing a User id, a User object, an array of User ids or User objects, or undefined.
 * @returns An Observable that emits a string representation of user names.
 *
 * @example
 * Users is a mixed array of User ids and User Objects:
 * ```typescript
 * users = ['user-id-1', 'user-id-2', { id: 'user-id-3', firstName: 'John', lastName: 'Doe' }];
 * ```
 * Pipe usage:
 * ```html
 * <div>{{ users | hxpUserResolverPipe }}</div>
 * ```
 */
class UserResolverPipe {
    constructor() {
        this.asyncPipe = inject(AsyncPipe);
        this.userResolverService = inject(UserResolverService);
    }
    transform(userData) {
        if (!userData) {
            return '';
        }
        const userDataArray = Array.isArray(userData) ? userData : [userData];
        return this.asyncPipe.transform(this.userResolverService.parse(userDataArray)) || '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: UserResolverPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.20", ngImport: i0, type: UserResolverPipe, isStandalone: true, name: "hxpUserResolverPipe", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: UserResolverPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'hxpUserResolverPipe',
                    pure: false,
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const CopyStatus = {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SingleItemCopyService {
    constructor() {
        this.copyApi = inject(COPY_API_TOKEN);
    }
    copy(copyDocumentId, name, targetParentId) {
        return from(this.copyApi.copy(copyDocumentId, 'default', { name, targetParentId })).pipe(map((response) => ({ document: response.data, status: CopyStatus.SUCCESS })), catchError(() => of({ document: undefined, status: CopyStatus.ERROR })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemCopyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemCopyService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemCopyService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const MoveStatus = {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SingleItemMoveService {
    constructor() {
        this.moveApi = inject(MOVE_API_TOKEN);
    }
    move(moveDocumentId, targetParentId) {
        return from(this.moveApi.move(moveDocumentId, 'default', {
            targetParentId,
        })).pipe(map((response) => ({ document: response.data, status: MoveStatus.SUCCESS })), catchError(() => of({ document: undefined, status: MoveStatus.ERROR })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemMoveService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemMoveService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleItemMoveService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DOCUMENT_SERVICE = new InjectionToken('DOCUMENT_SERVICE');
class SharedDocumentService {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SharedDocumentService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SharedDocumentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SharedDocumentService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class CreateDocumentVersionService {
    constructor() {
        this.checkInApi = inject(CHECKIN_API_TOKEN);
    }
    checkin(documentId, minor, repositoryId) {
        return from(this.checkInApi.checkin(documentId, minor, repositoryId)).pipe(map$1((response) => response.data));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CreateDocumentVersionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CreateDocumentVersionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: CreateDocumentVersionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class RestoreDocumentVersionService {
    constructor() {
        this.versionApi = inject(VERSION_API_TOKEN);
    }
    restore(versionId, repositoryId) {
        return from(this.versionApi.restoreVersion(versionId, repositoryId)).pipe(map$1((response) => response.data));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RestoreDocumentVersionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RestoreDocumentVersionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RestoreDocumentVersionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentService extends SharedDocumentService {
    constructor() {
        super(...arguments);
        this.folderishSort = 'sys_isFolderish desc';
        this.defaultSort = [this.folderishSort, 'sys_title asc'];
        this.documentCreatedSubject = new Subject();
        this.documentDeletedSubject = new Subject();
        this.documentSelectionClearSubject = new Subject();
        this.documentLoadedSubject = new BehaviorSubject(undefined);
        this.documentCopiedSubject = new Subject();
        this.documentMovedSubject = new Subject();
        this.documentRestoredSubject = new Subject();
        this.documentRequestReloadSubject = new Subject();
        this.documentUpdatedSubject = new BehaviorSubject({
            updatedProperties: new Map(),
        });
        this.repositoryId = DEFAULT_REPOSITORY_ID;
        this.documentApi = inject(DOCUMENT_API_TOKEN);
        this.queryApi = inject(QUERY_API_TOKEN);
        this.versionApi = inject(VERSION_API_TOKEN);
        this.copyService = inject(SingleItemCopyService);
        this.moveService = inject(SingleItemMoveService);
        this.createDocumentVersionService = inject(CreateDocumentVersionService);
        this.restoreDocumentVersionService = inject(RestoreDocumentVersionService);
        this.documentCreated$ = this.documentCreatedSubject.asObservable();
        this.documentDeleted$ = this.documentDeletedSubject.asObservable();
        this.documentLoaded$ = this.documentLoadedSubject.asObservable();
        this.documentCopied$ = this.documentCopiedSubject.asObservable();
        this.documentMoved$ = this.documentMovedSubject.asObservable();
        this.clearDocumentSelection$ = this.documentSelectionClearSubject.asObservable();
        this.documentRequestReload$ = this.documentRequestReloadSubject.asObservable();
        this.documentUpdated$ = this.documentUpdatedSubject.asObservable();
        this.documentRestored$ = this.documentRestoredSubject.asObservable();
    }
    setCurrentRepository(repositoryId) {
        this.repositoryId = repositoryId;
    }
    getDocumentById(documentId, repositoryId = this.repositoryId) {
        return from(this.documentApi.getDocumentById(documentId, repositoryId)).pipe(map((res) => res.data));
    }
    getDocumentByPath(path, repositoryId = this.repositoryId) {
        return from(this.documentApi.getDocumentByPath(path, repositoryId)).pipe(map((res) => res.data));
    }
    getAncestors(documentId, repositoryId = this.repositoryId) {
        return from(this.documentApi.getDocumentAncestors(documentId, repositoryId)).pipe(map((res) => (res.data && Array.isArray(res.data.ancestors) ? res.data.ancestors : [])), map((ancestors) => [{ ...ROOT_DOCUMENT }, ...ancestors]));
    }
    getAllChildren(parentId, options, repositoryId = this.repositoryId) {
        return this.getChildrenByNamedQuery('advanced_document_content', parentId, options, repositoryId);
    }
    getFolderChildren(parentId, repositoryId = this.repositoryId, options) {
        return this.getChildrenByNamedQuery('tree_children', parentId, options, repositoryId);
    }
    createDocument(properties, repositoryId = this.repositoryId) {
        const getSource = () => {
            if (properties.sys_parentId) {
                return this.documentApi.createDocumentUnderParentById(properties.sys_parentId, repositoryId, properties);
            }
            if (properties.sys_parentPath) {
                return this.documentApi.createDocumentUnderParentByPath(properties.sys_parentPath, repositoryId, properties);
            }
            return this.documentApi.createDocumentUnderParentById(ROOT_DOCUMENT.sys_id, repositoryId, properties);
        };
        return from(getSource()).pipe(map((res) => res.data), tap((data) => this.documentCreatedSubject.next(data)));
    }
    deleteDocument(documentId, repositoryId = this.repositoryId) {
        return from(this.documentApi.deleteDocumentById(documentId, repositoryId)).pipe(tap(() => this.documentDeletedSubject.next(documentId)), map(() => documentId));
    }
    updateDocument(documentId, updatedProperties, repositoryId = this.repositoryId) {
        return from(this.documentApi.updateDocumentById(documentId, repositoryId, updatedProperties, undefined)).pipe(map((res) => res.data), tap((data) => {
            this.documentUpdatedSubject.next({
                document: data,
                updatedProperties: new Map(Object.entries(updatedProperties)),
            });
        }));
    }
    copyDocument(documentId, name, targetParentId) {
        return this.copyService.copy(documentId, name, targetParentId).pipe(tap((response) => {
            if (response.status === CopyStatus.SUCCESS) {
                this.documentCopiedSubject.next(response.document);
            }
        }));
    }
    moveDocument(documentId, targetParentId) {
        return this.moveService.move(documentId, targetParentId).pipe(tap((response) => {
            if (response.status === MoveStatus.SUCCESS) {
                this.documentMovedSubject.next(response.document);
            }
        }));
    }
    createDocumentVersion(documentId, minor = false, repositoryId = this.repositoryId) {
        return this.createDocumentVersionService.checkin(documentId, minor, repositoryId).pipe(filter((documentVersion) => !!documentVersion), switchMap(() => this.getDocumentById(documentId, repositoryId)), tap((document) => {
            this.documentUpdatedSubject.next({
                document,
                updatedProperties: new Map(Object.entries({ sysver_isCheckedIn: document['sysver_isCheckedIn'] })),
            });
        }));
    }
    restoreVersion(documentId, repositoryId = this.repositoryId) {
        return this.restoreDocumentVersionService.restore(documentId, repositoryId).pipe(tap((document) => {
            this.documentRestoredSubject.next(document);
        }));
    }
    notifyDocumentLoaded(document) {
        this.documentLoadedSubject.next(document);
    }
    notifyDocumentCreated(document) {
        this.documentCreatedSubject.next(document);
    }
    clearSelectionDocumentList() {
        this.documentSelectionClearSubject.next();
    }
    requestReload() {
        this.documentRequestReloadSubject.next();
    }
    getChildrenByNamedQuery(queryName, parentId, options, repositoryId = this.repositoryId) {
        const query = {
            queryName,
            parameters: {
                parentId,
            },
            sort: this.getSortOption(options),
            limit: options?.limit || 10000,
            offset: options?.offset || 0,
            repositoryId,
        };
        return from(this.queryApi.getDocumentsByNamedQuery(query)).pipe(map(({ data }) => {
            return {
                documents: data.documents || [],
                limit: data.limit || 0,
                offset: data.offset || 0,
                totalCount: data.totalCount || 0,
            };
        }));
    }
    getSortOption(options = { sort: [], limit: 0, offset: 0 }) {
        const { sort } = options;
        return sort.length > 0 ? sort : this.defaultSort;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ComplexFieldCardViewItemModel extends CardViewBaseItemModel {
    constructor(cardViewItemProperties, complexCardViewItemProperties) {
        super(cardViewItemProperties);
        this.type = 'complex';
        this.property = cardViewItemProperties.key;
        this.complexCardViewItemProperties = complexCardViewItemProperties;
    }
    get displayValue() {
        const cardItems = [];
        for (const field of this.value) {
            const cardItem = this.createCardItem(`${this.property}.${field.name}`);
            cardItems.push(...cardItem);
        }
        return cardItems;
    }
    createCardItem(property) {
        return this.complexCardViewItemProperties.propertyUtilService.createCardItemUtil(property, this.complexCardViewItemProperties.model, this.complexCardViewItemProperties.document);
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const RecordStatus = {
    Incomplete: 'Incomplete',
    Ready: 'Ready',
    UnderRetention: 'UnderRetention',
    ReachedDisposition: 'ReachedDisposition',
    OnHold: 'OnHold',
};
const BLOCK_EDIT_STATUSES = [RecordStatus.OnHold, RecordStatus.UnderRetention, RecordStatus.ReachedDisposition];
const BLOCK_DELETE_STATUSES = [RecordStatus.OnHold, RecordStatus.UnderRetention];
const ViewMode = {
    Cases: 'Cases',
    Records: 'Records',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const isRoot = (document) => !!(document?.sys_primaryType === 'SysRoot');
const isFolder = (document) => !!document?.sys_isFolderish;
const isFile = (document) => !!document?.sys_mixinTypes?.includes('SysFilish');
const isVersionable = (document) => !!document?.sys_mixinTypes?.includes('SysVersionable');
const isVersion = (document) => !!document?.['sysver_isVersion'];
const hasBlob = (document, xpath = 'sysfile_blob') => !!document?.[xpath];
const hasRenditionBlob = (document) => hasBlob(document, 'sysrendition_blob');
const hasPermission = (document, permission) => !!document?.['sys_effectivePermissions']?.includes(permission);
const isDocumentParentFolder = (document, targetFolder) => document.sys_parentId === targetFolder.sys_id;
const isGovernable = (document) => !!document?.sys_mixinTypes?.includes('SysGovernable');
const isSysGovRecord = (document) => !!document?.['sysgov_isRecord'];
const hasLegalHold = (document) => !!document?.['sysgov_hasLegalHold'];
// Type :any is required in here for the optional chaining. With :unknown type the compiler doesn't allow to
// use optional chaining on the error object as it doesn't know if it's an object or not.
const isPermissionError = (error) => {
    // Check for Angular HttpErrorResponse (status at top level)
    if (error?.status === 403) {
        return true;
    }
    // Check for nested response.status (e.g., axios-style errors)
    if (error?.response?.status === 403) {
        return true;
    }
    return false;
};
const getRetentionStatus = (document) => {
    if (!isGovernable(document) || !isSysGovRecord(document)) {
        return undefined;
    }
    if (hasLegalHold(document)) {
        return RecordStatus.OnHold;
    }
    const retainUntil = document?.['sysgov_retainUntil'];
    if (retainUntil) {
        const now = new Date();
        const retainDate = new Date(retainUntil);
        return retainDate > now ? RecordStatus.UnderRetention : RecordStatus.ReachedDisposition;
    }
    return undefined;
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PropertyUtilService {
    constructor() {
        this.DEFAULT_EXCLUDED_SCHEMAS = ['system', 'sysfile', 'sysfiles', 'sysversionable', 'sysgovernable'];
        this.TOP_DEFAULT_PROPERTIES = [
            'sys_title',
            'sys_primaryType',
            'sys_description',
            'sys_created',
            'sys_modified',
            'sys_creator',
            'sys_lastContributor',
            'sysfile_blob',
        ];
        this.OTHER_PROPERTIES = ['sys_contributors', 'sys_path'];
        this.REQUIRED_PROPERTIES = ['sys_title', 'sysfile_blob.filename', 'sys_primaryType'];
        this.EDITABLE_DEFAULT_PROPERTIES = ['sys_title', 'sys_primaryType', 'sys_description', 'sysfile_blob'];
        this.NON_EDITABLE_DEFAULT_PROPERTIES = [
            'sys_created',
            'sys_modified',
            'sys_creator',
            'sys_lastContributor',
            'sys_contributors',
            'sys_path',
            'sysfile_blob.length',
            'sysfile_blob.mimeType',
        ];
        this.decimalNumberPipe = inject(DecimalNumberPipe);
        this.userResolverPipe = inject(UserResolverPipe);
        this.translationService = inject(TranslateService);
        this.localizedDatePipe = inject(LocalizedDatePipe);
        this.fileSizePipe = inject(FileSizePipe);
        this.documentService = inject(DocumentService);
    }
    createCardItemUtil(property, model, document) {
        const type = this.propertyType(model, property);
        const defaultParameters = this.setupDefaultCardParameters(property, document, model);
        switch (type) {
            case FieldType.Boolean:
            case FieldType.BooleanArray: {
                return [new CardViewBoolItemModel(defaultParameters)];
            }
            case FieldType.Date:
            case FieldType.DateArray: {
                return [
                    new CardViewDateItemModel({
                        ...defaultParameters,
                        format: 'mediumDate',
                    }),
                ];
            }
            case FieldType.Float:
            case FieldType.FloatArray: {
                return [
                    new CardViewFloatItemModel({
                        ...defaultParameters,
                        pipes: [{ pipe: this.decimalNumberPipe }],
                    }),
                ];
            }
            case FieldType.Integer:
            case FieldType.IntegerArray: {
                return [new CardViewIntItemModel(defaultParameters)];
            }
            case FieldType.User:
            case FieldType.UserArray: {
                return [
                    new CardViewTextItemModel({
                        ...defaultParameters,
                        multivalued: false,
                        pipes: [{ pipe: this.userResolverPipe }], // TODO - remove it once all user fields are resolved at the server level
                    }),
                ];
            }
            case FieldType.Blob: {
                return this.createBlobCardItems(property, document, model);
            }
            case FieldType.String: {
                return property === 'sys_primaryType'
                    ? [
                        new CardViewSelectItemModel({
                            ...defaultParameters,
                            options$: this.availableDocumentCategories(model, document),
                            displayNoneOption: false,
                        }),
                    ]
                    : [new CardViewTextItemModel(defaultParameters)];
            }
            default: {
                return [new CardViewTextItemModel(defaultParameters)];
            }
        }
    }
    propertyType(model, property) {
        return model?.getFieldType(property);
    }
    setupDefaultCardParameters(property, document, model) {
        const isEditable = this.TOP_DEFAULT_PROPERTIES.includes(property)
            ? this.EDITABLE_DEFAULT_PROPERTIES.includes(property)
            : !this.NON_EDITABLE_DEFAULT_PROPERTIES.includes(property);
        const params = {
            label: this.translateProperty(property),
            value: this.propertyValue(property, document, model),
            key: property,
            multivalued: model?.isMultivaluedType(this.propertyType(model, property)),
            editable: isEditable,
        };
        return params;
    }
    translateProperty(key) {
        const splitIndex = key.indexOf('_');
        if (splitIndex === -1) {
            return '';
        }
        let schemaPrefix = key.slice(0, Math.max(0, splitIndex));
        let propName = key.slice(Math.max(0, splitIndex + 1));
        if (schemaPrefix && propName) {
            // eslint-disable-next-line unicorn/prefer-string-replace-all
            propName = propName.replace(new RegExp(/[A-Z]/, 'g'), (letter) => `_${letter.toLowerCase()}`).toUpperCase();
            // eslint-disable-next-line unicorn/prefer-string-replace-all
            schemaPrefix = schemaPrefix.replace(new RegExp(/[A-Z]/, 'g'), (letter) => `_${letter.toLowerCase()}`).toUpperCase();
            const translationKey = `DOCUMENT.PROPERTIES.${schemaPrefix}.${propName}`;
            const translation = this.translationService.instant(translationKey);
            return translation === translationKey ? propName : translation;
        }
        return '';
    }
    propertyValue(property, document, model) {
        const propertyTypeValue = this.propertyType(model, property);
        const propertyValue = this.getPropertyValueFromDocument(property, document);
        switch (propertyTypeValue) {
            case FieldType.Complex: {
                return this.getComplexPropertyValue(property, document, model);
            }
            case FieldType.BlobArray: {
                return this.getBlobArrayPropertyValue(property, document);
            }
            case FieldType.Boolean:
            case FieldType.BooleanArray: {
                return !!propertyValue;
            }
            default: {
                return propertyValue;
            }
        }
    }
    createBlobCardItems(property, document, model) {
        const properties = ['filename', 'mimeType', 'length'].map((prop) => `${property}.${prop}`);
        return [
            new CardViewTextItemModel({
                ...this.setupDefaultCardParameters(properties[0], document, model),
            }),
            new CardViewTextItemModel({
                ...this.setupDefaultCardParameters(properties[1], document, model),
            }),
            new CardViewTextItemModel({
                ...this.setupDefaultCardParameters(properties[2], document, model),
                pipes: [{ pipe: this.fileSizePipe }],
            }),
        ];
    }
    getComplexPropertyValue(property, document, model) {
        return Object.entries(document[property]).map((entry) => ({
            name: this.translateProperty(`${property}.${entry[0]}`),
            value: this.propertyType(model, `${property}.${entry[0]}`) === FieldType.Date
                ? this.localizedDatePipe.transform(entry[1], 'mediumDate')
                : entry[1],
        }));
    }
    getBlobArrayPropertyValue(property, document) {
        return Object.values(document[property]).map((entry) => entry.filename);
    }
    getPropertyValueFromDocument(property, document) {
        return property.split('.').reduce((val, prop) => (val = val && val[prop]), document);
    }
    availableDocumentCategories(model, document) {
        if (!model) {
            return of([]);
        }
        let subTypes = [];
        if (isFile(document)) {
            subTypes = [...subTypes, ...model.getFilishTypes()];
        }
        if (isFolder(document)) {
            subTypes = [...subTypes, ...model.getFolderishTypes()];
        }
        const uniqueSubTypes = [...new Set(subTypes)];
        if (uniqueSubTypes.length > 0) {
            return of(uniqueSubTypes.map((subType) => ({ label: subType, key: subType })));
        }
        return this.documentService.getDocumentById(document.sys_parentId || ROOT_DOCUMENT.sys_id).pipe(catchError((error) => {
            if (error?.response?.status === 403) {
                return of(ROOT_DOCUMENT);
            }
            throw error;
        }), map((parentDocument) => [{ label: parentDocument.sys_primaryType, key: parentDocument.sys_primaryType }]));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PropertyUtilService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PropertyUtilService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PropertyUtilService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

const DOCUMENT_PROPERTIES_SERVICE = new InjectionToken('DOCUMENT_PROPERTIES_SERVICE');
class SharedDocumentPropertiesService {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SharedDocumentPropertiesService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SharedDocumentPropertiesService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SharedDocumentPropertiesService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const multivaluedTypes = new Set([
    FieldType.BlobArray,
    FieldType.BooleanArray,
    FieldType.DateArray,
    FieldType.FloatArray,
    FieldType.IntegerArray,
    FieldType.StringArray,
    FieldType.UserArray,
]);
const DEFAULT_EXCLUDED_SCHEMAS = new Set([
    'system',
    'sysfile',
    'sysfiles',
    'sysrelation',
    'sysrendition',
    'sysvocab',
    'user',
    'group',
    'sysversionable',
    'sysgovernable',
]);
class DocumentModel {
    constructor(model) {
        this.model = model;
        this.SYS_ROOT = 'SysRoot';
    }
    get documentModel() {
        return this.model;
    }
    getFieldConstraints(field) {
        const fieldDefinition = this.getFieldDefinition(field);
        return fieldDefinition?.constraints;
    }
    getFieldType(field) {
        let rawType = '';
        let type = FieldType.String;
        try {
            const fieldDefinition = this.getFieldDefinition(field);
            if (!fieldDefinition) {
                return FieldType.String;
            }
            if (fieldDefinition.type) {
                rawType = fieldDefinition.type;
            }
            else if (this.hasResolver(fieldDefinition)) {
                rawType = this.getResolverType(fieldDefinition);
            }
            else if (fieldDefinition.extends) {
                rawType = fieldDefinition.extends;
            }
            else if (fieldDefinition.fields) {
                return FieldType.Complex;
            }
            else if (fieldDefinition.list?.type) {
                return `${this.resolveType(fieldDefinition.list.type)}[]`;
            }
            type = this.resolveType(rawType);
        }
        catch (error) {
            console.error(error);
        }
        return type;
    }
    isMultivaluedType(type) {
        return !!type && multivaluedTypes.has(type);
    }
    isFieldTypeArray(fieldType) {
        return (fieldType === FieldType.FloatArray ||
            fieldType === FieldType.IntegerArray ||
            fieldType === FieldType.DateArray ||
            fieldType === FieldType.StringArray ||
            fieldType === FieldType.BooleanArray ||
            fieldType === FieldType.UserArray ||
            fieldType === FieldType.BlobArray);
    }
    getComplexFieldDetails(fieldName) {
        const fieldSchema = this.getSchemaByPrefix(fieldName);
        if (!fieldSchema?.fields) {
            return [];
        }
        const matchingField = fieldSchema.fields[fieldName];
        if (!matchingField) {
            return [];
        }
        const matchingFieldType = matchingField.type || 'string';
        // If the field has its own subfields defined inline
        if (matchingField.fields) {
            return Object.entries(matchingField.fields).map(([name, fieldDef]) => ({
                name,
                type: this.resolveType(fieldDef.type),
            }));
        }
        // If the field type is complex and references a pre-defined type
        if (this.resolveType(matchingFieldType) === FieldType.Complex && this.model?.types?.[matchingFieldType]) {
            const complexType = this.model.types[matchingFieldType];
            if (!complexType?.fields) {
                return [];
            }
            return Object.entries(complexType.fields).map(([name, fieldDef]) => ({
                name,
                type: this.resolveType(fieldDef.type),
            }));
        }
        return [];
    }
    resolveType(type = 'string') {
        if (!this.model?.types || !this.model.types[type]) {
            return type;
        }
        const typeObj = this.model.types[type];
        if (typeObj.extends) {
            return typeObj.extends;
        }
        if (typeObj.list) {
            if (this.hasResolver(typeObj.list)) {
                return `${this.resolveType(this.getResolverType(typeObj.list))}[]`;
            }
            return `${this.resolveType(typeObj.list?.extends || typeObj.list?.type || '')}[]`;
        }
        if (type === FieldType.Blob) {
            return FieldType.Blob;
        }
        if (typeObj.fields) {
            return FieldType.Complex;
        }
        return `${typeObj}`;
    }
    getSubtypes(primaryType) {
        return this.model?.primaryTypes?.[primaryType]?.subtypes || this.getAllTypes();
    }
    getFilishTypes() {
        return this.getAllTypes().filter((type) => this.hasMixin(type, 'SysFilish'));
    }
    getFolderishTypes() {
        return this.getAllTypes().filter((type) => this.hasMixin(type, 'SysFolderish'));
    }
    hasMixin(primaryType, mixin) {
        const typeObj = this.model?.primaryTypes?.[primaryType];
        if (!typeObj) {
            return false;
        }
        const parentType = typeObj.extends;
        return !!typeObj.mixins?.includes(mixin) || !!(parentType && this.hasMixin(parentType, mixin));
    }
    getAllTypes() {
        if (!this.model?.primaryTypes) {
            return [];
        }
        return Object.keys(this.model?.primaryTypes).filter((category) => category !== this.SYS_ROOT);
    }
    isCustomSchema(schemaName) {
        return !DEFAULT_EXCLUDED_SCHEMAS.has(schemaName);
    }
    /**
     * Checks if a primary type inherits from a target type by recursively traversing the type hierarchy.
     * This method checks the entire inheritance chain, not just the immediate parent.
     *
     * The method includes circular reference detection to prevent infinite recursion.
     *
     * @param sourceType - The primary type to check
     * @param targetType - The target type to check inheritance from
     * @returns true if sourceType inherits from targetType (directly or transitively), false otherwise
     */
    inherits(sourceType, targetType) {
        return this.checkInheritance(sourceType, targetType, []);
    }
    checkInheritance(sourceType, targetType, visitedTypes) {
        if (!this.model?.primaryTypes || !sourceType || !targetType) {
            return false;
        }
        // Check for circular reference to prevent infinite recursion
        if (visitedTypes.includes(sourceType)) {
            return false;
        }
        const primaryTypeObj = this.model.primaryTypes[sourceType];
        if (!primaryTypeObj) {
            return false;
        }
        if (sourceType === targetType) {
            return true;
        }
        if (primaryTypeObj.extends) {
            return this.checkInheritance(primaryTypeObj.extends, targetType, [...visitedTypes, sourceType]);
        }
        return false;
    }
    getSchemaByPrefix(fieldName) {
        const fieldPrefix = fieldName.split('_')[0];
        const fieldKey = fieldName.split('.')[0];
        return Object.values(this.getSchemas()).find((schema) => schema.prefix === fieldPrefix && schema.fields && Object.keys(schema.fields).includes(fieldKey));
    }
    hasResolver(field) {
        return !!this.getResolverType(field);
    }
    getResolverType(field) {
        return field?.constraints?.resolver?.type;
    }
    getSchemas() {
        return this.model.schemas || {};
    }
    getFieldDefinition(field) {
        const res = field.split('_').filter(Boolean);
        let returnValue;
        if (res.length > 1) {
            const fieldPrefix = res[0];
            const fieldSchema = this.getSchemaByPrefix(field);
            if (fieldSchema) {
                const restOfString = res.slice(1).join('_');
                if (restOfString.includes('.')) {
                    const [firstPart, secondPart] = restOfString.split('.');
                    const subfieldKey = `${fieldPrefix}_${firstPart}`;
                    const subfield = fieldSchema.fields?.[subfieldKey];
                    if (subfield?.fields) {
                        returnValue = subfield.fields[secondPart];
                    }
                    else if (subfield?.type && this.model.types) {
                        const typeDefinition = this.model.types[subfield.type];
                        if (typeDefinition && typeDefinition.fields) {
                            returnValue = typeDefinition.fields[secondPart];
                        }
                    }
                }
                else {
                    returnValue = fieldSchema.fields?.[field];
                }
            }
        }
        return returnValue;
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentModelService {
    constructor() {
        this.errored = false;
        this.modelApi = inject(MODEL_API_TOKEN);
    }
    getModel() {
        if (!this.model$ || this.errored) {
            this.errored = false;
            this.model$ = from(this.modelApi.getModel()).pipe(map((response) => new DocumentModel(response.data)), catchError((error) => {
                this.errored = true;
                if (error.status === 400 || error.response?.status === 400) {
                    console.warn('User cannot access the document model.');
                    return of(new DocumentModel({}));
                }
                throw error;
            }));
        }
        return this.model$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentModelService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentModelService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentModelService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class DocumentPropertiesService extends SharedDocumentPropertiesService {
    constructor() {
        super(...arguments);
        this.documentModelService = inject(DocumentModelService);
        this.propertyUtilService = inject(PropertyUtilService);
    }
    getPropertiesFromDocument(document, options) {
        if (!document) {
            return of([]);
        }
        return this.fetchDocumentModel().pipe(map(() => Object.keys(document)
            .filter(this.filterProperty(options))
            .flatMap((property) => this.getCardItem(property, document))
            .sort(this.sortCardsByLabel.bind(this))), catchError((error) => {
            console.error('Error fetching properties from document:', error);
            return of([]);
        }));
    }
    getDefaultPropertiesFromDocument(document) {
        if (!document) {
            return of([]);
        }
        return this.fetchDocumentModel().pipe(map(() => {
            const documentProperties = Object.keys(document);
            const defaultCards = this.propertyUtilService.TOP_DEFAULT_PROPERTIES.filter((property) => documentProperties.includes(property)).flatMap((property) => this.getCardItem(property, document));
            const otherCards = Object.keys(document)
                .filter(this.filterProperty({
                include: {
                    properties: this.propertyUtilService.OTHER_PROPERTIES,
                },
            }))
                .flatMap((property) => this.getCardItem(property, document))
                .sort(this.sortCardsByLabel.bind(this));
            return [...defaultCards, ...otherCards];
        }), catchError(() => of([])));
    }
    isRequired(property) {
        const propertyConstraints = this.model?.getFieldConstraints(property);
        return propertyConstraints?.['nullable'] === false;
    }
    propertyType(property) {
        return this.model ? this.propertyUtilService.propertyType(this.model, property) : undefined;
    }
    isFieldTypeArray(property) {
        return this?.model?.isFieldTypeArray(property);
    }
    /**
     * Extracts schema information for a given primary type.
     *
     * Returns an array of schema objects, each containing:
     * - schema: The schema name
     * - fields: A record of field names with their initialized values
     *
     * System schemas are always included. Custom schemas can be optionally included.
     *
     * @param primaryType - The primary type to extract schemas for (e.g., 'hyland:document')
     * @param options - Configuration options for schema extraction
     * @returns Observable that emits an array of schema tree objects
     *
     * @example
     * ```typescript
     * // Get system schemas only (default)
     * documentPropertiesService.extractSchemas('hyland:document')
     *   .subscribe(schemas => { ... });
     *
     * // Get both system and custom schemas
     * documentPropertiesService.extractSchemas('hyland:document', { includeCustomProperties: true })
     *   .subscribe(schemas => { ... });
     * ```
     */
    extractSchemas(primaryType, options) {
        return this.fetchModelAndSchemas(primaryType).pipe(map(({ documentModel, schemas }) => this.buildSchemaTree(documentModel, schemas, options)));
    }
    /**
     * Extracts custom schema fields for a given primary type as a flat record.
     *
     * Returns a single flattened object containing all custom schema fields merged together,
     * with field names as keys and their initialized values.
     *
     * @param primaryType - The primary type to extract schema fields for (e.g., 'hyland:document')
     * @returns Observable that emits a flat record of custom schema fields
     *
     * @example
     * ```typescript
     * documentPropertiesService.extractCustomSchemaFields('hyland:document')
     *   .subscribe(fields => {
     *     console.log('All custom fields:', fields);
     *   });
     * ```
     */
    extractCustomSchemaFields(primaryType) {
        return this.fetchModelAndSchemas(primaryType).pipe(map(({ documentModel, schemas }) => this.getCustomSchemaFields(documentModel, schemas, { includeCustomProperties: true })));
    }
    getRequiredProperties() {
        return this.propertyUtilService.REQUIRED_PROPERTIES;
    }
    buildSchemaTree(documentModel, schemas, options) {
        const schemaFields = [];
        const allSchemas = documentModel.documentModel.schemas || {};
        const includeSystem = options?.includeSystemProperties !== false;
        const includeCustom = options?.includeCustomProperties === true;
        for (const schemaName of schemas) {
            const isSystemSchema = this.propertyUtilService.DEFAULT_EXCLUDED_SCHEMAS.includes(schemaName);
            const isCustomSchema = !isSystemSchema;
            const shouldInclude = (isSystemSchema && includeSystem) || (isCustomSchema && includeCustom);
            if (shouldInclude && allSchemas[schemaName] !== undefined) {
                const properties = {};
                this.populateCustomSchemaFields(documentModel, properties, allSchemas[schemaName].fields);
                schemaFields.push({ schema: schemaName, fields: properties });
            }
        }
        return schemaFields;
    }
    fetchModelAndSchemas(primaryType) {
        return this.fetchDocumentModel().pipe(map((documentModel) => {
            const schemas = this.getCustomSchemas(documentModel, primaryType);
            return { documentModel, schemas };
        }));
    }
    getCustomSchemas(customModel, primaryType) {
        const primaryTypeFileSchema = this.extractCustomSchema(primaryType, customModel.documentModel.primaryTypes);
        return primaryTypeFileSchema.filter((schemaName) => !this.propertyUtilService.DEFAULT_EXCLUDED_SCHEMAS.includes(schemaName));
    }
    getCustomSchemaFields(customModel, schemas, options) {
        const customSchemaFields = {};
        const allCustomSchemas = customModel.documentModel.schemas || {};
        const includeSystem = options?.includeSystemProperties !== false;
        const includeCustom = options?.includeCustomProperties === true;
        for (const schemaName of schemas) {
            const isSystemSchema = this.propertyUtilService.DEFAULT_EXCLUDED_SCHEMAS.includes(schemaName);
            const isCustomSchema = !isSystemSchema;
            const shouldInclude = (isSystemSchema && includeSystem) || (isCustomSchema && includeCustom);
            if (shouldInclude && allCustomSchemas[schemaName] !== undefined) {
                this.populateCustomSchemaFields(customModel, customSchemaFields, allCustomSchemas[schemaName].fields);
            }
        }
        return customSchemaFields;
    }
    extractCustomSchema(primaryType, primaryTypes, visited = []) {
        // If no primary types are defined, return empty array.
        // Or, if circular inheritance is detected, stop recursion to prevent stack overflow.
        if (!primaryTypes?.[primaryType] || visited.includes(primaryType)) {
            return [];
        }
        visited.push(primaryType);
        const primaryTypeFileSchema = primaryTypes[primaryType].schemas ?? [];
        const parentPrimaryType = primaryTypes[primaryType].extends || '';
        const parentSchemas = parentPrimaryType.length > 0 ? this.extractCustomSchema(parentPrimaryType, primaryTypes, visited) : [];
        return [...parentSchemas, ...primaryTypeFileSchema];
    }
    populateCustomSchemaFields(customModel, customSchemaFields, schemaFields) {
        for (const fieldName in schemaFields) {
            if (schemaFields[fieldName] !== undefined) {
                const fieldType = this.propertyType(fieldName);
                if (fieldType === FieldType.Complex) {
                    this.handleComplexFieldType(customModel, customSchemaFields, fieldName, schemaFields);
                }
                else {
                    customSchemaFields[fieldName] = '';
                }
            }
        }
    }
    handleComplexFieldType(customModel, customSchemaFields, fieldName, schemaFields) {
        const complexField = schemaFields[fieldName];
        if (complexField.fields) {
            customSchemaFields[fieldName] = {};
            const inlineFields = Object.keys(complexField.fields);
            for (const inlineField of inlineFields) {
                customSchemaFields[fieldName][inlineField] = '';
            }
        }
        else {
            const nestedFields = this.getNestedFields(schemaFields[fieldName], customModel.documentModel.types);
            customSchemaFields[fieldName] = nestedFields;
        }
    }
    getNestedFields(fieldProperties, types) {
        const fieldsWithType = types[fieldProperties.type].fields;
        const result = {};
        for (const key in fieldsWithType) {
            if (fieldsWithType[key]) {
                result[key] = '';
            }
        }
        return result;
    }
    fetchDocumentModel() {
        return this.documentModelService.getModel().pipe(take(1), tap((model) => (this.model = model)), shareReplay());
    }
    getCardItem(property, document) {
        const type = this.propertyType(property);
        switch (type) {
            case FieldType.Complex: {
                return this.createComplexCardItems(property, document);
            }
            default: {
                return this.propertyUtilService.createCardItemUtil(property, this.model, document);
            }
        }
    }
    createComplexCardItems(property, document) {
        const complexCardViewItemProperties = {
            document,
            model: this.model,
            propertyUtilService: this.propertyUtilService,
        };
        const complexFieldGroupCardViewItem = new ComplexFieldCardViewItemModel({
            label: this.propertyUtilService.translateProperty(property),
            value: this.model?.getComplexFieldDetails(property),
            key: property,
        }, complexCardViewItemProperties);
        return complexFieldGroupCardViewItem.displayValue;
    }
    filterProperty(options) {
        const exclude = options?.exclude;
        const include = options?.include;
        return (property) => {
            if (exclude?.schemas?.some((schemaPrefix) => property.startsWith(schemaPrefix))) {
                return false;
            }
            if (exclude?.properties?.includes(property)) {
                return false;
            }
            if (include?.schemas && !include.schemas.some((schemaPrefix) => property.startsWith(schemaPrefix))) {
                return false;
            }
            if (include?.properties && !include.properties.includes(property)) {
                return false;
            }
            return true;
        };
    }
    sortCardsByLabel(card1, card2) {
        return card1.label.localeCompare(card2.label);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentPropertiesService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentPropertiesService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentPropertiesService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const PERMISSIONS_MANAGEMENT_COMPONENT_TYPE = new InjectionToken('PERMISSIONS_MANAGEMENT_COMPONENT_TYPE', {
    factory: () => 'dialog',
});
const USER_RESOLVER_PROVIDERS = [UserResolverPipe, AsyncPipe];
const DOCUMENT_PROVIDERS = [
    { provide: DOCUMENT_SERVICE, useExisting: DocumentService },
    { provide: DOCUMENT_PROPERTIES_SERVICE, useExisting: DocumentPropertiesService },
];
function provideAdfEnterpriseAdfHxContentServicesServices() {
    return makeEnvironmentProviders([
        ...ADF_HX_CONTENT_SERVICES_API_PROVIDERS,
        ...USER_RESOLVER_PROVIDERS,
        ...DOCUMENT_PROVIDERS,
        provideTranslations('adf-enterprise-adf-hx-content-services-services', 'assets/adf-enterprise-adf-hx-content-services-services'),
    ]);
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class RenditionsService {
    constructor() {
        this.renditionsApi = inject(RENDITIONS_API_TOKEN);
    }
    getRendition(documentId, renditionId, repositoryId = DEFAULT_REPOSITORY_ID) {
        return from(this.renditionsApi.getRendition(documentId, renditionId, repositoryId)).pipe(map(({ data }) => data));
    }
    requestRenditionCreation(documentId, sysrendition_id, repositoryId = DEFAULT_REPOSITORY_ID) {
        const rendition = { sysrendition_id };
        return from(this.renditionsApi.createRendition(documentId, repositoryId, rendition)).pipe(map(({ data }) => data));
    }
    listRenditions(documentId, repositoryId = DEFAULT_REPOSITORY_ID) {
        return from(this.renditionsApi.getRenditions(documentId, repositoryId)).pipe(map(({ data }) => data));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RenditionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RenditionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RenditionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentCacheService {
    constructor() {
        this.documentCache = new Map();
        this.documentService = inject(DocumentService);
        this.documentService.documentUpdated$.subscribe({
            next: ({ document }) => {
                if (document && document.sys_id) {
                    this.invalidate(document.sys_id);
                }
            },
            error: (error) => console.error(error),
        });
    }
    getDocumentCache() {
        return this.documentCache;
    }
    getDocument(documentId) {
        return this.documentCache.get(documentId) ?? this.fetchDocument(documentId);
    }
    invalidate(documentId) {
        this.documentCache.delete(documentId);
    }
    fetchDocument(documentId) {
        const cachedResult$ = this.documentService.getDocumentById(documentId)?.pipe(shareReplay(1));
        this.documentCache.set(documentId, cachedResult$);
        return cachedResult$;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentCacheService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentCacheService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentCacheService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class HxpNotificationService {
    constructor() {
        this.notificationService = inject(NotificationService);
    }
    showInfo(message, config, interpolateArgs) {
        this.openSnackBar(message, 'info', config, interpolateArgs);
    }
    showSuccess(message, config, interpolateArgs) {
        this.openSnackBar(message, 'done', config, interpolateArgs);
    }
    showError(message, config, interpolateArgs) {
        this.openSnackBar(message, 'error', config, interpolateArgs);
    }
    openSnackBar(message, decorativeIcon = 'info', config, interpolateArgs) {
        const configWithIcon = {
            ...config,
            data: { ...config?.data, decorativeIcon },
        };
        configWithIcon.panelClass = ['hxp-snack-bar-container', 'hxp-snack-bar-type-' + decorativeIcon];
        this.notificationService.openSnackMessage(message, configWithIcon, interpolateArgs);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpNotificationService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpNotificationService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: HxpNotificationService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const HXP_DOCUMENT_COPY_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_COPY_ACTION_SERVICE');
const HXP_DOCUMENT_MOVE_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_MOVE_ACTION_SERVICE');
const HXP_DOCUMENT_SHARE_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_SHARE_ACTION_SERVICE');
const HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE');
const HXP_DOCUMENT_DELETE_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_DELETE_ACTION_SERVICE');
const HXP_DOCUMENT_PERMISSIONS_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_PERMISSIONS_ACTION_SERVICE');
const HXP_DOCUMENT_INFO_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_INFO_ACTION_SERVICE');
const HXP_DOCUMENT_REPLACE_FILE_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_REPLACE_FILE_ACTION_SERVICE');
const HXP_DOCUMENT_CREATE_DOCUMENT_VERSION_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_CREATE_DOCUMENT_VERSION_ACTION_SERVICE');
const HXP_MANAGE_COLUMN_ACTION_SERVICE = new InjectionToken('HXP_MANAGE_COLUMN_ACTION_SERVICE');
const HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE');
const HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE');
const HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE = new InjectionToken('HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE');

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentActionService {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentActionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentActionService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentActionService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DocumentPermissions = {
    CREATE_CHILD: 'CreateChild',
    CREATE_VERSION: 'CreateVersion',
    DELETE: 'Delete',
    DELETE_CHILD: 'DeleteChild',
    EVERYTHING: 'Everything',
    MANAGE_LOCK: 'ManageLock',
    MANAGE_RETENTION: 'ManageRetention',
    READ: 'Read',
    READ_WRITE: 'ReadWrite',
    WRITE: 'Write',
    WRITE_VERSION: 'WriteVersion',
    MANAGE_SECURITY: 'ManageSecurity',
    READ_VERSION: 'ReadVersion',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SidebarService {
    constructor() {
        this.panel = signal(null);
    }
    togglePanel(panelType) {
        if (this.isPanelOpened(panelType)) {
            this.closePanel();
        }
        else {
            this.panel.set(panelType);
        }
    }
    closePanel() {
        this.panel.set(null);
    }
    isPanelOpened(panel) {
        return this.panel() === panel;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SidebarService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SidebarService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SidebarService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ManageVersionsButtonActionService extends DocumentActionService {
    constructor() {
        super(...arguments);
        this.sidebarService = inject(SidebarService);
    }
    isAvailable(context) {
        return (context.documents?.length === 1 &&
            isVersionable(context.documents[0]) &&
            hasPermission(context.documents[0], DocumentPermissions.READ_VERSION));
    }
    execute() {
        this.sidebarService.togglePanel('version');
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageVersionsButtonActionService, deps: null, target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageVersionsButtonActionService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ManageVersionsButtonActionService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ContextMenuActionsService {
    constructor() {
        this.documentDeleteHandler = inject(HXP_DOCUMENT_DELETE_ACTION_SERVICE);
        this.documentPermissionsHandler = inject(HXP_DOCUMENT_PERMISSIONS_ACTION_SERVICE);
        this.documentShareHandler = inject(HXP_DOCUMENT_SHARE_ACTION_SERVICE);
        this.documentSingleItemDownloadHandler = inject(HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE);
        this.documentInfoHandler = inject(HXP_DOCUMENT_INFO_ACTION_SERVICE);
        // copy and move actions are still declared under workspace-hxp.
        // Customer devs have to implement their own implementations since those actions are outside the lib.
        // We can't be sure that an implementation is provided so we marked them as @Optional.
        this.documentCopyHandler = inject(HXP_DOCUMENT_COPY_ACTION_SERVICE, { optional: true });
        this.documentMoveHandler = inject(HXP_DOCUMENT_MOVE_ACTION_SERVICE, { optional: true });
        this.replaceFileHander = inject(HXP_DOCUMENT_REPLACE_FILE_ACTION_SERVICE, { optional: true });
        this.createVersionHander = inject(HXP_DOCUMENT_CREATE_DOCUMENT_VERSION_ACTION_SERVICE, { optional: true });
        this.manageVersionsHandler = inject(ManageVersionsButtonActionService, { optional: true });
    }
    getContextActions(data, parentDocument) {
        const context = {
            documents: [data],
            parentDocument,
        };
        const actions = [
            {
                data,
                model: {
                    key: 'download',
                    icon: 'download',
                    title: 'SINGLE_FILE_DOWNLOAD.TOOLBAR.BUTTONS.DOWNLOAD.TITLE',
                    visible: this.documentSingleItemDownloadHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentSingleItemDownloadHandler, context),
            },
            {
                data,
                model: {
                    key: 'share',
                    icon: 'share',
                    title: 'DOCUMENT_SHARE.TOOLBAR.BUTTONS.SHARE.TITLE',
                    visible: this.documentShareHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentShareHandler, context),
            },
            {
                data,
                model: {
                    key: 'delete',
                    icon: 'trash',
                    title: 'DOCUMENT_DELETE.APP.TOOLBAR.BUTTONS.DELETE.TITLE',
                    visible: this.documentDeleteHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentDeleteHandler, context),
            },
        ];
        if (this.documentCopyHandler) {
            actions.push({
                data,
                model: {
                    key: 'copy',
                    icon: 'copy',
                    title: 'APP.TOOLBAR.BUTTONS.COPY.TITLE',
                    visible: this.documentCopyHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentCopyHandler, context),
            });
        }
        if (this.documentMoveHandler) {
            actions.push({
                data,
                model: {
                    key: 'move',
                    icon: 'move',
                    title: 'APP.TOOLBAR.BUTTONS.MOVE.TITLE',
                    visible: this.documentMoveHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.documentMoveHandler, context),
            });
        }
        actions.push({
            data,
            model: {
                key: 'permissions-management',
                icon: 'users',
                title: 'APP.TOOLBAR.BUTTONS.PERMISSIONS_MANAGEMENT.TITLE',
                visible: this.documentPermissionsHandler.isAvailable(context),
            },
            subject: this.toContextAction(this.documentPermissionsHandler, context),
        }, {
            data,
            model: {
                key: 'doc-info',
                icon: 'info',
                title: 'APP.TOOLBAR.BUTTONS.INFO.TITLE',
                visible: this.documentInfoHandler.isAvailable(context),
            },
            subject: this.toContextAction(this.documentInfoHandler, context),
        });
        if (this.replaceFileHander) {
            actions.push({
                data,
                model: {
                    key: 'replace',
                    icon: 'attach_file',
                    title: 'APP.TOOLBAR.BUTTONS.REPLACE_FILE.TITLE',
                    visible: this.replaceFileHander.isAvailable(context),
                },
                subject: this.toContextAction(this.replaceFileHander, context),
            });
        }
        if (this.createVersionHander) {
            actions.push({
                data,
                model: {
                    key: 'version',
                    icon: 'save',
                    title: 'APP.TOOLBAR.BUTTONS.DOCUMENT_VERSION.TITLE',
                    visible: this.createVersionHander.isAvailable(context),
                },
                subject: this.toContextAction(this.createVersionHander, context),
            });
        }
        if (this.manageVersionsHandler) {
            actions.push({
                data,
                model: {
                    key: 'manage-versions',
                    icon: 'clock',
                    title: 'MANAGE_VERSIONS.TOOLBAR.BUTTONS.VERSIONS.TITLE',
                    visible: this.manageVersionsHandler.isAvailable(context),
                },
                subject: this.toContextAction(this.manageVersionsHandler, { ...context }),
            });
        }
        return actions;
    }
    toContextAction(documentActionService, context) {
        const subject = new Subject();
        subject.subscribe({
            next: () => {
                documentActionService.execute(context);
            },
        });
        return subject;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContextMenuActionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContextMenuActionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContextMenuActionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class RouterExtService {
    constructor() {
        this.router = inject(Router);
        this.route = inject(ActivatedRoute);
        this.currentUrl = this.router.url;
        this.router.events.subscribe((event) => {
            if (event instanceof NavigationEnd) {
                this.previousUrl = this.currentUrl;
                this.currentUrl = event.url;
            }
        });
    }
    getPreviousUrl() {
        return this.previousUrl;
    }
    redirectToReferer(refererURL, defaultPath) {
        if (/search/i.test(refererURL)) {
            void this.router.navigateByUrl(refererURL);
        }
        else {
            void this.router.navigate([defaultPath], { relativeTo: this.route });
        }
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RouterExtService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RouterExtService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: RouterExtService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class BlobDownloadService {
    constructor() {
        this.downloadApi = inject(DOWNLOAD_API_TOKEN);
    }
    downloadBlob(documentId, property = 'sysfile_blob', repositoryId = DEFAULT_REPOSITORY_ID) {
        return from(this.downloadApi.downloadByIdAndXPath(documentId, property, false, repositoryId, { responseType: 'blob' })).pipe(map(({ data }) => data));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: BlobDownloadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: BlobDownloadService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: BlobDownloadService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const RenditionStatus = {
    PENDING: 'PENDING',
    COMPLETED: 'COMPLETED',
    FAILED: 'FAILED',
};
const DEFAULT_RENDITION_ID = 'pdfPreview';
/**
 * Resubscribes with the switchMapTo to the stream it's used on until the
 * `isPollingActive` function returns false or `maxAttempt` is exceeded.
 * @param {number} [pollInterval] delay between every re-subscription
 * @param {fn => boolean} [isPollingActive] function returning boolean value defining the stream should resubscribe
 * @param {number} [maxAttempts] how many tries should the poll do
 * @param {boolean} [emitOnlyLast] flag to determine if all returned by the subscription values should be emitted or
 * only the last one
 */
function pollWhile(pollInterval, isPollingActive, maxAttempts = Number.POSITIVE_INFINITY, emitOnlyLast = false) {
    return (source$) => {
        const poll$ = timer(0, pollInterval).pipe(scan((attempts) => ++attempts, 0), tap(attemptsGuardFactory(maxAttempts)), switchMap(() => source$), takeWhile(isPollingActive, true));
        return emitOnlyLast ? poll$.pipe(last()) : poll$;
    };
}
function attemptsGuardFactory(maxAttempts) {
    return (attemptsCount) => {
        if (attemptsCount > maxAttempts) {
            throw new Error('Exceeded maxAttempts');
        }
    };
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class IsSingleDocumentWithMainBlobService {
    constructor() {
        this.featuresService = inject(FeaturesServiceToken);
        this.isDocumentLayoutFeatureFlagOn = toSignal(this.featuresService.isOn$(ADF_HX_CONTENT_SERVICES_INTERNAL.CIC_WORKSPACE_DOCUMENT_LAYOUT_TOGGLE));
    }
    /**
     * Checks if the given array of documents represents a single document with a valid file blob.
     *
     * @param documents - The array of documents to be checked.
     * @returns A boolean value indicating whether the array represents a single document with a valid file blob.
     */
    validate(documents) {
        return this.isSingleDocument(documents) && this.hasValidFileBlob(documents[0]);
    }
    isSingleDocument(documents) {
        if (this.isDocumentLayoutFeatureFlagOn()) {
            return documents.length === 1;
        }
        else {
            return documents.length === 1 && !documents[0].sys_isFolderish;
        }
    }
    hasValidFileBlob({ sysfile_blob }) {
        return Boolean(sysfile_blob?.filename);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: IsSingleDocumentWithMainBlobService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: IsSingleDocumentWithMainBlobService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: IsSingleDocumentWithMainBlobService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const permissionMap = {
    [DocumentPermissions.MANAGE_SECURITY]: { value: 'PERMISSION_LEVEL.LABEL.EVERYTHING', class: 'everything' },
    [DocumentPermissions.READ_WRITE]: { value: 'PERMISSION_LEVEL.LABEL.READ_WRITE', class: 'readWrite' },
    [DocumentPermissions.READ]: { value: 'PERMISSION_LEVEL.LABEL.READ', class: 'read' },
};
/**
 * Transforms an array of effective permissions into a PermissionInfo object.
 *
 * @param effectivePermissions - The array of effective permissions.
 * @returns The PermissionInfo object representing the permission level, or undefined if the array is empty or no matching permission is found.
 *
 * @example
 * ```html
 * <div>{{ effectivePermissions | permissionLevel }}</div>
 * ```
 */
class PermissionLevelPipe {
    transform(effectivePermissions = []) {
        const emptyPermission = { value: '', class: '' };
        if (effectivePermissions.length === 0) {
            return emptyPermission;
        }
        if (effectivePermissions.includes(DocumentPermissions.MANAGE_SECURITY)) {
            return permissionMap[DocumentPermissions.MANAGE_SECURITY];
        }
        if (effectivePermissions.includes(DocumentPermissions.READ_WRITE)) {
            return permissionMap[DocumentPermissions.READ_WRITE];
        }
        if (effectivePermissions.includes(DocumentPermissions.READ)) {
            return permissionMap[DocumentPermissions.READ];
        }
        return emptyPermission;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionLevelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.20", ngImport: i0, type: PermissionLevelPipe, isStandalone: true, name: "permissionLevel" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionLevelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'permissionLevel',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentMoreMenuItemsFactoryService {
    constructor() {
        this.extensionService = inject(ExtensionService);
        this.featuresService = inject(FeaturesServiceToken);
    }
    getMoreMenuItems() {
        const featureName = 'document';
        const actionType = 'menu';
        return this.extensionService.setup$.pipe(filter((config) => this.hasFeature(featureName, config)), map((config) => config.features?.[featureName]), map((actionsRef) => {
            const menuActions = actionsRef.filter((actionRef) => actionRef.type === actionType);
            // Last non-null wins for icon and title (allows client extensions to override defaults)
            const icon = menuActions.map((a) => a.icon).filter(Boolean).pop();
            const title = menuActions.map((a) => a.title).filter(Boolean).pop();
            // Merge all children from all menu contributions and sort by order, then by id for deterministic ordering
            const mergedChildren = menuActions
                .flatMap((action) => action.children || [])
                .sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || (a.id ?? '').localeCompare(b.id ?? ''));
            return { id: 'more-menu', type: actionType, icon, title, children: mergedChildren };
        }), switchMap((config) => this.filterItemsByFeatureFlag(config)), filter((moreMenuAction) => !!moreMenuAction.children?.length), shareReplay(1));
    }
    hasFeature(featureName, config) {
        const feature = config?.features?.[featureName];
        return feature !== undefined && Array.isArray(feature);
    }
    filterItemsByFeatureFlag(config) {
        return from(config.children || []).pipe(switchMap((item) => this.shouldIncludeItem(item).pipe(filter((shouldInclude) => shouldInclude), map(() => item))), toArray(), map((filteredItems) => ({ ...config, children: filteredItems })));
    }
    shouldIncludeItem(item) {
        // Adding the `take(1)` to force the observable to complete, otherwise the upstream will never complete
        return item.rules?.['featureFlag'] ? this.featuresService.isOn$(item.rules['featureFlag']).pipe(take(1)) : of(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentMoreMenuItemsFactoryService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentMoreMenuItemsFactoryService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentMoreMenuItemsFactoryService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsPanelRequestService {
    constructor() {
        this.sidebarService = inject(SidebarService);
    }
    requestOpenPanel() {
        this.sidebarService.togglePanel('permission');
    }
    requestClosePanel() {
        this.sidebarService.closePanel();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsPanelRequestService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsPanelRequestService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsPanelRequestService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentRouterService {
    constructor() {
        this.location = inject(Location);
        this.router = inject(Router);
        this.document = inject(DOCUMENT);
    }
    /**
     * Returns the URL for the given document.
     * By default, the URL is relative to the current location, except when the `absolute` option is set to `true`.
     */
    urlFor(document, options = { absolute: false }) {
        return this.urlForId(document?.sys_id || '', document?.sys_repository, options);
    }
    /**
     * Returns the URL for the parent of the given document.
     * By default, the URL is relative to the current location, except when the `absolute` option is set to `true`.
     */
    urlForParent(document, options = { absolute: false }) {
        return this.urlForId(document?.sys_parentId || '', document?.sys_repository, options);
    }
    /**
     * Navigates to the given document.
     */
    navigateTo(document, extras) {
        const url = this.urlFor(document);
        void this.router.navigateByUrl(url, extras);
    }
    /**
     * Returns the URL for the given document id.
     */
    urlForId(documentId, repositoryId = DEFAULT_REPOSITORY_ID, options = { absolute: false }) {
        if (options?.absolute) {
            return this.absoluteUrlForId(documentId, repositoryId);
        }
        const urlTree = this.router.createUrlTree(['/', repositoryId, 'documents', documentId]);
        const relativeUrl = this.router.serializeUrl(urlTree);
        return relativeUrl;
    }
    absoluteUrlForId(documentId = '', repositoryId = DEFAULT_REPOSITORY_ID) {
        const urlTree = this.router.createUrlTree(['/', repositoryId, 'documents']);
        const relativeUrl = this.router.serializeUrl(urlTree);
        const preparedUrl = this.location.prepareExternalUrl(relativeUrl);
        const formattedUrl = preparedUrl.startsWith('/') ? preparedUrl : `/${preparedUrl}`;
        const windowRef = this.document.defaultView;
        if (!windowRef) {
            throw new Error('Window reference is not available');
        }
        const href = windowRef.location.href;
        const origin = windowRef.location.origin;
        const deployedApplicationAndCustomUi = href.slice(origin.length, href.indexOf(formattedUrl));
        return `${origin}${deployedApplicationAndCustomUi}${formattedUrl}/${documentId}`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentRouterService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentRouterService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentRouterService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const initialState = {
    permissions: [],
    loading: false,
    activeTab: 'group',
    searchUserField: '',
    searchGroupField: '',
    newUserField: '',
    newGroupField: '',
    suggestedUsers: [],
    suggestedGroups: [],
    initialInheritance: true,
    isInheritanceEnabled: true,
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const UserType = {
    GROUPS: 'GROUPS',
    USERS: 'USERS',
    ALL: 'ALL',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const levels = ['Read', 'ReadWrite', 'Everything'];
const EVERYONE_USER_ID = '__Everyone__';
const EVERYTHING_PERMISSION = 'Everything';
const EFFECTIVE_STATUS = 'EFFECTIVE';
const NOTIFICATION_MESSAGES = {
    restore: {
        success: {
            [UserType.GROUPS]: 'PERMISSIONS_MANAGEMENT_ACTION_STATUS.SNACKBAR.RESTORE_GROUP_SUCCESS',
            [UserType.USERS]: 'PERMISSIONS_MANAGEMENT_ACTION_STATUS.SNACKBAR.RESTORE_USER_SUCCESS',
            [UserType.ALL]: 'PERMISSIONS_MANAGEMENT_ACTION_STATUS.SNACKBAR.RESTORE_SUCCESS',
        },
        error: 'PERMISSIONS_MANAGEMENT_ACTION_STATUS.SNACKBAR.RESTORE_ERROR',
    },
    save: {
        success: 'PERMISSIONS_MANAGEMENT_ACTION_STATUS.SNACKBAR.SAVE_SUCCESS',
        error: 'PERMISSIONS_MANAGEMENT_ACTION_STATUS.SNACKBAR.SAVE_ERROR',
    },
};
const getHighestAce = (acl) => {
    acl.sort((ace1, ace2) => {
        const ace1Level = levels.indexOf(ace1?.permission);
        const ace2Level = levels.indexOf(ace2?.permission);
        return ace2Level - ace1Level;
    });
    return acl.length > 0 ? acl[0] : undefined;
};
const getHighestPermission = (permission1, permission2) => {
    const ace1Level = levels.indexOf(permission1);
    const ace2Level = levels.indexOf(permission2);
    return ace1Level > ace2Level ? permission1 : permission2;
};
const isPermissionInheritanceEnabled = (document) => {
    const { sys_acl = [] } = document;
    return !sys_acl.some((ace) => isAclInheritanceBlocked(ace));
};
const isAclInheritanceBlocked = (ace) => {
    return ace?.user?.id === EVERYONE_USER_ID && ace.permission === EVERYTHING_PERMISSION && ace.status === EFFECTIVE_STATUS && ace.granted === false;
};
function removeUserTypeFromAcl(acl, restoreOption) {
    if (restoreOption === UserType.ALL) {
        return [];
    }
    return acl.filter((row) => {
        switch (restoreOption) {
            case UserType.GROUPS: {
                return !row.group;
            }
            case UserType.USERS: {
                return !row.user;
            }
            default: {
                return false;
            }
        }
    });
}
function getNotificationMessage(isSuccess, restoreType) {
    const actionType = restoreType ? 'restore' : 'save';
    if (isSuccess) {
        return restoreType ? NOTIFICATION_MESSAGES.restore.success[restoreType] : NOTIFICATION_MESSAGES.save.success;
    }
    return NOTIFICATION_MESSAGES[actionType].error;
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsDataAccessService {
    constructor() {
        this.hxpNotificationService = inject(HxpNotificationService);
        this.documentService = inject(DocumentService);
    }
    updateDocument(id, acl, restoreType) {
        return this.documentService.updateDocument(id, { sys_acl: acl }).pipe(map(() => {
            const message = getNotificationMessage(true, restoreType);
            this.hxpNotificationService.showSuccess(message);
            return true;
        }), catchError(() => {
            const message = getNotificationMessage(false, restoreType);
            this.hxpNotificationService.showError(message);
            return of(false);
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsDataAccessService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsDataAccessService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsDataAccessService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsManagementStateService {
    constructor() {
        this.stateSubject = new BehaviorSubject(initialState);
        this.state$ = this.stateSubject.asObservable();
        this.document$ = this.select(({ document }) => document).pipe(filter((document) => !!document));
        this.loading$ = this.select(({ loading }) => loading);
        this.activeTab$ = this.select(({ activeTab }) => activeTab);
        this.searchUserField$ = this.select(({ searchUserField }) => searchUserField);
        this.searchGroupField$ = this.select(({ searchGroupField }) => searchGroupField);
        this.isInheritanceEnabled$ = this.select(({ isInheritanceEnabled }) => isInheritanceEnabled);
        this.initialInheritance$ = this.select(({ initialInheritance }) => initialInheritance);
        this.permissionsManagementRows$ = this.select(({ permissions }) => permissions);
        this.suggestedUsers$ = this.select(({ suggestedUsers }) => suggestedUsers);
        this.suggestedGroups$ = this.select(({ suggestedGroups }) => suggestedGroups);
        this.suggestedAvailableUsers$ = combineLatest([this.permissionsManagementRows$, this.suggestedUsers$]).pipe(map(([permissions, suggestions]) => suggestions.filter((item) => this.canUserBeSuggested(permissions, item.id))));
        this.suggestedAvailableGroups$ = combineLatest([this.permissionsManagementRows$, this.suggestedGroups$]).pipe(map(([permissions, suggestions]) => suggestions.filter((item) => this.canGroupBeSuggested(permissions, item.id))));
        this.title$ = merge(of('').pipe(takeUntil(this.document$)), this.document$.pipe(map((document) => document.sys_title ?? '')));
        this.sys_id$ = this.document$.pipe(map((document) => document.sys_id ?? ''));
        this.activePermissionsManagementRows$ = combineLatest([
            this.permissionsManagementRows$,
            this.activeTab$,
            this.searchUserField$,
            this.searchGroupField$,
        ]).pipe(map(([permissions, activeTab, searchUserField, searchGroupField]) => {
            const textFields = {
                user: searchUserField,
                group: searchGroupField,
            };
            const textToFilter = textFields[activeTab].toLowerCase();
            return permissions.filter(({ entityType, entityLabel = '' }) => entityType === activeTab && entityLabel.toLowerCase().includes(textToFilter));
        }), shareReplay({ bufferSize: 1, refCount: true }));
        this.isUntouched$ = combineLatest([this.permissionsManagementRows$, this.isInheritanceEnabled$, this.initialInheritance$]).pipe(map(([permissions, isInheritanceEnabled, initialInheritance]) => isInheritanceEnabled === initialInheritance && !permissions.some(({ edited }) => edited)));
        this.hasLocalPermission$ = this.permissionsManagementRows$.pipe(map((permissions) => permissions.some(({ permission }) => permission !== undefined)));
    }
    get publicApi() {
        return {
            title$: this.title$,
            loading$: this.loading$,
            activePermissionsManagementRows$: this.activePermissionsManagementRows$,
            suggestedUsers$: this.suggestedAvailableUsers$,
            suggestedGroups$: this.suggestedAvailableGroups$,
            isUntouched$: this.isUntouched$,
            permissionsManagementRows$: this.permissionsManagementRows$,
            sys_id$: this.sys_id$,
            initialInheritance$: this.initialInheritance$,
            isInheritanceEnabled$: this.isInheritanceEnabled$,
            hasLocalPermission$: this.hasLocalPermission$,
        };
    }
    updateState(stateUpdateFn) {
        this.state$.pipe(take(1)).subscribe({
            next: (state) => {
                const partialState = typeof stateUpdateFn === 'function' ? stateUpdateFn(state) : stateUpdateFn;
                this.stateSubject.next({ ...state, ...partialState });
            },
            error: () => {
                throw new Error('[PermissionsManagementStateService]: error updating state');
            },
        });
    }
    select(fn) {
        return this.state$.pipe(map(fn), distinctUntilChanged(), shareReplay({ bufferSize: 1, refCount: true }));
    }
    canUserBeSuggested(permissions = [], id = '') {
        return (!!id &&
            permissions.every((permission) => permission.entityId !== id || (!permission.permission && permission.inheritedPermission !== 'Everything')));
    }
    canGroupBeSuggested(permissions = [], id = '') {
        return !!id && permissions.every((permission) => permission.entityId !== id);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementStateService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementStateService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementStateService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const getEntityPropertiesFromGroup = (entity) => {
    return {
        entityId: entity.id ?? '',
        entityType: 'group',
        entityLabel: `${entity.name || ''}`.trim(),
        entity,
    };
};
const getEntityPropertiesFromUser = (entity) => {
    const entityId = entity.id ?? '';
    const entityLabel = entity.firstName || entity.lastName ? `${entity.firstName || ''} ${entity.lastName || ''}`.trim() : entityId;
    return {
        entityId: entityId,
        entityType: 'user',
        entityLabel: entityLabel,
        entity,
    };
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsParserHelper {
    getAclGroupedByPermissionsEntity({ sys_acl = [], sys_effectiveAcl = [] }) {
        const aclGroupedByEntity = new Map();
        for (const ace of sys_effectiveAcl) {
            if (this.isValidAce(ace)) {
                const [entity] = this.getEntityFromAce(ace);
                const key = `${entity.entityType}_${entity.entityId}`;
                const entityAclData = aclGroupedByEntity.get(key) ?? { entity, local: [], inherited: [] };
                if (this.isAcePresentInAcl(ace, sys_acl)) {
                    const acl = entityAclData.local;
                    aclGroupedByEntity.set(key, { ...entityAclData, local: [...acl, ace] });
                }
                else {
                    const acl = entityAclData.inherited;
                    aclGroupedByEntity.set(key, { ...entityAclData, inherited: [...acl, ace] });
                }
            }
        }
        return [...aclGroupedByEntity.values()];
    }
    isValidAce(ace) {
        return (ace.user || ace.group) && ace.granted && ace.status === 'EFFECTIVE';
    }
    getEntityFromAce(ace) {
        const permissionEntity = [];
        if (ace.user) {
            permissionEntity.push(getEntityPropertiesFromUser(ace.user));
        }
        else if (ace.group) {
            permissionEntity.push(getEntityPropertiesFromGroup(ace.group));
        }
        return permissionEntity;
    }
    isAcePresentInAcl(aceToFind, acl) {
        const entityToFind = this.getEntityFromAce(aceToFind);
        return acl.some((ace) => ace.granted === aceToFind.granted &&
            ace.permission === aceToFind.permission &&
            ace.begin === aceToFind.begin &&
            ace.creator === aceToFind.creator &&
            ace.end === aceToFind.end &&
            ace.status === aceToFind.status &&
            this.isSameEntity(entityToFind, this.getEntityFromAce(ace)));
    }
    isSameEntity([entityToFind], [entity]) {
        return entity.entityId === entityToFind.entityId && entity.entityType === entityToFind.entityType;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsParserHelper, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsParserHelper, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsParserHelper, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const IDENTITY_USER_SERVICE_TOKEN = new InjectionToken('IDENTITY_USER_SERVICE');

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsParserService {
    constructor() {
        this.identityUserService = inject(IDENTITY_USER_SERVICE_TOKEN);
        this.helper = inject(PermissionsParserHelper);
    }
    aclToPermissionsManagementRows(document) {
        const permissionsManagementRows = [];
        const aclGroupedByEntity = this.helper.getAclGroupedByPermissionsEntity(document);
        for (const [index, entityAces] of aclGroupedByEntity.entries()) {
            const { entity, local, inherited } = entityAces;
            const localPermission = getHighestAce(local);
            const inheritedPermission = getHighestAce(inherited);
            permissionsManagementRows.push({
                index,
                ...entity,
                permission: localPermission?.permission,
                isNew: false,
                edited: false,
                inherited: inherited.length > 0,
                inheritedPermission: inheritedPermission ? inheritedPermission.permission : 'None',
                overridden: local.length > 0 && inherited.length > 0,
                originalACE: localPermission ?? inheritedPermission,
            });
        }
        return permissionsManagementRows;
    }
    permissionsManagementRowsToAcl(permissionsManagementRow, isInheritanceEnabled = true) {
        const { id } = this.identityUserService.getCurrentUserInfo();
        return permissionsManagementRow
            .filter((row) => row.permission && row.permission !== 'None' && (!isInheritanceEnabled || this.isPermissionHigherThanInherited(row)))
            .map((row) => {
            const appliedEntity = this.getEntityFromPermissionsManagementRow(row);
            const creator = row.edited || row.isNew ? id : row.originalACE?.creator;
            const granted = row.isNew || row.originalACE?.granted;
            return {
                ...row.originalACE,
                creator,
                granted,
                permission: row.permission,
                ...appliedEntity,
            };
        });
    }
    getEntityPropertiesFromGroups(entities) {
        return entities.map((element) => getEntityPropertiesFromGroup(element));
    }
    getEntityPropertiesFromUsers(entities) {
        return entities.map((element) => getEntityPropertiesFromUser(element));
    }
    getEntityFromPermissionsManagementRow(row) {
        let entity = {};
        if (row.entityType === 'user') {
            entity = { user: row.entity };
        }
        else if (row.entityType === 'group') {
            entity = { group: row.entity };
        }
        return entity;
    }
    isPermissionHigherThanInherited(row) {
        if (!row.permission) {
            return false;
        }
        return row.permission && getHighestPermission(row.permission, row.inheritedPermission) !== row.inheritedPermission;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsParserService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsParserService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsParserService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class PermissionsManagementFacade {
    constructor() {
        this.searchUserFieldSubject = new BehaviorSubject('');
        this.searchGroupFieldSubject = new BehaviorSubject('');
        this.newUserFieldSubject = new BehaviorSubject('');
        this.newGroupFieldSubject = new BehaviorSubject('');
        this.searchUserField$ = this.getDebouncedValueForServerRequestObservable(this.searchUserFieldSubject);
        this.searchGroupField$ = this.getDebouncedValueForServerRequestObservable(this.searchGroupFieldSubject);
        this.newUserField$ = this.getDebouncedValueForServerRequestObservable(this.newUserFieldSubject);
        this.newGroupField$ = this.getDebouncedValueForServerRequestObservable(this.newGroupFieldSubject);
        this.initialized = false;
        this.permissionsManagementStateService = inject(PermissionsManagementStateService);
        this.permissionsParserService = inject(PermissionsParserService);
        this.permissionsDataAccessService = inject(PermissionsDataAccessService);
        this.userApi = inject(USER_API_TOKEN);
        this.groupApi = inject(GROUP_API_TOKEN);
        this.api = this.permissionsManagementStateService.publicApi;
        // when the Individual Users tab will be like the User Groups one (with inherited column)
        // it will be possible to restore back previous/cleaner implementation:
        // this.suggestedIndividuals$ = this.api.suggestedUsers$.pipe(map(this.permissionsParserService.getEntityPropertiesFromUsers));
        this.suggestedIndividuals$ = combineLatest([
            this.api.suggestedUsers$.pipe(map(this.permissionsParserService.getEntityPropertiesFromUsers)),
            this.api.activePermissionsManagementRows$,
        ]).pipe(map(([suggestedUsers, userPermissionsManagementRows]) => suggestedUsers.map((suggestedUser) => {
            const row = userPermissionsManagementRows.find(({ entityId }) => entityId === suggestedUser.entityId);
            const inheritedPermissionEntity = {
                ...suggestedUser,
                inheritedPermission: row?.inheritedPermission,
            };
            return inheritedPermissionEntity;
        })));
        this.suggestedGroups$ = this.api.suggestedGroups$.pipe(map(this.permissionsParserService.getEntityPropertiesFromGroups));
    }
    onInitializePermissionsManagement(document, parentDocument, destroyRef) {
        if (!this.initialized) {
            this.subscribeToKeyboardTypes(destroyRef);
            this.initialized = true;
            const unregisterFn = destroyRef.onDestroy(() => {
                this.initialized = false;
                unregisterFn();
            });
        }
        const isInheritanceEnabled = isPermissionInheritanceEnabled(document);
        const inheritedPermissions = isInheritanceEnabled ? [] : parentDocument?.sys_effectiveAcl || [];
        const permissions = this.permissionsParserService.aclToPermissionsManagementRows({
            sys_acl: document.sys_acl,
            sys_effectiveAcl: [...(document.sys_effectiveAcl || []), ...inheritedPermissions],
        });
        this.permissionsManagementStateService.updateState({
            ...initialState,
            document,
            permissions,
            initialInheritance: isInheritanceEnabled,
            isInheritanceEnabled,
        });
    }
    onUpdateActiveTab(activeTab) {
        this.permissionsManagementStateService.updateState({ activeTab });
    }
    onSearchUserField(searchUserField) {
        this.searchUserFieldSubject.next(searchUserField);
    }
    onSearchGroupField(searchGroupField) {
        this.searchGroupFieldSubject.next(searchGroupField);
    }
    onNewUserField(newUserField) {
        this.newUserFieldSubject.next(newUserField);
    }
    onNewGroupField(newGroupField) {
        this.newGroupFieldSubject.next(newGroupField);
    }
    onAddNewPermissionsManagementRow(newPermissionEntity) {
        this.permissionsManagementStateService.updateState((state) => {
            const index = state.permissions.length;
            const permissionsManagementRow = {
                index,
                ...newPermissionEntity,
                isNew: true,
                edited: true,
                inherited: false,
                overridden: false,
                inheritedPermission: 'None',
            };
            return { permissions: [...state.permissions, permissionsManagementRow] };
        });
    }
    onEditPermissionsManagementRow(permissionsManagementRow) {
        this.permissionsManagementStateService.updateState(({ permissions }) => {
            const permissionIndex = permissionsManagementRow.index;
            if (permissionIndex > -1) {
                permissions = [
                    ...permissions.slice(0, permissionIndex),
                    { ...permissionsManagementRow, edited: true },
                    ...permissions.slice(permissionIndex + 1),
                ];
            }
            return { permissions };
        });
    }
    onUpdateInheritanceState(isEnabled) {
        this.permissionsManagementStateService.updateState({ isInheritanceEnabled: isEnabled });
    }
    updateDocumentAcl() {
        return combineLatest([this.api.sys_id$, this.api.permissionsManagementRows$, this.api.isInheritanceEnabled$]).pipe(take(1), switchMap(([sys_id, permissions, isInheritanceEnabled]) => {
            if (!sys_id) {
                return of(false);
            }
            let acl = this.permissionsParserService.permissionsManagementRowsToAcl(permissions, isInheritanceEnabled);
            acl = isInheritanceEnabled
                ? acl.filter((ace) => !isAclInheritanceBlocked(ace))
                : [
                    ...acl,
                    {
                        user: EVERYONE_USER_ID,
                        permission: EVERYTHING_PERMISSION,
                        granted: false,
                    },
                ];
            return this.permissionsDataAccessService.updateDocument(sys_id, acl);
        }));
    }
    restorePermissionsToInherited(restoreOption) {
        return combineLatest([this.api.sys_id$, this.api.permissionsManagementRows$]).pipe(take(1), map(([sys_id, permissions]) => {
            if (!sys_id) {
                return null;
            }
            const acl = this.permissionsParserService.permissionsManagementRowsToAcl(permissions);
            const filteredAcl = removeUserTypeFromAcl(acl, restoreOption);
            return { sys_id, sys_acl: filteredAcl };
        }), switchMap((data) => data && data.sys_acl !== null ? this.permissionsDataAccessService.updateDocument(data.sys_id, data.sys_acl, restoreOption) : of(false)));
    }
    getDebouncedValueForServerRequestObservable(subject) {
        const observable = subject.asObservable();
        return concat(observable.pipe(take(1)), observable.pipe(debounceTime(1000), distinctUntilChanged()));
    }
    subscribeToKeyboardTypes(destroyRef) {
        this.subscribeAndExecuteFunctionToUpdateState(this.searchUserField$, destroyRef, (searchUserField) => ({
            searchUserField,
        }));
        this.subscribeAndExecuteFunctionToUpdateState(this.searchGroupField$, destroyRef, (searchGroupField) => ({
            searchGroupField,
        }));
        this.subscribeAndExecuteFunctionToUpdateState(this.newUserField$, destroyRef, (newUserField) => {
            const loading = newUserField.length > 0;
            if (loading) {
                void this.requestUserSuggestions(newUserField);
                return { newUserField, loading };
            }
            return { newUserField, loading, suggestedUsers: [] };
        });
        this.subscribeAndExecuteFunctionToUpdateState(this.newGroupField$, destroyRef, (newGroupField) => {
            const loading = newGroupField.length > 0;
            if (loading) {
                void this.requestGroupSuggestions(newGroupField);
                return { newGroupField, loading };
            }
            return { newGroupField, loading, suggestedGroups: [] };
        });
    }
    subscribeAndExecuteFunctionToUpdateState(observable, destroyRef, fn) {
        observable.pipe(distinctUntilChanged(), shareReplay({ bufferSize: 1, refCount: true }), takeUntilDestroyed(destroyRef)).subscribe({
            next: (value) => {
                const payload = fn(value);
                this.permissionsManagementStateService.updateState(payload);
            },
            error: (e) => {
                throw new Error(`[PermissionsManagementFacade]: ${e.message}`);
            },
        });
    }
    async requestUserSuggestions(textToSearch) {
        const { data: suggestedUsers = [] } = await this.userApi.searchUsersByName(textToSearch);
        this.permissionsManagementStateService.updateState({
            suggestedUsers,
            loading: false,
        });
    }
    async requestGroupSuggestions(textToSearch) {
        const { data: suggestedGroups = [] } = await this.groupApi.searchGroups(textToSearch);
        this.permissionsManagementStateService.updateState({
            suggestedGroups,
            loading: false,
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementFacade, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementFacade }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: PermissionsManagementFacade, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class IsSuggestedPermissionEntityValidator {
    createValidator(suggestions$) {
        const distinctSuggestions$ = suggestions$.pipe(distinctUntilChanged(this.isSameArray));
        return ({ value }) => distinctSuggestions$.pipe(take(1), map((suggestions) => this.isValid(value, suggestions) ? null : this.error(value)), catchError(() => of(this.error(value))));
    }
    isValid(value, suggestions) {
        return this.isPermissionEntity(value) && this.suggestionsIncludePermissionEntity(suggestions, value);
    }
    isPermissionEntity(value) {
        return typeof value !== 'string';
    }
    suggestionsIncludePermissionEntity(suggestions, entity) {
        return suggestions.some((suggestion) => entity.entityLabel === suggestion.entityLabel);
    }
    isSameArray(prev, next) {
        return prev.length === next.length && prev.every(({ entityId }, index) => entityId === next[index].entityId);
    }
    error(value) {
        return { suggestedEntity: { value } };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: IsSuggestedPermissionEntityValidator, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: IsSuggestedPermissionEntityValidator, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: IsSuggestedPermissionEntityValidator, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DownloadStatus = {
    REQUEST: 'REQUEST',
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const downloadNotificationMessages = {
    [DownloadStatus.REQUEST]: 'DOWNLOAD_STATUS.SNACKBAR.REQUEST',
    [DownloadStatus.SUCCESS]: 'DOWNLOAD_STATUS.SNACKBAR.SUCCESS',
    [DownloadStatus.ERROR]: 'DOWNLOAD_STATUS.SNACKBAR.ERROR',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const downloadSnackBarTypes = {
    [DownloadStatus.REQUEST]: 'info',
    [DownloadStatus.SUCCESS]: 'done',
    [DownloadStatus.ERROR]: 'error',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SingleFileDownloadService {
    constructor() {
        this.downloadService = inject(DownloadService);
        this.blobDownloadService = inject(BlobDownloadService);
    }
    download(document) {
        const initialDownloadStatus = DownloadStatus.ERROR;
        const downloadStatusSubject = new BehaviorSubject(initialDownloadStatus);
        of(document)
            .pipe(take(1), filter(({ sys_id, sysfile_blob }) => sys_id && sysfile_blob?.filename), tap(() => this.emitDownloadStatusRequest(downloadStatusSubject)), switchMap(({ sys_id }) => this.blobDownloadService.downloadBlob(sys_id)), tap((data) => {
            // downloadService doesn't download the blob, it saves the blob to disk
            this.downloadService.downloadBlob(data, document['sysfile_blob'].filename);
        }))
            .subscribe({
            next: () => this.emitDownloadStatusSuccess(downloadStatusSubject),
            error: () => this.emitDownloadStatusError(downloadStatusSubject),
        });
        return downloadStatusSubject.asObservable();
    }
    emitDownloadStatusError(downloadStatusSubject) {
        downloadStatusSubject.next(DownloadStatus.ERROR);
        downloadStatusSubject.complete();
    }
    emitDownloadStatusSuccess(downloadStatusSubject) {
        downloadStatusSubject.next(DownloadStatus.SUCCESS);
        downloadStatusSubject.complete();
    }
    emitDownloadStatusRequest(downloadStatusSubject) {
        downloadStatusSubject.next(DownloadStatus.REQUEST);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleFileDownloadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleFileDownloadService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SingleFileDownloadService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class FileDownloadService {
    constructor() {
        this.singleFileDownloadService = inject(SingleFileDownloadService);
        this.hxpNotificationService = inject(HxpNotificationService);
        this.isSingleDocumentWithMainBlobService = inject(IsSingleDocumentWithMainBlobService);
    }
    downloadFile(hxpSingleFileDownload) {
        if (this.isSingleDocumentWithMainBlobService.validate(hxpSingleFileDownload)) {
            this.singleFileDownloadService.download(hxpSingleFileDownload[0]).subscribe({
                next: (status) => {
                    this.displayNotificationMessage(status);
                },
                error: () => {
                    this.displayNotificationMessage(DownloadStatus.ERROR);
                },
            });
        }
    }
    displayNotificationMessage(status) {
        this.hxpNotificationService.openSnackBar(downloadNotificationMessages[status], downloadSnackBarTypes[status]);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileDownloadService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileDownloadService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: FileDownloadService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ContentShareService {
    constructor() {
        this.documentRouterService = inject(DocumentRouterService);
    }
    getSingleContentShareLink(document) {
        return document ? this.documentRouterService.urlFor(document, { absolute: true }) : undefined;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ContentShareService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentTreeNode {
    constructor(document, level = 1, isExpandable = false, isLoading = false, isSelectable = true, isSkeleton = false, totalCount = 0, nodeLoaded = new Subject(), loadCancel$ = new Subject()) {
        this.document = document;
        this.level = level;
        this.isExpandable = isExpandable;
        this.isLoading = isLoading;
        this.isSelectable = isSelectable;
        this.isSkeleton = isSkeleton;
        this.totalCount = totalCount;
        this.nodeLoaded = nodeLoaded;
        this.loadCancel$ = loadCancel$;
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DEFAULT_ITEMS_PER_PAGE = 20;

class DocumentTreeDatabaseService {
    constructor() {
        this._getLevel = (node) => node.level;
        this._isExpandable = (node) => node.isExpandable;
        this._dataChange = new BehaviorSubject([]);
        this._treeControl = new FlatTreeControl(this._getLevel, this._isExpandable);
        // Triggered when DataSource.disconnect is called. Do not replace with DestroyRef
        this.destroy$ = new Subject();
        this.documentService = inject(DocumentService);
    }
    get treeControl() {
        return this._treeControl;
    }
    setDocumentTreeRoot(document) {
        this._treeControl.dataNodes = [this.toNode(document)];
    }
    connect(collectionViewer) {
        this._treeControl.expansionModel.changed.pipe(takeUntil(this.destroy$)).subscribe({
            next: (change) => {
                if (change.added || change.removed) {
                    // eslint-disable-next-line rxjs/no-nested-subscribe
                    this._handleTreeControl(change);
                }
            },
        });
        return merge(collectionViewer.viewChange, this._dataChange).pipe(map(() => this._treeControl.dataNodes));
    }
    disconnect() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    openNodeAtIndex(index) {
        const node = this.treeControl.dataNodes[index];
        this._treeControl.expand(node);
        this.toggleNode(node, { expand: true });
    }
    findNodeByDocumentId(documentId) {
        return this._treeControl.dataNodes.find((node) => node.document.sys_id === documentId);
    }
    openNodes(documents) {
        const doc = documents.shift();
        const documentNode = this.findNodeByDocumentId(doc?.sys_id);
        if (documentNode) {
            if (!this._treeControl.isExpanded(documentNode) || documentNode.isLoading) {
                this._treeControl.expand(documentNode);
                if (documentNode.nodeLoaded) {
                    documentNode.nodeLoaded.pipe(takeUntil(this.destroy$)).subscribe({
                        next: () => {
                            if (documents.length > 0) {
                                // eslint-disable-next-line rxjs/no-nested-subscribe
                                this.openNodes(documents);
                            }
                        },
                    });
                }
            }
            else if (documents.length > 0) {
                this.openNodes(documents);
            }
        }
    }
    refreshNode(documentId) {
        const nodeToExpand = this.findNodeByDocumentId(documentId);
        if (nodeToExpand) {
            this.toggleNode(nodeToExpand, { isRefresh: true, expand: true });
        }
    }
    updateNode(updatedDocument) {
        const nodeToUpdate = this.findNodeByDocumentId(updatedDocument.sys_id);
        if (!nodeToUpdate) {
            return;
        }
        nodeToUpdate.document = updatedDocument;
        this._dataChange.next(this._treeControl.dataNodes);
    }
    deleteNode(node) {
        const nodeIndex = this._treeControl.dataNodes.indexOf(node);
        if (nodeIndex < 0) {
            return;
        }
        let count = 1;
        for (let i = nodeIndex + 1; i < this._treeControl.dataNodes.length && this._treeControl.dataNodes[i].level > node.level; i++) {
            count++;
        }
        this._treeControl.dataNodes.splice(nodeIndex, count);
        this._dataChange.next(this._treeControl.dataNodes);
    }
    dataChanges() {
        return this._dataChange.asObservable();
    }
    toggleNode(node, options) {
        const { expand } = options;
        if (expand) {
            this.fetchAndUpdateNode(node, options);
        }
        else {
            this.collapseNode(node);
        }
    }
    fetchAndUpdateNode(node, options) {
        const { limit = DEFAULT_ITEMS_PER_PAGE, offset = 0 } = options;
        if (options.isRefresh) {
            this.resetNodeLoading(node);
        }
        node.isLoading = true;
        const fetchOptions = { limit, offset, sort: [] };
        this.getChildren(node.document, '', fetchOptions)
            .pipe(takeUntil(node.loadCancel$), finalize(() => (node.isLoading = false)))
            .subscribe({
            next: (children) => {
                this.pruneRemainingSkeletons(node);
                // eslint-disable-next-line rxjs/no-nested-subscribe
                this.handleNodeChildren(node, children, options);
            },
            error: (error) => {
                console.error(error);
                this.pruneRemainingSkeletons(node);
                this._dataChange.next(this._treeControl.dataNodes);
                if (node.nodeLoaded) {
                    node.nodeLoaded.next(false);
                }
            },
        });
    }
    handleNodeChildren(node, children, options) {
        const { limit = DEFAULT_ITEMS_PER_PAGE, offset = 0, isRefresh = false } = options;
        const index = this._treeControl.dataNodes.indexOf(node);
        if (!children.documents || index < 0) {
            return;
        }
        if (isRefresh) {
            this.clearChildren(node, index);
        }
        const insertIndex = this.getChildInsertIndex(node, index);
        // Find the index of the first non-skeleton node after the current insert index.
        const skeletonNodesEndIndex = this._treeControl.dataNodes.findIndex((item, i) => i >= insertIndex && !item.isSkeleton);
        const endIndex = skeletonNodesEndIndex >= 0 ? skeletonNodesEndIndex : this._treeControl.dataNodes.length;
        // Remove skeleton nodes from the current node's children.
        this._treeControl.dataNodes.splice(insertIndex, endIndex - insertIndex);
        // Create new tree nodes for each child document and insert them into the data array.
        const newNodes = children.documents.map((child) => new DocumentTreeNode(child, node.level + 1, this.isExpandable(child)));
        this._treeControl.dataNodes.splice(insertIndex, 0, ...newNodes);
        const totalCount = children.totalCount ?? children.documents.length;
        const nextOffset = offset + limit;
        const hasMorePages = nextOffset < totalCount;
        if (hasMorePages) {
            this.addSkeletonPlaceholders(node, insertIndex + newNodes.length, totalCount, offset, limit);
        }
        if (!hasMorePages) {
            this.pruneRemainingSkeletons(node);
        }
        this._dataChange.next(this._treeControl.dataNodes);
        node.nodeLoaded.next(true);
    }
    pruneRemainingSkeletons(node) {
        const parentIndex = this._treeControl.dataNodes.indexOf(node);
        if (parentIndex < 0) {
            return;
        }
        const isSkeletonChildToRemove = (item, i) => i > parentIndex && item.level === node.level + 1 && item.isSkeleton && item.document?.sys_parentId === node.document.sys_id;
        this._treeControl.dataNodes = this._treeControl.dataNodes.filter((item, i) => !isSkeletonChildToRemove(item, i));
    }
    addSkeletonPlaceholders(node, insertIndex, totalCount, offset, limit) {
        const placeholdersCount = Math.min(DEFAULT_ITEMS_PER_PAGE, Math.max(0, totalCount - (offset + limit)));
        // Attach the parent sys_id so pruning (and any future logic) can explicitly match ownership.
        const parentId = node.document.sys_id;
        const placeholders = Array.from({ length: placeholdersCount }, () => ({
            document: {
                sys_primaryType: 'skeleton-type',
                sys_parentId: parentId,
            },
            level: node.level + 1,
            isExpandable: false,
            isSkeleton: true,
        }));
        this._treeControl.dataNodes.splice(insertIndex, 0, ...placeholders);
        // Automatically fetch the next batch of children after a short delay to avoid overloading requests.
        this.dataChanges()
            .pipe(take(1), delay(100), takeUntil(node.loadCancel$))
            .subscribe({
            // eslint-disable-next-line rxjs/no-nested-subscribe
            next: () => this.fetchAndUpdateNode(node, { limit, offset: offset + limit, expand: true }),
            error: (err) => console.error('Failed to fetch and update node:', err),
        });
    }
    getChildInsertIndex(node, parentIndex) {
        const lastChildIndex = this.findLastIndex(this._treeControl.dataNodes, 
        // eslint-disable-next-line unicorn/no-array-method-this-argument
        (item, index) => index > parentIndex && item.level > node.level && !item.isSkeleton && item.document.sys_parentId === node.document.sys_id);
        return lastChildIndex >= 0 ? lastChildIndex + 1 : parentIndex + 1;
    }
    collapseNode(node) {
        this.resetNodeLoading(node);
        this.clearChildren(node, this._treeControl.dataNodes.indexOf(node));
        this._dataChange.next(this._treeControl.dataNodes);
    }
    resetNodeLoading(node) {
        node.loadCancel$.next();
        node.loadCancel$.complete();
        node.loadCancel$ = new Subject();
    }
    findLastIndex(array, predicate) {
        for (let i = array.length - 1; i >= 0; i--) {
            if (predicate(array[i], i, array)) {
                return i;
            }
        }
        return -1;
    }
    clearChildren(node, index) {
        let count = 0;
        for (let i = index + 1; i < this._treeControl.dataNodes.length && this._treeControl.dataNodes[i].level > node.level; i++) {
            count++;
        }
        this._treeControl.dataNodes.splice(index + 1, count);
    }
    _handleTreeControl(change) {
        if (change.added) {
            for (const node of change.added) {
                this.toggleNode(node, { expand: true });
            }
        }
        if (change.removed) {
            for (const node of [...change.removed].reverse()) {
                this.toggleNode(node, { expand: false });
            }
        }
    }
    toNode(document) {
        return new DocumentTreeNode(document, 0, true, false, false);
    }
    isExpandable(node) {
        // In the future we should check and rely on the fact if the document contains any children, rather than if is a folder type
        return isFolder(node);
    }
    getChildren(node, repositoryId, options) {
        return this.documentService.getFolderChildren(node.sys_id || '', repositoryId, options).pipe(catchError(() => of({
            documents: [],
            limit: 0,
            offset: 0,
            totalCount: 0,
        })));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentTreeDatabaseService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentTreeDatabaseService }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentTreeDatabaseService, decorators: [{
            type: Injectable
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DEFAULT_PAGE_SIZE = 25;
const MAX_SEARCH_RESULTS_PAGINATION_LIMIT = 10_000;
const MAX_SEARCH_RESULTS_TOTAL_COUNT_LIMIT = 100_000;

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchService {
    constructor() {
        this.queryApi = inject(QUERY_API_TOKEN);
        this.featuresService = inject(FeaturesServiceToken);
    }
    getDocumentsByQuery(search, options) {
        const query = {
            query: search,
            limit: options?.pagination?.maxItems || DEFAULT_PAGE_SIZE,
            offset: options?.pagination?.skipCount || 0,
            trackTotalCount: true,
            sort: options?.sort || [],
        };
        return this.featuresService.isOn$(ADF_HX_CONTENT_SERVICES_INTERNAL.SEARCH_RESULTS_100K).pipe(take(1), switchMap((isEnabled) => {
            if (isEnabled) {
                query.trackTotalCountUpTo = MAX_SEARCH_RESULTS_TOTAL_COUNT_LIMIT;
            }
            return from(this.queryApi.getDocumentsByQuery(query)).pipe(map(({ data }) => data));
        }));
    }
    sanitizeQuery(query) {
        const pattern = /(\*|%|'|"|\/|\+|_|-|\\)/g;
        return query.replaceAll(pattern, (match) => `\\${match}`);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DocumentVersionsService {
    constructor() {
        this.versionDeletedSubject = new Subject();
        this.versionUpdatedSubject = new Subject();
        this.searchService = inject(SearchService);
        this.documentService = inject(DocumentService);
        this.versionDeleted$ = this.versionDeletedSubject.asObservable();
        this.versionUpdated$ = this.versionUpdatedSubject.asObservable();
    }
    getVersions(document) {
        return document?.sys_id ? this.getVersionsById(document.sys_id) : of([]);
    }
    getCurrentDocument(document) {
        return document.sysver_isVersion ? this.documentService.getDocumentById(document.sys_parentId || '') : of(document);
    }
    updateVersion(updatePayload) {
        if (!updatePayload.sys_id) {
            return of(false);
        }
        return this.documentService.updateDocument(updatePayload.sys_id, updatePayload).pipe(map(() => true), tap(() => this.versionUpdatedSubject.next()));
    }
    deleteVersion(document) {
        if (!document.sys_id) {
            return of(false);
        }
        return this.documentService.deleteDocument(document.sys_id).pipe(map(() => true), tap(() => this.versionDeletedSubject.next()));
    }
    getVersionsById(documentId) {
        const query = this.buildQuery(documentId);
        return this.searchService.getDocumentsByQuery(query).pipe(map(({ documents }) => documents || []));
    }
    buildQuery(documentId) {
        return `SELECT * FROM SysContent WHERE sys_parentId = '${documentId}' AND sysver_isVersion = 1 ORDER BY sysver_created DESC`;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentVersionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentVersionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DocumentVersionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const versionsMocks = [
    {
        sysver_isVersion: true,
        sysver_isCheckedIn: false,
        sys_version: 1,
        sysver_created: '2024-04-30T14:55:16.230Z',
        sysver_creator: '743084d2-ee7b-4a55-9202-f73828b60bf2',
        sysver_title: '2024-04-30T14:55:16.230Z',
        sysver_description: 'First version',
        sys_changeToken: '0-0',
        sys_contributors: [
            {
                email: 'automate-test-user+hxps-rc_repoadmin@hyland.com',
                firstName: 'repoadmin',
                id: '743084d2-ee7b-4a55-9202-f73828b60bf2',
                lastName: 'repoadmin',
            },
        ],
        sys_created: '2024-04-30T14:54:16.230Z',
        sys_creator: {
            email: 'automate-test-user+hxps-rc_repoadmin@hyland.com',
            firstName: 'repoadmin',
            id: '743084d2-ee7b-4a55-9202-f73828b60bf2',
            lastName: 'repoadmin',
        },
        sys_effectivePermissions: [
            'CreateChild',
            'CreateVersion',
            'Delete',
            'DeleteChild',
            'ManageLock',
            'ManageRetention',
            'ManageSecurity',
            'Read',
            'ReadWrite',
            'Write',
        ],
        sys_hasLegalHold: false,
        sys_id: '7a31a105-fb8d-4643-ab8f-a9550f98b584',
        sys_isCheckedIn: false,
        sys_isFolderish: false,
        sys_isLatestVersion: false,
        sys_isProxy: false,
        sys_isRecord: false,
        sys_isTrashed: false,
        sys_isVersion: false,
        sys_lastContributor: {
            email: 'automate-test-user+hxps-rc_repoadmin@hyland.com',
            firstName: 'repoadmin',
            id: '743084d2-ee7b-4a55-9202-f73828b60bf2',
            lastName: 'repoadmin',
        },
        sys_mixinTypes: ['SysVersionable', 'SysFilish'],
        sys_modified: '2024-04-30T14:54:16.230Z',
        sys_name: 'Pro Industries Employment Application - Jane Doe (6).pdf.8505855865464574512',
        sys_parentId: '7a31a105-fb8d-4643-ab8f-a9550f98b584',
        sys_parentPath: '/',
        sys_path: '/Pro Industries Employment Application - Jane Doe (6).pdf.8505855865464574512',
        sys_pathDepth: 2,
        sys_primaryType: 'SysFile',
        sys_repository: 'default',
        sys_title: 'Pro Industries Employment Application - Jane Doe (6).pdf',
        sysfile_blob: {
            digest: '2b58b309085beaf109e45fdbacb632cbdde209c900442b821270eff0bd2ab7b0',
            filename: 'Pro Industries Employment Application - Jane Doe (6).pdf',
            key: '2b58b309085beaf109e45fdbacb632cbdde209c900442b821270eff0bd2ab7b0',
            length: 76209,
            mimeType: 'application/pdf',
        },
    },
    {
        sysver_isVersion: true,
        sysver_isCheckedIn: false,
        sys_version: 2,
        sysver_created: '2024-04-30T14:56:16.230Z',
        sysver_creator: '743084d2-ee7b-4a55-9202-f73828b60bf2',
        sysver_title: '2024-04-30T14:56:16.230Z',
        sysver_description: 'Second version',
        sys_changeToken: '0-0',
        sys_contributors: [
            {
                email: 'automate-test-user+hxps-rc_repoadmin@hyland.com',
                firstName: 'repoadmin',
                id: '743084d2-ee7b-4a55-9202-f73828b60bf2',
                lastName: 'repoadmin',
            },
        ],
        sys_created: '2024-04-30T14:54:16.230Z',
        sys_creator: {
            email: 'automate-test-user+hxps-rc_repoadmin@hyland.com',
            firstName: 'repoadmin',
            id: '743084d2-ee7b-4a55-9202-f73828b60bf2',
            lastName: 'repoadmin',
        },
        sys_effectivePermissions: [
            'CreateChild',
            'CreateVersion',
            'Delete',
            'DeleteChild',
            'ManageLock',
            'ManageRetention',
            'ManageSecurity',
            'Read',
            'ReadWrite',
            'Write',
        ],
        sys_hasLegalHold: false,
        sys_id: '1280321d-dca8-4abe-be10-8ddf76938845',
        sys_isCheckedIn: false,
        sys_isFolderish: false,
        sys_isLatestVersion: false,
        sys_isProxy: false,
        sys_isRecord: false,
        sys_isTrashed: false,
        sys_isVersion: false,
        sys_lastContributor: {
            email: 'automate-test-user+hxps-rc_repoadmin@hyland.com',
            firstName: 'repoadmin',
            id: '743084d2-ee7b-4a55-9202-f73828b60bf2',
            lastName: 'repoadmin',
        },
        sys_mixinTypes: ['SysVersionable', 'SysFilish'],
        sys_modified: '2024-04-30T14:54:16.230Z',
        sys_name: 'Pro Industries Employment Application - Jane Doe (6).pdf.8505855865464574512',
        sys_parentId: '7a31a105-fb8d-4643-ab8f-a9550f98b584',
        sys_parentPath: '/',
        sys_path: '/Pro Industries Employment Application - Jane Doe (6).pdf.8505855865464574512',
        sys_pathDepth: 2,
        sys_primaryType: 'SysFile',
        sys_repository: 'default',
        sys_title: 'Pro Industries Employment Application - Jane Doe (6).pdf',
        sysfile_blob: {
            digest: '2b58b309085beaf109e45fdbacb632cbdde209c900442b821270eff0bd2ab7b0',
            filename: 'Pro Industries Employment Application - Jane Doe (6).pdf',
            key: '2b58b309085beaf109e45fdbacb632cbdde209c900442b821270eff0bd2ab7b0',
            length: 76209,
            mimeType: 'application/pdf',
        },
    },
];

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const ColumnKeys = {
    Icon: 'icon',
    SysTitle: 'sys_title',
    SysFileBlobLength: 'sysfile_blob/length',
    SysCreated: 'sys_created',
    SysModified: 'sys_modified',
    SysEffectivePermissions: 'sys_effectivePermissions',
    SysParentPath: 'sys_parentPath',
    SysPrimaryType: 'sys_primaryType',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ColumnDataService {
    constructor() {
        this.adfFileSize = inject(FileSizePipe);
        this.timeAgoService = inject(TimeAgoPipe);
        this.userResolverService = inject(UserResolverService);
        this.translationService = inject(TranslationService);
        this.permissionService = inject(PermissionLevelPipe);
        this.decimalNumberService = inject(DecimalNumberPipe);
        this.datePipe = inject(DatePipe);
        this.propertyUtilService = inject(PropertyUtilService);
    }
    doesColumnValueExist(document, columnKey) {
        const keys = columnKey.split('.');
        let current = document;
        for (const key of keys) {
            if (current && key in current) {
                current = current[key];
            }
            else {
                return false;
            }
        }
        return true;
    }
    getColumnValue(document, columnKey) {
        switch (columnKey) {
            case ColumnKeys.Icon: {
                return of(document.sys_primaryType);
            }
            case ColumnKeys.SysFileBlobLength: {
                return of(this.adfFileSize.transform(document['sysfile_blob']?.length));
            }
            case ColumnKeys.SysCreated: {
                return this.formatDateWithUser(document.sys_creator, document.sys_created, 'DOCUMENT_LIST.COLUMNS.CREATED.BY');
            }
            case ColumnKeys.SysModified: {
                return this.formatDateWithUser(document.sys_lastContributor, document.sys_modified, 'DOCUMENT_LIST.COLUMNS.LAST_MODIFIED.BY');
            }
            case ColumnKeys.SysEffectivePermissions: {
                const permissions = this.permissionService.transform(document.sys_effectivePermissions);
                return of(permissions ? `${this.translationService.instant(permissions.value)}` : '');
            }
            case ColumnKeys.SysParentPath: {
                return document.sys_parentPath === '/'
                    ? of(this.translationService.instant('DOCUMENT_LIST.LOCATION.HOME'))
                    : of(`${this.translationService.instant('DOCUMENT_LIST.LOCATION.HOME')}${document.sys_parentPath}`);
            }
            default: {
                return of(document[columnKey] || '');
            }
        }
    }
    getCustomColumnValue(document, columnKey, model, type) {
        if (!this.doesColumnValueExist(document, columnKey)) {
            return of(undefined);
        }
        const rawValue = this.propertyUtilService.propertyValue(columnKey, document, model);
        switch (type) {
            case FieldType.Date: {
                return of(this.datePipe.transform(rawValue));
            }
            case FieldType.DateArray: {
                return of(rawValue.map((date) => this.datePipe.transform(date)));
            }
            case FieldType.Float: {
                return of(this.decimalNumberService.transform(rawValue));
            }
            case FieldType.Boolean: {
                return of(rawValue ? 'True' : 'False');
            }
            default: {
                return of(rawValue);
            }
        }
    }
    getCustomSchemaFields(model) {
        if (!model) {
            return [];
        }
        const customSchemaFields = [];
        const allCustomSchema = model.documentModel.schemas || {};
        for (const [schemaName, value] of Object.entries(allCustomSchema)) {
            if (model.isCustomSchema(schemaName)) {
                const prefix = value.prefix || '';
                const fieldNames = this.getSchemaFieldNames(value);
                for (const fieldName of fieldNames) {
                    customSchemaFields.push(...this.generateCustomPropertyFields(fieldName, prefix, model));
                }
            }
        }
        return customSchemaFields;
    }
    generateCustomPropertyFields(fieldName, prefix, model) {
        const customFields = [];
        const fieldType = model.getFieldType(fieldName);
        if (fieldType === FieldType.Complex) {
            for (const complexFieldDetail of model.getComplexFieldDetails(fieldName)) {
                customFields.push(...this.generateCustomPropertyFieldsComplexType(fieldName, complexFieldDetail, prefix, model));
            }
        }
        else if (fieldType === FieldType.Blob) {
            for (const blobField of this.getBlobFields(fieldType, model)) {
                const blobFieldTitle = `${fieldName}_${blobField.name}`;
                customFields.push({
                    name: `${fieldName}.${blobField.name}`,
                    title: blobFieldTitle.slice(Math.max(0, prefix.length > 0 ? prefix.length + 1 : 0)),
                    type: blobField.type,
                });
            }
        }
        else {
            customFields.push({
                name: fieldName,
                title: fieldName.slice(Math.max(0, prefix.length > 0 ? prefix.length + 1 : 0)),
                type: fieldType,
            });
        }
        return customFields;
    }
    generateCustomPropertyFieldsComplexType(fieldName, complexFieldDetail, prefix, model) {
        const customFields = [];
        const matchingFieldType = model.getFieldType(`${fieldName}.${complexFieldDetail.name}`);
        if (matchingFieldType === FieldType.Blob) {
            for (const complexBlobField of this.getBlobFields(matchingFieldType, model)) {
                const complexBlobFieldTitle = `${fieldName}_${complexFieldDetail.name}_${complexBlobField.name}`;
                customFields.push({
                    name: `${fieldName}.${complexFieldDetail.name}.${complexBlobField.name}`,
                    title: complexBlobFieldTitle.slice(Math.max(0, prefix.length > 0 ? prefix.length + 1 : 0)),
                    type: complexBlobField.type,
                });
            }
        }
        else {
            const complexFieldTitle = `${fieldName}_${complexFieldDetail.name}`;
            customFields.push({
                name: `${fieldName}.${complexFieldDetail.name}`,
                title: complexFieldTitle.slice(Math.max(0, prefix.length > 0 ? prefix.length + 1 : 0)),
                type: complexFieldDetail.type,
            });
        }
        return customFields;
    }
    getSchemaFieldNames(schema) {
        const fieldDetails = schema.fields || {};
        return Object.keys(fieldDetails);
    }
    getBlobFields(matchingFieldType, model) {
        const blobPropertyFields = [];
        if (model.documentModel?.types?.[matchingFieldType]) {
            const complexType = model.documentModel.types[matchingFieldType];
            if (!complexType?.fields) {
                return [];
            }
            for (const [name, fieldDef] of Object.entries(complexType.fields)) {
                if (['filename', 'mimeType', 'length'].includes(name)) {
                    blobPropertyFields.push({ name, type: model.resolveType(fieldDef.type) });
                }
            }
        }
        return blobPropertyFields;
    }
    formatDateWithUser(user, date = '', translationKey) {
        const parsedDate = new Date(date);
        const userNameObservable = user ? this.userResolverService.parse([user]) : of('');
        return userNameObservable.pipe(map((userName) => {
            if (Number.isNaN(parsedDate.getTime())) {
                return '';
            }
            return `${this.timeAgoService.transform(parsedDate)} ${this.translationService.instant(translationKey)} ${userName}`;
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ColumnDataService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ColumnDataService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ColumnDataService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const DEFAULT_COLUMNS = [
    { key: ColumnKeys.Icon, title: 'File Type', sortable: false, removable: true },
    { key: ColumnKeys.SysTitle, title: 'DOCUMENT_LIST.COLUMNS.TITLE', sortable: true, removable: false },
    { key: ColumnKeys.SysFileBlobLength, title: 'DOCUMENT_LIST.COLUMNS.SIZE', sortable: true, removable: true },
    { key: ColumnKeys.SysCreated, title: 'DOCUMENT_LIST.COLUMNS.CREATED.LABEL', sortable: true, removable: true },
    { key: ColumnKeys.SysModified, title: 'DOCUMENT_LIST.COLUMNS.LAST_MODIFIED.LABEL', sortable: true, removable: true },
    { key: ColumnKeys.SysEffectivePermissions, title: 'DOCUMENT_LIST.COLUMNS.PERMISSION', sortable: true, removable: true },
    { key: ColumnKeys.SysParentPath, title: 'DOCUMENT_LIST.COLUMNS.LOCATION', sortable: true, removable: true },
    { key: ColumnKeys.SysPrimaryType, title: 'DOCUMENT_LIST.COLUMNS.DOCUMENT_CATEGORY', sortable: true, removable: true },
];

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class ColumnConfigService {
    constructor() {
        this.storageService = inject(StorageService);
        this.documentModeService = inject(DocumentModelService);
        this.columnDataService = inject(ColumnDataService);
        this.translationService = inject(TranslationService);
        this.columnConfigsSubject = new BehaviorSubject(this.getDefaultColumns());
        this.columnConfigs$ = this.columnConfigsSubject.asObservable();
    }
    getDefaultColumns() {
        return DEFAULT_COLUMNS;
    }
    getSelectedColumnsForCurrentUser(userInfo) {
        const storedColumns = this.storageService.getItem(`${userInfo.email}_selectedColumns`);
        return storedColumns ? JSON.parse(storedColumns) : this.getDefaultColumns();
    }
    setCurrentSelectedColumnsForCurrentUser(userInfo, columns) {
        this.storageService.setItem(`${userInfo.email}_selectedColumns`, JSON.stringify(columns));
        this.columnConfigsSubject.next([...columns]);
    }
    getCustomColumns() {
        return this.documentModeService.getModel().pipe(map((model) => {
            const customColumns = [];
            const customSchemaFields = this.columnDataService.getCustomSchemaFields(model);
            for (const field of customSchemaFields) {
                customColumns.push({
                    key: field.name,
                    title: field.title.replaceAll(/\w\S*/g, function (txt) {
                        return txt.charAt(0).toUpperCase() + txt.slice(1).toLowerCase();
                    }),
                    sortable: true,
                    removable: true,
                    type: field.type,
                });
            }
            return customColumns;
        }));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ColumnConfigService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ColumnConfigService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: ColumnConfigService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFilterValueStoreService {
    constructor() {
        this.SEARCH_FILTER_VALUES_KEY = 'hxp-search-filters-value-store';
        this.storedValues = new Map();
        this.identityUserService = inject(IDENTITY_USER_SERVICE_TOKEN);
        this.storageService = inject(StorageService);
        this.load();
    }
    get storageKey() {
        return `${this.identityUserService.getCurrentUserInfo().email}_${this.SEARCH_FILTER_VALUES_KEY}`;
    }
    reset() {
        this.storedValues?.clear();
        this.storageService.removeItem(this.storageKey);
    }
    addValue(filter, data) {
        this.storedValues?.set(filter.id, data);
        this.save();
    }
    deleteValue(filter) {
        this.storedValues?.delete(filter.id);
        this.save();
    }
    getValue(filter) {
        return this.storedValues?.get(filter.id);
    }
    hasValues() {
        return this.storedValues?.size > 0;
    }
    load() {
        const data = this.storageService.getItem(this.storageKey);
        if (data) {
            try {
                const parsedData = JSON.parse(data);
                this.storedValues = new Map(Object.entries(parsedData));
            }
            catch (error) {
                console.error('Error parsing search filter values', error);
            }
        }
    }
    save() {
        const filtersValuesMap = {};
        for (const [key, value] of this.storedValues.entries()) {
            filtersValuesMap[key] = value;
        }
        this.storageService.setItem(this.storageKey, JSON.stringify(filtersValuesMap));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterValueStoreService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterValueStoreService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterValueStoreService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFilterValueService {
    constructor() {
        this.filterReset$ = new Subject();
        this.filterApplied$ = new Subject();
        this.filterValuesByType = new Map();
        this.baseQuery = 'SELECT * FROM SysContent';
        this.filterApplied$.subscribe({
            next: (filterApplied) => this.filterValuesByType.set(filterApplied.filter, filterApplied.value),
        });
        this.filterReset$.subscribe({
            next: (filterToReset) => this.filterValuesByType.delete(filterToReset),
        });
    }
    emptyFilters() {
        this.filterValuesByType.clear();
    }
    clearFilters() {
        for (const appliedFilter of this.filterValuesByType.keys()) {
            appliedFilter.clearFilter();
        }
        this.filterValuesByType.clear();
    }
    clearFilter(filter) {
        filter.clearFilter();
        this.filterValuesByType.delete(filter);
    }
    hasFilters() {
        return this.filterValuesByType.size > 0;
    }
    toHXQL() {
        const appliedFilters = [...this.filterValuesByType.entries()];
        const filtersClauses = appliedFilters.map(([filter, filterData]) => filter.toHXQL(filterData));
        const whereClause = filtersClauses.join(' AND ');
        return whereClause ? `${this.baseQuery} WHERE ${whereClause}` : this.baseQuery;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterValueService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterValueService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFilterValueService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class SearchFiltersExtensionsService {
    constructor() {
        this.featureName = 'search';
        this.actionType = 'filters';
        this.extensionService = inject(ExtensionService);
        this.featuresService = inject(FeaturesServiceToken);
    }
    getSearchFiltersItems() {
        return this.extensionService.setup$.pipe(filter((config) => this.hasFeatureConfig(config)), map((config) => this.extractFeatureConfig(config)), switchMap((config) => this.filterItemsByFeatureFlag(config)), shareReplay(1));
    }
    hasFeatureConfig(config) {
        return !!config?.features?.[this.featureName]?.[this.actionType];
    }
    extractFeatureConfig(config) {
        return config.features?.[this.featureName][this.actionType];
    }
    filterItemsByFeatureFlag(config) {
        return from(config.items || []).pipe(switchMap((item) => this.shouldIncludeItem(item).pipe(filter((shouldInclude) => shouldInclude), map(() => item))), toArray(), map((filteredItems) => ({ ...config, items: filteredItems })));
    }
    shouldIncludeItem(item) {
        return item.rules?.featureFlag ? this.featuresService.isOn$(item.rules.featureFlag) : of(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFiltersExtensionsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFiltersExtensionsService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: SearchFiltersExtensionsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
const SearchType = {
    BASIC: 'basic',
    HXQL: 'hxql',
};

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class MockSearchFilterValue {
    constructor() {
        this.label = '';
        this.value = '';
    }
}
const compareFn = (a, b) => a.value.localeCompare(b.value);
class MockSearchFilterData {
    constructor(values = []) {
        this.values = [];
        this.values = values;
    }
    isEquivalentTo(data) {
        if (!data || this.values.length !== data.values.length) {
            return false;
        }
        const sortedValues = this.values.sort(compareFn);
        const sortedDataValues = data.values.sort(compareFn);
        for (const [i, sortedValue] of sortedValues.entries()) {
            if (sortedValue.value !== sortedDataValues[i].value) {
                return false;
            }
        }
        return true;
    }
}

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */
class DateTimeFormatPipe {
    static { this.DEFAULT_LOCALE = 'en-US'; }
    static { this.DATE_TIME_FORMAT_24_HR = 'YYYY-MM-d H:mm:ss'; }
    static { this.DATE_TIME_FORMAT_12_HR = 'MMM d, y h:mm a'; }
    constructor() {
        this.defaultLocale = DateTimeFormatPipe.DEFAULT_LOCALE;
        this.userPreferenceService = inject(UserPreferencesService);
        this.userPreferenceService
            .select(UserPreferenceValues.Locale)
            .pipe(takeUntilDestroyed())
            .subscribe((locale) => {
            this.defaultLocale = locale || DateTimeFormatPipe.DEFAULT_LOCALE;
        });
    }
    transform(value, format) {
        if (value !== null && value !== undefined) {
            let displayFormat = DateTimeFormatPipe.DATE_TIME_FORMAT_12_HR;
            if (format === '24hr') {
                displayFormat = DateTimeFormatPipe.DATE_TIME_FORMAT_24_HR;
            }
            const datePipe = new DatePipe(this.defaultLocale, displayFormat);
            return datePipe.transform(value, displayFormat);
        }
        return '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DateTimeFormatPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "19.2.20", ngImport: i0, type: DateTimeFormatPipe, isStandalone: true, name: "hxpDateTimePipe", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.20", ngImport: i0, type: DateTimeFormatPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'hxpDateTimePipe',
                    pure: false,
                }]
        }], ctorParameters: () => [] });

/*
 * Copyright 2005-2026 Hyland Software, Inc. and its affiliates. All rights reserved.
 * License rights for this program may be obtained from Hyland Software, Inc. and its affiliates.
 * pursuant to a written agreement and any use of this program without such an
 * agreement is prohibited.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BLOCK_DELETE_STATUSES, BLOCK_EDIT_STATUSES, BlobDownloadService, ColumnConfigService, ColumnDataService, ColumnKeys, ContentShareService, ContextMenuActionsService, CopyStatus, DEFAULT_COLUMNS, DEFAULT_ITEMS_PER_PAGE, DEFAULT_PAGE_SIZE, DEFAULT_RENDITION_ID, DOCUMENT_PROPERTIES_SERVICE, DOCUMENT_PROVIDERS, DOCUMENT_SERVICE, DateTimeFormatPipe, DocumentActionService, DocumentCacheService, DocumentModel, DocumentModelService, DocumentMoreMenuItemsFactoryService, DocumentPermissions, DocumentPropertiesService, DocumentRouterService, DocumentService, DocumentTreeDatabaseService, DocumentTreeNode, DocumentVersionsService, DownloadStatus, EFFECTIVE_STATUS, EVERYONE_USER_ID, EVERYTHING_PERMISSION, FileDownloadService, HXP_DOCUMENT_COPY_ACTION_SERVICE, HXP_DOCUMENT_CREATE_DOCUMENT_VERSION_ACTION_SERVICE, HXP_DOCUMENT_DELETE_ACTION_SERVICE, HXP_DOCUMENT_INFO_ACTION_SERVICE, HXP_DOCUMENT_MOVE_ACTION_SERVICE, HXP_DOCUMENT_PERMISSIONS_ACTION_SERVICE, HXP_DOCUMENT_REPLACE_FILE_ACTION_SERVICE, HXP_DOCUMENT_RESTORE_VERSION_ACTION_SERVICE, HXP_DOCUMENT_SHARE_ACTION_SERVICE, HXP_DOCUMENT_SINGLE_ITEM_DOWNLOAD_ACTION_SERVICE, HXP_DOCUMENT_VERSION_DELETE_ACTION_SERVICE, HXP_DOCUMENT_VERSION_EDIT_ACTION_SERVICE, HXP_MANAGE_COLUMN_ACTION_SERVICE, HxpNotificationService, IDENTITY_USER_SERVICE_TOKEN, IsSingleDocumentWithMainBlobService, IsSuggestedPermissionEntityValidator, MAX_SEARCH_RESULTS_PAGINATION_LIMIT, MAX_SEARCH_RESULTS_TOTAL_COUNT_LIMIT, ManageVersionsButtonActionService, MockSearchFilterData, MockSearchFilterValue, MoveStatus, NOTIFICATION_MESSAGES, PERMISSIONS_MANAGEMENT_COMPONENT_TYPE, PermissionLevelPipe, PermissionsDataAccessService, PermissionsManagementFacade, PermissionsManagementStateService, PermissionsPanelRequestService, PropertyUtilService, RecordStatus, RenditionStatus, RenditionsService, RouterExtService, SearchFilterValueService, SearchFilterValueStoreService, SearchFiltersExtensionsService, SearchService, SearchType, SharedDocumentPropertiesService, SharedDocumentService, SidebarService, SingleFileDownloadService, SingleItemCopyService, SingleItemMoveService, USER_RESOLVER_PROVIDERS, UserResolverPipe, UserResolverService, UserService, UserType, ViewMode, getHighestAce, getHighestPermission, getNotificationMessage, getRetentionStatus, hasBlob, hasLegalHold, hasPermission, hasRenditionBlob, isAclInheritanceBlocked, isDocumentParentFolder, isFile, isFolder, isGovernable, isPermissionError, isPermissionInheritanceEnabled, isRoot, isSysGovRecord, isVersion, isVersionable, pollWhile, provideAdfEnterpriseAdfHxContentServicesServices, removeUserTypeFromAcl, versionsMocks };
//# sourceMappingURL=alfresco-adf-hx-content-services-services.mjs.map
