import * as i0 from '@angular/core';
import { input, linkedSignal, computed, inject, ElementRef, afterNextRender, ChangeDetectionStrategy, ViewEncapsulation, Component, NgModule } from '@angular/core';
import * as i1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import * as i3 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i2 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import { TranslatePipe } from '@ngx-translate/core';

/**
 * The Breadcrumbs component displays a navigation path, allowing users to easily navigate back to previous pages.
 * It supports truncation of items into a menu when the available space is insufficient.
 */
class SatBreadcrumbsComponent {
    /**
     * Input signal for the breadcrumb items.
     */
    items = input([]);
    /**
     * Signal for the items currently displayed in the breadcrumbs.
     * @internal
     */
    visibleItems = linkedSignal({
        computation: () => [...(this.items() || [])],
        source: this.items,
    });
    /**
     * Computed signal for the hidden items (collapsed into the menu).
     * @internal
     */
    hiddenItems = computed(() => (this.items() ?? []).filter(item => !this.visibleItems().includes(item)));
    _element = inject(ElementRef);
    /**
     * Last registered width of the component
     */
    width = 0;
    /**
     * To determine if the last item in the breadcrumbs is the current page.
     * @internal
     */
    hasCurrentPage = computed(() => {
        // If the last item does not have an href, it is considered the current page.
        const items = this.items();
        return !items?.[items.length - 1]?.href;
    });
    truncationTimeout;
    resizeTimeout;
    resizeObserver = new ResizeObserver(entries => {
        for (const entry of entries) {
            this.debounceResize(entry.contentRect.width);
        }
    });
    constructor() {
        afterNextRender({
            read: () => {
                this.resizeObserver.observe(this._element.nativeElement);
            },
        });
    }
    ngOnDestroy() {
        this.resizeObserver?.disconnect();
        clearTimeout(this.resizeTimeout);
        clearTimeout(this.truncationTimeout);
    }
    /**
     * The resize event can fire frequently during user interactions, so we debounce it to trigger
     * only after resizing or layout changes have stopped. This prevents flickering effects during resizing.
     */
    debounceResize(width) {
        clearTimeout(this.resizeTimeout);
        this.resizeTimeout = setTimeout(() => {
            if (width > this.width) {
                this.visibleItems.set([...(this.items() || [])]);
            }
            this.width = width;
            this.debounceTruncation();
        }, 100);
    }
    /**
     * Recursively manages breadcrumb item overflow.
     * Uses a 0ms timeout to run immediately after the next render cycle,
     * ensuring the component measures its size accurately for each recursion step.
     */
    debounceTruncation() {
        clearTimeout(this.truncationTimeout);
        this.truncationTimeout = setTimeout(() => {
            if (!this._element) {
                return;
            }
            if (this._element.nativeElement.scrollWidth <= this._element.nativeElement.offsetWidth) {
                // It's not overflowing
                return;
            }
            /**
             * When there are more than two visible items, or when Breadcrumbs have current location and more than
             * three visible items, the item to hide is the second one, because for most users the first item is of
             * more importance, following in importance the last item, and they are likely to want to return to it.
             */
            const visibleItems = this.visibleItems();
            const maximumVisibleItems = this.hasCurrentPage() ? 3 : 2;
            const itemsToDisplay = visibleItems.length > maximumVisibleItems
                ? [visibleItems[0], ...visibleItems.slice(2)]
                : visibleItems.slice(1);
            if (itemsToDisplay.length !== visibleItems.length) {
                this.visibleItems.set(itemsToDisplay);
                if (itemsToDisplay.length) {
                    // If there are still items to display, we need to check again for overflow.
                    this.debounceTruncation();
                }
            }
        }, 0);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBreadcrumbsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatBreadcrumbsComponent, isStandalone: true, selector: "sat-breadcrumbs", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<nav\n  [attr.aria-label]=\"'sat.breadcrumbs.breadcrumbs' | translate\"\n  class=\"mat-body-medium sat-breadcrumbs-nav\"\n>\n  <ol class=\"sat-breadcrumbs-list\">\n    @if (visibleItems().length >= (hasCurrentPage() ? 3 : 2)) {\n      <li>\n        <a [attr.href]=\"visibleItems()[0].href\">\n          {{visibleItems()[0].label}}\n        </a>\n        <mat-icon svgIcon=\"chevron_right\" aria-hidden class=\"sat-breadcrumbs-chevron\"></mat-icon>\n      </li>\n    }\n    @if (hiddenItems().length) {\n      <li>\n        <button\n          mat-icon-button\n          [matMenuTriggerFor]=\"menu\"\n          [attr.aria-label]=\"'sat.breadcrumbs.show-more' | translate\"\n        >\n          <mat-icon svgIcon=\"more_horiz\"></mat-icon>\n        </button>\n        <mat-menu #menu=\"matMenu\">\n          @for (item of hiddenItems(); track item) {\n            <a\n              mat-menu-item\n              [attr.href]=\"item.href ?? null\"\n              [attr.aria-current]=\"item.href ? null : 'page'\"\n            >\n              {{item.label}}\n            </a>\n          }\n        </mat-menu>\n        <mat-icon svgIcon=\"chevron_right\" aria-hidden class=\"sat-breadcrumbs-chevron\"></mat-icon>\n      </li>\n    }\n    @for (\n      item of (visibleItems().length >= (hasCurrentPage() ? 3 : 2) ? visibleItems().slice(1) : visibleItems());\n      track item\n    ) {\n      <li>\n        <a [attr.href]=\"item.href ?? null\" [attr.aria-current]=\"item.href ? null : 'page'\">\n          {{item.label}}\n        </a>\n        @if (item.href) {\n          <mat-icon svgIcon=\"chevron_right\" aria-hidden class=\"sat-breadcrumbs-chevron\"></mat-icon>\n        }\n      </li>\n    }\n  </ol>\n</nav>\n", styles: ["sat-breadcrumbs{display:inline-flex;max-width:100%;overflow:hidden}nav.sat-breadcrumbs-nav{display:flex;flex:1 0 100%;align-items:center;height:28px;flex-wrap:nowrap}nav.sat-breadcrumbs-nav{--mat-icon-button-touch-target-display: none}nav.sat-breadcrumbs-nav .mat-mdc-icon-button.mat-mdc-button-base{--mdc-icon-button-state-layer-size: 28px;width:var(--mdc-icon-button-state-layer-size);height:var(--mdc-icon-button-state-layer-size);padding:2px}nav.sat-breadcrumbs-nav>*{flex:0 0 auto}.mat-icon.sat-breadcrumbs-chevron{width:16px;height:16px}.sat-breadcrumbs-list{display:flex;list-style:none;padding:0;margin:0;gap:var(--sat-breadcrumbs-gap, 4px)}.sat-breadcrumbs-list li{display:flex;align-items:center}.sat-breadcrumbs-chevron{margin:0 0 0 var(--sat-breadcrumbs-gap, 4px)}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1.MatIconButton, selector: "button[mat-icon-button]", exportAs: ["matButton"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i2.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i2.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i2.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i3.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "pipe", type: TranslatePipe, name: "translate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBreadcrumbsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-breadcrumbs', imports: [MatButtonModule, MatMenuModule, MatIconModule, TranslatePipe], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<nav\n  [attr.aria-label]=\"'sat.breadcrumbs.breadcrumbs' | translate\"\n  class=\"mat-body-medium sat-breadcrumbs-nav\"\n>\n  <ol class=\"sat-breadcrumbs-list\">\n    @if (visibleItems().length >= (hasCurrentPage() ? 3 : 2)) {\n      <li>\n        <a [attr.href]=\"visibleItems()[0].href\">\n          {{visibleItems()[0].label}}\n        </a>\n        <mat-icon svgIcon=\"chevron_right\" aria-hidden class=\"sat-breadcrumbs-chevron\"></mat-icon>\n      </li>\n    }\n    @if (hiddenItems().length) {\n      <li>\n        <button\n          mat-icon-button\n          [matMenuTriggerFor]=\"menu\"\n          [attr.aria-label]=\"'sat.breadcrumbs.show-more' | translate\"\n        >\n          <mat-icon svgIcon=\"more_horiz\"></mat-icon>\n        </button>\n        <mat-menu #menu=\"matMenu\">\n          @for (item of hiddenItems(); track item) {\n            <a\n              mat-menu-item\n              [attr.href]=\"item.href ?? null\"\n              [attr.aria-current]=\"item.href ? null : 'page'\"\n            >\n              {{item.label}}\n            </a>\n          }\n        </mat-menu>\n        <mat-icon svgIcon=\"chevron_right\" aria-hidden class=\"sat-breadcrumbs-chevron\"></mat-icon>\n      </li>\n    }\n    @for (\n      item of (visibleItems().length >= (hasCurrentPage() ? 3 : 2) ? visibleItems().slice(1) : visibleItems());\n      track item\n    ) {\n      <li>\n        <a [attr.href]=\"item.href ?? null\" [attr.aria-current]=\"item.href ? null : 'page'\">\n          {{item.label}}\n        </a>\n        @if (item.href) {\n          <mat-icon svgIcon=\"chevron_right\" aria-hidden class=\"sat-breadcrumbs-chevron\"></mat-icon>\n        }\n      </li>\n    }\n  </ol>\n</nav>\n", styles: ["sat-breadcrumbs{display:inline-flex;max-width:100%;overflow:hidden}nav.sat-breadcrumbs-nav{display:flex;flex:1 0 100%;align-items:center;height:28px;flex-wrap:nowrap}nav.sat-breadcrumbs-nav{--mat-icon-button-touch-target-display: none}nav.sat-breadcrumbs-nav .mat-mdc-icon-button.mat-mdc-button-base{--mdc-icon-button-state-layer-size: 28px;width:var(--mdc-icon-button-state-layer-size);height:var(--mdc-icon-button-state-layer-size);padding:2px}nav.sat-breadcrumbs-nav>*{flex:0 0 auto}.mat-icon.sat-breadcrumbs-chevron{width:16px;height:16px}.sat-breadcrumbs-list{display:flex;list-style:none;padding:0;margin:0;gap:var(--sat-breadcrumbs-gap, 4px)}.sat-breadcrumbs-list li{display:flex;align-items:center}.sat-breadcrumbs-chevron{margin:0 0 0 var(--sat-breadcrumbs-gap, 4px)}\n"] }]
        }], ctorParameters: () => [] });

class SatBreadcrumbsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBreadcrumbsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatBreadcrumbsModule, imports: [SatBreadcrumbsComponent], exports: [SatBreadcrumbsComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBreadcrumbsModule, imports: [SatBreadcrumbsComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatBreadcrumbsModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SatBreadcrumbsComponent],
                    exports: [SatBreadcrumbsComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatBreadcrumbsComponent, SatBreadcrumbsModule };
//# sourceMappingURL=hylandsoftware-satori-ui-breadcrumbs.mjs.map
