import { SATORI_ICONS } from '@hylandsoftware/satori-icons';
export { SATORI_ICONS } from '@hylandsoftware/satori-icons';
import * as i0 from '@angular/core';
import { inject, NgModule, makeEnvironmentProviders, provideAppInitializer } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';

/**
 * @deprecated Use provideSatoriIcons from @hylandsoftware/satori-ui/icons instead
 */
class SatIconModule {
    constructor() {
        const registry = inject(MatIconRegistry);
        const sanitizer = inject(DomSanitizer);
        registry.addSvgIconSetLiteral(sanitizer.bypassSecurityTrustHtml(SATORI_ICONS));
        // support temporary _24px suffixed icons name
        // TODO: major release: remove support for _24px suffixed icons name
        registry.addSvgIconSetLiteral(sanitizer.bypassSecurityTrustHtml(SATORI_ICONS.replaceAll(/id="([^"]*)"/gi, 'id="$1_24px"')));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatIconModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatIconModule });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatIconModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatIconModule, decorators: [{
            type: NgModule
        }], ctorParameters: () => [] });

function provideSatoriIcons() {
    return makeEnvironmentProviders([
        provideAppInitializer(() => {
            const registry = inject(MatIconRegistry);
            const sanitizer = inject(DomSanitizer);
            registry.addSvgIconSetLiteral(sanitizer.bypassSecurityTrustHtml(SATORI_ICONS));
        }),
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { SatIconModule, provideSatoriIcons };
//# sourceMappingURL=hylandsoftware-satori-ui-icons.mjs.map
