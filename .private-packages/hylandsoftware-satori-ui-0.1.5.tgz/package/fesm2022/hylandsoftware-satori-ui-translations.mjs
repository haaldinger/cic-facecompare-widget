import { provideHttpClient, HttpClient } from '@angular/common/http';
import { InjectionToken, inject, makeEnvironmentProviders } from '@angular/core';
import { provideTranslateService, TranslateLoader } from '@ngx-translate/core';
import { forkJoin, map, catchError, throwError, of } from 'rxjs';

class MultiTranslateHttpLoader {
    http;
    prefix;
    suffix;
    translationPaths;
    constructor(http, prefix, suffix, translationPaths) {
        this.http = http;
        this.prefix = prefix;
        this.suffix = suffix;
        this.translationPaths = translationPaths;
    }
    getTranslation(lang) {
        // This will go through all the translation paths and fetch the translations for the specified language
        const requests = this.translationPaths.map(path => this.getTranslationFile(lang, path));
        return forkJoin(requests).pipe(map((responses) => Object.assign({}, ...responses)));
    }
    getTranslationFile(lang, translationPath) {
        const fileUrl = this.buildFileUrl(lang, translationPath);
        const baseLang = this.getBaseLang(lang);
        const fallbackUrl = baseLang ? this.buildFileUrl(baseLang, translationPath) : null;
        return this.http.get(fileUrl).pipe(catchError(() => fallbackUrl
            ? this.http.get(fallbackUrl)
            : throwError(() => new Error(fileUrl))), catchError(() => {
            const urls = [fileUrl, fallbackUrl].filter(Boolean).join(', ');
            console.error(`Error loading translation file(s): ${urls}`);
            return of({});
        }));
    }
    buildFileUrl(lang, translationPath) {
        return `${this.prefix}${translationPath ? translationPath + '/' : ''}${lang}${this.suffix}`;
    }
    getBaseLang(lang) {
        const parts = lang.split(/[-_]/);
        return parts.length > 1 ? parts[0] : null;
    }
}

const SAT_TRANSLATION_FILE_LOCATIONS = new InjectionToken('SAT_TRANSLATION_FILE_LOCATIONS');
const satoriUITranslationPath = '@hylandsoftware/satori-ui';
const httpLoaderFactory = (languageSettings) => (http) => {
    const translationPaths = inject(SAT_TRANSLATION_FILE_LOCATIONS, { optional: true })?.flat() ?? [];
    return new MultiTranslateHttpLoader(http, languageSettings?.prefix ?? './i18n/', languageSettings?.suffix ?? '.json', translationPaths);
};
/**
 * Provides the default translation feature for the Satori UI library.
 * This sets up the translation loader to fetch translation files from the `./i18n/` directory
 * @param languageConfig Configuration for the default language of the application.
 */
function provideAndConfigureSatoriUITranslations(languageConfig) {
    return makeEnvironmentProviders([
        provideHttpClient(),
        provideTranslateService({
            fallbackLang: languageConfig.fallbackLang ?? languageConfig.default,
            loader: {
                provide: TranslateLoader,
                useFactory: httpLoaderFactory(languageConfig.settings),
                deps: [HttpClient],
            },
        }),
        provideTranslations([satoriUITranslationPath]),
    ]);
}
// If translationPaths is not provided, it will fetch file directly from "./i18n/en-US.json"
function provideTranslations(translationPaths = ['']) {
    return makeEnvironmentProviders([
        {
            provide: SAT_TRANSLATION_FILE_LOCATIONS,
            useValue: translationPaths,
            multi: true,
        },
    ]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { provideAndConfigureSatoriUITranslations, provideTranslations };
//# sourceMappingURL=hylandsoftware-satori-ui-translations.mjs.map
