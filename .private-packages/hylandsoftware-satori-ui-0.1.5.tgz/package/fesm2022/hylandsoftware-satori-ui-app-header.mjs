import { DOCUMENT } from '@angular/common';
import * as i0 from '@angular/core';
import { inject, signal, computed, Injectable, ChangeDetectionStrategy, ViewEncapsulation, Component, input, viewChild, ElementRef, effect, Directive, NgModule } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { fromEvent, EMPTY } from 'rxjs';
import { debounceTime, startWith, map } from 'rxjs/operators';

class SatAppHeaderService {
    document = inject(DOCUMENT);
    window = this.document.defaultView;
    scrollSignal = toSignal(fromEvent(this.document, 'scroll', { capture: true }));
    resizeSignal = toSignal(this.window ? fromEvent(this.window, 'resize').pipe(debounceTime(100), startWith(null)) : EMPTY);
    /** @internal Gets updated by the App Header component. Helps `verticalSpace()` to exit early. */
    shouldStick = signal(false);
    /**
     * How much vertical space the App Header is taking up in total at the top of the viewport.
     * Useful for determining offsets for other scrollable content (see Nested Scrollviews).
     */
    verticalSpace = computed(() => {
        this.scrollSignal();
        this.resizeSignal();
        const staticElement = this.document.querySelector('sat-app-header');
        if (!staticElement) {
            return undefined;
        }
        if (!this.shouldStick()) {
            return staticElement.clientHeight;
        }
        const stickyElement = this.document.querySelector('.sat-app-header-content');
        const staticElementBox = staticElement.getBoundingClientRect();
        const stickyElementBox = stickyElement?.getBoundingClientRect();
        if (staticElementBox && stickyElementBox) {
            const staticElementBottom = staticElementBox.bottom;
            const stickyElementTop = stickyElementBox.top;
            const currentVisibleStaticHeight = staticElementBottom - stickyElementTop;
            const stickyElementHeight = stickyElementBox.height + 1; // +1 to account for the border pseudoelement
            return Math.max(currentVisibleStaticHeight, stickyElementHeight);
        }
        return undefined;
    });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAppHeaderService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAppHeaderService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAppHeaderService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const APP_HEADER_MIN_HEIGHT = 64;
/**
 * The component is a customizable header designed to provide a consistent look and feel across applications.
 * It supports navigation, branding, and action items.
 *
 * @deprecated This component will be removed in future versions. Use `sat-app-header` instead.
 *
 */
class HeaderComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: HeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: HeaderComponent, isStandalone: true, selector: "sat-header", ngImport: i0, template: "<header>\n  <div class=\"sat-app-header-content-container\">\n    <div class=\"sat-app-header-content\">\n      <div class=\"sat-app-header-leading-container\">\n        <ng-content select=\"[satAppHeaderTitle], [satHeaderTitle]\"></ng-content>\n      </div>\n      <div class=\"sat-app-header-trailing-container\">\n        <ng-content select=\"[satAppHeaderLogo], [satHeaderLogo]\"></ng-content>\n        <ng-content select=\"[satAppHeaderActions], [satHeaderActions]\"></ng-content>\n      </div>\n    </div>\n  </div>\n  <ng-content select=\"[satAppHeaderNavigation], [satHeaderNavigation]\"></ng-content>\n</header>\n", styles: ["sat-header,sat-app-header{display:block;width:100%;border-bottom-style:solid;border-bottom-width:1px;border-bottom-color:var(--mat-sys-outline-variant, #c8c5d3)}sat-header .sat-app-header-content-container,sat-app-header .sat-app-header-content-container{background-color:var(--mat-sys-background, #f9f9fc)}sat-header .sat-app-header-content-container.sat-app-header-sticky-content-container:before,sat-app-header .sat-app-header-content-container.sat-app-header-sticky-content-container:before{content:\"\";width:100%;height:1px;background-color:var(--mat-sys-outline-variant, #c8c5d3);display:block;position:absolute;inset:auto 0;z-index:1}sat-header .sat-app-header-content,sat-app-header .sat-app-header-content{box-sizing:border-box;min-height:64px;display:flex;align-items:flex-start;justify-content:space-between;padding:8px 4px;flex-wrap:nowrap;gap:1rem;background-color:var(--mat-sys-background, #f9f9fc)}sat-header .sat-app-header-content.sat-app-header-sticky-content,sat-app-header .sat-app-header-content.sat-app-header-sticky-content{position:absolute;top:0;z-index:3}sat-header .sat-app-header-leading-container,sat-app-header .sat-app-header-leading-container{display:flex;align-items:flex-start;flex-wrap:nowrap;align-self:center}sat-header [satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderPlatformNavMobileTrigger]{display:none}@media(width<=675px){sat-header [satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderPlatformNavMobileTrigger]{display:block}}@media(width<=675px){sat-header [satAppHeaderLeadingAction]+[satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderLeadingAction]+[satAppHeaderPlatformNavMobileTrigger]{display:none}}sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--mat-sys-headline-small);color:var(--mat-sys-on-surface-variant, #414752);margin:0;align-self:center}@media(width<=619px){sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--mat-sys-title-large)}}@media(width>675px){sat-header [satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header h1[satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header [satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header h1[satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header [satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header h1[satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header [satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header h1[satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]){margin-left:20px}}sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:block}@media(width<=619px){sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:none}}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{padding:0 1rem;margin-bottom:calc(-1 * var(--mat-tab-header-divider-height, 1px));z-index:2;background-color:var(--mat-sys-background, #f9f9fc);border-bottom-style:solid;border-bottom-width:var(--mat-tab-header-divider-height, 1px);border-bottom-color:var(--mat-sys-outline-variant, #c8c5d3)}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{--mat-tab-header-divider-height: 0}sat-header .sat-app-header-logo sat-word-mark-logo,sat-header sat-word-mark-logo.sat-app-header-logo,sat-app-header .sat-app-header-logo sat-word-mark-logo,sat-app-header sat-word-mark-logo.sat-app-header-logo{width:106px;height:48px}sat-header .sat-app-header-trailing-container,sat-app-header .sat-app-header-trailing-container{display:flex;align-items:center;gap:.5rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: HeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-header', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<header>\n  <div class=\"sat-app-header-content-container\">\n    <div class=\"sat-app-header-content\">\n      <div class=\"sat-app-header-leading-container\">\n        <ng-content select=\"[satAppHeaderTitle], [satHeaderTitle]\"></ng-content>\n      </div>\n      <div class=\"sat-app-header-trailing-container\">\n        <ng-content select=\"[satAppHeaderLogo], [satHeaderLogo]\"></ng-content>\n        <ng-content select=\"[satAppHeaderActions], [satHeaderActions]\"></ng-content>\n      </div>\n    </div>\n  </div>\n  <ng-content select=\"[satAppHeaderNavigation], [satHeaderNavigation]\"></ng-content>\n</header>\n", styles: ["sat-header,sat-app-header{display:block;width:100%;border-bottom-style:solid;border-bottom-width:1px;border-bottom-color:var(--mat-sys-outline-variant, #c8c5d3)}sat-header .sat-app-header-content-container,sat-app-header .sat-app-header-content-container{background-color:var(--mat-sys-background, #f9f9fc)}sat-header .sat-app-header-content-container.sat-app-header-sticky-content-container:before,sat-app-header .sat-app-header-content-container.sat-app-header-sticky-content-container:before{content:\"\";width:100%;height:1px;background-color:var(--mat-sys-outline-variant, #c8c5d3);display:block;position:absolute;inset:auto 0;z-index:1}sat-header .sat-app-header-content,sat-app-header .sat-app-header-content{box-sizing:border-box;min-height:64px;display:flex;align-items:flex-start;justify-content:space-between;padding:8px 4px;flex-wrap:nowrap;gap:1rem;background-color:var(--mat-sys-background, #f9f9fc)}sat-header .sat-app-header-content.sat-app-header-sticky-content,sat-app-header .sat-app-header-content.sat-app-header-sticky-content{position:absolute;top:0;z-index:3}sat-header .sat-app-header-leading-container,sat-app-header .sat-app-header-leading-container{display:flex;align-items:flex-start;flex-wrap:nowrap;align-self:center}sat-header [satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderPlatformNavMobileTrigger]{display:none}@media(width<=675px){sat-header [satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderPlatformNavMobileTrigger]{display:block}}@media(width<=675px){sat-header [satAppHeaderLeadingAction]+[satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderLeadingAction]+[satAppHeaderPlatformNavMobileTrigger]{display:none}}sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--mat-sys-headline-small);color:var(--mat-sys-on-surface-variant, #414752);margin:0;align-self:center}@media(width<=619px){sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--mat-sys-title-large)}}@media(width>675px){sat-header [satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header h1[satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header [satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header h1[satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header [satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header h1[satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header [satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header h1[satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]){margin-left:20px}}sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:block}@media(width<=619px){sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:none}}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{padding:0 1rem;margin-bottom:calc(-1 * var(--mat-tab-header-divider-height, 1px));z-index:2;background-color:var(--mat-sys-background, #f9f9fc);border-bottom-style:solid;border-bottom-width:var(--mat-tab-header-divider-height, 1px);border-bottom-color:var(--mat-sys-outline-variant, #c8c5d3)}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{--mat-tab-header-divider-height: 0}sat-header .sat-app-header-logo sat-word-mark-logo,sat-header sat-word-mark-logo.sat-app-header-logo,sat-app-header .sat-app-header-logo sat-word-mark-logo,sat-app-header sat-word-mark-logo.sat-app-header-logo{width:106px;height:48px}sat-header .sat-app-header-trailing-container,sat-app-header .sat-app-header-trailing-container{display:flex;align-items:center;gap:.5rem}\n"] }]
        }] });
/**
 * The `App Header` component is a customizable header designed to provide a consistent look and feel across applications.
 * It supports navigation, branding, and action items.
 *
 * @example
 * <sat-app-header>
 *  <h2 satAppHeaderTitle>{{ title }}</h2>
 *  <sat-word-mark-logo satAppHeaderLogo></sat-word-mark-logo>
 *  <div satAppHeaderActions>
 *    ...
 *  </div>
 *  <nav mat-tab-nav-bar satAppHeaderNavigation [tabPanel]="tabPanel" mat-stretch-tabs="false">
 *    <a mat-tab-link routerLink="#" [active]="true">Tasks</a>
 *  </nav>
 * </sat-app-header>
 */
class AppHeaderComponent {
    /** Whether the header should stick to the top of the viewport. Defaults to true. Excludes navigation (Tabs). */
    sticky = input(true);
    content = viewChild('appHeaderContent');
    document = inject(DOCUMENT);
    hostElement = inject(ElementRef);
    service = inject(SatAppHeaderService);
    scrollTop = toSignal(fromEvent(this.document, 'scroll', { capture: true }).pipe(map(() => {
        const main = this.document.querySelector('main');
        if (!main) {
            if (this.sticky()) {
                console.warn('App Header sticky behavior requires a full-height scrollable <main> element in the document.');
            }
            return undefined;
        }
        return main.scrollTop ?? 0;
    }), startWith(0)));
    hasScrolledPastTop = computed(() => (this.scrollTop() ?? 0) > 0);
    /** @internal */
    shouldStick = computed(() => this.sticky() && this.hasScrolledPastTop());
    resizeSignal = toSignal(fromEvent(window, 'resize').pipe(debounceTime(100), startWith(null)));
    /** @internal Accounts for App Header title wrapping to multiple lines. */
    headerPaddingTop = computed(() => {
        this.resizeSignal(); // Subscribe to resize events to trigger recalculation
        return this.shouldStick()
            ? this.content()?.nativeElement.clientHeight || APP_HEADER_MIN_HEIGHT
            : 0;
    });
    /** @internal Width of the sticky content, matching the host element to avoid covering the scrollbar. */
    stickyContentWidth = computed(() => {
        this.resizeSignal();
        if (!this.shouldStick())
            return null;
        return this.hostElement.nativeElement.offsetWidth;
    });
    constructor() {
        effect(() => {
            this.service.shouldStick.set(this.shouldStick());
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.19", type: AppHeaderComponent, isStandalone: true, selector: "sat-app-header", inputs: { sticky: { classPropertyName: "sticky", publicName: "sticky", isSignal: true, isRequired: false, transformFunction: null } }, viewQueries: [{ propertyName: "content", first: true, predicate: ["appHeaderContent"], descendants: true, isSignal: true }], ngImport: i0, template: "<header [style.padding-top.px]=\"headerPaddingTop()\">\n  <div\n    class=\"sat-app-header-content-container\"\n    [class.sat-app-header-sticky-content-container]=\"shouldStick()\"\n  >\n    <div\n      #appHeaderContent\n      class=\"sat-app-header-content\"\n      [class.sat-app-header-sticky-content]=\"shouldStick()\"\n      [style.width.px]=\"stickyContentWidth()\"\n    >\n      <div class=\"sat-app-header-leading-container\">\n        <ng-content select=\"[satAppHeaderLeadingAction]\"></ng-content>\n        <ng-content select=\"[satAppHeaderPlatformNavMobileTrigger]\"></ng-content>\n        <ng-content select=\"[satAppHeaderTitle], [satHeaderTitle]\"></ng-content>\n      </div>\n      <div class=\"sat-app-header-trailing-container\">\n        <ng-content select=\"[satAppHeaderLogo], [satHeaderLogo]\"></ng-content>\n        <ng-content select=\"[satAppHeaderActions], [satHeaderActions]\"></ng-content>\n      </div>\n    </div>\n  </div>\n  <ng-content select=\"[satAppHeaderNavigation], [satHeaderNavigation]\"></ng-content>\n</header>\n", styles: ["sat-header,sat-app-header{display:block;width:100%;border-bottom-style:solid;border-bottom-width:1px;border-bottom-color:var(--mat-sys-outline-variant, #c8c5d3)}sat-header .sat-app-header-content-container,sat-app-header .sat-app-header-content-container{background-color:var(--mat-sys-background, #f9f9fc)}sat-header .sat-app-header-content-container.sat-app-header-sticky-content-container:before,sat-app-header .sat-app-header-content-container.sat-app-header-sticky-content-container:before{content:\"\";width:100%;height:1px;background-color:var(--mat-sys-outline-variant, #c8c5d3);display:block;position:absolute;inset:auto 0;z-index:1}sat-header .sat-app-header-content,sat-app-header .sat-app-header-content{box-sizing:border-box;min-height:64px;display:flex;align-items:flex-start;justify-content:space-between;padding:8px 4px;flex-wrap:nowrap;gap:1rem;background-color:var(--mat-sys-background, #f9f9fc)}sat-header .sat-app-header-content.sat-app-header-sticky-content,sat-app-header .sat-app-header-content.sat-app-header-sticky-content{position:absolute;top:0;z-index:3}sat-header .sat-app-header-leading-container,sat-app-header .sat-app-header-leading-container{display:flex;align-items:flex-start;flex-wrap:nowrap;align-self:center}sat-header [satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderPlatformNavMobileTrigger]{display:none}@media(width<=675px){sat-header [satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderPlatformNavMobileTrigger]{display:block}}@media(width<=675px){sat-header [satAppHeaderLeadingAction]+[satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderLeadingAction]+[satAppHeaderPlatformNavMobileTrigger]{display:none}}sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--mat-sys-headline-small);color:var(--mat-sys-on-surface-variant, #414752);margin:0;align-self:center}@media(width<=619px){sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--mat-sys-title-large)}}@media(width>675px){sat-header [satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header h1[satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header [satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header h1[satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header [satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header h1[satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header [satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header h1[satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]){margin-left:20px}}sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:block}@media(width<=619px){sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:none}}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{padding:0 1rem;margin-bottom:calc(-1 * var(--mat-tab-header-divider-height, 1px));z-index:2;background-color:var(--mat-sys-background, #f9f9fc);border-bottom-style:solid;border-bottom-width:var(--mat-tab-header-divider-height, 1px);border-bottom-color:var(--mat-sys-outline-variant, #c8c5d3)}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{--mat-tab-header-divider-height: 0}sat-header .sat-app-header-logo sat-word-mark-logo,sat-header sat-word-mark-logo.sat-app-header-logo,sat-app-header .sat-app-header-logo sat-word-mark-logo,sat-app-header sat-word-mark-logo.sat-app-header-logo{width:106px;height:48px}sat-header .sat-app-header-trailing-container,sat-app-header .sat-app-header-trailing-container{display:flex;align-items:center;gap:.5rem}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-app-header', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, template: "<header [style.padding-top.px]=\"headerPaddingTop()\">\n  <div\n    class=\"sat-app-header-content-container\"\n    [class.sat-app-header-sticky-content-container]=\"shouldStick()\"\n  >\n    <div\n      #appHeaderContent\n      class=\"sat-app-header-content\"\n      [class.sat-app-header-sticky-content]=\"shouldStick()\"\n      [style.width.px]=\"stickyContentWidth()\"\n    >\n      <div class=\"sat-app-header-leading-container\">\n        <ng-content select=\"[satAppHeaderLeadingAction]\"></ng-content>\n        <ng-content select=\"[satAppHeaderPlatformNavMobileTrigger]\"></ng-content>\n        <ng-content select=\"[satAppHeaderTitle], [satHeaderTitle]\"></ng-content>\n      </div>\n      <div class=\"sat-app-header-trailing-container\">\n        <ng-content select=\"[satAppHeaderLogo], [satHeaderLogo]\"></ng-content>\n        <ng-content select=\"[satAppHeaderActions], [satHeaderActions]\"></ng-content>\n      </div>\n    </div>\n  </div>\n  <ng-content select=\"[satAppHeaderNavigation], [satHeaderNavigation]\"></ng-content>\n</header>\n", styles: ["sat-header,sat-app-header{display:block;width:100%;border-bottom-style:solid;border-bottom-width:1px;border-bottom-color:var(--mat-sys-outline-variant, #c8c5d3)}sat-header .sat-app-header-content-container,sat-app-header .sat-app-header-content-container{background-color:var(--mat-sys-background, #f9f9fc)}sat-header .sat-app-header-content-container.sat-app-header-sticky-content-container:before,sat-app-header .sat-app-header-content-container.sat-app-header-sticky-content-container:before{content:\"\";width:100%;height:1px;background-color:var(--mat-sys-outline-variant, #c8c5d3);display:block;position:absolute;inset:auto 0;z-index:1}sat-header .sat-app-header-content,sat-app-header .sat-app-header-content{box-sizing:border-box;min-height:64px;display:flex;align-items:flex-start;justify-content:space-between;padding:8px 4px;flex-wrap:nowrap;gap:1rem;background-color:var(--mat-sys-background, #f9f9fc)}sat-header .sat-app-header-content.sat-app-header-sticky-content,sat-app-header .sat-app-header-content.sat-app-header-sticky-content{position:absolute;top:0;z-index:3}sat-header .sat-app-header-leading-container,sat-app-header .sat-app-header-leading-container{display:flex;align-items:flex-start;flex-wrap:nowrap;align-self:center}sat-header [satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderPlatformNavMobileTrigger]{display:none}@media(width<=675px){sat-header [satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderPlatformNavMobileTrigger]{display:block}}@media(width<=675px){sat-header [satAppHeaderLeadingAction]+[satAppHeaderPlatformNavMobileTrigger],sat-app-header [satAppHeaderLeadingAction]+[satAppHeaderPlatformNavMobileTrigger]{display:none}}sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--mat-sys-headline-small);color:var(--mat-sys-on-surface-variant, #414752);margin:0;align-self:center}@media(width<=619px){sat-header [satAppHeaderTitle],sat-header h1[satAppHeaderTitle],sat-header [satHeaderTitle],sat-header h1[satHeaderTitle],sat-app-header [satAppHeaderTitle],sat-app-header h1[satAppHeaderTitle],sat-app-header [satHeaderTitle],sat-app-header h1[satHeaderTitle]{font:var(--mat-sys-title-large)}}@media(width>675px){sat-header [satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header h1[satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header [satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-header h1[satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header [satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header h1[satAppHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header [satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]),sat-app-header h1[satHeaderTitle]:not([satAppHeaderLeadingAction]~[satAppHeaderTitle]){margin-left:20px}}sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:block}@media(width<=619px){sat-header [satAppHeaderLogo],sat-header [satHeaderLogo],sat-app-header [satAppHeaderLogo],sat-app-header [satHeaderLogo]{display:none}}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{padding:0 1rem;margin-bottom:calc(-1 * var(--mat-tab-header-divider-height, 1px));z-index:2;background-color:var(--mat-sys-background, #f9f9fc);border-bottom-style:solid;border-bottom-width:var(--mat-tab-header-divider-height, 1px);border-bottom-color:var(--mat-sys-outline-variant, #c8c5d3)}sat-header [satAppHeaderNavigation],sat-header [satHeaderNavigation],sat-app-header [satAppHeaderNavigation],sat-app-header [satHeaderNavigation]{--mat-tab-header-divider-height: 0}sat-header .sat-app-header-logo sat-word-mark-logo,sat-header sat-word-mark-logo.sat-app-header-logo,sat-app-header .sat-app-header-logo sat-word-mark-logo,sat-app-header sat-word-mark-logo.sat-app-header-logo{width:106px;height:48px}sat-header .sat-app-header-trailing-container,sat-app-header .sat-app-header-trailing-container{display:flex;align-items:center;gap:.5rem}\n"] }]
        }], ctorParameters: () => [] });

/**
 * You can use this directive to create a title in the app header.
 *
 * @deprecated `satHeaderTitle` is deprecated, use `satAppHeaderTitle` instead.
 */
class AppHeaderTitleDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderTitleDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: AppHeaderTitleDirective, isStandalone: true, selector: "[satHeaderTitle], [satAppHeaderTitle]", host: { classAttribute: "sat-app-header-title" }, exportAs: ["satAppHeaderTitle"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderTitleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHeaderTitle], [satAppHeaderTitle]',
                    exportAs: 'satAppHeaderTitle',
                    host: {
                        class: 'sat-app-header-title',
                    },
                }]
        }] });

/**
 * You can use this directive to create action buttons and items in the app header.
 *
 * @deprecated `satHeaderActions` is deprecated, use `satAppHeaderActions` instead.
 */
class AppHeaderActionsDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderActionsDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: AppHeaderActionsDirective, isStandalone: true, selector: "[satHeaderActions], [satAppHeaderActions]", host: { classAttribute: "sat-app-header-actions" }, exportAs: ["satAppHeaderActions"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderActionsDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHeaderActions], [satAppHeaderActions]',
                    exportAs: 'satAppHeaderActions',
                    host: {
                        class: 'sat-app-header-actions',
                    },
                }]
        }] });

/**
 * You can use this directive to create a Hyland logo in the app header.
 * It integrates seamlessly with `sat-word-mark-logo` when used for the App Header logo slot.
 *
 * @deprecated `satHeaderLogo` is deprecated, use `satAppHeaderLogo` instead.
 */
class AppHeaderLogoDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderLogoDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: AppHeaderLogoDirective, isStandalone: true, selector: "[satHeaderLogo], [satAppHeaderLogo]", host: { classAttribute: "sat-app-header-logo" }, exportAs: ["satAppHeaderLogo"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderLogoDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHeaderLogo], [satAppHeaderLogo]',
                    exportAs: 'satAppHeaderLogo',
                    host: {
                        class: 'sat-app-header-logo',
                    },
                }]
        }] });

/**
 * You can use this directive to create navigation in the app header.
 *
 * @deprecated `satHeaderNavigation` is deprecated, use `satAppHeaderNavigation` instead.
 */
class AppHeaderNavigationDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderNavigationDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: AppHeaderNavigationDirective, isStandalone: true, selector: "[satHeaderNavigation], [satAppHeaderNavigation]", host: { classAttribute: "sat-app-header-navigation" }, exportAs: ["satAppHeaderNavigation"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderNavigationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHeaderNavigation], [satAppHeaderNavigation]',
                    exportAs: 'satAppHeaderNavigation',
                    host: {
                        class: 'sat-app-header-navigation',
                    },
                }]
        }] });

/**
 * You can use this directive to insert a Platform Nav trigger in the app header,
 * that is only visible when viewed on small viewports.
 */
class AppHeaderPlatformNavMobileTriggerDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderPlatformNavMobileTriggerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: AppHeaderPlatformNavMobileTriggerDirective, isStandalone: true, selector: "[satAppHeaderPlatformNavMobileTrigger]", host: { classAttribute: "sat-app-header-platform-nav-mobile-trigger" }, exportAs: ["satAppHeaderPlatformNavMobileTrigger"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderPlatformNavMobileTriggerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satAppHeaderPlatformNavMobileTrigger]',
                    exportAs: 'satAppHeaderPlatformNavMobileTrigger',
                    host: {
                        class: 'sat-app-header-platform-nav-mobile-trigger',
                    },
                }]
        }] });

/**
 * You can use this directive to position a leading action icon button in the App Header.
 * The leading action takes precedence over the Platform Nav mobile trigger when both are present.
 */
class AppHeaderLeadingActionDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderLeadingActionDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: AppHeaderLeadingActionDirective, isStandalone: true, selector: "[satAppHeaderLeadingAction]", host: { classAttribute: "sat-app-header-leading-action" }, exportAs: ["satAppHeaderLeadingAction"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: AppHeaderLeadingActionDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satAppHeaderLeadingAction]',
                    exportAs: 'satAppHeaderLeadingAction',
                    host: {
                        class: 'sat-app-header-leading-action',
                    },
                }]
        }] });

const headerArtifacts = [
    HeaderComponent,
    AppHeaderComponent,
    AppHeaderTitleDirective,
    AppHeaderActionsDirective,
    AppHeaderLogoDirective,
    AppHeaderNavigationDirective,
    AppHeaderPlatformNavMobileTriggerDirective,
    AppHeaderLeadingActionDirective,
];
class SatAppHeaderModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAppHeaderModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatAppHeaderModule, imports: [HeaderComponent,
            AppHeaderComponent,
            AppHeaderTitleDirective,
            AppHeaderActionsDirective,
            AppHeaderLogoDirective,
            AppHeaderNavigationDirective,
            AppHeaderPlatformNavMobileTriggerDirective,
            AppHeaderLeadingActionDirective], exports: [HeaderComponent,
            AppHeaderComponent,
            AppHeaderTitleDirective,
            AppHeaderActionsDirective,
            AppHeaderLogoDirective,
            AppHeaderNavigationDirective,
            AppHeaderPlatformNavMobileTriggerDirective,
            AppHeaderLeadingActionDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAppHeaderModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAppHeaderModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: headerArtifacts,
                    exports: headerArtifacts,
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AppHeaderActionsDirective, AppHeaderComponent, AppHeaderLeadingActionDirective, AppHeaderLogoDirective, AppHeaderNavigationDirective, AppHeaderPlatformNavMobileTriggerDirective, AppHeaderTitleDirective, HeaderComponent, SatAppHeaderModule, SatAppHeaderService, SatAppHeaderModule as SatHeaderModule };
//# sourceMappingURL=hylandsoftware-satori-ui-app-header.mjs.map
