import { _CdkPrivateStyleLoader } from '@angular/cdk/private';
import * as i0 from '@angular/core';
import { inject, Directive } from '@angular/core';
import { _StructuralStylesLoader } from '@angular/material/core';

/**
 * Directive that adds the `mat-focus-indicator` class to the host element.
 *
 * This enables Material's focus indicator styles on any element where the directive is applied.
 *
 * @example
 * ```html
 * <button satFocusIndicator>Click me</button>
 * ```
 */
class SatFocusIndicatorDirective {
    constructor() {
        inject(_CdkPrivateStyleLoader).load(_StructuralStylesLoader);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatFocusIndicatorDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: SatFocusIndicatorDirective, isStandalone: true, selector: "[satFocusIndicator]", host: { properties: { "class.mat-focus-indicator": "true" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatFocusIndicatorDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satFocusIndicator]',
                    host: {
                        '[class.mat-focus-indicator]': 'true',
                    },
                }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatFocusIndicatorDirective };
//# sourceMappingURL=hylandsoftware-satori-ui-focus-indicator.mjs.map
