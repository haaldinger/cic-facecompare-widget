import * as i0 from '@angular/core';
import { ViewEncapsulation, ChangeDetectionStrategy, Component, input, NgModule } from '@angular/core';

/**
 * Component for displaying the Hyland H mark logo.
 */
class SatHMarkLogoComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatHMarkLogoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatHMarkLogoComponent, isStandalone: true, selector: "sat-h-mark-logo", ngImport: i0, template: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 56 30\" fill=\"none\">\n  <path d=\"M26.6593 -0.0090332L18.2177 14.9941H27.9944L36.4359 -0.0090332H26.6593Z\" fill=\"var(--sat-logo-hyland-purple-color, #6E33FF)\"/>\n  <path d=\"M8.44107 14.9969L0 30H9.77667L18.2177 14.9969H8.44107Z\" fill=\"var(--sat-logo-hyland-yellow-color, #F1CB61)\"/>\n  <path d=\"M28.0037 15.005L19.5627 30.0085H29.3393L37.7804 15.005H28.0037Z\" fill=\"var(--sat-logo-hyland-blue-color, #52A1FF)\"/>\n  <path d=\"M46.2224 -2.00626e-05L37.7804 15.005H47.558L56 -2.00626e-05H46.2224Z\" fill=\"var(--sat-logo-hyland-teal-color, #13EAC1)\"/>\n</svg>\n", styles: ["sat-h-mark-logo{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1200/632.78}sat-h-mark-logo svg{width:100%;height:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatHMarkLogoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-h-mark-logo', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 56 30\" fill=\"none\">\n  <path d=\"M26.6593 -0.0090332L18.2177 14.9941H27.9944L36.4359 -0.0090332H26.6593Z\" fill=\"var(--sat-logo-hyland-purple-color, #6E33FF)\"/>\n  <path d=\"M8.44107 14.9969L0 30H9.77667L18.2177 14.9969H8.44107Z\" fill=\"var(--sat-logo-hyland-yellow-color, #F1CB61)\"/>\n  <path d=\"M28.0037 15.005L19.5627 30.0085H29.3393L37.7804 15.005H28.0037Z\" fill=\"var(--sat-logo-hyland-blue-color, #52A1FF)\"/>\n  <path d=\"M46.2224 -2.00626e-05L37.7804 15.005H47.558L56 -2.00626e-05H46.2224Z\" fill=\"var(--sat-logo-hyland-teal-color, #13EAC1)\"/>\n</svg>\n", styles: ["sat-h-mark-logo{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1200/632.78}sat-h-mark-logo svg{width:100%;height:100%}\n"] }]
        }] });

/**
 * Logo component for displaying the brand logo.
 * This component supports both horizontal and vertical layouts.
 * This component is a combination of the H mark logo and the word mark logo.
 */
class SatLogoComponent {
    /**
     * The direction of the logo.
     * Can be either `horizontal` or `vertical`.
     */
    direction = input('horizontal');
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatLogoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.19", type: SatLogoComponent, isStandalone: true, selector: "sat-logo", inputs: { direction: { classPropertyName: "direction", publicName: "direction", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.sat-logo-horizontal": "direction() === 'horizontal'", "class.sat-logo-vertical": "direction() === 'vertical'" } }, ngImport: i0, template: `
    <ng-content select="sat-h-mark-logo"></ng-content>
    <ng-content select="sat-word-mark-logo"></ng-content>
  `, isInline: true, styles: ["sat-logo{display:flex;align-items:center;justify-content:space-between;overflow:hidden}.sat-logo-horizontal{flex-direction:row;aspect-ratio:1200/248.44}.sat-logo-horizontal sat-h-mark-logo{width:39.2616666667%}.sat-logo-horizontal sat-word-mark-logo{width:58.6808333333%}.sat-logo-vertical{flex-direction:column;aspect-ratio:1200/536.06}.sat-logo-vertical sat-h-mark-logo{height:61.0677909189%;width:auto}.sat-logo-vertical sat-word-mark-logo{height:25.433720106%;width:auto}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatLogoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-logo', host: {
                        '[class.sat-logo-horizontal]': "direction() === 'horizontal'",
                        '[class.sat-logo-vertical]': "direction() === 'vertical'",
                    }, template: `
    <ng-content select="sat-h-mark-logo"></ng-content>
    <ng-content select="sat-word-mark-logo"></ng-content>
  `, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: ["sat-logo{display:flex;align-items:center;justify-content:space-between;overflow:hidden}.sat-logo-horizontal{flex-direction:row;aspect-ratio:1200/248.44}.sat-logo-horizontal sat-h-mark-logo{width:39.2616666667%}.sat-logo-horizontal sat-word-mark-logo{width:58.6808333333%}.sat-logo-vertical{flex-direction:column;aspect-ratio:1200/536.06}.sat-logo-vertical sat-h-mark-logo{height:61.0677909189%;width:auto}.sat-logo-vertical sat-word-mark-logo{height:25.433720106%;width:auto}\n"] }]
        }] });

/**
 * Component for displaying the Hyland word mark logo.
 */
class SatWordMarkLogoComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatWordMarkLogoComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatWordMarkLogoComponent, isStandalone: true, selector: "sat-word-mark-logo", ngImport: i0, template: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 106 12\" fill=\"none\">\n  <path d=\"M12.8021 8.1691e-06V11.9304H10.0188V7.01175H2.78338V11.9304H0V8.1691e-06H2.78338V4.65278H10.0179V8.1691e-06H12.8021ZM27.2005 8.1691e-06H30.4679L24.516 6.98005V11.9322H21.7326V6.98005L15.7657 8.1691e-06H19.1162L23.1672 4.71882L27.2005 8.1691e-06ZM33.4289 8.1691e-06H36.2122V9.55475H44.2974V11.9304H33.4289V8.1691e-06ZM56.3964 8.1691e-06L62.3483 11.9304H59.3308L58.065 9.3716H51.4966L50.2308 11.9304H47.2636L53.2456 8.1691e-06H56.3964ZM52.6281 7.07867H56.9458L54.7949 2.72528L52.6281 7.07867ZM77.9286 11.9304H75.4782L68.0096 3.5389V11.9304H65.3092V8.1691e-06H68.1262L75.2273 7.99267V8.1691e-06H77.9277V11.9304H77.9286ZM82.642 -0.00439453H88.881C93.159 -0.00439453 95.8417 2.33696 95.8417 5.99825C95.8417 9.65953 93.1572 12.0009 88.881 12.0009H82.642V-0.00439453ZM88.8139 9.59701C91.41 9.59701 92.9258 8.17582 92.9258 5.99649C92.9258 3.81715 91.4109 2.39596 88.7971 2.39596H85.3512V9.59878H88.8139V9.59701ZM100.525 0.552107V2.77459H99.8776V0.552107H98.6674V8.1691e-06H101.731V0.552107H100.525ZM103.903 2.77459L102.961 0.6384V2.77459H102.329V8.1691e-06H103.307L104.174 1.98563L105.039 8.1691e-06H106V2.77459H105.372V0.637519L104.426 2.77371H103.903V2.77459Z\" fill=\"currentColor\"/>\n</svg>\n", styles: ["sat-word-mark-logo{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1200/136.33}sat-word-mark-logo svg{width:100%;height:100%;color:var(--sat-logo-hyland-dark-blue-color)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatWordMarkLogoComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-word-mark-logo', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 106 12\" fill=\"none\">\n  <path d=\"M12.8021 8.1691e-06V11.9304H10.0188V7.01175H2.78338V11.9304H0V8.1691e-06H2.78338V4.65278H10.0179V8.1691e-06H12.8021ZM27.2005 8.1691e-06H30.4679L24.516 6.98005V11.9322H21.7326V6.98005L15.7657 8.1691e-06H19.1162L23.1672 4.71882L27.2005 8.1691e-06ZM33.4289 8.1691e-06H36.2122V9.55475H44.2974V11.9304H33.4289V8.1691e-06ZM56.3964 8.1691e-06L62.3483 11.9304H59.3308L58.065 9.3716H51.4966L50.2308 11.9304H47.2636L53.2456 8.1691e-06H56.3964ZM52.6281 7.07867H56.9458L54.7949 2.72528L52.6281 7.07867ZM77.9286 11.9304H75.4782L68.0096 3.5389V11.9304H65.3092V8.1691e-06H68.1262L75.2273 7.99267V8.1691e-06H77.9277V11.9304H77.9286ZM82.642 -0.00439453H88.881C93.159 -0.00439453 95.8417 2.33696 95.8417 5.99825C95.8417 9.65953 93.1572 12.0009 88.881 12.0009H82.642V-0.00439453ZM88.8139 9.59701C91.41 9.59701 92.9258 8.17582 92.9258 5.99649C92.9258 3.81715 91.4109 2.39596 88.7971 2.39596H85.3512V9.59878H88.8139V9.59701ZM100.525 0.552107V2.77459H99.8776V0.552107H98.6674V8.1691e-06H101.731V0.552107H100.525ZM103.903 2.77459L102.961 0.6384V2.77459H102.329V8.1691e-06H103.307L104.174 1.98563L105.039 8.1691e-06H106V2.77459H105.372V0.637519L104.426 2.77371H103.903V2.77459Z\" fill=\"currentColor\"/>\n</svg>\n", styles: ["sat-word-mark-logo{width:100%;display:flex;justify-content:center;align-items:center;aspect-ratio:1200/136.33}sat-word-mark-logo svg{width:100%;height:100%;color:var(--sat-logo-hyland-dark-blue-color)}\n"] }]
        }] });

const COMPONENTS = [SatLogoComponent, SatHMarkLogoComponent, SatWordMarkLogoComponent];
class SatLogoModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatLogoModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatLogoModule, imports: [SatLogoComponent, SatHMarkLogoComponent, SatWordMarkLogoComponent], exports: [SatLogoComponent, SatHMarkLogoComponent, SatWordMarkLogoComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatLogoModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatLogoModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: COMPONENTS,
                    exports: COMPONENTS,
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatHMarkLogoComponent, SatLogoComponent, SatLogoModule, SatWordMarkLogoComponent };
//# sourceMappingURL=hylandsoftware-satori-ui-logo.mjs.map
