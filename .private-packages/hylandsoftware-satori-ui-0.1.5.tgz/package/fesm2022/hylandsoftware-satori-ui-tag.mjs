import * as i0 from '@angular/core';
import { ViewEncapsulation, ChangeDetectionStrategy, Component, input, computed, Directive, booleanAttribute, NgModule } from '@angular/core';
import * as i1$1 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i1 from '@hylandsoftware/satori-ui/focus-indicator';
import { SatFocusIndicatorDirective } from '@hylandsoftware/satori-ui/focus-indicator';

/**
 * Tag component for displaying a tag with an optional icon and label.
 * This component is designed to be used internally within the Satori UI framework, providing a consistent look and feel for tags across applications.
 * @internal
 */
class SatTagComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatTagComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatTagComponent, isStandalone: true, selector: "sat-tag", host: { classAttribute: "sat-tag" }, ngImport: i0, template: `
    <ng-content select=".sat-tag-icon"></ng-content>
    <p class="sat-tag-label">
      <ng-content></ng-content>
    </p>
  `, isInline: true, styles: [".sat-tag{position:relative;display:inline-flex;justify-content:center;align-items:center;gap:4px;min-height:24px;box-sizing:border-box;border-radius:var(--sat-tag-corner);padding:2px 8px;box-shadow:inset 0 0 0 1px var(--mat-sys-surface-container-lowest, transparent)}.sat-tag .sat-tag-icon{display:contents}.sat-tag .sat-tag-icon .mat-icon{display:flex;justify-content:center;align-items:center;width:16px;height:16px;flex-shrink:0}.sat-tag .sat-tag-icon .mat-icon>svg{display:flex;justify-content:center;align-items:center;width:100%;height:100%}.sat-tag .sat-tag-label{font-family:var(--sat-tag-label-font);font-size:var(--sat-tag-label-size);font-weight:var(--sat-tag-label-weight);line-height:var(--sat-tag-label-line-height);letter-spacing:var(--sat-tag-label-tracking);font-style:normal;margin:0;padding:0}.sat-tag:has(.sat-tag-icon .mat-icon){padding-left:6px}.sat-interactive-tag{cursor:pointer}.sat-interactive-tag.mat-focus-indicator{--mat-focus-indicator-border-radius: 8px}.sat-interactive-tag.mat-focus-indicator:focus{outline:none}.sat-interactive-tag.mat-focus-indicator:before{margin:-4px}.sat-interactive-tag .sat-tag-label{text-decoration:underline dotted;text-decoration-thickness:11%;text-underline-offset:3%;text-decoration-skip-ink:auto;text-underline-position:from-font}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatTagComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-tag', template: `
    <ng-content select=".sat-tag-icon"></ng-content>
    <p class="sat-tag-label">
      <ng-content></ng-content>
    </p>
  `, host: {
                        class: 'sat-tag',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, styles: [".sat-tag{position:relative;display:inline-flex;justify-content:center;align-items:center;gap:4px;min-height:24px;box-sizing:border-box;border-radius:var(--sat-tag-corner);padding:2px 8px;box-shadow:inset 0 0 0 1px var(--mat-sys-surface-container-lowest, transparent)}.sat-tag .sat-tag-icon{display:contents}.sat-tag .sat-tag-icon .mat-icon{display:flex;justify-content:center;align-items:center;width:16px;height:16px;flex-shrink:0}.sat-tag .sat-tag-icon .mat-icon>svg{display:flex;justify-content:center;align-items:center;width:100%;height:100%}.sat-tag .sat-tag-label{font-family:var(--sat-tag-label-font);font-size:var(--sat-tag-label-size);font-weight:var(--sat-tag-label-weight);line-height:var(--sat-tag-label-line-height);letter-spacing:var(--sat-tag-label-tracking);font-style:normal;margin:0;padding:0}.sat-tag:has(.sat-tag-icon .mat-icon){padding-left:6px}.sat-interactive-tag{cursor:pointer}.sat-interactive-tag.mat-focus-indicator{--mat-focus-indicator-border-radius: 8px}.sat-interactive-tag.mat-focus-indicator:focus{outline:none}.sat-interactive-tag.mat-focus-indicator:before{margin:-4px}.sat-interactive-tag .sat-tag-label{text-decoration:underline dotted;text-decoration-thickness:11%;text-underline-offset:3%;text-decoration-skip-ink:auto;text-underline-position:from-font}\n"] }]
        }] });

/**
 * The `SatCategoryTagComponent` is used to display category labels with predefined styles.
 * It supports various categories like purple, blue, pink, etc., and automatically applies the appropriate styles based on the category type mentioned in `SatTagCategory`.
 * There is no default icon for the category component. You need to provide a custom icon which meets your requirements. Otherwise no icon will be displayed.
 *
 * @example
 * <sat-category-tag category="purple">
 *   <mat-icon aria-label="custom icon" svgIcon="tag"></mat-icon>
 *   Purple Category
 * </sat-category-tag>
 */
class SatCategoryTagComponent {
    /**
     * The category of the tag, which determines its style and icon.
     * This should be one of the predefined categories.
     *
     * @type {SatTagCategory}
     * @required
     */
    category = input.required();
    /** @ignore */
    backgroundColor = computed(() => `var(--sat-tag-cat-${this.category()}-container)`);
    /** @ignore */
    color = computed(() => `var(--sat-tag-on-cat-${this.category()}-container)`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatCategoryTagComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.19", type: SatCategoryTagComponent, isStandalone: true, selector: "sat-category-tag", inputs: { category: { classPropertyName: "category", publicName: "category", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: `
    <sat-tag
      [style.backgroundColor]="backgroundColor()"
      [style.color]="color()"
    >
      <div class="sat-tag-icon">
        <ng-content select="[mat-icon], mat-icon"></ng-content>
      </div>
      <ng-content></ng-content>
    </sat-tag>
  `, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: SatTagComponent, selector: "sat-tag" }, { kind: "ngmodule", type: MatIconModule }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatCategoryTagComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-category-tag', imports: [SatTagComponent, MatIconModule], template: `
    <sat-tag
      [style.backgroundColor]="backgroundColor()"
      [style.color]="color()"
    >
      <div class="sat-tag-icon">
        <ng-content select="[mat-icon], mat-icon"></ng-content>
      </div>
      <ng-content></ng-content>
    </sat-tag>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:inline-flex}\n"] }]
        }] });

/**
 * The Directive is used to hide the icon in the tag components.
 * This directive can be applied to all the different types of tag components (e.g. SatStatusTagComponent, SatCategoryTagComponent) to remove the icon from the tag.
 * @deprecated Use the `hideIcon` input property available on the status tag components instead.
 */
class SatHideIconDirective {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatHideIconDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: SatHideIconDirective, isStandalone: true, selector: "[satHideIcon]", exportAs: ["satHideIcon"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatHideIconDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satHideIcon]',
                    exportAs: 'satHideIcon',
                }]
        }] });

/**
 * Directive that transforms a tag element to make it interactive to allow to attach a tooltip or rich-tooltip.
 */
class SatInteractiveTagDirective {
    /**
     * Keyboard interaction to allow the tag to be activated with Enter or Space keys, similar to a button
     */
    onKeyDown(event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            event.target?.click();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatInteractiveTagDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: SatInteractiveTagDirective, isStandalone: true, selector: "[satInteractiveTag]", host: { attributes: { "role": "button" }, listeners: { "keydown": "onKeyDown($event)" }, properties: { "attr.tabindex": "0" }, classAttribute: "sat-interactive-tag" }, exportAs: ["satInteractiveTag"], hostDirectives: [{ directive: i1.SatFocusIndicatorDirective }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatInteractiveTagDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[satInteractiveTag]',
                    exportAs: 'satInteractiveTag',
                    host: {
                        role: 'button',
                        class: 'sat-interactive-tag',
                        '[attr.tabindex]': '0',
                        '(keydown)': 'onKeyDown($event)',
                    },
                    hostDirectives: [SatFocusIndicatorDirective],
                }]
        }] });

const satStatusTagIcon = {
    'important-loud': 'error',
    'important': 'error',
    'success': 'circle_check',
    'warning': 'critical',
    'info': 'critical',
    'neutral': 'circle_minus',
};

/**
 * The `SatStatusTagComponent` is used to display status labels with predefined styles and icons.
 * It supports various statuses like success, warning, info, etc., and automatically applies the appropriate styles and icons based on different status types mentioned in `SatTagStatus`, and the icon or the style of this component is predefined for the selected status.
 * You can also provide a custom icon to overwrite the predefined icon for a specific status.
 *
 * @example
 * <sat-status-tag status="success"> Success </sat-status-tag>
 */
class SatStatusTagComponent {
    /**
     * The status of the tag, which determines its appearance and color.
     * This should be one of the predefined statuses.
     * @type {SatTagStatus}
     * @required
     */
    status = input.required();
    /**
     * Whether to hide the icon in the tag.
     * @deprecated Use `hideIcon` instead.
     */
    satHideIcon = input(false, { transform: booleanAttribute });
    /**
     * Whether to hide the icon in the tag.
     */
    hideIcon = input(false, { transform: booleanAttribute });
    backgroundColor = computed(() => `var(--sat-tag-${this.status()}-container)`);
    color = computed(() => `var(--sat-tag-on-${this.status()}-container)`);
    defaultIcon = computed(() => satStatusTagIcon[this.status()] || satStatusTagIcon.neutral);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatStatusTagComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatStatusTagComponent, isStandalone: true, selector: "sat-status-tag", inputs: { status: { classPropertyName: "status", publicName: "status", isSignal: true, isRequired: true, transformFunction: null }, satHideIcon: { classPropertyName: "satHideIcon", publicName: "satHideIcon", isSignal: true, isRequired: false, transformFunction: null }, hideIcon: { classPropertyName: "hideIcon", publicName: "hideIcon", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: `
    <sat-tag
      [style.backgroundColor]="backgroundColor()"
      [style.color]="color()"
    >
      <div class="sat-tag-icon">
        @if (!(hideIcon() || satHideIcon())) {
          <ng-container #statusTagIconContainer>
            <ng-content select="[mat-icon], mat-icon"></ng-content>
          </ng-container>
          @if (statusTagIconContainer?.previousElementSibling?.localName !== 'mat-icon') {
            <mat-icon aria-hidden="true" [svgIcon]="defaultIcon()"></mat-icon>
          }
        }
      </div>
      <ng-content></ng-content>
    </sat-tag>
  `, isInline: true, styles: [":host{display:inline-flex}\n"], dependencies: [{ kind: "component", type: SatTagComponent, selector: "sat-tag" }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i1$1.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatStatusTagComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-status-tag', imports: [SatTagComponent, MatIconModule], template: `
    <sat-tag
      [style.backgroundColor]="backgroundColor()"
      [style.color]="color()"
    >
      <div class="sat-tag-icon">
        @if (!(hideIcon() || satHideIcon())) {
          <ng-container #statusTagIconContainer>
            <ng-content select="[mat-icon], mat-icon"></ng-content>
          </ng-container>
          @if (statusTagIconContainer?.previousElementSibling?.localName !== 'mat-icon') {
            <mat-icon aria-hidden="true" [svgIcon]="defaultIcon()"></mat-icon>
          }
        }
      </div>
      <ng-content></ng-content>
    </sat-tag>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:inline-flex}\n"] }]
        }] });

const COMPONENTS = [SatCategoryTagComponent, SatStatusTagComponent];
const DIRECTIVES = [SatHideIconDirective, SatInteractiveTagDirective];
class SatTagModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatTagModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatTagModule, imports: [SatCategoryTagComponent, SatStatusTagComponent, SatHideIconDirective, SatInteractiveTagDirective], exports: [SatCategoryTagComponent, SatStatusTagComponent, SatHideIconDirective, SatInteractiveTagDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatTagModule, imports: [COMPONENTS] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatTagModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [...COMPONENTS, ...DIRECTIVES],
                    exports: [...COMPONENTS, ...DIRECTIVES],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatCategoryTagComponent, SatHideIconDirective, SatInteractiveTagDirective, SatStatusTagComponent, SatTagModule };
//# sourceMappingURL=hylandsoftware-satori-ui-tag.mjs.map
