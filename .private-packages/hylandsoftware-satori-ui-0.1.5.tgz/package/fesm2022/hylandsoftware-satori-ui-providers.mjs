import { makeEnvironmentProviders } from '@angular/core';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideSatoriIcons } from '@hylandsoftware/satori-ui/icons';

/**
 * This function returns providers for configuration of Angular Material components,
 * setting some default options related to Satori UI theme and appearance.
 */
function provideSatoriTheme() {
    return makeEnvironmentProviders([
        {
            provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
            useValue: {
                appearance: 'outline',
                floatLabel: 'always',
                subscriptSizing: 'dynamic',
            },
        },
        provideAnimationsAsync(),
    ]);
}

/**
 * Provides all necessary configuration for Satori UI including theme and icons.
 *
 * @param config Optional configuration for Satori UI providers
 *
 * @example
 * ```typescript
 * // All providers enabled (default)
 * export const appConfig: ApplicationConfig = {
 *   providers: [provideSatori()]
 * };
 *
 * // Only theme provider
 * export const appConfig: ApplicationConfig = {
 *   providers: [provideSatori({ icons: false })]
 * };
 * ```
 */
function provideSatori(config) {
    const providers = [];
    if (config?.theme !== false) {
        providers.push(provideSatoriTheme());
    }
    if (config?.icons !== false) {
        providers.push(provideSatoriIcons());
    }
    return makeEnvironmentProviders(providers);
}

/**
 * Generated bundle index. Do not edit.
 */

export { provideSatori, provideSatoriTheme };
//# sourceMappingURL=hylandsoftware-satori-ui-providers.mjs.map
