export * from '@hylandsoftware/satori-ui/app-header';
export * from '@hylandsoftware/satori-ui/breadcrumbs';
export * from '@hylandsoftware/satori-ui/icons';
export * from '@hylandsoftware/satori-ui/logo';
export * from '@hylandsoftware/satori-ui/platform-nav';
export * from '@hylandsoftware/satori-ui/providers';
export * from '@hylandsoftware/satori-ui/rich-tooltip';
export * from '@hylandsoftware/satori-ui/tag';
export { provideAndConfigureSatoriUITranslations as provideSatoriUITranslations } from '@hylandsoftware/satori-ui/translations';

/**
 * Export all sub-modules for backwards compatibility, enabling consumers to import from
 * a single entry point, for example:
 * import { SatAppHeaderModule, SatBreadcrumbsModule } from '@hylandsoftware/satori-ui';
 *
 * To enable lazy-loading behaviors by default for all consumers, importing from this
 * index file is deprecated and will be removed in future versions. Please import directly
 * from the specific sub-module instead, for example:
 * import { SatAppHeaderModule } from '@hylandsoftware/satori-ui/app-header';
 * import { SatBreadcrumbsModule } from '@hylandsoftware/satori-ui/breadcrumbs';
 */
/** @deprecated import from '@hylandsoftware/satori-ui/app-header' instead */

/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=hylandsoftware-satori-ui.mjs.map
