import * as i0 from '@angular/core';
import { ChangeDetectionStrategy, Component, input, computed, ViewEncapsulation, NgModule } from '@angular/core';

/** @internal */
class SatAvatarActiveIndicatorComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarActiveIndicatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatAvatarActiveIndicatorComponent, isStandalone: true, selector: "sat-avatar-active-indicator", host: { attributes: { "aria-hidden": "true" }, classAttribute: "sat-avatar-indicator" }, ngImport: i0, template: `
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 1C24.2843 1 31 7.71573 31 16C31 24.2843 24.2843 31 16 31C7.71573 31 1 24.2843 1 16C1 7.71573 7.71573 1 16 1Z" stroke-width="2"/>
      <path d="M13.2726 23.1579L7.05713 16.9431C6.5363 16.4223 6.5363 15.5785 7.05713 15.0577C7.57796 14.5368 8.42171 14.5368 8.94254 15.0577L13.3937 19.5095L23.1216 10.9965C23.6756 10.5108 24.5174 10.5668 25.0031 11.1228C25.4881 11.6762 25.4321 12.5186 24.8781 13.0043L13.2726 23.1579Z"/>
    </svg>
  `, isInline: true, styles: ["svg path:first-child{fill:var(--sat-avatar-indicator-active);stroke:var(--sat-avatar-border)}\n", "svg path:last-child{fill:var(--sat-avatar-on-indicator)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarActiveIndicatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-avatar-active-indicator', template: `
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 1C24.2843 1 31 7.71573 31 16C31 24.2843 24.2843 31 16 31C7.71573 31 1 24.2843 1 16C1 7.71573 7.71573 1 16 1Z" stroke-width="2"/>
      <path d="M13.2726 23.1579L7.05713 16.9431C6.5363 16.4223 6.5363 15.5785 7.05713 15.0577C7.57796 14.5368 8.42171 14.5368 8.94254 15.0577L13.3937 19.5095L23.1216 10.9965C23.6756 10.5108 24.5174 10.5668 25.0031 11.1228C25.4881 11.6762 25.4321 12.5186 24.8781 13.0043L13.2726 23.1579Z"/>
    </svg>
  `, host: { class: 'sat-avatar-indicator', 'aria-hidden': 'true' }, changeDetection: ChangeDetectionStrategy.OnPush, styles: ["svg path:first-child{fill:var(--sat-avatar-indicator-active);stroke:var(--sat-avatar-border)}\n", "svg path:last-child{fill:var(--sat-avatar-on-indicator)}\n"] }]
        }] });

/** @internal */
class SatAvatarAwayIndicatorComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarAwayIndicatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatAvatarAwayIndicatorComponent, isStandalone: true, selector: "sat-avatar-away-indicator", host: { attributes: { "aria-hidden": "true" }, classAttribute: "sat-avatar-indicator" }, ngImport: i0, template: `
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 1C24.2843 1 31 7.71573 31 16C31 24.2843 24.2843 31 16 31C7.71573 31 1 24.2843 1 16C1 7.71573 7.71573 1 16 1Z" stroke-width="2"/>
      <path d="M21.3319 22.6667C21.0539 22.6667 20.7733 22.5794 20.533 22.3997L14.6665 18V9.33333C14.6665 8.59635 15.2635 8 15.9998 8C16.7362 8 17.3332 8.59635 17.3332 9.33333V16.6667L22.1333 20.2669C22.7225 20.7083 22.8416 21.5443 22.3996 22.1328C22.1379 22.4831 21.7375 22.6667 21.3319 22.6667Z"/>
    </svg>
  `, isInline: true, styles: ["svg path:first-child{fill:var(--sat-avatar-indicator-away);stroke:var(--sat-avatar-border)}\n", "svg path:last-child{fill:var(--sat-avatar-on-indicator)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarAwayIndicatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-avatar-away-indicator', template: `
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16 1C24.2843 1 31 7.71573 31 16C31 24.2843 24.2843 31 16 31C7.71573 31 1 24.2843 1 16C1 7.71573 7.71573 1 16 1Z" stroke-width="2"/>
      <path d="M21.3319 22.6667C21.0539 22.6667 20.7733 22.5794 20.533 22.3997L14.6665 18V9.33333C14.6665 8.59635 15.2635 8 15.9998 8C16.7362 8 17.3332 8.59635 17.3332 9.33333V16.6667L22.1333 20.2669C22.7225 20.7083 22.8416 21.5443 22.3996 22.1328C22.1379 22.4831 21.7375 22.6667 21.3319 22.6667Z"/>
    </svg>
  `, host: { class: 'sat-avatar-indicator', 'aria-hidden': 'true' }, changeDetection: ChangeDetectionStrategy.OnPush, styles: ["svg path:first-child{fill:var(--sat-avatar-indicator-away);stroke:var(--sat-avatar-border)}\n", "svg path:last-child{fill:var(--sat-avatar-on-indicator)}\n"] }]
        }] });

/** @internal */
class SatAvatarOfflineIndicatorComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarOfflineIndicatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatAvatarOfflineIndicatorComponent, isStandalone: true, selector: "sat-avatar-offline-indicator", host: { attributes: { "aria-hidden": "true" }, classAttribute: "sat-avatar-indicator" }, ngImport: i0, template: `
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.002 1C24.2873 1 31.0038 7.71659 31.0039 16.002C31.0039 24.2874 24.2874 31.0039 16.002 31.0039C7.71659 31.0038 1 24.2873 1 16.002C1.00009 7.71665 7.71665 1.00009 16.002 1Z" stroke-width="2"/>
      <path d="M17.8877 16.0015L22.2789 11.6103C22.7998 11.0894 22.7998 10.2456 22.2789 9.72466C21.758 9.20376 20.9141 9.20376 20.3932 9.72466L16.002 14.1159L11.6108 9.72466C11.0899 9.20376 10.2461 9.20376 9.72515 9.72466C9.20425 10.2456 9.20425 11.0894 9.72515 11.6103L14.1164 16.0015L9.72515 20.3927C9.20425 20.9136 9.20425 21.7575 9.72515 22.2784C9.9856 22.5389 10.3268 22.6691 10.668 22.6691C11.0092 22.6691 11.3504 22.5389 11.6108 22.2784L16.002 17.8872L20.3932 22.2784C20.6537 22.5389 20.9949 22.6691 21.3361 22.6691C21.6773 22.6691 22.0185 22.5389 22.2789 22.2784C22.7998 21.7575 22.7998 20.9136 22.2789 20.3927L17.8877 16.0015Z"/>
    </svg>
  `, isInline: true, styles: ["svg path:first-child{fill:var(--sat-avatar-indicator-offline);stroke:var(--sat-avatar-border)}\n", "svg path:last-child{fill:var(--sat-avatar-on-indicator)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarOfflineIndicatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-avatar-offline-indicator', template: `
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.002 1C24.2873 1 31.0038 7.71659 31.0039 16.002C31.0039 24.2874 24.2874 31.0039 16.002 31.0039C7.71659 31.0038 1 24.2873 1 16.002C1.00009 7.71665 7.71665 1.00009 16.002 1Z" stroke-width="2"/>
      <path d="M17.8877 16.0015L22.2789 11.6103C22.7998 11.0894 22.7998 10.2456 22.2789 9.72466C21.758 9.20376 20.9141 9.20376 20.3932 9.72466L16.002 14.1159L11.6108 9.72466C11.0899 9.20376 10.2461 9.20376 9.72515 9.72466C9.20425 10.2456 9.20425 11.0894 9.72515 11.6103L14.1164 16.0015L9.72515 20.3927C9.20425 20.9136 9.20425 21.7575 9.72515 22.2784C9.9856 22.5389 10.3268 22.6691 10.668 22.6691C11.0092 22.6691 11.3504 22.5389 11.6108 22.2784L16.002 17.8872L20.3932 22.2784C20.6537 22.5389 20.9949 22.6691 21.3361 22.6691C21.6773 22.6691 22.0185 22.5389 22.2789 22.2784C22.7998 21.7575 22.7998 20.9136 22.2789 20.3927L17.8877 16.0015Z"/>
    </svg>
  `, host: { class: 'sat-avatar-indicator', 'aria-hidden': 'true' }, changeDetection: ChangeDetectionStrategy.OnPush, styles: ["svg path:first-child{fill:var(--sat-avatar-indicator-offline);stroke:var(--sat-avatar-border)}\n", "svg path:last-child{fill:var(--sat-avatar-on-indicator)}\n"] }]
        }] });

/** @internal */
class SatAvatarReadonlyIndicatorComponent {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarReadonlyIndicatorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.19", type: SatAvatarReadonlyIndicatorComponent, isStandalone: true, selector: "sat-avatar-readonly-indicator", host: { attributes: { "aria-hidden": "true" }, classAttribute: "sat-avatar-indicator" }, ngImport: i0, template: `
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.0137 1.01367C24.2979 1.01367 31.0137 7.7294 31.0137 16.0137C31.0137 24.2979 24.2979 31.0137 16.0137 31.0137C7.7294 31.0137 1.01367 24.2979 1.01367 16.0137C1.01367 7.7294 7.7294 1.01367 16.0137 1.01367Z" stroke-width="2"/>
      <path d="M22.6803 17.3464H9.34701C8.61003 17.3464 8.01367 16.75 8.01367 16.013C8.01367 15.276 8.61003 14.6797 9.34701 14.6797H22.6803C23.4173 14.6797 24.0137 15.276 24.0137 16.013C24.0137 16.75 23.4173 17.3464 22.6803 17.3464Z"/>
    </svg>
  `, isInline: true, styles: ["svg path:first-child{fill:var(--sat-avatar-indicator-readonly);stroke:var(--sat-avatar-border)}\n", "svg path:last-child{fill:var(--sat-avatar-on-indicator)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarReadonlyIndicatorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-avatar-readonly-indicator', template: `
    <svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M16.0137 1.01367C24.2979 1.01367 31.0137 7.7294 31.0137 16.0137C31.0137 24.2979 24.2979 31.0137 16.0137 31.0137C7.7294 31.0137 1.01367 24.2979 1.01367 16.0137C1.01367 7.7294 7.7294 1.01367 16.0137 1.01367Z" stroke-width="2"/>
      <path d="M22.6803 17.3464H9.34701C8.61003 17.3464 8.01367 16.75 8.01367 16.013C8.01367 15.276 8.61003 14.6797 9.34701 14.6797H22.6803C23.4173 14.6797 24.0137 15.276 24.0137 16.013C24.0137 16.75 23.4173 17.3464 22.6803 17.3464Z"/>
    </svg>
  `, host: { class: 'sat-avatar-indicator', 'aria-hidden': 'true' }, changeDetection: ChangeDetectionStrategy.OnPush, styles: ["svg path:first-child{fill:var(--sat-avatar-indicator-readonly);stroke:var(--sat-avatar-border)}\n", "svg path:last-child{fill:var(--sat-avatar-on-indicator)}\n"] }]
        }] });

/**
 * The `sat-avatar` component is used to display user initials with various styles and indicators.
 * It supports different categories, sizes, and status indicators.
 */
class SatAvatarComponent {
    /**
     * One out of: purple, blue, pink, teal, yellow, green, red, orange.
     * Used to determine the color of the avatar.
     */
    category = input('purple');
    /**
     * One out of: 24, 28, 36, 64, 80, 128.
     * Used as the pixel size of the avatar.
     */
    size = input('24');
    /**
     * One out of: active, away, offline, readonly.
     * Used to determine the optional indicator displayed on the avatar.
     * If left unset, no indicator will be displayed.
     */
    indicator = input();
    /**
     * The first two character of this string, or the first character of this string in size 24
     * will be displayed uppercase in the avatar.
     */
    initials = input('WW');
    /** Whether to not display a border around the avatar. Defaults to false. */
    borderless = input(false);
    /** @internal */
    _displayedInitials = computed(() => this.size() === '24'
        ? this.initials()[0].toUpperCase()
        : this.initials().slice(0, 2).toUpperCase());
    /** @internal */
    _backgroundColor = computed(() => `var(--sat-avatar-cat-${this.category()}-container)`);
    /** @internal */
    _color = computed(() => `var(--sat-avatar-on-cat-${this.category()}-container)`);
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatAvatarComponent, isStandalone: true, selector: "sat-avatar", inputs: { category: { classPropertyName: "category", publicName: "category", isSignal: true, isRequired: false, transformFunction: null }, size: { classPropertyName: "size", publicName: "size", isSignal: true, isRequired: false, transformFunction: null }, indicator: { classPropertyName: "indicator", publicName: "indicator", isSignal: true, isRequired: false, transformFunction: null }, initials: { classPropertyName: "initials", publicName: "initials", isSignal: true, isRequired: false, transformFunction: null }, borderless: { classPropertyName: "borderless", publicName: "borderless", isSignal: true, isRequired: false, transformFunction: null } }, host: { attributes: { "role": "img" } }, ngImport: i0, template: "<div\n  [class]=\"'sat-avatar sat-avatar-' + size()\"\n  [class.sat-avatar-borderless]=\"borderless()\"\n  [style.backgroundColor]=\"_backgroundColor()\"\n  [style.color]=\"_color()\"\n>\n  <ng-content select=\"img\"></ng-content>\n  <span aria-hidden=\"true\">{{_displayedInitials()}}</span>\n  @switch (indicator()) {\n    @case ('active') {\n      <sat-avatar-active-indicator></sat-avatar-active-indicator>\n    }\n    @case ('away') {\n      <sat-avatar-away-indicator></sat-avatar-away-indicator>\n    }\n    @case ('offline') {\n      <sat-avatar-offline-indicator></sat-avatar-offline-indicator>\n    }\n    @case ('readonly') {\n      <sat-avatar-readonly-indicator></sat-avatar-readonly-indicator>\n    }\n  }\n</div>\n", styles: [".sat-avatar{display:flex;justify-content:center;align-items:center;aspect-ratio:1/1;position:relative;border-radius:var(--sat-avatar-corner-full);border:1px solid var(--sat-avatar-border);box-sizing:border-box}.sat-avatar img{border-radius:var(--sat-avatar-corner-full);width:100%;height:100%;position:absolute}.sat-avatar .sat-avatar-indicator{display:flex;position:absolute;bottom:-1px;inset-inline-end:-1px}.sat-avatar.sat-avatar-borderless{border:none}.sat-avatar.sat-avatar-borderless .sat-avatar-indicator{position:absolute;bottom:0;inset-inline-end:0}.sat-avatar.sat-avatar-24{width:24px;height:24px;font:var(--sat-avatar-label-small)}.sat-avatar.sat-avatar-24 .sat-avatar-indicator{width:8px;height:8px}.sat-avatar.sat-avatar-28{width:28px;height:28px;font:var(--sat-avatar-label-small)}.sat-avatar.sat-avatar-28 .sat-avatar-indicator{width:8px;height:8px}.sat-avatar.sat-avatar-36{width:36px;height:36px;font:var(--sat-avatar-label-large)}.sat-avatar.sat-avatar-36 .sat-avatar-indicator{width:12px;height:12px}.sat-avatar.sat-avatar-64{width:64px;height:64px;font:var(--sat-avatar-title-large)}.sat-avatar.sat-avatar-64 .sat-avatar-indicator{width:18px;height:18px}.sat-avatar.sat-avatar-80{width:80px;height:80px;font:var(--sat-avatar-headline-small)}.sat-avatar.sat-avatar-80 .sat-avatar-indicator{width:24px;height:24px}.sat-avatar.sat-avatar-128{width:128px;height:128px;font:var(--sat-avatar-headline-large)}.sat-avatar.sat-avatar-128 .sat-avatar-indicator{width:32px;height:32px}\n"], dependencies: [{ kind: "component", type: SatAvatarActiveIndicatorComponent, selector: "sat-avatar-active-indicator" }, { kind: "component", type: SatAvatarAwayIndicatorComponent, selector: "sat-avatar-away-indicator" }, { kind: "component", type: SatAvatarOfflineIndicatorComponent, selector: "sat-avatar-offline-indicator" }, { kind: "component", type: SatAvatarReadonlyIndicatorComponent, selector: "sat-avatar-readonly-indicator" }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-avatar', imports: [
                        SatAvatarActiveIndicatorComponent,
                        SatAvatarAwayIndicatorComponent,
                        SatAvatarOfflineIndicatorComponent,
                        SatAvatarReadonlyIndicatorComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, host: { role: 'img' }, template: "<div\n  [class]=\"'sat-avatar sat-avatar-' + size()\"\n  [class.sat-avatar-borderless]=\"borderless()\"\n  [style.backgroundColor]=\"_backgroundColor()\"\n  [style.color]=\"_color()\"\n>\n  <ng-content select=\"img\"></ng-content>\n  <span aria-hidden=\"true\">{{_displayedInitials()}}</span>\n  @switch (indicator()) {\n    @case ('active') {\n      <sat-avatar-active-indicator></sat-avatar-active-indicator>\n    }\n    @case ('away') {\n      <sat-avatar-away-indicator></sat-avatar-away-indicator>\n    }\n    @case ('offline') {\n      <sat-avatar-offline-indicator></sat-avatar-offline-indicator>\n    }\n    @case ('readonly') {\n      <sat-avatar-readonly-indicator></sat-avatar-readonly-indicator>\n    }\n  }\n</div>\n", styles: [".sat-avatar{display:flex;justify-content:center;align-items:center;aspect-ratio:1/1;position:relative;border-radius:var(--sat-avatar-corner-full);border:1px solid var(--sat-avatar-border);box-sizing:border-box}.sat-avatar img{border-radius:var(--sat-avatar-corner-full);width:100%;height:100%;position:absolute}.sat-avatar .sat-avatar-indicator{display:flex;position:absolute;bottom:-1px;inset-inline-end:-1px}.sat-avatar.sat-avatar-borderless{border:none}.sat-avatar.sat-avatar-borderless .sat-avatar-indicator{position:absolute;bottom:0;inset-inline-end:0}.sat-avatar.sat-avatar-24{width:24px;height:24px;font:var(--sat-avatar-label-small)}.sat-avatar.sat-avatar-24 .sat-avatar-indicator{width:8px;height:8px}.sat-avatar.sat-avatar-28{width:28px;height:28px;font:var(--sat-avatar-label-small)}.sat-avatar.sat-avatar-28 .sat-avatar-indicator{width:8px;height:8px}.sat-avatar.sat-avatar-36{width:36px;height:36px;font:var(--sat-avatar-label-large)}.sat-avatar.sat-avatar-36 .sat-avatar-indicator{width:12px;height:12px}.sat-avatar.sat-avatar-64{width:64px;height:64px;font:var(--sat-avatar-title-large)}.sat-avatar.sat-avatar-64 .sat-avatar-indicator{width:18px;height:18px}.sat-avatar.sat-avatar-80{width:80px;height:80px;font:var(--sat-avatar-headline-small)}.sat-avatar.sat-avatar-80 .sat-avatar-indicator{width:24px;height:24px}.sat-avatar.sat-avatar-128{width:128px;height:128px;font:var(--sat-avatar-headline-large)}.sat-avatar.sat-avatar-128 .sat-avatar-indicator{width:32px;height:32px}\n"] }]
        }] });

class SatAvatarModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarModule, imports: [SatAvatarComponent], exports: [SatAvatarComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarModule });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatAvatarModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [SatAvatarComponent],
                    exports: [SatAvatarComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatAvatarComponent, SatAvatarModule };
//# sourceMappingURL=hylandsoftware-satori-ui-avatar.mjs.map
