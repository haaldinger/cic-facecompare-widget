import * as i0 from '@angular/core';
import { input, computed, numberAttribute, booleanAttribute, output, viewChild, TemplateRef, effect, ViewEncapsulation, ChangeDetectionStrategy, Component, inject, HostListener, Directive, ElementRef, Injectable, ViewContainerRef, ChangeDetectorRef, signal, NgModule } from '@angular/core';
import * as i1$1 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import { CdkTrapFocus, isFakeMousedownFromScreenReader } from '@angular/cdk/a11y';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { TemplatePortal } from '@angular/cdk/portal';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Directionality } from '@angular/cdk/bidi';
import { Overlay, OverlayConfig } from '@angular/cdk/overlay';

const transformRichTooltip = trigger('transformRichTooltip', [
    state('enter', style({
        opacity: 1,
        transform: `scale(1)`,
    })),
    transition('void => *', [
        style({
            opacity: 0,
            transform: `scale(0)`,
        }),
        animate(`200ms cubic-bezier(0.25, 0.8, 0.25, 1)`),
    ]),
    transition('* => void', [animate('50ms 100ms linear', style({ opacity: 0 }))]),
]);

/**
 * Throws an exception for the case when tooltip's x-position value isn't valid.
 * In other words, it doesn't match 'before' or 'after'.
 * @docs-private
 */
function throwRichTooltipInvalidPositionX() {
    throw new Error(`positionX value must be either 'before' or 'after'.
    Example: <sat-rich-tooltip positionX="before" #tooltip="satRichTooltip"></sat-rich-tooltip>`);
}
/**
 * Throws an exception for the case when tooltip's y-position value isn't valid.
 * In other words, it doesn't match 'above' or 'below'.
 * @docs-private
 */
function throwRichTooltipInvalidPositionY() {
    throw new Error(`positionY value must be either 'above' or 'below'.
    Example: <sat-rich-tooltip positionY="above" #tooltip="satRichTooltip"></sat-rich-tooltip>`);
}
/**
 * Throws an exception for the case when the trigger doesn't have a valid rich tooltip instance.
 * @docs-private
 */
function throwRichTooltipMissingError() {
    throw new Error(`satRichTooltipTriggerFor: must pass in a rich-tooltip instance.
    Example:
      <sat-rich-tooltip #tooltip="satRichTooltip"></sat-rich-tooltip>
      <button [satRichTooltipTriggerFor]="tooltip"></button>`);
}

/** Counter for generating unique element ids.
 * This is needed for accessibility.
 */
let idCounter = 0;
/**
 * The `SatRichTooltipComponent` is used to display rich tooltips with various configurations.
 * It supports different positions, behaviors, and scroll strategies etc..
 */
class SatRichTooltipComponent {
    /** Settings for richTooltip, view setters and getters for more detail */
    _positionX = 'after';
    _positionY = 'below';
    _behavior = 'transient';
    _scrollStrategy = 'reposition';
    _showDelay = 200;
    _hideDelay = 1500;
    _overlapTrigger = false;
    _disableAnimation = false;
    _targetOffsetX = 0;
    _targetOffsetY = 20;
    _closeOnClick = false;
    _focusTrapEnabled = true;
    _focusTrapAutoCaptureEnabled = true;
    _uniqueId = idCounter++;
    _titleUniqueId = `sat-rich-tooltip-${this._uniqueId}-title`;
    _contentUniqueId = `sat-rich-tooltip-${this._uniqueId}-content`;
    /** Config object to be passed into the richTooltip's ngClass */
    classList = {};
    /** Closing disabled on richTooltip */
    closeDisabled = false;
    /** unique id for the rich tooltip panel. */
    id = input(`sat-rich-tooltip-${this._uniqueId}`);
    /** aria-label for the rich tooltip panel. */
    ariaLabel = input(null, { alias: 'aria-label' });
    /** aria-labelledby for the rich tooltip panel. This needs to be same with the id for the title element */
    ariaLabelledby = input(this._titleUniqueId, { alias: 'aria-labelledby' });
    /** aria-describedby for the rich tooltip panel. This needs to be same with the id for the content element. */
    ariaDescribedby = input(this._contentUniqueId, { alias: 'aria-describedby' });
    // TODO: DS-1559 Remove the deprecated `role` input and related logic in a future version.
    /**
     * The ARIA role for the tooltip container.
     * @deprecated The role is now automatically determined by the `behavior` input.
     * Use `behavior="persistent"` for dialog role or `behavior="transient"` for tooltip role.
     * This input will be removed in a future version.
     */
    role = input(undefined);
    _roleWarningLogged = false;
    // TODO: DS-1559 Rename to "role" after removing the deprecated `role` input.
    /**
     * The resolved ARIA role for the tooltip container.
     * Derived from behavior: 'persistent' → 'dialog', 'transient' → 'tooltip'.
     * @internal
     */
    resolvedRole = computed(() => (this.behavior() === 'persistent' ? 'dialog' : 'tooltip'));
    /**
     * Whether the tooltip has persistent behavior (interactive, click-triggered).
     * @internal
     */
    isPersistent = computed(() => this.behavior() === 'persistent');
    /**
     * Position of the richTooltip in the X axis.
     * @default after
     */
    positionX = input(this._positionX);
    /**
     * Validated position of the richTooltip in the X axis.
     * Throws an error if the position is invalid.
     * @ignore
     */
    validatedPositionX = computed(() => {
        const value = this.positionX();
        if (value !== 'before' && value !== 'after') {
            throwRichTooltipInvalidPositionX();
        }
        return value;
    });
    /**
     * Position of the richTooltip in the Y axis.
     * @default below
     */
    positionY = input(this._positionY);
    /**
     * Validated position of the richTooltip in the Y axis.
     * Throws an error if the position is invalid.
     * @ignore
     */
    validatedPositionY = computed(() => {
        const value = this.positionY();
        if (value !== 'above' && value !== 'below') {
            throwRichTooltipInvalidPositionY();
        }
        return value;
    });
    /**
     * RichTooltip behavior type
     * @default transient
     */
    behavior = input(this._behavior);
    /**
     * RichTooltip scroll strategy
     * @default reposition
     */
    scrollStrategy = input(this._scrollStrategy);
    /**
     * RichTooltip enter delay (milliseconds)
     * @default 200
     */
    showDelay = input(this._showDelay, { transform: numberAttribute });
    /**
     * RichTooltip leave delay (milliseconds)
     * @default 1500
     */
    hideDelay = input(this._hideDelay, { transform: numberAttribute });
    /**
     * RichTooltip overlap trigger
     * @default false
     */
    overlapTrigger = input(this._overlapTrigger, { transform: booleanAttribute });
    /**
     * RichTooltip horizontal target offset (px)
     * @default 0
     */
    targetOffsetX = input(this._targetOffsetX, {
        transform: numberAttribute,
    });
    /**
     * RichTooltip vertical target offset (px)
     * @default 20
     */
    targetOffsetY = input(this._targetOffsetY, {
        transform: numberAttribute,
    });
    /**
     * RichTooltip container close on click
     * @default false
     */
    closeOnClick = input(this._closeOnClick, { transform: booleanAttribute });
    /**
     * Disable animations of richTooltip and all child elements
     * @default false
     */
    disableAnimation = input(this._disableAnimation, { transform: booleanAttribute });
    /**
     * Rich Tooltip focus trap using cdkTrapFocus
     * @default true
     */
    focusTrapEnabled = input(this._focusTrapEnabled, { transform: booleanAttribute });
    /**
     * Rich Tooltip focus trap auto capture using cdkTrapFocusAutoCapture
     * @default true
     */
    focusTrapAutoCaptureEnabled = input(this._focusTrapAutoCaptureEnabled, {
        transform: booleanAttribute,
    });
    /**
     * Event emitted when the richTooltip is closed.
     */
    closed = output();
    /**
     * Event emitted when the richTooltip is closed.
     *
     * @deprecated Switch to `closed` instead. Will be removed in future version.
     */
    // TODO: Need to remove the deprecation with this card - https://hyland.atlassian.net/browse/DS-915
    // eslint-disable-next-line @angular-eslint/no-output-native
    close = output();
    /** @ignore */
    templateRef = viewChild(TemplateRef);
    /** @ignore */
    monitoredEl = viewChild('monitoredEl');
    constructor() {
        // TODO: DS-1559 Remove along with the "role" input.
        // Log deprecation warning if role input is used
        effect(() => {
            if (this.role() !== undefined && !this._roleWarningLogged) {
                this._roleWarningLogged = true;
                console.warn('SatRichTooltip: The "role" input is deprecated and will be removed in a future version. ' +
                    'The role is now automatically determined by the "behavior" input (persistent → dialog, transient → tooltip).');
            }
        });
    }
    /**
     * Handle a keyboard event from the richTooltip, delegating to the appropriate action.
     * @internal
     */
    handleKeydown(event) {
        if (event.key === 'Escape') {
            this.emitCloseEvent('keydown');
        }
    }
    /**
     * This emits a close event to which the trigger is subscribed. When emitted, the
     * trigger will close the richTooltip.
     * @internal
     */
    emitCloseEvent(reason) {
        this.closed.emit(reason);
        // TODO: Need to remove the deprecation with this card - https://hyland.atlassian.net/browse/DS-915
        this.close.emit(reason);
    }
    /**
     * Close richTooltip on click if closeOnClick is true
     * @internal
     */
    onClick() {
        if (this.closeOnClick()) {
            this.emitCloseEvent('click');
        }
    }
    /**
     * Prevents closing the Rich Tooltip when the user moves their pointer from the trigger element to the tooltip.
     * @internal
     */
    onMouseover() {
        if (this.behavior() === 'transient') {
            this.closeDisabled = true;
        }
    }
    /**
     * Enables closing of the Rich Tooltip when the user moves their pointer away from the Rich Tooltip element.
     * @internal
     */
    onMouseout() {
        if (this.behavior() === 'transient') {
            this.closeDisabled = false;
            this.emitCloseEvent('focusout');
        }
    }
    /** @ignore */
    doNothing() {
        //NOSONAR
        // Sonar incorrectly flags using mouseover and mouseleave without a focus event listener,
        // but in a transient Rich Tooltip, mouse events must prevent the Rich Tooltip from closing,
        // while focus events are non-existent since transient Rich Tooltips are not focusable.
    }
    ngOnDestroy() {
        this.emitCloseEvent();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "19.2.19", type: SatRichTooltipComponent, isStandalone: true, selector: "sat-rich-tooltip", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "aria-label", isSignal: true, isRequired: false, transformFunction: null }, ariaLabelledby: { classPropertyName: "ariaLabelledby", publicName: "aria-labelledby", isSignal: true, isRequired: false, transformFunction: null }, ariaDescribedby: { classPropertyName: "ariaDescribedby", publicName: "aria-describedby", isSignal: true, isRequired: false, transformFunction: null }, role: { classPropertyName: "role", publicName: "role", isSignal: true, isRequired: false, transformFunction: null }, positionX: { classPropertyName: "positionX", publicName: "positionX", isSignal: true, isRequired: false, transformFunction: null }, positionY: { classPropertyName: "positionY", publicName: "positionY", isSignal: true, isRequired: false, transformFunction: null }, behavior: { classPropertyName: "behavior", publicName: "behavior", isSignal: true, isRequired: false, transformFunction: null }, scrollStrategy: { classPropertyName: "scrollStrategy", publicName: "scrollStrategy", isSignal: true, isRequired: false, transformFunction: null }, showDelay: { classPropertyName: "showDelay", publicName: "showDelay", isSignal: true, isRequired: false, transformFunction: null }, hideDelay: { classPropertyName: "hideDelay", publicName: "hideDelay", isSignal: true, isRequired: false, transformFunction: null }, overlapTrigger: { classPropertyName: "overlapTrigger", publicName: "overlapTrigger", isSignal: true, isRequired: false, transformFunction: null }, targetOffsetX: { classPropertyName: "targetOffsetX", publicName: "targetOffsetX", isSignal: true, isRequired: false, transformFunction: null }, targetOffsetY: { classPropertyName: "targetOffsetY", publicName: "targetOffsetY", isSignal: true, isRequired: false, transformFunction: null }, closeOnClick: { classPropertyName: "closeOnClick", publicName: "closeOnClick", isSignal: true, isRequired: false, transformFunction: null }, disableAnimation: { classPropertyName: "disableAnimation", publicName: "disableAnimation", isSignal: true, isRequired: false, transformFunction: null }, focusTrapEnabled: { classPropertyName: "focusTrapEnabled", publicName: "focusTrapEnabled", isSignal: true, isRequired: false, transformFunction: null }, focusTrapAutoCaptureEnabled: { classPropertyName: "focusTrapAutoCaptureEnabled", publicName: "focusTrapAutoCaptureEnabled", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { closed: "closed", close: "close" }, viewQueries: [{ propertyName: "templateRef", first: true, predicate: TemplateRef, descendants: true, isSignal: true }, { propertyName: "monitoredEl", first: true, predicate: ["monitoredEl"], descendants: true, isSignal: true }], exportAs: ["satRichTooltip"], ngImport: i0, template: "<ng-template>\n  <div\n    class=\"sat-rich-tooltip-container mat-elevation-z2\"\n    [attr.tabindex]=\"isPersistent() ? 0 : -1\"\n    [attr.role]=\"resolvedRole()\"\n    [attr.aria-modal]=\"isPersistent() ? 'false' : null\"\n    [id]=\"id()\"\n    [class.sat-rich-tooltip-overlap]=\"overlapTrigger()\"\n    [ngClass]=\"classList\"\n    (keydown)=\"handleKeydown($event)\"\n    (click)=\"onClick()\"\n    (mouseover)=\"onMouseover()\"\n    (mouseleave)=\"onMouseout()\"\n    (focus)=\"doNothing()\"\n    [@.disabled]=\"disableAnimation()\"\n    [cdkTrapFocus]=\"isPersistent() && focusTrapEnabled()\"\n    [cdkTrapFocusAutoCapture]=\"isPersistent() && focusTrapAutoCaptureEnabled()\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.aria-labelledby]=\"ariaLabelledby()\"\n    [attr.aria-describedby]=\"ariaDescribedby()\"\n    [@transformRichTooltip]=\"'enter'\"\n  >\n    <ng-content select=\"sat-rich-tooltip-title\"></ng-content>\n    <ng-content select=\"sat-rich-tooltip-content\"></ng-content>\n    <ng-content select=\"sat-rich-tooltip-actions\"></ng-content>\n  </div>\n</ng-template>\n", styles: [".sat-rich-tooltip-container{display:grid;padding:12px 0 8px;gap:4px;border-radius:12px;max-width:40vw}@media(width<=768px){.sat-rich-tooltip-container{max-width:70vw}}@media(width<=480px){.sat-rich-tooltip-container{max-width:90vw}}.sat-rich-tooltip-title{display:block;align-self:stretch;padding:0 16px}.sat-rich-tooltip-content{display:block;align-self:stretch;padding:0 16px;overflow:auto;max-height:25vh;width:100%;box-sizing:border-box}.sat-rich-tooltip-actions{display:flex;align-items:center;padding:8px 8px 0;gap:8px;align-self:stretch;flex-wrap:wrap}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-start{justify-content:start}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-center{justify-content:center}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-end{justify-content:flex-end}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }], animations: [transformRichTooltip], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-rich-tooltip', changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, animations: [transformRichTooltip], imports: [CommonModule, CdkTrapFocus], exportAs: 'satRichTooltip', template: "<ng-template>\n  <div\n    class=\"sat-rich-tooltip-container mat-elevation-z2\"\n    [attr.tabindex]=\"isPersistent() ? 0 : -1\"\n    [attr.role]=\"resolvedRole()\"\n    [attr.aria-modal]=\"isPersistent() ? 'false' : null\"\n    [id]=\"id()\"\n    [class.sat-rich-tooltip-overlap]=\"overlapTrigger()\"\n    [ngClass]=\"classList\"\n    (keydown)=\"handleKeydown($event)\"\n    (click)=\"onClick()\"\n    (mouseover)=\"onMouseover()\"\n    (mouseleave)=\"onMouseout()\"\n    (focus)=\"doNothing()\"\n    [@.disabled]=\"disableAnimation()\"\n    [cdkTrapFocus]=\"isPersistent() && focusTrapEnabled()\"\n    [cdkTrapFocusAutoCapture]=\"isPersistent() && focusTrapAutoCaptureEnabled()\"\n    [attr.aria-label]=\"ariaLabel()\"\n    [attr.aria-labelledby]=\"ariaLabelledby()\"\n    [attr.aria-describedby]=\"ariaDescribedby()\"\n    [@transformRichTooltip]=\"'enter'\"\n  >\n    <ng-content select=\"sat-rich-tooltip-title\"></ng-content>\n    <ng-content select=\"sat-rich-tooltip-content\"></ng-content>\n    <ng-content select=\"sat-rich-tooltip-actions\"></ng-content>\n  </div>\n</ng-template>\n", styles: [".sat-rich-tooltip-container{display:grid;padding:12px 0 8px;gap:4px;border-radius:12px;max-width:40vw}@media(width<=768px){.sat-rich-tooltip-container{max-width:70vw}}@media(width<=480px){.sat-rich-tooltip-container{max-width:90vw}}.sat-rich-tooltip-title{display:block;align-self:stretch;padding:0 16px}.sat-rich-tooltip-content{display:block;align-self:stretch;padding:0 16px;overflow:auto;max-height:25vh;width:100%;box-sizing:border-box}.sat-rich-tooltip-actions{display:flex;align-items:center;padding:8px 8px 0;gap:8px;align-self:stretch;flex-wrap:wrap}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-start{justify-content:start}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-center{justify-content:center}.sat-rich-tooltip-actions.sat-rich-tooltip-actions-align-end{justify-content:flex-end}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Directive for closing the rich tooltip.
 * This directive listens for click events and triggers the close action on the tooltip.
 */
class SatRichTooltipCloseDirective {
    tooltip = inject(SatRichTooltipComponent);
    /**
     * Listens for click events to close the tooltip.
     */
    onClose(event) {
        event.stopPropagation(); // Prevent event bubbling
        this.tooltip.emitCloseEvent(); // Call the close method on the tooltip instance
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipCloseDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.19", type: SatRichTooltipCloseDirective, isStandalone: true, selector: "[sat-rich-tooltip-close], [satRichTooltipClose]", host: { listeners: { "click": "onClose($event)" }, properties: { "attr.aria-label": "ariaLabel || null", "attr.type": "type" } }, exportAs: ["satRichTooltipClose"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipCloseDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[sat-rich-tooltip-close], [satRichTooltipClose]',
                    exportAs: 'satRichTooltipClose',
                    host: {
                        '[attr.aria-label]': 'ariaLabel || null',
                        '[attr.type]': 'type',
                    },
                }]
        }], propDecorators: { onClose: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

/**
 * Component for rendering action buttons in the rich tooltip.
 * These action buttons can be aligned to the start, center, or end of the rich tooltip.
 * By default, there will be a close button if the tooltip behaviour is set to be persistent.
 */
class SatRichTooltipActionsComponent {
    tooltip = inject(SatRichTooltipComponent);
    _transientWarningLogged = false;
    /**
     * Alignment of the actions
     * @default 'start'
     */
    align = input('start');
    // TODO: DS-1559 Remove this input along with `role` input of Rich Tooltip
    /**
     * Whether the close feature should be required
     * @deprecated The close feature is required by default for all persistent tooltips,
     * and must not be used in transient tooltips. This input will be removed in a future
     * release. To ensure accessibility, close buttons are always included in persistent
     * tooltips, and must not be included in transient tooltips.
     */
    requireCloseFeature = input(false);
    constructor() {
        effect(() => {
            if (this.tooltip.behavior() === 'transient' && !this._transientWarningLogged) {
                this._transientWarningLogged = true;
                console.warn('SatRichTooltip: Actions (sat-rich-tooltip-actions) should not be used in transient tooltips. ' +
                    'Transient tooltips are informational only and should not contain interactive elements. ' +
                    'Use behavior="persistent" for tooltips with actions.');
            }
        });
    }
    /** @ignore */
    get tooltipBehaviour() {
        return this.tooltip.behavior();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipActionsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.19", type: SatRichTooltipActionsComponent, isStandalone: true, selector: "sat-rich-tooltip-actions", inputs: { align: { classPropertyName: "align", publicName: "align", isSignal: true, isRequired: false, transformFunction: null }, requireCloseFeature: { classPropertyName: "requireCloseFeature", publicName: "requireCloseFeature", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "class.sat-rich-tooltip-actions-align-start": "align() === \"start\"", "class.sat-rich-tooltip-actions-align-center": "align() === \"center\"", "class.sat-rich-tooltip-actions-align-end": "align() === \"end\"" }, classAttribute: "sat-rich-tooltip-actions" }, ngImport: i0, template: "<ng-content select=\"[button, a]\"></ng-content>\n\n@if (tooltipBehaviour === 'persistent') {\n  <button mat-button type=\"button\" sat-rich-tooltip-close>Close</button>\n}\n", dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i1$1.MatButton, selector: "    button[mat-button], button[mat-raised-button], button[mat-flat-button],    button[mat-stroked-button]  ", exportAs: ["matButton"] }, { kind: "directive", type: SatRichTooltipCloseDirective, selector: "[sat-rich-tooltip-close], [satRichTooltipClose]", exportAs: ["satRichTooltipClose"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipActionsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'sat-rich-tooltip-actions', host: {
                        'class': 'sat-rich-tooltip-actions',
                        '[class.sat-rich-tooltip-actions-align-start]': 'align() === "start"',
                        '[class.sat-rich-tooltip-actions-align-center]': 'align() === "center"',
                        '[class.sat-rich-tooltip-actions-align-end]': 'align() === "end"',
                    }, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, imports: [MatButtonModule, SatRichTooltipCloseDirective], template: "<ng-content select=\"[button, a]\"></ng-content>\n\n@if (tooltipBehaviour === 'persistent') {\n  <button mat-button type=\"button\" sat-rich-tooltip-close>Close</button>\n}\n" }]
        }], ctorParameters: () => [] });

/**
 * Component for rendering the content of the rich tooltip.
 */
class SatRichTooltipContentComponent {
    tooltip = inject(SatRichTooltipComponent);
    // TODO: DS-1559 Remove the deprecated `aria-label` input.
    /** @deprecated This element is not focusable and does not need an aria-label. */
    ariaLabel = input('', { alias: 'aria-label' });
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipContentComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.19", type: SatRichTooltipContentComponent, isStandalone: true, selector: "sat-rich-tooltip-content", inputs: { ariaLabel: { classPropertyName: "ariaLabel", publicName: "aria-label", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.id": "tooltip.ariaDescribedby()" }, classAttribute: "sat-rich-tooltip-content" }, ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipContentComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-rich-tooltip-content',
                    template: `<ng-content></ng-content>`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        'class': 'sat-rich-tooltip-content',
                        '[attr.id]': 'tooltip.ariaDescribedby()',
                    },
                }]
        }] });

/**
 * Component for rendering the title of the rich tooltip.
 */
class SatRichTooltipTitleComponent {
    elementRef = inject(ElementRef);
    tooltip = inject(SatRichTooltipComponent);
    /**
     * aria-label for the rich tooltip title.
     * @default ''
     */
    ariaLabel = input('', { alias: 'aria-label' });
    /** @ignore */
    get getAriaLabel() {
        return this.elementRef.nativeElement.textContent?.trim();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipTitleComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "19.2.19", type: SatRichTooltipTitleComponent, isStandalone: true, selector: "sat-rich-tooltip-title", inputs: { ariaLabel: { classPropertyName: "ariaLabel", publicName: "aria-label", isSignal: true, isRequired: false, transformFunction: null } }, host: { properties: { "attr.aria-label": "ariaLabel() || getAriaLabel", "attr.aria-describedby": "tooltip.ariaDescribedby()", "attr.id": "tooltip.ariaLabelledby()" }, classAttribute: "sat-rich-tooltip-title" }, ngImport: i0, template: `<ng-content></ng-content>`, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipTitleComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'sat-rich-tooltip-title',
                    template: `<ng-content></ng-content>`,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    encapsulation: ViewEncapsulation.None,
                    host: {
                        'class': 'sat-rich-tooltip-title',
                        '[attr.aria-label]': 'ariaLabel() || getAriaLabel',
                        '[attr.aria-describedby]': 'tooltip.ariaDescribedby()',
                        '[attr.id]': 'tooltip.ariaLabelledby()',
                    },
                }]
        }] });

/** @internal */
class RichTooltipOverlayService {
    overlay = inject(Overlay);
    directionality = inject(Directionality);
    /** @ignore */
    // This method creates the overlay from the provided richTooltip's template and saves its OverlayRef so that it can be attached to the DOM when openRichTooltip is called.
    createOverlay(tooltip) {
        return this.overlay.create(this.getOverlayConfig(tooltip));
    }
    /** @ignore */
    // The text direction of the containing app.
    get dir() {
        return this.directionality?.value === 'rtl' ? 'rtl' : 'ltr';
    }
    /** @ignore */
    // This method builds the configuration object needed to create the overlay, the OverlayConfig.
    getOverlayConfig(tooltip) {
        const overlayState = new OverlayConfig();
        /** Display overlay backdrop if trigger event is click */
        if (tooltip.behavior() === 'persistent') {
            overlayState.hasBackdrop = true;
            overlayState.backdropClass = 'cdk-overlay-transparent-backdrop';
        }
        overlayState.direction = this.dir;
        overlayState.scrollStrategy = this.getOverlayScrollStrategy(tooltip.scrollStrategy());
        return overlayState;
    }
    /** @ignore */
    // This method returns the scroll strategy used by the cdk/overlay.
    getOverlayScrollStrategy(strategy) {
        switch (strategy) {
            case 'noop':
                return this.overlay.scrollStrategies.noop();
            case 'close':
                return this.overlay.scrollStrategies.close();
            case 'block':
                return this.overlay.scrollStrategies.block();
            case 'reposition':
            default:
                return this.overlay.scrollStrategies.reposition();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: RichTooltipOverlayService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: RichTooltipOverlayService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: RichTooltipOverlayService, decorators: [{
            type: Injectable
        }] });

/** @internal */
class RichTooltipPositionService {
    overlay = inject(Overlay);
    /**
     * This method builds the position strategy for the overlay, so the richTooltip is properly connected
     * to the trigger.
     * @ignore
     * @returns ConnectedPositionStrategy
     */
    getPosition(tooltip, elementRef) {
        const [originX, originFallbackX] = tooltip.validatedPositionX() === 'before' ? ['end', 'start'] : ['start', 'end'];
        const [overlayY, overlayFallbackY] = tooltip.validatedPositionY() === 'above' ? ['bottom', 'top'] : ['top', 'bottom'];
        let originY = overlayY;
        let originFallbackY = overlayFallbackY;
        const overlayX = originX;
        const overlayFallbackX = originFallbackX;
        let offsetX = 0;
        let offsetY = 0;
        /**
         * Reverse overlayY and fallbackOverlayY when overlapTrigger is false.
         * Also update the horizontal and vertical offset
         */
        if (!tooltip.overlapTrigger()) {
            originY = overlayY === 'top' ? 'bottom' : 'top';
            originFallbackY = overlayFallbackY === 'top' ? 'bottom' : 'top';
            if (tooltip.targetOffsetX() && !Number.isNaN(Number(tooltip.targetOffsetX()))) {
                const targetOffsetX = Number(tooltip.targetOffsetX());
                // Need to have a horizontal offset if provided by the input
                if (originX === 'start')
                    offsetX = targetOffsetX;
                // Need to have the horizontal offset in the negative direction
                else
                    offsetX = -targetOffsetX;
            }
            if (tooltip.targetOffsetY() && !Number.isNaN(Number(tooltip.targetOffsetY()))) {
                const targetOffsetY = Number(tooltip.targetOffsetY());
                // Need to have a vertical offset if provided by the input
                if (originY === 'bottom')
                    offsetY = targetOffsetY;
                // Need to have the vertical offset in the negative direction
                else
                    offsetY = -targetOffsetY;
            }
        }
        return this.overlay
            .position()
            .flexibleConnectedTo(elementRef)
            .withLockedPosition(true)
            .withPush(true) // Enables pushing the overlay into the viewport
            .withViewportMargin(8) // Set an 8px margin to keep the overlay from touching the viewport edges.
            .withPositions([
            {
                originX,
                originY,
                overlayX,
                overlayY,
                offsetY,
            },
            {
                originX: originFallbackX,
                originY,
                overlayX: overlayFallbackX,
                overlayY,
                offsetY,
            },
            {
                originX,
                originY: originFallbackY,
                overlayX,
                overlayY: overlayFallbackY,
                offsetY: -offsetY,
            },
            {
                originX: originFallbackX,
                originY: originFallbackY,
                overlayX: overlayFallbackX,
                overlayY: overlayFallbackY,
                offsetY: -offsetY,
            },
        ])
            .withDefaultOffsetX(offsetX)
            .withDefaultOffsetY(offsetY);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: RichTooltipPositionService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: RichTooltipPositionService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: RichTooltipPositionService, decorators: [{
            type: Injectable
        }] });

/**
 * Directive for triggering the rich tooltip.
 * This directive listens for various events (click, mouseenter, focus, mouseleave) to control the opening and closing of the tooltip.
 */
class SatRichTooltipTriggerDirective {
    elementRef = inject(ElementRef);
    viewContainerRef = inject(ViewContainerRef);
    richTooltipOverlayService = inject(RichTooltipOverlayService);
    richTooltipPositionService = inject(RichTooltipPositionService);
    changeDetectorRef = inject(ChangeDetectorRef);
    /** Whether the rich tooltip is currently open. */
    richTooltipOpen = signal(false);
    richTooltipOpened = new Subject();
    richTooltipClosed = new Subject();
    portal;
    overlayRef = null;
    halt = false; // Restricts the tooltip to be triggered multiple time if there is a delay while opening it.
    backdropSubscription;
    positionSubscription;
    detachmentsSubscription;
    mouseoverTimer;
    openedByMouse = false;
    _previousAriaDescribedById = null;
    /** References the richTooltip instance that the trigger is associated with. */
    tooltip = input.required({ alias: 'satRichTooltipTriggerFor' });
    /**
     * Computes the aria-haspopup value based on the tooltip's behavior.
     * Returns "dialog" when behavior is "persistent", otherwise undefined (no attribute) for transient tooltips.
     * @ignore
     */
    ariaHaspopup = computed(() => {
        return this.tooltip().isPersistent() ? 'dialog' : null;
    });
    /**
     * Computes the aria-expanded value based on the tooltip's behavior.
     * Returns the open state when behavior is "persistent", otherwise undefined (no attribute) for transient tooltips.
     * Per ARIA best practices, aria-expanded is appropriate for dialog triggers but not for tooltip triggers.
     * @ignore
     */
    ariaExpanded = computed(() => {
        return this.tooltip().isPersistent() ? this.richTooltipOpen() : null;
    });
    ariaDescribedby = signal(this.elementRef.nativeElement.getAttribute('aria-describedby') ?? null);
    /** RichTooltip won't open on trigger */
    satRichTooltipDisabled = input(false, { transform: booleanAttribute });
    /** RichTooltip backdrop close on click */
    satRichTooltipBackdropCloseOnClick = input(true, {
        transform: booleanAttribute,
    });
    /** Event emitted when the associated richTooltip is opened. */
    tooltipOpened = output();
    /** Event emitted when the associated richTooltip is closed. */
    tooltipClosed = output();
    /** @ignore */
    ngAfterViewInit() {
        this.checkRichTooltip();
        this.tooltip().closed.subscribe(() => this.closeRichTooltip());
    }
    /**
     * Listens for click events to toggle the rich tooltip only if the behavior is persistent.
     * @param event The click event.
     */
    onClick(event) {
        if (event && this.tooltip().behavior() === 'persistent') {
            this.toggleRichTooltip();
        }
    }
    /**
     * Listens for mouse enter events to open the rich tooltip only if the behavior is transient.
     * @param event The mouse enter event.
     */
    onMouseEnter(event) {
        if (event && !this.richTooltipOpen() && this.tooltip().behavior() === 'transient') {
            this.checkTooltipToOpen(true);
        }
    }
    /**
     * Listens for focus events to open the rich tooltip only if the behavior is transient.
     * @param event The focus event.
     */
    onFocus(event) {
        if (event && !this.richTooltipOpen() && this.tooltip().behavior() === 'transient') {
            this.checkTooltipToOpen();
        }
    }
    /**
     * Listens for focusout events to close the rich tooltip only if the behavior is transient.
     * @param event The focus event.
     */
    onFocusOut(event) {
        if (event && this.richTooltipOpen() && this.tooltip().behavior() === 'transient') {
            setTimeout(() => {
                if (!this.tooltip().closeDisabled) {
                    this.closeRichTooltip();
                }
            }, this.tooltip().hideDelay());
        }
    }
    /** Listens for Escape key down on the trigger to close the Rich Tooltip. */
    onEscapeKey() {
        if (this.richTooltipOpen()) {
            this.closeRichTooltip();
        }
    }
    /**
     * Listens for mouse leave events to close the rich tooltip only if the behavior is transient.
     * @param event The mouse leave event.
     */
    onMouseLeave(event) {
        if (event && this.tooltip().behavior() === 'transient') {
            if (this.richTooltipOpen()) {
                if (this.mouseoverTimer) {
                    clearTimeout(this.mouseoverTimer);
                    this.mouseoverTimer = null;
                }
                setTimeout(() => {
                    if (!this.tooltip().closeDisabled) {
                        this.closeRichTooltip();
                    }
                }, this.tooltip().hideDelay());
            }
        }
    }
    /** @ignore */
    checkTooltipToOpen(openedByMouse = false) {
        if (!this.halt) {
            this.halt = true;
            this.openedByMouse = openedByMouse;
            this.mouseoverTimer = setTimeout(() => {
                this.openRichTooltip();
            }, this.tooltip().showDelay());
        }
    }
    /**
     * Listens for mousedown events to track if the tooltip was opened by mouse interaction.
     * @param event The mousedown event.
     */
    handleMousedown(event) {
        if (event && !isFakeMousedownFromScreenReader(event)) {
            this.openedByMouse = true;
        }
    }
    /** @ignore */
    // Toggles the richTooltip between the open and closed states.
    toggleRichTooltip() {
        return this.richTooltipOpen() ? this.closeRichTooltip() : this.openRichTooltip();
    }
    /** @ignore */
    // Opens the richTooltip.
    openRichTooltip() {
        if (!this.satRichTooltipDisabled() && !this.richTooltipOpen()) {
            const positionStrategy = this.richTooltipPositionService.getPosition(this.tooltip(), this.elementRef);
            if (!this.overlayRef) {
                const templateRef = this.tooltip().templateRef();
                if (templateRef)
                    this.portal = new TemplatePortal(templateRef, this.viewContainerRef);
                this.overlayRef = this.richTooltipOverlayService.createOverlay(this.tooltip());
                this.overlayRef.updatePositionStrategy(positionStrategy);
            }
            this.overlayRef.attach(this.portal);
            // required for ChangeDetectionStrategy.OnPush
            this.changeDetectorRef.markForCheck();
            this.subscribeToBackdrop();
            this.subscribeToDetachments();
            this.initRichTooltip();
            this._syncAriaDescription();
        }
    }
    /** @ignore */
    // Closes the richTooltip.
    closeRichTooltip() {
        this.overlayRef?.detach();
        this.changeDetectorRef.markForCheck();
        this.resetRichTooltip();
        this._cleanAriaDescription();
    }
    /** @ignore */
    // Removes the richTooltip from the DOM.
    destroyRichTooltip() {
        if (this.mouseoverTimer) {
            clearTimeout(this.mouseoverTimer);
            this.mouseoverTimer = null;
        }
        if (this.overlayRef) {
            this.overlayRef.dispose();
            this.overlayRef = null;
            this.cleanUpSubscriptions();
        }
        this._cleanAriaDescription();
        this.richTooltipOpened.complete();
        this.richTooltipClosed.complete();
    }
    /** @ignore */
    //  Updates the tooltip's ARIA description based on rich tooltip id.
    _syncAriaDescription() {
        if (this.tooltip().isPersistent()) {
            return;
        }
        this._previousAriaDescribedById = this.tooltip().id();
        this.ariaDescribedby.set(this.ariaDescribedby()
            ? `${this.ariaDescribedby()} ${this._previousAriaDescribedById}`
            : this._previousAriaDescribedById);
    }
    /** @ignore */
    //  Clean tooltip's ARIA description when the tooltip element is detached.
    _cleanAriaDescription() {
        if (!this._previousAriaDescribedById) {
            return;
        }
        const currentValue = this.ariaDescribedby();
        if (currentValue) {
            const cleanedValue = currentValue
                .split(' ')
                .filter(id => id !== this._previousAriaDescribedById)
                .join(' ');
            this.ariaDescribedby.set(cleanedValue || null);
        }
        this._previousAriaDescribedById = null;
    }
    /** @ignore */
    // Focuses the richTooltip trigger.
    focus() {
        this.elementRef.nativeElement.focus();
    }
    /** @ignore */
    // This method ensures that the richTooltip closes when the overlay backdrop is clicked. We do not use first() here because doing so would not catch clicks from within the richTooltip, and it would fail to unsubscribe properly. Instead, we unsubscribe explicitly when the richTooltip is closed or destroyed.
    subscribeToBackdrop() {
        // Only subscribe to backdrop if trigger event is click
        if (this.overlayRef) {
            if (this.tooltip().behavior() === 'persistent' &&
                this.satRichTooltipBackdropCloseOnClick() === true) {
                this.overlayRef
                    .backdropClick()
                    .pipe(takeUntil(this.richTooltipClosed))
                    .subscribe(() => {
                    this.tooltip().emitCloseEvent();
                });
            }
        }
    }
    /** @ignore */
    subscribeToDetachments() {
        if (this.overlayRef) {
            this.overlayRef
                .detachments()
                .pipe(takeUntil(this.richTooltipClosed))
                .subscribe(() => {
                this.setRichTooltipClosed();
            });
        }
    }
    /** @ignore */
    // This method sets the richTooltip state to open and focuses the first item if the richTooltip was opened via the keyboard.
    initRichTooltip() {
        this.setRichTooltipOpened();
    }
    /** @ignore */
    // This method resets the richTooltip when it's closed, most importantly restoring focus to the richTooltip trigger if the richTooltip was opened via the keyboard.
    resetRichTooltip() {
        this.setRichTooltipClosed();
        // Focus only needs to be reset to the host element if the richTooltip was opened by the keyboard and behavior is persistent.
        if (!this.openedByMouse && this.tooltip().behavior() === 'persistent') {
            this.focus();
        }
        this.openedByMouse = false;
    }
    /** @ignore */
    // set state rather than toggle to support triggers sharing a richTooltip
    setRichTooltipOpened() {
        if (!this.richTooltipOpen()) {
            this.richTooltipOpen.set(true);
            this.halt = false;
            this.richTooltipOpened.next();
            this.tooltipOpened.emit();
        }
    }
    /** @ignore */
    // set state rather than toggle to support triggers sharing a richTooltip
    setRichTooltipClosed() {
        if (this.richTooltipOpen()) {
            this.richTooltipOpen.set(false);
            this.richTooltipClosed.next();
            this.tooltipClosed.emit();
        }
    }
    /** @ignore */
    // This method checks that a valid instance of MdRichTooltip has been passed into satRichTooltipTriggerFor. If not, an exception is thrown.
    checkRichTooltip() {
        if (!this.tooltip()) {
            throwRichTooltipMissingError();
        }
    }
    /** @ignore */
    cleanUpSubscriptions() {
        if (this.backdropSubscription) {
            this.backdropSubscription.unsubscribe();
        }
        if (this.positionSubscription) {
            this.positionSubscription.unsubscribe();
        }
        if (this.detachmentsSubscription) {
            this.detachmentsSubscription.unsubscribe();
        }
    }
    /** @ignore */
    ngOnDestroy() {
        this.destroyRichTooltip();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipTriggerDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "19.2.19", type: SatRichTooltipTriggerDirective, isStandalone: true, selector: "[satRichTooltipTriggerFor]", inputs: { tooltip: { classPropertyName: "tooltip", publicName: "satRichTooltipTriggerFor", isSignal: true, isRequired: true, transformFunction: null }, satRichTooltipDisabled: { classPropertyName: "satRichTooltipDisabled", publicName: "satRichTooltipDisabled", isSignal: true, isRequired: false, transformFunction: null }, satRichTooltipBackdropCloseOnClick: { classPropertyName: "satRichTooltipBackdropCloseOnClick", publicName: "satRichTooltipBackdropCloseOnClick", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { tooltipOpened: "tooltipOpened", tooltipClosed: "tooltipClosed" }, host: { listeners: { "click": "onClick($event)", "mouseenter": "onMouseEnter($event)", "focus": "onFocus($event)", "focusout": "onFocusOut($event)", "keydown.escape": "onEscapeKey()", "mouseleave": "onMouseLeave($event)", "mousedown": "handleMousedown($event)" }, properties: { "class.sat-rich-tooltip-disabled": "satRichTooltipDisabled()", "attr.aria-haspopup": "ariaHaspopup()", "attr.aria-expanded": "ariaExpanded()", "attr.aria-describedby": "ariaDescribedby()" }, classAttribute: "sat-rich-tooltip-trigger" }, providers: [RichTooltipOverlayService, RichTooltipPositionService], exportAs: ["satRichTooltipTrigger"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipTriggerDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: `[satRichTooltipTriggerFor]`,
                    providers: [RichTooltipOverlayService, RichTooltipPositionService],
                    host: {
                        'class': 'sat-rich-tooltip-trigger',
                        '[class.sat-rich-tooltip-disabled]': 'satRichTooltipDisabled()',
                        '[attr.aria-haspopup]': 'ariaHaspopup()',
                        '[attr.aria-expanded]': 'ariaExpanded()',
                        '[attr.aria-describedby]': 'ariaDescribedby()',
                    },
                    exportAs: 'satRichTooltipTrigger',
                }]
        }], propDecorators: { onClick: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], onMouseEnter: [{
                type: HostListener,
                args: ['mouseenter', ['$event']]
            }], onFocus: [{
                type: HostListener,
                args: ['focus', ['$event']]
            }], onFocusOut: [{
                type: HostListener,
                args: ['focusout', ['$event']]
            }], onEscapeKey: [{
                type: HostListener,
                args: ['keydown.escape']
            }], onMouseLeave: [{
                type: HostListener,
                args: ['mouseleave', ['$event']]
            }], handleMousedown: [{
                type: HostListener,
                args: ['mousedown', ['$event']]
            }] } });

const satRichTooltipArtifacts = [
    SatRichTooltipComponent,
    SatRichTooltipTriggerDirective,
    SatRichTooltipTitleComponent,
    SatRichTooltipContentComponent,
    SatRichTooltipActionsComponent,
    SatRichTooltipCloseDirective,
];
class SatRichTooltipModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipModule, imports: [SatRichTooltipComponent,
            SatRichTooltipTriggerDirective,
            SatRichTooltipTitleComponent,
            SatRichTooltipContentComponent,
            SatRichTooltipActionsComponent,
            SatRichTooltipCloseDirective], exports: [SatRichTooltipComponent,
            SatRichTooltipTriggerDirective,
            SatRichTooltipTitleComponent,
            SatRichTooltipContentComponent,
            SatRichTooltipActionsComponent,
            SatRichTooltipCloseDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipModule, imports: [SatRichTooltipComponent,
            SatRichTooltipActionsComponent] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.19", ngImport: i0, type: SatRichTooltipModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: satRichTooltipArtifacts,
                    exports: satRichTooltipArtifacts,
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { SatRichTooltipActionsComponent, SatRichTooltipCloseDirective, SatRichTooltipComponent, SatRichTooltipContentComponent, SatRichTooltipModule, SatRichTooltipTitleComponent, SatRichTooltipTriggerDirective };
//# sourceMappingURL=hylandsoftware-satori-ui-rich-tooltip.mjs.map
