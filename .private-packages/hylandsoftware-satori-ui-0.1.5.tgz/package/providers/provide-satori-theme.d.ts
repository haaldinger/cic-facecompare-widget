import { EnvironmentProviders } from '@angular/core';
/**
 * This function returns providers for configuration of Angular Material components,
 * setting some default options related to Satori UI theme and appearance.
 */
export declare function provideSatoriTheme(): EnvironmentProviders;
