import { EnvironmentProviders } from '@angular/core';
/**
 * Configuration options for Satori UI.
 */
export interface SatoriConfig {
    /** Whether to provide Satori theme configuration. Defaults to true. */
    theme?: boolean;
    /** Whether to provide Satori icons configuration. Defaults to true. */
    icons?: boolean;
}
/**
 * Provides all necessary configuration for Satori UI including theme and icons.
 *
 * @param config Optional configuration for Satori UI providers
 *
 * @example
 * ```typescript
 * // All providers enabled (default)
 * export const appConfig: ApplicationConfig = {
 *   providers: [provideSatori()]
 * };
 *
 * // Only theme provider
 * export const appConfig: ApplicationConfig = {
 *   providers: [provideSatori({ icons: false })]
 * };
 * ```
 */
export declare function provideSatori(config?: SatoriConfig): EnvironmentProviders;
