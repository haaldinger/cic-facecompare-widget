import * as i0 from "@angular/core";
/**
 * Tag component for displaying a tag with an optional icon and label.
 * This component is designed to be used internally within the Satori UI framework, providing a consistent look and feel for tags across applications.
 * @internal
 */
export declare class SatTagComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatTagComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatTagComponent, "sat-tag", never, {}, {}, never, [".sat-tag-icon", "*"], true, never>;
}
