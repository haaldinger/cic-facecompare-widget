import * as i0 from "@angular/core";
/**
 * The Directive is used to hide the icon in the tag components.
 * This directive can be applied to all the different types of tag components (e.g. SatStatusTagComponent, SatCategoryTagComponent) to remove the icon from the tag.
 * @deprecated Use the `hideIcon` input property available on the status tag components instead.
 */
export declare class SatHideIconDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatHideIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatHideIconDirective, "[satHideIcon]", ["satHideIcon"], {}, {}, never, never, true, never>;
}
