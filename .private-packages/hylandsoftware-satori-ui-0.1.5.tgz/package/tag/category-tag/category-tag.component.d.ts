import { SatTagCategory } from '../types/tag-category-type';
import * as i0 from "@angular/core";
/**
 * The `SatCategoryTagComponent` is used to display category labels with predefined styles.
 * It supports various categories like purple, blue, pink, etc., and automatically applies the appropriate styles based on the category type mentioned in `SatTagCategory`.
 * There is no default icon for the category component. You need to provide a custom icon which meets your requirements. Otherwise no icon will be displayed.
 *
 * @example
 * <sat-category-tag category="purple">
 *   <mat-icon aria-label="custom icon" svgIcon="tag"></mat-icon>
 *   Purple Category
 * </sat-category-tag>
 */
export declare class SatCategoryTagComponent {
    /**
     * The category of the tag, which determines its style and icon.
     * This should be one of the predefined categories.
     *
     * @type {SatTagCategory}
     * @required
     */
    readonly category: import("@angular/core").InputSignal<SatTagCategory>;
    /** @ignore */
    readonly backgroundColor: import("@angular/core").Signal<string>;
    /** @ignore */
    readonly color: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatCategoryTagComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatCategoryTagComponent, "sat-category-tag", never, { "category": { "alias": "category"; "required": true; "isSignal": true; }; }, {}, never, ["[mat-icon], mat-icon", "*"], true, never>;
}
