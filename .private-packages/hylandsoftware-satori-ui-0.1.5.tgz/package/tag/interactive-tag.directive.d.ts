import * as i0 from "@angular/core";
import * as i1 from "@hylandsoftware/satori-ui/focus-indicator";
/**
 * Directive that transforms a tag element to make it interactive to allow to attach a tooltip or rich-tooltip.
 */
export declare class SatInteractiveTagDirective {
    /**
     * Keyboard interaction to allow the tag to be activated with Enter or Space keys, similar to a button
     */
    onKeyDown(event: KeyboardEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatInteractiveTagDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatInteractiveTagDirective, "[satInteractiveTag]", ["satInteractiveTag"], {}, {}, never, never, true, [{ directive: typeof i1.SatFocusIndicatorDirective; inputs: {}; outputs: {}; }]>;
}
