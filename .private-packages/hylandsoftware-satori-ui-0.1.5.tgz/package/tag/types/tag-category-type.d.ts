/**
 * The predefined categories of a tag.
 */
export type SatTagCategory = 'purple' | 'blue' | 'pink' | 'teal' | 'yellow' | 'green' | 'red' | 'orange' | 'gray';
