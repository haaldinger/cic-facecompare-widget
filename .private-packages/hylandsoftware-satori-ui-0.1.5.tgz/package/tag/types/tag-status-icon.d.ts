import { SatTagStatus } from './tag-status-type';
export declare const satStatusTagIcon: Record<SatTagStatus, string>;
