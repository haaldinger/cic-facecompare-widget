/**
 * The predefined statuses of a tag.
 */
export type SatTagStatus = 'important-loud' | 'important' | 'success' | 'warning' | 'info' | 'neutral';
