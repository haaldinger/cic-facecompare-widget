import { SatTagStatus } from '../types/tag-status-type';
import * as i0 from "@angular/core";
/**
 * The `SatStatusTagComponent` is used to display status labels with predefined styles and icons.
 * It supports various statuses like success, warning, info, etc., and automatically applies the appropriate styles and icons based on different status types mentioned in `SatTagStatus`, and the icon or the style of this component is predefined for the selected status.
 * You can also provide a custom icon to overwrite the predefined icon for a specific status.
 *
 * @example
 * <sat-status-tag status="success"> Success </sat-status-tag>
 */
export declare class SatStatusTagComponent {
    /**
     * The status of the tag, which determines its appearance and color.
     * This should be one of the predefined statuses.
     * @type {SatTagStatus}
     * @required
     */
    readonly status: import("@angular/core").InputSignal<SatTagStatus>;
    /**
     * Whether to hide the icon in the tag.
     * @deprecated Use `hideIcon` instead.
     */
    readonly satHideIcon: import("@angular/core").InputSignalWithTransform<boolean, boolean>;
    /**
     * Whether to hide the icon in the tag.
     */
    readonly hideIcon: import("@angular/core").InputSignalWithTransform<boolean, boolean>;
    readonly backgroundColor: import("@angular/core").Signal<string>;
    readonly color: import("@angular/core").Signal<string>;
    readonly defaultIcon: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatStatusTagComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatStatusTagComponent, "sat-status-tag", never, { "status": { "alias": "status"; "required": true; "isSignal": true; }; "satHideIcon": { "alias": "satHideIcon"; "required": false; "isSignal": true; }; "hideIcon": { "alias": "hideIcon"; "required": false; "isSignal": true; }; }, {}, never, ["[mat-icon], mat-icon", "*"], true, never>;
}
