import * as i0 from "@angular/core";
import * as i1 from "./category-tag/category-tag.component";
import * as i2 from "./status-tag/status-tag.component";
import * as i3 from "./hide-icon.directive";
import * as i4 from "./interactive-tag.directive";
export declare class SatTagModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatTagModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatTagModule, never, [typeof i1.SatCategoryTagComponent, typeof i2.SatStatusTagComponent, typeof i3.SatHideIconDirective, typeof i4.SatInteractiveTagDirective], [typeof i1.SatCategoryTagComponent, typeof i2.SatStatusTagComponent, typeof i3.SatHideIconDirective, typeof i4.SatInteractiveTagDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatTagModule>;
}
