export { SatAvatarComponent, type SatAvatarCategory, type SatAvatarIndicator, type SatAvatarSize, } from './avatar.component';
export { SatAvatarModule } from './module';
