import * as i0 from "@angular/core";
/** The category of the avatar, which determines its color. */
export type SatAvatarCategory = 'purple' | 'blue' | 'pink' | 'teal' | 'yellow' | 'green' | 'red' | 'orange';
/** The indicator type of the avatar, which determines its status. */
export type SatAvatarIndicator = 'active' | 'away' | 'offline' | 'readonly';
/** The size of the avatar, which determines its pixel size. */
export type SatAvatarSize = '128' | '80' | '64' | '36' | '28' | '24';
/**
 * The `sat-avatar` component is used to display user initials with various styles and indicators.
 * It supports different categories, sizes, and status indicators.
 */
export declare class SatAvatarComponent {
    /**
     * One out of: purple, blue, pink, teal, yellow, green, red, orange.
     * Used to determine the color of the avatar.
     */
    readonly category: import("@angular/core").InputSignal<SatAvatarCategory>;
    /**
     * One out of: 24, 28, 36, 64, 80, 128.
     * Used as the pixel size of the avatar.
     */
    readonly size: import("@angular/core").InputSignal<SatAvatarSize>;
    /**
     * One out of: active, away, offline, readonly.
     * Used to determine the optional indicator displayed on the avatar.
     * If left unset, no indicator will be displayed.
     */
    readonly indicator: import("@angular/core").InputSignal<SatAvatarIndicator | undefined>;
    /**
     * The first two character of this string, or the first character of this string in size 24
     * will be displayed uppercase in the avatar.
     */
    readonly initials: import("@angular/core").InputSignal<string>;
    /** Whether to not display a border around the avatar. Defaults to false. */
    readonly borderless: import("@angular/core").InputSignal<boolean>;
    /** @internal */
    readonly _displayedInitials: import("@angular/core").Signal<string>;
    /** @internal */
    readonly _backgroundColor: import("@angular/core").Signal<string>;
    /** @internal */
    readonly _color: import("@angular/core").Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatAvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatAvatarComponent, "sat-avatar", never, { "category": { "alias": "category"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "indicator": { "alias": "indicator"; "required": false; "isSignal": true; }; "initials": { "alias": "initials"; "required": false; "isSignal": true; }; "borderless": { "alias": "borderless"; "required": false; "isSignal": true; }; }, {}, never, ["img"], true, never>;
}
