import * as i0 from "@angular/core";
/** @internal */
export declare class SatAvatarOfflineIndicatorComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatAvatarOfflineIndicatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatAvatarOfflineIndicatorComponent, "sat-avatar-offline-indicator", never, {}, {}, never, never, true, never>;
}
