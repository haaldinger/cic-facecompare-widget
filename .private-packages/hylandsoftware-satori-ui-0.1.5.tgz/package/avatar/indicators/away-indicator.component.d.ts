import * as i0 from "@angular/core";
/** @internal */
export declare class SatAvatarAwayIndicatorComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatAvatarAwayIndicatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatAvatarAwayIndicatorComponent, "sat-avatar-away-indicator", never, {}, {}, never, never, true, never>;
}
