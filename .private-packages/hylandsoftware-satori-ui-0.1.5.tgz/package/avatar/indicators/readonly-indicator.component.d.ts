import * as i0 from "@angular/core";
/** @internal */
export declare class SatAvatarReadonlyIndicatorComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatAvatarReadonlyIndicatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatAvatarReadonlyIndicatorComponent, "sat-avatar-readonly-indicator", never, {}, {}, never, never, true, never>;
}
