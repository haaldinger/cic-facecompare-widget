import * as i0 from "@angular/core";
/** @internal */
export declare class SatAvatarActiveIndicatorComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatAvatarActiveIndicatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatAvatarActiveIndicatorComponent, "sat-avatar-active-indicator", never, {}, {}, never, never, true, never>;
}
