import * as i0 from "@angular/core";
import * as i1 from "./avatar.component";
export declare class SatAvatarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatAvatarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatAvatarModule, never, [typeof i1.SatAvatarComponent], [typeof i1.SatAvatarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatAvatarModule>;
}
