import * as i0 from "@angular/core";
/**
 * Directive that adds the `mat-focus-indicator` class to the host element.
 *
 * This enables Material's focus indicator styles on any element where the directive is applied.
 *
 * @example
 * ```html
 * <button satFocusIndicator>Click me</button>
 * ```
 */
export declare class SatFocusIndicatorDirective {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SatFocusIndicatorDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatFocusIndicatorDirective, "[satFocusIndicator]", never, {}, {}, never, never, true, never>;
}
