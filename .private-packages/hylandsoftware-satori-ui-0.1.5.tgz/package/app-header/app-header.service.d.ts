import * as i0 from "@angular/core";
export declare class SatAppHeaderService {
    private readonly document;
    private readonly window;
    private readonly scrollSignal;
    private readonly resizeSignal;
    /** @internal Gets updated by the App Header component. Helps `verticalSpace()` to exit early. */
    readonly shouldStick: import("@angular/core").WritableSignal<boolean>;
    /**
     * How much vertical space the App Header is taking up in total at the top of the viewport.
     * Useful for determining offsets for other scrollable content (see Nested Scrollviews).
     */
    readonly verticalSpace: import("@angular/core").Signal<number | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatAppHeaderService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SatAppHeaderService>;
}
