import * as i0 from "@angular/core";
/**
 * You can use this directive to create a Hyland logo in the app header.
 * It integrates seamlessly with `sat-word-mark-logo` when used for the App Header logo slot.
 *
 * @deprecated `satHeaderLogo` is deprecated, use `satAppHeaderLogo` instead.
 */
export declare class AppHeaderLogoDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderLogoDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AppHeaderLogoDirective, "[satHeaderLogo], [satAppHeaderLogo]", ["satAppHeaderLogo"], {}, {}, never, never, true, never>;
}
