import * as i0 from "@angular/core";
/**
 * You can use this directive to create action buttons and items in the app header.
 *
 * @deprecated `satHeaderActions` is deprecated, use `satAppHeaderActions` instead.
 */
export declare class AppHeaderActionsDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderActionsDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AppHeaderActionsDirective, "[satHeaderActions], [satAppHeaderActions]", ["satAppHeaderActions"], {}, {}, never, never, true, never>;
}
