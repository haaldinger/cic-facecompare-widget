import * as i0 from "@angular/core";
/**
 * You can use this directive to insert a Platform Nav trigger in the app header,
 * that is only visible when viewed on small viewports.
 */
export declare class AppHeaderPlatformNavMobileTriggerDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderPlatformNavMobileTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AppHeaderPlatformNavMobileTriggerDirective, "[satAppHeaderPlatformNavMobileTrigger]", ["satAppHeaderPlatformNavMobileTrigger"], {}, {}, never, never, true, never>;
}
