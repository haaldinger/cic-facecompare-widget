import * as i0 from "@angular/core";
/**
 * The component is a customizable header designed to provide a consistent look and feel across applications.
 * It supports navigation, branding, and action items.
 *
 * @deprecated This component will be removed in future versions. Use `sat-app-header` instead.
 *
 */
export declare class HeaderComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderComponent, "sat-header", never, {}, {}, never, ["[satAppHeaderTitle], [satHeaderTitle]", "[satAppHeaderLogo], [satHeaderLogo]", "[satAppHeaderActions], [satHeaderActions]", "[satAppHeaderNavigation], [satHeaderNavigation]"], true, never>;
}
/**
 * The `App Header` component is a customizable header designed to provide a consistent look and feel across applications.
 * It supports navigation, branding, and action items.
 *
 * @example
 * <sat-app-header>
 *  <h2 satAppHeaderTitle>{{ title }}</h2>
 *  <sat-word-mark-logo satAppHeaderLogo></sat-word-mark-logo>
 *  <div satAppHeaderActions>
 *    ...
 *  </div>
 *  <nav mat-tab-nav-bar satAppHeaderNavigation [tabPanel]="tabPanel" mat-stretch-tabs="false">
 *    <a mat-tab-link routerLink="#" [active]="true">Tasks</a>
 *  </nav>
 * </sat-app-header>
 */
export declare class AppHeaderComponent {
    /** Whether the header should stick to the top of the viewport. Defaults to true. Excludes navigation (Tabs). */
    readonly sticky: import("@angular/core").InputSignal<boolean>;
    private readonly content;
    private readonly document;
    private readonly hostElement;
    private readonly service;
    private readonly scrollTop;
    private readonly hasScrolledPastTop;
    /** @internal */
    readonly shouldStick: import("@angular/core").Signal<boolean>;
    private readonly resizeSignal;
    /** @internal Accounts for App Header title wrapping to multiple lines. */
    readonly headerPaddingTop: import("@angular/core").Signal<number>;
    /** @internal Width of the sticky content, matching the host element to avoid covering the scrollbar. */
    readonly stickyContentWidth: import("@angular/core").Signal<number | null>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AppHeaderComponent, "sat-app-header", never, { "sticky": { "alias": "sticky"; "required": false; "isSignal": true; }; }, {}, never, ["[satAppHeaderLeadingAction]", "[satAppHeaderPlatformNavMobileTrigger]", "[satAppHeaderTitle], [satHeaderTitle]", "[satAppHeaderLogo], [satHeaderLogo]", "[satAppHeaderActions], [satHeaderActions]", "[satAppHeaderNavigation], [satHeaderNavigation]"], true, never>;
}
