import * as i0 from "@angular/core";
/**
 * You can use this directive to create navigation in the app header.
 *
 * @deprecated `satHeaderNavigation` is deprecated, use `satAppHeaderNavigation` instead.
 */
export declare class AppHeaderNavigationDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderNavigationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AppHeaderNavigationDirective, "[satHeaderNavigation], [satAppHeaderNavigation]", ["satAppHeaderNavigation"], {}, {}, never, never, true, never>;
}
