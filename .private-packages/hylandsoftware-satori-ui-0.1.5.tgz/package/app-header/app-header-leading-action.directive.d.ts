import * as i0 from "@angular/core";
/**
 * You can use this directive to position a leading action icon button in the App Header.
 * The leading action takes precedence over the Platform Nav mobile trigger when both are present.
 */
export declare class AppHeaderLeadingActionDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<AppHeaderLeadingActionDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AppHeaderLeadingActionDirective, "[satAppHeaderLeadingAction]", ["satAppHeaderLeadingAction"], {}, {}, never, never, true, never>;
}
