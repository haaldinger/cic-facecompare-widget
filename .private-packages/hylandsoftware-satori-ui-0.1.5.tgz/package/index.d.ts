/**
 * Export all sub-modules for backwards compatibility, enabling consumers to import from
 * a single entry point, for example:
 * import { SatAppHeaderModule, SatBreadcrumbsModule } from '@hylandsoftware/satori-ui';
 *
 * To enable lazy-loading behaviors by default for all consumers, importing from this
 * index file is deprecated and will be removed in future versions. Please import directly
 * from the specific sub-module instead, for example:
 * import { SatAppHeaderModule } from '@hylandsoftware/satori-ui/app-header';
 * import { SatBreadcrumbsModule } from '@hylandsoftware/satori-ui/breadcrumbs';
 */
/** @deprecated import from '@hylandsoftware/satori-ui/app-header' instead */
export * from '@hylandsoftware/satori-ui/app-header';
/** @deprecated import from '@hylandsoftware/satori-ui/breadcrumbs' instead */
export * from '@hylandsoftware/satori-ui/breadcrumbs';
/** @deprecated import from '@hylandsoftware/satori-ui/icons' instead */
export * from '@hylandsoftware/satori-ui/icons';
/** @deprecated import from '@hylandsoftware/satori-ui/logo' instead */
export * from '@hylandsoftware/satori-ui/logo';
/** @deprecated import from '@hylandsoftware/satori-ui/platform-nav' instead */
export * from '@hylandsoftware/satori-ui/platform-nav';
/** @deprecated import from '@hylandsoftware/satori-ui/providers' instead */
export * from '@hylandsoftware/satori-ui/providers';
/** @deprecated import from '@hylandsoftware/satori-ui/rich-tooltip' instead */
export * from '@hylandsoftware/satori-ui/rich-tooltip';
/** @deprecated import from '@hylandsoftware/satori-ui/tag' instead */
export * from '@hylandsoftware/satori-ui/tag';
/**
 * @deprecated import from '@hylandsoftware/satori-ui/translations' instead
 * @deprecated This provider name is deprecated. Use `provideAndConfigureSatoriUITranslations` instead.
 * Provides the default translation feature for the Satori UI library.
 * Replace all instances of `provideSatoriUITranslations` with `provideAndConfigureSatoriUITranslations` in your application config.
 */
export { provideAndConfigureSatoriUITranslations as provideSatoriUITranslations } from '@hylandsoftware/satori-ui/translations';
