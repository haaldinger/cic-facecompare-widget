import * as i0 from "@angular/core";
/**
 * @deprecated Use provideSatoriIcons from @hylandsoftware/satori-ui/icons instead
 */
export declare class SatIconModule {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<SatIconModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatIconModule, never, never, never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatIconModule>;
}
