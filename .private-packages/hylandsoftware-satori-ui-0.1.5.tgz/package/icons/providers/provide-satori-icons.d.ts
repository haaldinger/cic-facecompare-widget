import { EnvironmentProviders } from '@angular/core';
export declare function provideSatoriIcons(): EnvironmentProviders;
