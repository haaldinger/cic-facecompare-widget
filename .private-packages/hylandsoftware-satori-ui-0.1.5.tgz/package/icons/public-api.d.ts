export { SATORI_ICONS } from '@hylandsoftware/satori-icons';
export { SatIconModule } from './icon.module';
export { provideSatoriIcons } from './providers/provide-satori-icons';
