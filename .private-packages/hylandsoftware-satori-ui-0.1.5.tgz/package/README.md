# Satori UI

- [What is Satori UI](docs/what-is-satori-ui.mdx)
- [Getting Started](docs/getting-started.mdx)
- Configuring SatoriUI
  - [Translation Provider](docs/configuration/translation-provider.mdx)
- [Version matrix](docs/version-compatibility-matrix.mdx)
