export { SatBreadcrumbsComponent, type SatBreadcrumbsItem } from './breadcrumbs.component';
export { SatBreadcrumbsModule } from './module';
