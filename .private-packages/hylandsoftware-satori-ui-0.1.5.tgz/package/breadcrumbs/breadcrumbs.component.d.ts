import { OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Data representing a single breadcrumb item.
 *
 * The last breadcrumb item can optionally not be a link,
 * to represent the current page. In that case, the `href` property should be omitted.
 */
export interface SatBreadcrumbsItem {
    /** The label to display in the Breadcrumbs item. */
    label: string;
    /** The URL to navigate to when the item is clicked. Optional for the last item. */
    href?: string;
}
/**
 * The Breadcrumbs component displays a navigation path, allowing users to easily navigate back to previous pages.
 * It supports truncation of items into a menu when the available space is insufficient.
 */
export declare class SatBreadcrumbsComponent implements OnDestroy {
    /**
     * Input signal for the breadcrumb items.
     */
    readonly items: import("@angular/core").InputSignal<SatBreadcrumbsItem[]>;
    /**
     * Signal for the items currently displayed in the breadcrumbs.
     * @internal
     */
    readonly visibleItems: import("@angular/core").WritableSignal<SatBreadcrumbsItem[]>;
    /**
     * Computed signal for the hidden items (collapsed into the menu).
     * @internal
     */
    readonly hiddenItems: import("@angular/core").Signal<SatBreadcrumbsItem[]>;
    private readonly _element;
    /**
     * Last registered width of the component
     */
    private width;
    /**
     * To determine if the last item in the breadcrumbs is the current page.
     * @internal
     */
    readonly hasCurrentPage: import("@angular/core").Signal<boolean>;
    private truncationTimeout?;
    private resizeTimeout?;
    private readonly resizeObserver;
    constructor();
    ngOnDestroy(): void;
    /**
     * The resize event can fire frequently during user interactions, so we debounce it to trigger
     * only after resizing or layout changes have stopped. This prevents flickering effects during resizing.
     */
    private debounceResize;
    /**
     * Recursively manages breadcrumb item overflow.
     * Uses a 0ms timeout to run immediately after the next render cycle,
     * ensuring the component measures its size accurately for each recursion step.
     */
    private debounceTruncation;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatBreadcrumbsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatBreadcrumbsComponent, "sat-breadcrumbs", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
