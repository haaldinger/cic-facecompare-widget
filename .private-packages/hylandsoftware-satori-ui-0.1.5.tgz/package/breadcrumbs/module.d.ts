import * as i0 from "@angular/core";
import * as i1 from "./breadcrumbs.component";
export declare class SatBreadcrumbsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatBreadcrumbsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<SatBreadcrumbsModule, never, [typeof i1.SatBreadcrumbsComponent], [typeof i1.SatBreadcrumbsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<SatBreadcrumbsModule>;
}
