import { HttpClient } from '@angular/common/http';
import { TranslateLoader, TranslationObject } from '@ngx-translate/core';
import { Observable } from 'rxjs';
export declare class MultiTranslateHttpLoader implements TranslateLoader {
    private http;
    private prefix;
    private suffix;
    private translationPaths;
    constructor(http: HttpClient, prefix: string, suffix: string, translationPaths: string[]);
    getTranslation(lang: string): Observable<TranslationObject>;
    private getTranslationFile;
    private buildFileUrl;
    private getBaseLang;
}
