import { EnvironmentProviders } from '@angular/core';
export interface SatoriUILanguageConfig {
    fallbackLang?: string;
    /** @deprecated Use `fallbackLang` instead. */
    default?: string;
    /**
     * Optional configuration for language prefixes and suffixes.
     * See: https://ngx-translate.org/getting-started/translation-files/#loading-translations-dynamically
     */
    settings?: {
        prefix?: string;
        suffix?: string;
    };
}
/**
 * Provides the default translation feature for the Satori UI library.
 * This sets up the translation loader to fetch translation files from the `./i18n/` directory
 * @param languageConfig Configuration for the default language of the application.
 */
export declare function provideAndConfigureSatoriUITranslations(languageConfig: SatoriUILanguageConfig): EnvironmentProviders;
export declare function provideTranslations(translationPaths?: string[]): EnvironmentProviders;
