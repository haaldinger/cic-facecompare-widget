export { provideAndConfigureSatoriUITranslations, provideTranslations, type SatoriUILanguageConfig, } from '../translations/provide-satori-ui-translations';
