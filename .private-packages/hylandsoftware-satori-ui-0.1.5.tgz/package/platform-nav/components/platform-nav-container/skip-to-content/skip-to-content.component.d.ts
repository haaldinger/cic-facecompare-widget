import * as i0 from "@angular/core";
/**
 * @internal
 * This component provides a "Skip to main content" link that allows users to bypass navigation links and go directly to the main content of the page.
 * It is particularly useful for improving accessibility for keyboard and screen reader users.
 */
export declare class SatSkipToContentComponent {
    /** @internal */
    readonly visible: import("@angular/core").WritableSignal<boolean>;
    /** @internal */
    display(): void;
    /** @internal */
    hide(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatSkipToContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatSkipToContentComponent, "sat-skip-to-content", never, {}, {}, never, never, true, never>;
}
