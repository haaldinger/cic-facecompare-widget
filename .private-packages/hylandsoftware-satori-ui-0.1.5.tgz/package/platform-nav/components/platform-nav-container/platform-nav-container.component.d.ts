import { SatPlatformNavStateService } from '../../services/platform-nav-state.service';
import * as i0 from "@angular/core";
/**
 * This component defines the structural layout for vertical navigation-based applications. It enhances accessibility by supporting a "Skip to Content" feature and allows for flexible content projection. This enables developers to inject key layout elements—such as navigation sidebars and main content areas—while maintaining a clean and organized layout hierarchy.
 *
 * Key features:
 * - Displays a `sat-skip-to-content` element to allow users to quickly skip to the main content for better accessibility.
 * - Projects a `sat-platform-nav` element, typically used for the sidebar or navigation menu.
 * - Projects a `sat-platform-nav-main-content` element, typically used for the application’s main content area.
 * - Defines the main content container with `id="main-content"`, which serves as the target for skip-to-content navigation.
 *
 * @example
 * <sat-platform-nav-container>
 *   <sat-platform-nav>
 *     …
 *   </sat-platform-nav>
 *   <sat-platform-nav-main-content></sat-platform-nav-main-content>
 * </sat-platform-nav-container>
 *
 */
export declare class SatPlatformNavContainerComponent {
    /** @internal */
    readonly service: SatPlatformNavStateService;
    /** @internal */
    closePlatformNav(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavContainerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavContainerComponent, "sat-platform-nav-container", never, {}, {}, never, ["sat-platform-nav", "sat-platform-nav-main-content"], true, never>;
}
