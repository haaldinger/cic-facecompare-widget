import { SatNavigationItem } from '../../types/platform-nav-item.type';
import * as i0 from "@angular/core";
/**
 * The `SatPlatformNavAvatarComponent` displays an avatar in the platform navigation.
 * It supports rendering an icon, image, or initials based on the provided navigation item.
 *
 * - If the navigation item has an `icon`, it renders a Material icon.
 * - If the navigation item has an `image`, it renders the image inside a custom app icon component.
 * - Otherwise, it renders the initials derived from the navigation item's label.
 *
 * @deprecated This component supports a deprecated usage pattern where content is projected via <ng-content>.
 *
 * Prefer passing a `SatNavigationItem` via the `item` input for avatar rendering.
 */
export declare class SatPlatformNavAvatarComponent {
    /**
     * The navigation item associated with this avatar.
     */
    readonly item: import("@angular/core").InputSignal<SatNavigationItem | undefined>;
    /** @internal */
    readonly icon: import("@angular/core").Signal<string | null>;
    /** @internal */
    readonly image: import("@angular/core").Signal<string | null>;
    private itemIsSatNavigationItemWithIcon;
    private itemIsSatNavigationItemWithImage;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavAvatarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavAvatarComponent, "sat-platform-nav-avatar", never, { "item": { "alias": "item"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
