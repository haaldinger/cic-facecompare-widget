import { SatPlatformNavStateService } from '../../services/platform-nav-state.service';
import * as i0 from "@angular/core";
/**
 * This component displays a clickable user identity block, such as a name along with an avatar that can have initials or user profile image in the platform sidebar’s user section. It also has a responsive behavior based on the collapsed state of the sidebar.
 *
 * Key features:
 * - Typically used to show user info like names, emails, or avatar initials.
 * - Styled for sidebar placement within sat-platform-nav-user.
 */
export declare class SatPlatformNavUserProfileComponent {
    /** @internal */
    readonly service: SatPlatformNavStateService;
    /**
     * @internal
     * The text content of the profile name, used for tooltip and fallback initials.
     */
    readonly profileNameText: import("@angular/core").WritableSignal<string | undefined>;
    /** @internal */
    profileNameChanged(event: MutationRecord[]): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavUserProfileComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavUserProfileComponent, "sat-platform-nav-user-profile", never, {}, {}, never, ["mat-icon, img", "*"], true, never>;
}
