import * as i0 from "@angular/core";
/**
 * This directive is applied to an Angular Material mat-menu to define a custom-styled user menu that appears when the user profile is clicked.
 *
 * Key features:
 * - Defines the dropdown menu that appears when the profile is clicked.
 * - Enhances mat-menu to match the Platform Nav’s user interface.
 * - Supports standard Angular Material menu behavior.
 * - This directive can apply specific styles, positioning, or behavior consistent with the platform’s design.
 */
export declare class SatPlatformNavUserMenuDirective {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavUserMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatPlatformNavUserMenuDirective, "[satPlatformNavUserMenu]", ["satPlatformNavUserMenu"], {}, {}, never, never, true, never>;
}
