import * as i0 from "@angular/core";
/**
 * This component is a structural wrapper used to project and style app-icon content within a navigation list item. This is an internal component that is not intended for direct use outside of the platform navigation context.
 *
 * Key features:
 * - Is typically used inside a nav list item to display a user’s avatar or an associated icon.
 * - Relies entirely on content projection for flexibility.
 *
 * @internal
 */
export declare class SatPlatformNavAppIconComponent {
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavAppIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavAppIconComponent, "sat-platform-nav-app-icon", never, {}, {}, never, ["*"], true, never>;
}
