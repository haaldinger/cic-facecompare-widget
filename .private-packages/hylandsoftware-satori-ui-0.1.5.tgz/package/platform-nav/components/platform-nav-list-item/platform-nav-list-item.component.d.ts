import { SatPlatformNavStateService } from '../../services/platform-nav-state.service';
import * as i0 from "@angular/core";
/**
 * This element represents an interactive item within the `sat-platform-nav` navigation panel. It supports icons, dynamic avatar generation, active state styling, and responsive behavior based on the collapsed state of the sidebar.
 *
 * The `SatPlatformNavListItemComponent` is designed to display a single item in the platform navigation.
 *
 * Key features:
 * - Accepts a projected mat-icon for visual representation of the item.
 * - Automatically generates a fallback avatar (initials-based) if no icon is present, using the SatPlatformNavListItemInitialsPipe applied to the item’s label.
 * - Hides the text label when the navigation panel is collapsed, using SatPlatformNavService.
 * - Allows keyboard accessibility supporting navigation via keyboard.
 *
 * @deprecated This component supports a deprecated usage pattern where content is projected for displaying the icon or avatar.
 * The use of mat-icon is deprecated and will be removed in future versions. Prefer using `<sat-platform-nav-avatar>` with the `item` input for avatar rendering.
 *
 * Deprecated usage: Icon render via mat-icon is deprecated.
 */
export declare class SatPlatformNavListItemComponent {
    /** The URL to navigate to when the item is clicked. */
    readonly url: import("@angular/core").InputSignal<string | undefined>;
    /**
     * Determines whether the list item should be rendered in an active/selected state.
     */
    readonly active: import("@angular/core").InputSignal<boolean>;
    /**
     * @internal
     * The text content of the label, used for tooltip and fallback initials.
     */
    readonly labelText: import("@angular/core").WritableSignal<string | undefined>;
    /** @internal */
    readonly service: SatPlatformNavStateService;
    private readonly tooltipService;
    private readonly tooltip;
    private readonly tooltipDelay;
    private tooltipTimer;
    /** @internal */
    onMouseEnter(): void;
    /** @internal */
    onMouseLeave(): void;
    /** @internal */
    labelChanged(event: MutationRecord[]): void;
    private hidePreviousTooltip;
    private showCurrentTooltip;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavListItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavListItemComponent, "sat-platform-nav-list-item", never, { "url": { "alias": "url"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; }, {}, never, ["mat-icon, sat-platform-nav-avatar", "*"], true, never>;
}
