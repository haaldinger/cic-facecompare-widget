import * as i0 from "@angular/core";
/** @internal */
export declare class SatPlatformNavEnvironmentSwitcherItemComponent {
    /**
     * The value of the switcher item, which is used to identify the selected environment.
     */
    readonly value: import("@angular/core").InputSignal<string>;
    /**
     * Denotes whether the switcher item is currently active/selected.
     */
    readonly active: import("@angular/core").InputSignal<boolean>;
    /**
     * Denotes whether the switcher item is disabled.
     */
    readonly disabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    private readonly _element;
    /**
     * Event to notify parent when this item is clicked
     */
    readonly selectionChange: import("@angular/core").OutputEmitterRef<string>;
    /** @internal */
    onSelectionChange(): void;
    /**
     * @internal
     * Handles keyboard interaction for accessibility:
     * Only responds to Enter and Space keys to select the option.
     */
    handleKeydown(event: KeyboardEvent): void;
    /** Gets the host DOM element. */
    _getHostElement(): HTMLElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavEnvironmentSwitcherItemComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavEnvironmentSwitcherItemComponent, "sat-platform-nav-switcher-item", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; }, never, ["*"], true, never>;
}
