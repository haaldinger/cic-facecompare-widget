import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * This pipe transforms a name or label into a set of uppercase initials, typically used to display fallback text inside avatar components. It helps maintain a consistent user experience when profile images are not available.
 *
 * > **ℹ️ Note -**
 * > We strongly recommend using the `satPlatformNavInitials` pipe to generate initials for avatars.
 * > This ensures consistent formatting and visual alignment across the navigation item and user profile areas.
 *
 * ```html
 * <sat-platform-nav-avatar>
 *   {{ user.name | satPlatformNavInitials }}
 * </sat-platform-nav-avatar>
 * ```
 *
 * **How It Works**
 *
 * - Extracts the first letter of each word (default: up to 2 words).
 * - For single-word names, returns the first two characters.
 * - Trims whitespace and safely handles empty or invalid strings.
 *
 * **Example Outputs**
 *
 * | Input          | Output |
 * | -------------- | ------ |
 * | John Doe       | JD     |
 * | Mary Ann Smith | MA     |
 * | " "            | ""     |
 *
 * **Optional Parameter**
 *
 * You can pass an optional maxWords parameter to control how many words are considered -
 *
 * ```html
 * <sat-platform-nav-avatar>
 *   {{ 'John David Smith' | satPlatformNavInitials: 1 }} <!-- Output: J -->
 * </sat-platform-nav-avatar>
 * ```
 */
export declare class SatPlatformNavInitialsPipe implements PipeTransform {
    private readonly _maxWords;
    /**
     * Transforms a name string into initials by taking the first letter
     * of each word (up to the first two words).
     *
     * @param value The name to transform into initials
     * @param maxWords Optional parameter to specify maximum number of words to use (default: 2)
     * @returns The generated initials as uppercase letters
     */
    transform(value: string, maxWords?: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavInitialsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SatPlatformNavInitialsPipe, "satPlatformNavInitials", true>;
}
