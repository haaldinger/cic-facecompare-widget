import { MatTooltip } from '@angular/material/tooltip';
import * as i0 from "@angular/core";
/** @internal */
export declare class SatPlatformNavTooltipService {
    private readonly _tooltipShownFirst;
    /**
     * Whether the tooltip has already been shown.
     * Useful for showing tooltips with a delay only the first time.
     */
    readonly tooltipShownFirst: import("@angular/core").Signal<boolean>;
    /**
     * Currently active tooltip instance.
     * Used to ensure only one tooltip is visible at a time.
     * When a new tooltip is triggered (via focus or hover), the previous one is hidden using this reference.
     */
    activateTooltip: MatTooltip | null;
    /**
     * Marks that the tooltip has been shown at least once.
     * Call this after showing your tooltip so it doesn't repeat the delay.
     *
     * @param value A boolean indicating whether the tooltip has already been shown.
     */
    updateTooltipShownFirst(value: boolean): void;
    /**
     * Updates the currently active tooltip.
     * Call this whenever a tooltip is shown or hidden so the service can manage exclusive visibility.
     *
     * @param tooltip The tooltip instance to set as active, or null to clear it.
     */
    updateActiveTooltip(tooltip: MatTooltip | null): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavTooltipService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<SatPlatformNavTooltipService>;
}
