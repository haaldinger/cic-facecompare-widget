import { SatPlatformNavStateService } from './services/platform-nav-state.service';
import * as i0 from "@angular/core";
/**
 * This component renders the vertical navigation menu, used as a sidebar. It supports static and dynamic nav items. Designed to work inside sat-platform-nav-container, it helps create a well-structured layout for navigation items and an action button for accessing user profile details. It includes control for toggling the collapsed state of the navigation panel, a title that conditionally renders based on the state.
 *
 * Key features:
 * - Dynamically toggles between expanded and collapsed states when user clicks on the h_glyph icon.
 * - Displays the "Content Innovation Cloud" title only when the panel is expanded.
 * - Includes an action button intended to open a popup displaying user profile details.
 */
export declare class SatPlatformNavComponent {
    /**
     * @internal
     */
    readonly service: SatPlatformNavStateService;
    /**
     * @internal
     */
    private readonly tooltipService;
    /**
     * Activates the neutral look of the platform navigation dedicated to administration context.
     */
    readonly neutralTheme: import("@angular/core").InputSignal<boolean>;
    /**
     * Clears the active tooltip on mouse leave.
     * Resets the tooltipShownFirst flag, hides and disables the current activated tooltip.
     * @internal
     */
    onMouseLeave(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatPlatformNavComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatPlatformNavComponent, "sat-platform-nav", never, { "neutralTheme": { "alias": "neutralTheme"; "required": false; "isSignal": true; }; }, {}, never, ["sat-platform-nav-switcher", "*", "sat-platform-nav-user"], true, never>;
}
