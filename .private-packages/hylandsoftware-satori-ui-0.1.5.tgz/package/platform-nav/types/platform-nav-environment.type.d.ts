/**
 * This type defines the structure of an environment used in the environment switcher component. It includes properties for the environment’s name, value, and whether the environment should be disabled.
 */
export interface SatPlatformNavEnvironmentType {
    /**
     * The value associated with the environment.
     * @required
     */
    value: string;
    /**
     * The name of the environment.
     * @required
     */
    label: string;
    /**
     * Indicates whether the environment option is disabled.
     */
    disabled?: boolean;
}
