/**
 * The position of the tooltip along the X axis.
 */
export type RichTooltipPositionX = 'before' | 'after';
/**
 * The position of the tooltip along the Y axis.
 */
export type RichTooltipPositionY = 'above' | 'below';
/**
 * The scroll strategy of the tooltip.
 */
export type RichTooltipScrollStrategy = 'noop' | 'close' | 'block' | 'reposition';
/**
 * The behavior of the tooltip.
 */
export type RichTooltipBehavior = 'transient' | 'persistent';
/**
 * The alignment of the tooltip actions.
 */
export type RichTooltipActionAlignment = 'start' | 'center' | 'end';
/**
 * The reason for closing the tooltip.
 */
export type RichTooltipCloseReason = void | 'click' | 'keydown' | 'focusout';
/**
 * The ARIA role of the tooltip container.
 * Automatically derived from behavior:
 * - 'persistent' behavior \u2192 'dialog' role (interactive, click-triggered)
 * - 'transient' behavior \u2192 'tooltip' role (informational, hover-triggered)
 */
export type RichTooltipRole = 'dialog' | 'tooltip';
