import * as i0 from "@angular/core";
/**
 * Directive for closing the rich tooltip.
 * This directive listens for click events and triggers the close action on the tooltip.
 */
export declare class SatRichTooltipCloseDirective {
    private readonly tooltip;
    /**
     * Listens for click events to close the tooltip.
     */
    onClose(event: Event): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipCloseDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatRichTooltipCloseDirective, "[sat-rich-tooltip-close], [satRichTooltipClose]", ["satRichTooltipClose"], {}, {}, never, never, true, never>;
}
