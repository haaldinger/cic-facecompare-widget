import { Direction } from '@angular/cdk/bidi';
import { OverlayConfig, OverlayRef, ScrollStrategy } from '@angular/cdk/overlay';
import { RichTooltipScrollStrategy } from '../rich-tooltip-types';
import { SatRichTooltipComponent } from '../rich-tooltip.component';
import * as i0 from "@angular/core";
/** @internal */
export declare class RichTooltipOverlayService {
    private readonly overlay;
    private readonly directionality;
    /** @ignore */
    createOverlay(tooltip: SatRichTooltipComponent): OverlayRef;
    /** @ignore */
    get dir(): Direction;
    /** @ignore */
    getOverlayConfig(tooltip: SatRichTooltipComponent): OverlayConfig;
    /** @ignore */
    getOverlayScrollStrategy(strategy: RichTooltipScrollStrategy): ScrollStrategy;
    static ɵfac: i0.ɵɵFactoryDeclaration<RichTooltipOverlayService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RichTooltipOverlayService>;
}
