import { FlexibleConnectedPositionStrategy } from '@angular/cdk/overlay';
import { ElementRef } from '@angular/core';
import { SatRichTooltipComponent } from '../rich-tooltip.component';
import * as i0 from "@angular/core";
/** @internal */
export declare class RichTooltipPositionService {
    private readonly overlay;
    /**
     * This method builds the position strategy for the overlay, so the richTooltip is properly connected
     * to the trigger.
     * @ignore
     * @returns ConnectedPositionStrategy
     */
    getPosition(tooltip: SatRichTooltipComponent, elementRef: ElementRef): FlexibleConnectedPositionStrategy;
    static ɵfac: i0.ɵɵFactoryDeclaration<RichTooltipPositionService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RichTooltipPositionService>;
}
