import { ElementRef } from '@angular/core';
import { RichTooltipBehavior, RichTooltipPositionX, RichTooltipPositionY, RichTooltipScrollStrategy } from './rich-tooltip-types';
/**
 * Configuration properties for the rich tooltip.
 */
export interface SatRichTooltipConfig {
    /** The horizontal position of the tooltip. */
    positionX: RichTooltipPositionX;
    /** The vertical position of the tooltip. */
    positionY: RichTooltipPositionY;
    /** The behavior of the tooltip. */
    behavior: RichTooltipBehavior;
    /** The scroll strategy of the tooltip. */
    scrollStrategy: RichTooltipScrollStrategy;
    /** The delay before showing the tooltip. */
    showDelay: number;
    /** The delay before hiding the tooltip. */
    hideDelay: number;
    /** Whether the tooltip should overlap the trigger element. */
    overlapTrigger: boolean;
    /** The offset of the tooltip from the target element on the X axis. */
    targetOffsetX: number;
    /** The offset of the tooltip from the target element on the Y axis. */
    targetOffsetY: number;
    /** Whether the tooltip should close on click. */
    closeOnClick: boolean;
    /** Whether the tooltip animation is disabled. */
    disableAnimation: boolean;
    /** Whether the tooltip should trap focus. */
    focusTrapEnabled: boolean;
    /** Whether the tooltip should automatically capture focus. */
    focusTrapAutoCaptureEnabled: boolean;
}
/** @internal */
export interface SatRichTooltipTarget {
    _elementRef: ElementRef;
}
