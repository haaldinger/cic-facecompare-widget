import { SatRichTooltipComponent } from '../rich-tooltip.component';
import * as i0 from "@angular/core";
/**
 * Component for rendering the content of the rich tooltip.
 */
export declare class SatRichTooltipContentComponent {
    protected readonly tooltip: SatRichTooltipComponent;
    /** @deprecated This element is not focusable and does not need an aria-label. */
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatRichTooltipContentComponent, "sat-rich-tooltip-content", never, { "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
