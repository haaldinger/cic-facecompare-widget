import { RichTooltipActionAlignment, RichTooltipBehavior } from '../../rich-tooltip-types';
import * as i0 from "@angular/core";
/**
 * Component for rendering action buttons in the rich tooltip.
 * These action buttons can be aligned to the start, center, or end of the rich tooltip.
 * By default, there will be a close button if the tooltip behaviour is set to be persistent.
 */
export declare class SatRichTooltipActionsComponent {
    private readonly tooltip;
    private _transientWarningLogged;
    /**
     * Alignment of the actions
     * @default 'start'
     */
    readonly align: import("@angular/core").InputSignal<RichTooltipActionAlignment>;
    /**
     * Whether the close feature should be required
     * @deprecated The close feature is required by default for all persistent tooltips,
     * and must not be used in transient tooltips. This input will be removed in a future
     * release. To ensure accessibility, close buttons are always included in persistent
     * tooltips, and must not be included in transient tooltips.
     */
    readonly requireCloseFeature: import("@angular/core").InputSignal<boolean>;
    constructor();
    /** @ignore */
    get tooltipBehaviour(): RichTooltipBehavior;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatRichTooltipActionsComponent, "sat-rich-tooltip-actions", never, { "align": { "alias": "align"; "required": false; "isSignal": true; }; "requireCloseFeature": { "alias": "requireCloseFeature"; "required": false; "isSignal": true; }; }, {}, never, ["[button, a]"], true, never>;
}
