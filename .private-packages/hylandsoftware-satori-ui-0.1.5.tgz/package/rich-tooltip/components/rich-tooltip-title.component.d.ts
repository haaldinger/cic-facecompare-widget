import { SatRichTooltipComponent } from '../rich-tooltip.component';
import * as i0 from "@angular/core";
/**
 * Component for rendering the title of the rich tooltip.
 */
export declare class SatRichTooltipTitleComponent {
    private readonly elementRef;
    protected readonly tooltip: SatRichTooltipComponent;
    /**
     * aria-label for the rich tooltip title.
     * @default ''
     */
    readonly ariaLabel: import("@angular/core").InputSignal<string>;
    /** @ignore */
    get getAriaLabel(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipTitleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatRichTooltipTitleComponent, "sat-rich-tooltip-title", never, { "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}
