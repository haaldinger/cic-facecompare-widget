import { ElementRef, OnDestroy, TemplateRef } from '@angular/core';
import { RichTooltipBehavior, RichTooltipCloseReason, RichTooltipPositionX, RichTooltipPositionY, RichTooltipRole, RichTooltipScrollStrategy } from './rich-tooltip-types';
import * as i0 from "@angular/core";
/**
 * The `SatRichTooltipComponent` is used to display rich tooltips with various configurations.
 * It supports different positions, behaviors, and scroll strategies etc..
 */
export declare class SatRichTooltipComponent implements OnDestroy {
    /** Settings for richTooltip, view setters and getters for more detail */
    private readonly _positionX;
    private readonly _positionY;
    private readonly _behavior;
    private readonly _scrollStrategy;
    private readonly _showDelay;
    private readonly _hideDelay;
    private readonly _overlapTrigger;
    private readonly _disableAnimation;
    private readonly _targetOffsetX;
    private readonly _targetOffsetY;
    private readonly _closeOnClick;
    private readonly _focusTrapEnabled;
    private readonly _focusTrapAutoCaptureEnabled;
    private readonly _uniqueId;
    private readonly _titleUniqueId;
    private readonly _contentUniqueId;
    /** Config object to be passed into the richTooltip's ngClass */
    classList: {
        [key: string]: boolean;
    };
    /** Closing disabled on richTooltip */
    closeDisabled: boolean;
    /** unique id for the rich tooltip panel. */
    readonly id: import("@angular/core").InputSignal<string>;
    /** aria-label for the rich tooltip panel. */
    readonly ariaLabel: import("@angular/core").InputSignal<string | null>;
    /** aria-labelledby for the rich tooltip panel. This needs to be same with the id for the title element */
    readonly ariaLabelledby: import("@angular/core").InputSignal<string>;
    /** aria-describedby for the rich tooltip panel. This needs to be same with the id for the content element. */
    readonly ariaDescribedby: import("@angular/core").InputSignal<string>;
    /**
     * The ARIA role for the tooltip container.
     * @deprecated The role is now automatically determined by the `behavior` input.
     * Use `behavior="persistent"` for dialog role or `behavior="transient"` for tooltip role.
     * This input will be removed in a future version.
     */
    readonly role: import("@angular/core").InputSignal<RichTooltipRole | undefined>;
    private _roleWarningLogged;
    /**
     * The resolved ARIA role for the tooltip container.
     * Derived from behavior: 'persistent' → 'dialog', 'transient' → 'tooltip'.
     * @internal
     */
    readonly resolvedRole: import("@angular/core").Signal<"dialog" | "tooltip">;
    /**
     * Whether the tooltip has persistent behavior (interactive, click-triggered).
     * @internal
     */
    readonly isPersistent: import("@angular/core").Signal<boolean>;
    /**
     * Position of the richTooltip in the X axis.
     * @default after
     */
    readonly positionX: import("@angular/core").InputSignal<RichTooltipPositionX>;
    /**
     * Validated position of the richTooltip in the X axis.
     * Throws an error if the position is invalid.
     * @ignore
     */
    readonly validatedPositionX: import("@angular/core").Signal<RichTooltipPositionX>;
    /**
     * Position of the richTooltip in the Y axis.
     * @default below
     */
    readonly positionY: import("@angular/core").InputSignal<RichTooltipPositionY>;
    /**
     * Validated position of the richTooltip in the Y axis.
     * Throws an error if the position is invalid.
     * @ignore
     */
    readonly validatedPositionY: import("@angular/core").Signal<RichTooltipPositionY>;
    /**
     * RichTooltip behavior type
     * @default transient
     */
    readonly behavior: import("@angular/core").InputSignal<RichTooltipBehavior>;
    /**
     * RichTooltip scroll strategy
     * @default reposition
     */
    readonly scrollStrategy: import("@angular/core").InputSignal<RichTooltipScrollStrategy>;
    /**
     * RichTooltip enter delay (milliseconds)
     * @default 200
     */
    readonly showDelay: import("@angular/core").InputSignalWithTransform<number, unknown>;
    /**
     * RichTooltip leave delay (milliseconds)
     * @default 1500
     */
    readonly hideDelay: import("@angular/core").InputSignalWithTransform<number, unknown>;
    /**
     * RichTooltip overlap trigger
     * @default false
     */
    readonly overlapTrigger: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /**
     * RichTooltip horizontal target offset (px)
     * @default 0
     */
    readonly targetOffsetX: import("@angular/core").InputSignalWithTransform<number, unknown>;
    /**
     * RichTooltip vertical target offset (px)
     * @default 20
     */
    readonly targetOffsetY: import("@angular/core").InputSignalWithTransform<number, unknown>;
    /**
     * RichTooltip container close on click
     * @default false
     */
    readonly closeOnClick: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /**
     * Disable animations of richTooltip and all child elements
     * @default false
     */
    readonly disableAnimation: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /**
     * Rich Tooltip focus trap using cdkTrapFocus
     * @default true
     */
    readonly focusTrapEnabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /**
     * Rich Tooltip focus trap auto capture using cdkTrapFocusAutoCapture
     * @default true
     */
    readonly focusTrapAutoCaptureEnabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /**
     * Event emitted when the richTooltip is closed.
     */
    readonly closed: import("@angular/core").OutputEmitterRef<RichTooltipCloseReason>;
    /**
     * Event emitted when the richTooltip is closed.
     *
     * @deprecated Switch to `closed` instead. Will be removed in future version.
     */
    readonly close: import("@angular/core").OutputEmitterRef<RichTooltipCloseReason>;
    /** @ignore */
    readonly templateRef: import("@angular/core").Signal<TemplateRef<ElementRef<any>> | undefined>;
    /** @ignore */
    readonly monitoredEl: import("@angular/core").Signal<ElementRef<HTMLElement> | undefined>;
    constructor();
    /**
     * Handle a keyboard event from the richTooltip, delegating to the appropriate action.
     * @internal
     */
    handleKeydown(event: KeyboardEvent): void;
    /**
     * This emits a close event to which the trigger is subscribed. When emitted, the
     * trigger will close the richTooltip.
     * @internal
     */
    emitCloseEvent(reason: RichTooltipCloseReason): void;
    /**
     * Close richTooltip on click if closeOnClick is true
     * @internal
     */
    onClick(): void;
    /**
     * Prevents closing the Rich Tooltip when the user moves their pointer from the trigger element to the tooltip.
     * @internal
     */
    onMouseover(): void;
    /**
     * Enables closing of the Rich Tooltip when the user moves their pointer away from the Rich Tooltip element.
     * @internal
     */
    onMouseout(): void;
    /** @ignore */
    doNothing(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatRichTooltipComponent, "sat-rich-tooltip", ["satRichTooltip"], { "id": { "alias": "id"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "aria-label"; "required": false; "isSignal": true; }; "ariaLabelledby": { "alias": "aria-labelledby"; "required": false; "isSignal": true; }; "ariaDescribedby": { "alias": "aria-describedby"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "positionX": { "alias": "positionX"; "required": false; "isSignal": true; }; "positionY": { "alias": "positionY"; "required": false; "isSignal": true; }; "behavior": { "alias": "behavior"; "required": false; "isSignal": true; }; "scrollStrategy": { "alias": "scrollStrategy"; "required": false; "isSignal": true; }; "showDelay": { "alias": "showDelay"; "required": false; "isSignal": true; }; "hideDelay": { "alias": "hideDelay"; "required": false; "isSignal": true; }; "overlapTrigger": { "alias": "overlapTrigger"; "required": false; "isSignal": true; }; "targetOffsetX": { "alias": "targetOffsetX"; "required": false; "isSignal": true; }; "targetOffsetY": { "alias": "targetOffsetY"; "required": false; "isSignal": true; }; "closeOnClick": { "alias": "closeOnClick"; "required": false; "isSignal": true; }; "disableAnimation": { "alias": "disableAnimation"; "required": false; "isSignal": true; }; "focusTrapEnabled": { "alias": "focusTrapEnabled"; "required": false; "isSignal": true; }; "focusTrapAutoCaptureEnabled": { "alias": "focusTrapAutoCaptureEnabled"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "close": "close"; }, never, ["sat-rich-tooltip-title", "sat-rich-tooltip-content", "sat-rich-tooltip-actions"], true, never>;
}
