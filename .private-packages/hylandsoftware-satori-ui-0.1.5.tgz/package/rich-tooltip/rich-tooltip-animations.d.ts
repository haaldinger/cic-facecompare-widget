import { AnimationTriggerMetadata } from '@angular/animations';
export declare const transformRichTooltip: AnimationTriggerMetadata;
