import { AfterViewInit, OnDestroy } from '@angular/core';
import { SatRichTooltipComponent } from './rich-tooltip.component';
import * as i0 from "@angular/core";
/**
 * Directive for triggering the rich tooltip.
 * This directive listens for various events (click, mouseenter, focus, mouseleave) to control the opening and closing of the tooltip.
 */
export declare class SatRichTooltipTriggerDirective implements AfterViewInit, OnDestroy {
    private readonly elementRef;
    private readonly viewContainerRef;
    private readonly richTooltipOverlayService;
    private readonly richTooltipPositionService;
    private readonly changeDetectorRef;
    /** Whether the rich tooltip is currently open. */
    readonly richTooltipOpen: import("@angular/core").WritableSignal<boolean>;
    private readonly richTooltipOpened;
    private readonly richTooltipClosed;
    private portal?;
    private overlayRef;
    private halt;
    private backdropSubscription?;
    private positionSubscription?;
    private detachmentsSubscription?;
    private mouseoverTimer?;
    private openedByMouse;
    private _previousAriaDescribedById;
    /** References the richTooltip instance that the trigger is associated with. */
    readonly tooltip: import("@angular/core").InputSignal<SatRichTooltipComponent>;
    /**
     * Computes the aria-haspopup value based on the tooltip's behavior.
     * Returns "dialog" when behavior is "persistent", otherwise undefined (no attribute) for transient tooltips.
     * @ignore
     */
    readonly ariaHaspopup: import("@angular/core").Signal<"dialog" | null>;
    /**
     * Computes the aria-expanded value based on the tooltip's behavior.
     * Returns the open state when behavior is "persistent", otherwise undefined (no attribute) for transient tooltips.
     * Per ARIA best practices, aria-expanded is appropriate for dialog triggers but not for tooltip triggers.
     * @ignore
     */
    readonly ariaExpanded: import("@angular/core").Signal<boolean | null>;
    readonly ariaDescribedby: import("@angular/core").WritableSignal<string | null>;
    /** RichTooltip won't open on trigger */
    readonly satRichTooltipDisabled: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** RichTooltip backdrop close on click */
    readonly satRichTooltipBackdropCloseOnClick: import("@angular/core").InputSignalWithTransform<boolean, unknown>;
    /** Event emitted when the associated richTooltip is opened. */
    tooltipOpened: import("@angular/core").OutputEmitterRef<void>;
    /** Event emitted when the associated richTooltip is closed. */
    tooltipClosed: import("@angular/core").OutputEmitterRef<void>;
    /** @ignore */
    ngAfterViewInit(): void;
    /**
     * Listens for click events to toggle the rich tooltip only if the behavior is persistent.
     * @param event The click event.
     */
    onClick(event: MouseEvent): void;
    /**
     * Listens for mouse enter events to open the rich tooltip only if the behavior is transient.
     * @param event The mouse enter event.
     */
    onMouseEnter(event: MouseEvent): void;
    /**
     * Listens for focus events to open the rich tooltip only if the behavior is transient.
     * @param event The focus event.
     */
    onFocus(event: FocusEvent): void;
    /**
     * Listens for focusout events to close the rich tooltip only if the behavior is transient.
     * @param event The focus event.
     */
    onFocusOut(event: FocusEvent): void;
    /** Listens for Escape key down on the trigger to close the Rich Tooltip. */
    onEscapeKey(): void;
    /**
     * Listens for mouse leave events to close the rich tooltip only if the behavior is transient.
     * @param event The mouse leave event.
     */
    onMouseLeave(event: MouseEvent): void;
    /** @ignore */
    checkTooltipToOpen(openedByMouse?: boolean): void;
    /**
     * Listens for mousedown events to track if the tooltip was opened by mouse interaction.
     * @param event The mousedown event.
     */
    handleMousedown(event: MouseEvent): void;
    /** @ignore */
    toggleRichTooltip(): void;
    /** @ignore */
    openRichTooltip(): void;
    /** @ignore */
    closeRichTooltip(): void;
    /** @ignore */
    destroyRichTooltip(): void;
    /** @ignore */
    private _syncAriaDescription;
    /** @ignore */
    private _cleanAriaDescription;
    /** @ignore */
    private focus;
    /** @ignore */
    private subscribeToBackdrop;
    /** @ignore */
    private subscribeToDetachments;
    /** @ignore */
    private initRichTooltip;
    /** @ignore */
    private resetRichTooltip;
    /** @ignore */
    private setRichTooltipOpened;
    /** @ignore */
    private setRichTooltipClosed;
    /** @ignore */
    private checkRichTooltip;
    /** @ignore */
    private cleanUpSubscriptions;
    /** @ignore */
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatRichTooltipTriggerDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SatRichTooltipTriggerDirective, "[satRichTooltipTriggerFor]", ["satRichTooltipTrigger"], { "tooltip": { "alias": "satRichTooltipTriggerFor"; "required": true; "isSignal": true; }; "satRichTooltipDisabled": { "alias": "satRichTooltipDisabled"; "required": false; "isSignal": true; }; "satRichTooltipBackdropCloseOnClick": { "alias": "satRichTooltipBackdropCloseOnClick"; "required": false; "isSignal": true; }; }, { "tooltipOpened": "tooltipOpened"; "tooltipClosed": "tooltipClosed"; }, never, never, true, never>;
}
