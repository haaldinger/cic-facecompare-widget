import { SatLogoDirection } from './direction-type';
import * as i0 from "@angular/core";
/**
 * Logo component for displaying the brand logo.
 * This component supports both horizontal and vertical layouts.
 * This component is a combination of the H mark logo and the word mark logo.
 */
export declare class SatLogoComponent {
    /**
     * The direction of the logo.
     * Can be either `horizontal` or `vertical`.
     */
    readonly direction: import("@angular/core").InputSignal<SatLogoDirection>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SatLogoComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SatLogoComponent, "sat-logo", never, { "direction": { "alias": "direction"; "required": false; "isSignal": true; }; }, {}, never, ["sat-h-mark-logo", "sat-word-mark-logo"], true, never>;
}
