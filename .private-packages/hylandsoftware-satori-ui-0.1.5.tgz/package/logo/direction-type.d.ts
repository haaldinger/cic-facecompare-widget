/**
 * Direction of the logo.
 * Based on this direction, the logo can be displayed either horizontally or vertically.
 */
export type SatLogoDirection = 'horizontal' | 'vertical';
